#include <stdio.h>
#include <string.h>
#include "stage89_stage.h"
#include "stage89_render.h"
#include "sff_stdio_adapter.h"
#define D (2UL*1024UL*1024UL)
#define P (64UL*1024UL*1024UL)
#define W (16UL*1024UL*1024UL)
static char dt[D]; static unsigned char px[P],wk[W]; static Stage89Stage st; static Stage89Runtime rt; static SffFile sf;
static int rd(const char*p,unsigned long*n){FILE*f=fopen(p,"rb");size_t g;if(!f)return 0;g=fread(dt,1,D-1,f);fclose(f);dt[g]=0;*n=(unsigned long)g+1;return 1;}
int main(int ac,char**av){unsigned long n;FILE*f;SffStdioSource ss;SffIo io;SffOpenOptions o;int i;if(ac<2)return 2;if(!rd(av[1],&n)||!stage89_stage_parse(&st,av[1],dt,n))return 3;f=fopen(st.sff_path,"rb");if(!f){printf("no sff %s\n",st.sff_path);return 4;}sff_stdio_source_init(&ss,f);sff_stdio_make_io(&ss,&io);o.tolerant=1;o.codec=0;if(sff_open_io(&sf,&io,&o)!=SFF_OK)return 5;stage89_runtime_init(&rt,&st,px,P,wk,W);stage89_runtime_decode(&rt,&sf);printf("%s bg=%d cache=%d miss=%d err=%d\n",st.display_name,st.bg_count,rt.cache_count,rt.missing_sprites,rt.decode_errors);for(i=0;i<st.bg_count;i++){Stage89Bg*b=&st.bg[i];if(b->type==STAGE89_BG_PARALLAX){Stage89SpriteCache*c=b->cache_index>=0?&rt.cache[b->cache_index]:0;printf("PAR %s spr=%d,%d cache=%d dim=%ux%u axis=%d,%d tile=%d,%d space=%d,%d mode=%d xscale=%ld,%ld width=%ld,%ld\n",b->name,b->group,b->item,b->cache_index,c?c->width:0,c?c->height:0,c?c->axis_x:0,c?c->axis_y:0,b->tile_x,b->tile_y,b->tile_spacing_x,b->tile_spacing_y,b->parallax_mode,(long)b->xscale_top,(long)b->xscale_bottom,(long)b->width_top,(long)b->width_bottom);}}
sff_close(&sf);fclose(f);return 0;}
