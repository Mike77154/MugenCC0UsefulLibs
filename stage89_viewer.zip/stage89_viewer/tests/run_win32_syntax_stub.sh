#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cc -std=gnu89 -fsyntax-only -Wall -Wextra \
  -Wno-implicit-function-declaration -Wno-int-conversion \
  -Wno-pointer-to-int-cast -Wno-int-to-pointer-cast -Wno-unused-parameter \
  -I"$ROOT/tests/win32_stub" -I"$ROOT/include" \
  -I"$ROOT/third_party/sff_fixed/sff" \
  -I"$ROOT/third_party/layer89_v0_1_0/include" \
  -I"$ROOT/third_party/actionairstage_dsl_v0_1_0/include" \
  -I"$ROOT/third_party/bgctrlstage_dsl_v0_1_0/include" \
  "$ROOT/src/stage89_win32.c"
