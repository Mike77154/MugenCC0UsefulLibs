#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stage89_stage.h"

#define PROBE_DEF_CAP (2UL * 1024UL * 1024UL)
static char g_text[PROBE_DEF_CAP];
static Stage89Stage g_stage;
static BgcRuntime g_runtime;
static BgcTargetInit g_targets[STAGE89_MAX_BG];

static int read_file(const char *path, unsigned long *out_size)
{
    FILE *fp;
    size_t got;
    fp = fopen(path, "rb");
    if (fp == (FILE*)0) return 0;
    got = fread(g_text, 1u, (size_t)(PROBE_DEF_CAP - 1UL), fp);
    if (ferror(fp)) { fclose(fp); return 0; }
    fclose(fp);
    g_text[got] = '\0';
    *out_size = (unsigned long)got + 1UL;
    return 1;
}

static void init_runtime(void)
{
    int i;
    memset(g_targets, 0, sizeof(g_targets));
    for (i = 0; i < g_stage.bg_count; ++i) {
        g_targets[i].id = g_stage.bg[i].id;
        g_targets[i].start_x = (bgc_q16)g_stage.bg[i].start_x;
        g_targets[i].start_y = (bgc_q16)g_stage.bg[i].start_y;
        g_targets[i].velocity_x = (bgc_q16)g_stage.bg[i].velocity_x;
        g_targets[i].velocity_y = (bgc_q16)g_stage.bg[i].velocity_y;
        g_targets[i].visible = g_stage.bg[i].visible;
        g_targets[i].enabled = 1;
        g_targets[i].action_no = g_stage.bg[i].action_no;
        g_targets[i].sin_x = g_stage.bg[i].sin_x;
        g_targets[i].sin_y = g_stage.bg[i].sin_y;
        g_targets[i].has_sin_x = g_stage.bg[i].has_sin_x;
        g_targets[i].has_sin_y = g_stage.bg[i].has_sin_y;
        g_targets[i].position_link = g_stage.bg[i].position_link;
    }
    bgc_runtime_init(&g_runtime, &g_stage.bgctrls, g_targets, g_stage.bg_count);
}

int main(int argc, char **argv)
{
    unsigned long size;
    unsigned long tick;
    const BgcTargetState *state;
    int i;
    int changed;
    if (argc < 3) {
        fprintf(stderr, "usage: probe_bgctrl_stage stage.def tick [tick ...]\n");
        return 2;
    }
    if (!read_file(argv[1], &size)) return 3;
    if (!stage89_stage_parse(&g_stage, argv[1], g_text, size)) return 4;
    init_runtime();
    printf("STAGE|%s|bg=%d|defs=%d|ctrls=%d\n", g_stage.display_name, g_stage.bg_count,
           g_stage.bgctrls.def_count, g_stage.bgctrls.ctrl_count);
    for (i = 2; i < argc; ++i) {
        int j;
        int shown;
        tick = (unsigned long)strtoul(argv[i], (char**)0, 10);
        if (!bgc_runtime_seek(&g_runtime, tick)) return 5;
        shown = 0;
        printf("TICK|%lu", tick);
        for (j = 0; j < g_stage.bg_count; ++j) {
            state = bgc_runtime_get_state(&g_runtime, j);
            if (state == (const BgcTargetState*)0) continue;
            changed = state->pos_x != g_targets[j].start_x || state->pos_y != g_targets[j].start_y ||
                      state->velocity_x != g_targets[j].velocity_x || state->velocity_y != g_targets[j].velocity_y ||
                      state->visible != (g_targets[j].visible != 0) || state->enabled != 1 ||
                      state->action_no != g_targets[j].action_no || state->has_sin_x != g_targets[j].has_sin_x ||
                      state->has_sin_y != g_targets[j].has_sin_y;
            if (!changed) continue;
            if (shown < 12) {
                printf("|i=%d,id=%ld,x=%ld,y=%ld,vx=%ld,vy=%ld,vis=%d,en=%d,act=%ld,at=%lu,sx=%d,sy=%d",
                    j, state->id, bgc_q16_to_int(state->computed_x), bgc_q16_to_int(state->computed_y),
                    bgc_q16_to_int(state->velocity_x), bgc_q16_to_int(state->velocity_y),
                    state->visible, state->enabled, state->action_no, state->action_tick,
                    state->has_sin_x, state->has_sin_y);
            }
            ++shown;
        }
        printf("|changed=%d\n", shown);
    }
    return 0;
}
