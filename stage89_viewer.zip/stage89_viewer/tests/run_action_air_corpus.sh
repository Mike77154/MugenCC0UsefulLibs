#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/build_host/action_air_corpus"
mkdir -p "$OUT"
"$ROOT/tests/run_host_tests.sh" >/dev/null
count=0
find "$ROOT/corpus/action_air_stages" -type f -name '*.def' | sort | while IFS= read -r def; do
  count=$((count + 1))
  name=$(basename "$def" .def | sed "s/[^A-Za-z0-9_-]/_/g")
  tick=60
  case "$name" in bugle) tick=3150 ;; esac
  "$ROOT/build_host/inspect_air_stage" "$def"
  "$ROOT/build_host/core_smoke" "$def" "$OUT/${count}_${name}.ppm" 0 0 0 0 0 "$tick"
done
