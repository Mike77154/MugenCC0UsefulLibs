#ifndef COMMDLG_H_STUB
#define COMMDLG_H_STUB
#include "windows.h"
typedef struct tagOPENFILENAMEA {
 DWORD lStructSize; HWND hwndOwner; HINSTANCE hInstance; LPCSTR lpstrFilter;
 LPSTR lpstrCustomFilter; DWORD nMaxCustFilter; DWORD nFilterIndex; LPSTR lpstrFile;
 DWORD nMaxFile; LPSTR lpstrFileTitle; DWORD nMaxFileTitle; LPCSTR lpstrInitialDir;
 LPCSTR lpstrTitle; DWORD Flags; WORD nFileOffset; WORD nFileExtension;
 LPCSTR lpstrDefExt; LPARAM lCustData; void *lpfnHook; LPCSTR lpTemplateName;
} OPENFILENAMEA;
#endif
