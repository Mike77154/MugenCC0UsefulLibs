#ifndef WINDOWS_H_STUB
#define WINDOWS_H_STUB
#include <stddef.h>
#include <string.h>

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int UINT;
typedef unsigned long DWORD;
typedef long LONG;
typedef int BOOL;
typedef unsigned long WPARAM;
typedef long LPARAM;
typedef long LRESULT;
typedef long INT_PTR;
typedef void *HANDLE;
typedef void *HWND;
typedef void *HINSTANCE;
typedef void *HICON;
typedef void *HCURSOR;
typedef void *HBRUSH;
typedef void *HFONT;
typedef void *HDC;
typedef void *HBITMAP;
typedef void *HMENU;
typedef void *HMODULE;
typedef void *LPVOID;
typedef char *LPSTR;
typedef const char *LPCSTR;
typedef LONG *PLONG;
typedef void *LPSECURITY_ATTRIBUTES;
typedef void *LPOVERLAPPED;
typedef unsigned long COLORREF;
typedef unsigned short ATOM;
typedef void (*TIMERPROC)(void);

#define CALLBACK
#define WINAPI
#define TRUE 1
#define FALSE 0
#define MAX_PATH 260
#define INVALID_HANDLE_VALUE ((HANDLE)(-1))
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)
#define INVALID_FILE_SIZE ((DWORD)-1)
#define INVALID_SET_FILE_POINTER ((DWORD)-1)
#define NO_ERROR 0
#define FILE_BEGIN 0
#define GENERIC_READ 1
#define FILE_SHARE_READ 1
#define OPEN_EXISTING 1
#define FILE_ATTRIBUTE_NORMAL 0
#define FILE_FLAG_RANDOM_ACCESS 0
#define FILE_ATTRIBUTE_DIRECTORY 0x10
#define WS_CHILD 1
#define WS_VISIBLE 2
#define WS_BORDER 4
#define WS_VSCROLL 8
#define WS_OVERLAPPEDWINDOW 16
#define WS_CLIPCHILDREN 32
#define WS_EX_ACCEPTFILES 1
#define BS_PUSHBUTTON 1
#define BS_AUTOCHECKBOX 2
#define ES_AUTOHSCROLL 1
#define ES_READONLY 2
#define LBS_NOTIFY 1
#define LBS_NOINTEGRALHEIGHT 2
#define SS_LEFT 1
#define SS_CENTERIMAGE 2
#define MB_OK 1
#define MB_ICONERROR 2
#define OFN_FILEMUSTEXIST 1
#define OFN_PATHMUSTEXIST 2
#define OFN_HIDEREADONLY 4
#define LB_GETCOUNT 1
#define LB_GETTEXT 2
#define LB_SETCURSEL 3
#define LB_RESETCONTENT 4
#define LB_ADDSTRING 5
#define LB_GETCURSEL 6
#define LB_ERR (-1)
#define LBN_DBLCLK 2
#define BM_SETCHECK 1
#define BM_GETCHECK 2
#define BST_UNCHECKED 0
#define BST_CHECKED 1
#define WM_CREATE 1
#define WM_SIZE 2
#define WM_COMMAND 3
#define WM_TIMER 4
#define WM_KEYDOWN 5
#define WM_MOUSEWHEEL 6
#define WM_LBUTTONDOWN 7
#define WM_MOUSEMOVE 8
#define WM_LBUTTONUP 9
#define WM_DROPFILES 10
#define WM_PAINT 11
#define WM_ERASEBKGND 12
#define WM_DESTROY 13
#define WM_SETFONT 14
#define VK_LEFT 1
#define VK_RIGHT 2
#define VK_UP 3
#define VK_DOWN 4
#define VK_SPACE 5
#define VK_ADD 6
#define VK_OEM_PLUS 7
#define VK_SUBTRACT 8
#define VK_OEM_MINUS 9
#define VK_OEM_COMMA 0xBC
#define VK_OEM_PERIOD 0xBE
#define CS_HREDRAW 1
#define CS_VREDRAW 2
#define IDI_APPLICATION ((LPCSTR)1)
#define IDC_ARROW ((LPCSTR)1)
#define COLOR_BTNFACE 1
#define DEFAULT_GUI_FONT 1
#define BLACK_BRUSH 2
#define CW_USEDEFAULT 0
#define BI_RGB 0
#define DIB_RGB_COLORS 0
#define SRCCOPY 0
#define COLORONCOLOR 0
#define TRANSPARENT 0
#define HGDI_ERROR ((void*)(-1))

#define LOWORD(v) ((WORD)((unsigned long)(v) & 0xFFFFUL))
#define HIWORD(v) ((WORD)(((unsigned long)(v) >> 16) & 0xFFFFUL))
#define GET_WHEEL_DELTA_WPARAM(v) ((short)HIWORD(v))
#define RGB(r,g,b) ((COLORREF)0)
#define ZeroMemory(p,n) memset((p),0,(n))

struct tagRECT { LONG left; LONG top; LONG right; LONG bottom; };
typedef struct tagRECT RECT;
typedef struct tagPAINTSTRUCT { HDC hdc; BOOL fErase; RECT rcPaint; BOOL fRestore; BOOL fIncUpdate; BYTE rgbReserved[32]; } PAINTSTRUCT;
typedef struct tagBITMAPINFOHEADER {
 DWORD biSize; LONG biWidth; LONG biHeight; WORD biPlanes; WORD biBitCount;
 DWORD biCompression; DWORD biSizeImage; LONG biXPelsPerMeter; LONG biYPelsPerMeter;
 DWORD biClrUsed; DWORD biClrImportant;
} BITMAPINFOHEADER;
typedef struct tagRGBQUAD { BYTE b; BYTE g; BYTE r; BYTE a; } RGBQUAD;
typedef struct tagBITMAPINFO { BITMAPINFOHEADER bmiHeader; RGBQUAD bmiColors[1]; } BITMAPINFO;
typedef struct tagWIN32_FIND_DATAA { DWORD dwFileAttributes; char cFileName[MAX_PATH]; } WIN32_FIND_DATAA;
typedef struct tagMSG { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; LONG pt_x; LONG pt_y; } MSG;
typedef LRESULT (CALLBACK *WNDPROC)(HWND,UINT,WPARAM,LPARAM);
typedef struct tagWNDCLASSEXA {
 UINT cbSize; UINT style; WNDPROC lpfnWndProc; int cbClsExtra; int cbWndExtra;
 HINSTANCE hInstance; HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground;
 LPCSTR lpszMenuName; LPCSTR lpszClassName; HICON hIconSm;
} WNDCLASSEXA;

#endif
