#ifndef SHELLAPI_H_STUB
#define SHELLAPI_H_STUB
#include "windows.h"
typedef HANDLE HDROP;
#endif
