#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/build_host"
mkdir -p "$OUT"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -DSTAGE89_HOST_TEST=1 \
  -I"$ROOT/include" \
  -I"$ROOT/third_party/sff_fixed/sff" \
  -I"$ROOT/third_party/sff_fixed/extras" \
  -I"$ROOT/third_party/sff_fixed/sublibs/pcx89" \
  -I"$ROOT/third_party/sff_fixed/sublibs/png89" \
  -I"$ROOT/third_party/sff_fixed/sublibs/zlib89" \
  -I"$ROOT/third_party/layer89_v0_1_0/include" \
  -I"$ROOT/third_party/actionairstage_dsl_v0_1_0/include" \
  -I"$ROOT/third_party/bgctrlstage_dsl_v0_1_0/include" \
  "$ROOT/tests/core_smoke.c" \
  "$ROOT/src/stage89_fixed.c" "$ROOT/src/stage89_stage.c" "$ROOT/src/stage89_render.c" \
  "$ROOT/third_party/layer89_v0_1_0/src/layer89.c" \
  "$ROOT/third_party/actionairstage_dsl_v0_1_0/src/actionairstage_dsl.c" \
  "$ROOT/third_party/bgctrlstage_dsl_v0_1_0/src/bgctrlstage_dsl.c" \
  "$ROOT/third_party/sff_fixed/extras/sff_stdio_adapter.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_api.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_decomp.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_endian.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_map.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_pcx.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_png.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_png_builtin.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_v1.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_v2.c" \
  "$ROOT/third_party/sff_fixed/sublibs/pcx89/pcx89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/png89/png89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/png89/png89_zlib89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/zlib89/zlib89.c" \
  -o "$OUT/core_smoke"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -DSTAGE89_HOST_TEST=1 \
  -I"$ROOT/include" \
  -I"$ROOT/third_party/actionairstage_dsl_v0_1_0/include" \
  -I"$ROOT/third_party/bgctrlstage_dsl_v0_1_0/include" \
  -I"$ROOT/third_party/sff_fixed/sff" \
  -I"$ROOT/third_party/sff_fixed/extras" \
  "$ROOT/tests/inspect_air_stage.c" \
  "$ROOT/src/stage89_fixed.c" "$ROOT/src/stage89_stage.c" \
  "$ROOT/third_party/actionairstage_dsl_v0_1_0/src/actionairstage_dsl.c" \
  "$ROOT/third_party/bgctrlstage_dsl_v0_1_0/src/bgctrlstage_dsl.c" \
  "$ROOT/third_party/sff_fixed/extras/sff_stdio_adapter.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_api.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_decomp.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_endian.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_map.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_pcx.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_png.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_png_builtin.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_v1.c" \
  "$ROOT/third_party/sff_fixed/sff/sff_v2.c" \
  "$ROOT/third_party/sff_fixed/sublibs/pcx89/pcx89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/png89/png89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/png89/png89_zlib89.c" \
  "$ROOT/third_party/sff_fixed/sublibs/zlib89/zlib89.c" \
  -I"$ROOT/third_party/sff_fixed/sublibs/pcx89" \
  -I"$ROOT/third_party/sff_fixed/sublibs/png89" \
  -I"$ROOT/third_party/sff_fixed/sublibs/zlib89" \
  -o "$OUT/inspect_air_stage"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -I"$ROOT/include" \
  -I"$ROOT/third_party/actionairstage_dsl_v0_1_0/include" \
  -I"$ROOT/third_party/bgctrlstage_dsl_v0_1_0/include" \
  "$ROOT/tests/probe_bgctrl_stage.c" \
  "$ROOT/src/stage89_fixed.c" "$ROOT/src/stage89_stage.c" \
  "$ROOT/third_party/actionairstage_dsl_v0_1_0/src/actionairstage_dsl.c" \
  "$ROOT/third_party/bgctrlstage_dsl_v0_1_0/src/bgctrlstage_dsl.c" \
  -o "$OUT/probe_bgctrl_stage"
"$OUT/core_smoke" "$ROOT/corpus/stages/kfm.def" "$OUT/kfm.ppm"
"$OUT/core_smoke" "$ROOT/corpus/stages/stage0.def" "$OUT/stage0.ppm"
"$OUT/core_smoke" "$ROOT/corpus/stages/stage0-720.def" "$OUT/stage0-720.ppm"
