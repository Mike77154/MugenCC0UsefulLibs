#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/build_host/parallax_corpus"
mkdir -p "$OUT"
"$ROOT/tests/run_host_tests.sh" >/dev/null
: > "$OUT/results.txt"
for def in "$ROOT"/corpus/user_stages/*.def; do
  name=$(basename "$def" .def)
  "$ROOT/build_host/core_smoke" "$def" "$OUT/$name.ppm" 0 0 0 0 0 | tee -a "$OUT/results.txt"
done
printf 'Parallax-only camera probes:\n' >> "$OUT/results.txt"
for name in kfm redtechbay redtechfactoryzero redtechtower; do
  def="$ROOT/corpus/user_stages/$name.def"
  for camera_x in -100 0 100; do
    "$ROOT/build_host/core_smoke" "$def" "$OUT/${name}_parallax_${camera_x}.ppm" "$camera_x" 0 0 0 1 >/dev/null
  done
  printf '  %s: camera_x=-100,0,100\n' "$name" >> "$OUT/results.txt"
done
printf 'OK: %s\n' "$OUT/results.txt"
