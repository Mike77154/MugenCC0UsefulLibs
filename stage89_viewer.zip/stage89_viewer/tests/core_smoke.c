#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "stage89_stage.h"
#include "stage89_render.h"
#include "sff_stdio_adapter.h"

#define TEST_DEF_CAP (2UL * 1024UL * 1024UL)
#define TEST_PIXEL_CAP (64UL * 1024UL * 1024UL)
#define TEST_WORK_CAP (16UL * 1024UL * 1024UL)
#define TEST_W 640
#define TEST_H 480

static char g_def[TEST_DEF_CAP];
static unsigned char g_pixels[TEST_PIXEL_CAP];
static unsigned char g_work[TEST_WORK_CAP];
static unsigned long g_frame[TEST_W * TEST_H];
static SffFile g_sff;
static Stage89Stage g_stage;
static Stage89Runtime g_runtime;
static Stage89View g_view;

static int load_file(const char *path, char *dst, unsigned long cap, unsigned long *out_size)
{
    FILE *fp;
    size_t got;
    fp = fopen(path, "rb");
    if (fp == (FILE*)0) return 0;
    got = fread(dst, 1u, (size_t)(cap - 1UL), fp);
    if (ferror(fp)) { fclose(fp); return 0; }
    dst[got] = '\0';
    fclose(fp);
    *out_size = (unsigned long)got + 1UL;
    return 1;
}

static int save_ppm(const char *path, const Stage89Surface *surface)
{
    FILE *fp;
    int x;
    int y;
    unsigned long p;
    unsigned char rgb[3];
    fp = fopen(path, "wb");
    if (fp == (FILE*)0) return 0;
    fprintf(fp, "P6\n%d %d\n255\n", surface->width, surface->height);
    for (y = 0; y < surface->height; ++y) {
        for (x = 0; x < surface->width; ++x) {
            p = surface->pixels[(unsigned long)y * (unsigned long)surface->stride + (unsigned long)x];
            rgb[0] = (unsigned char)((p >> 16) & 255UL);
            rgb[1] = (unsigned char)((p >> 8) & 255UL);
            rgb[2] = (unsigned char)(p & 255UL);
            fwrite(rgb, 1u, 3u, fp);
        }
    }
    fclose(fp);
    return 1;
}

int main(int argc, char **argv)
{
    unsigned long def_size;
    FILE *sff_fp;
    SffStdioSource source;
    SffIo io;
    SffOpenOptions options;
    Stage89Surface surface;
    int result;
    const char *out_path;

    if (argc < 2) {
        fprintf(stderr, "usage: core_smoke stage.def [out.ppm] [camera_x] [camera_y] [grid] [players] [parallax_only] [tick]\n");
        return 2;
    }
    out_path = argc >= 3 ? argv[2] : "stage89_preview.ppm";
    if (!load_file(argv[1], g_def, TEST_DEF_CAP, &def_size)) {
        fprintf(stderr, "cannot read DEF\n");
        return 3;
    }
    if (!stage89_stage_parse(&g_stage, argv[1], g_def, def_size)) {
        fprintf(stderr, "cannot parse DEF\n");
        return 4;
    }
    sff_fp = fopen(g_stage.sff_path, "rb");
    if (sff_fp == (FILE*)0) {
        fprintf(stderr, "cannot open SFF: %s\n", g_stage.sff_path);
        return 5;
    }
    if (!sff_stdio_source_init(&source, sff_fp)) { fclose(sff_fp); return 6; }
    sff_stdio_make_io(&source, &io);
    options.tolerant = 1;
    options.codec = (const SffImageCodec*)0;
    result = sff_open_io(&g_sff, &io, &options);
    if (result != SFF_OK) {
        fprintf(stderr, "SFF open error %d\n", result);
        fclose(sff_fp);
        return 7;
    }
    if (argc >= 8 && strtol(argv[7], (char**)0, 10) != 0) {
        int i;
        for (i = 0; i < g_stage.bg_count; ++i) {
            if (g_stage.bg[i].type != STAGE89_BG_PARALLAX) g_stage.bg[i].visible = 0;
        }
    }
    stage89_runtime_init(&g_runtime, &g_stage, g_pixels, TEST_PIXEL_CAP, g_work, TEST_WORK_CAP);
    result = stage89_runtime_decode(&g_runtime, &g_sff);
    if (!result) {
        fprintf(stderr, "no sprites decoded; missing=%d decode_errors=%d sff_error=%d\n",
            g_runtime.missing_sprites, g_runtime.decode_errors, g_runtime.last_sff_error);
        fclose(sff_fp);
        return 8;
    }
    stage89_view_reset(&g_view, &g_stage);
    if (argc >= 4) g_view.camera_x = stage89_q16_from_int(strtol(argv[3], (char**)0, 10));
    if (argc >= 5) g_view.camera_y = stage89_q16_from_int(strtol(argv[4], (char**)0, 10));
    g_view.show_grid = argc >= 6 ? (int)strtol(argv[5], (char**)0, 10) : 1;
    g_view.show_players = argc >= 7 ? (int)strtol(argv[6], (char**)0, 10) : 1;
    if (argc >= 9) g_view.tick = (unsigned long)strtoul(argv[8], (char**)0, 10);
    surface.pixels = g_frame;
    surface.width = TEST_W;
    surface.height = TEST_H;
    surface.stride = TEST_W;
    stage89_render(&g_runtime, &g_view, &surface);
    if (!save_ppm(out_path, &surface)) { fclose(sff_fp); return 9; }
    printf("ok: %s | bg=%d anim=%d actions=%d frames=%d bgctrls=%d cache=%d bytes=%lu missing=%d decode_errors=%d tick=%lu output=%s\n",
        g_stage.display_name, g_stage.bg_count, g_runtime.animated_bg_count,
        g_stage.actions.action_count, g_stage.actions.frame_count, g_stage.bgctrls.ctrl_count,
        g_runtime.cache_count, g_runtime.pixel_used,
        g_runtime.missing_sprites, g_runtime.decode_errors, g_view.tick, out_path);
    fclose(sff_fp);
    return 0;
}
