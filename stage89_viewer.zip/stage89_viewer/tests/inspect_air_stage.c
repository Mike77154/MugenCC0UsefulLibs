#include <stdio.h>
#include <string.h>
#include "stage89_stage.h"
#include "sff_stdio_adapter.h"

#define DEF_CAP (2UL * 1024UL * 1024UL)
static char g_text[DEF_CAP];
static Stage89Stage g_stage;
static SffFile g_sff;

static int read_file(const char *path, unsigned long *out_size)
{
    FILE *fp;
    size_t got;
    fp = fopen(path, "rb");
    if (fp == (FILE*)0) return 0;
    got = fread(g_text, 1u, (size_t)(DEF_CAP - 1UL), fp);
    if (ferror(fp)) { fclose(fp); return 0; }
    fclose(fp);
    g_text[got] = '\0';
    *out_size = (unsigned long)got + 1UL;
    return 1;
}

static int already_reported(int group, int item, int pairs[][2], int count)
{
    int i;
    for (i = 0; i < count; ++i) if (pairs[i][0] == group && pairs[i][1] == item) return 1;
    return 0;
}

int main(int argc, char **argv)
{
    unsigned long size;
    FILE *fp;
    SffStdioSource source;
    SffIo io;
    SffOpenOptions options;
    int result;
    int i;
    int j;
    int missing[1024][2];
    int missing_count;
    int type_counts[12];
    long action_no;
    int action_index;
    sff_u32 sprite_index;
    if (argc < 2) return 2;
    if (!read_file(argv[1], &size)) return 3;
    if (!stage89_stage_parse(&g_stage, argv[1], g_text, size)) return 4;
    fp = fopen(g_stage.sff_path, "rb");
    if (fp == (FILE*)0) {
        printf("OPEN_FAIL|%s|declared=%s|resolved=%s\n", argv[1], g_stage.sff_name, g_stage.sff_path);
        return 5;
    }
    sff_stdio_source_init(&source, fp);
    sff_stdio_make_io(&source, &io);
    options.tolerant = 1;
    options.codec = (const SffImageCodec*)0;
    result = sff_open_io(&g_sff, &io, &options);
    if (result != SFF_OK) {
        printf("SFF_FAIL|%s|error=%d|resolved=%s\n", argv[1], result, g_stage.sff_path);
        fclose(fp);
        return 6;
    }
    missing_count = 0;
    memset(type_counts, 0, sizeof(type_counts));
    for (i = 0; i < g_stage.bg_count; ++i) {
        Stage89Bg *bg;
        bg = &g_stage.bg[i];
        if (bg->type == STAGE89_BG_ANIM && bg->action_index >= 0) {
            const AasAction *action;
            action = &g_stage.actions.actions[bg->action_index];
            for (j = 0; j < (int)action->frame_count; ++j) {
                const AasFrame *frame;
                frame = &g_stage.actions.frames[(int)action->first_frame + j];
                if (frame->group < 0 || frame->item < 0) continue;
                if (sff_find_sprite(&g_sff, (sff_u16)frame->group, (sff_u16)frame->item, &sprite_index) != SFF_OK &&
                    !already_reported(frame->group, frame->item, missing, missing_count) && missing_count < 1024) {
                    missing[missing_count][0] = frame->group;
                    missing[missing_count][1] = frame->item;
                    ++missing_count;
                }
            }
        } else if (bg->type != STAGE89_BG_ANIM && bg->type != STAGE89_BG_DUMMY) {
            if (sff_find_sprite(&g_sff, (sff_u16)bg->group, (sff_u16)bg->item, &sprite_index) != SFF_OK &&
                !already_reported(bg->group, bg->item, missing, missing_count) && missing_count < 1024) {
                missing[missing_count][0] = bg->group;
                missing[missing_count][1] = bg->item;
                ++missing_count;
            }
        }
    }
    for (i = 0; i < g_stage.bgctrls.ctrl_count; ++i) {
        const BgcCtrl *ctrl;
        ctrl = &g_stage.bgctrls.ctrls[i];
        if ((int)ctrl->type >= 0 && (int)ctrl->type < 12) ++type_counts[(int)ctrl->type];
        if (ctrl->type == BGC_CTRL_ANIM && ctrl->value_count > 0) {
            action_no = bgc_q16_to_int(ctrl->value[0]);
            action_index = aas_find_action(&g_stage.actions, action_no);
            if (action_index >= 0) {
                const AasAction *action;
                action = &g_stage.actions.actions[action_index];
                for (j = 0; j < (int)action->frame_count; ++j) {
                    const AasFrame *frame;
                    frame = &g_stage.actions.frames[(int)action->first_frame + j];
                    if (frame->group < 0 || frame->item < 0) continue;
                    if (sff_find_sprite(&g_sff, (sff_u16)frame->group, (sff_u16)frame->item, &sprite_index) != SFF_OK &&
                        !already_reported(frame->group, frame->item, missing, missing_count) && missing_count < 1024) {
                        missing[missing_count][0] = frame->group;
                        missing[missing_count][1] = frame->item;
                        ++missing_count;
                    }
                }
            }
        }
    }
    printf("OK|%s|name=%s|kind=%d|sprites=%lu|bg=%d|actions=%d|frames=%d|bgctrldefs=%d|bgctrls=%d|fallback=%d|missing=%d",
        argv[1], g_stage.display_name, (int)sff_kind(&g_sff), (unsigned long)sff_sprite_count(&g_sff),
        g_stage.bg_count, g_stage.actions.action_count, g_stage.actions.frame_count,
        g_stage.bgctrls.def_count, g_stage.bgctrls.ctrl_count,
        g_stage.sff_used_fallback, missing_count);
    printf("|types:null=%d,visible=%d,enabled=%d,velset=%d,veladd=%d,posset=%d,posadd=%d,anim=%d,sinx=%d,siny=%d",
        type_counts[BGC_CTRL_NULL], type_counts[BGC_CTRL_VISIBLE], type_counts[BGC_CTRL_ENABLED],
        type_counts[BGC_CTRL_VELSET], type_counts[BGC_CTRL_VELADD], type_counts[BGC_CTRL_POSSET],
        type_counts[BGC_CTRL_POSADD], type_counts[BGC_CTRL_ANIM], type_counts[BGC_CTRL_SINX], type_counts[BGC_CTRL_SINY]);
    for (i = 0; i < missing_count; ++i) printf("|%d,%d", missing[i][0], missing[i][1]);
    printf("\n");
    sff_close(&g_sff);
    fclose(fp);
    return 0;
}
