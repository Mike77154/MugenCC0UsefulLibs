#include "stage89_render.h"
#include <string.h>

#define STAGE89_NODE_BG 1
#define STAGE89_NODE_PLAYERS 2
#define STAGE89_NODE_GRID 3
#define STAGE89_TILE_LIMIT 40

#define STAGE89_RGB(r,g,b) ((unsigned long)(((unsigned long)(r) << 16) | ((unsigned long)(g) << 8) | (unsigned long)(b)))

typedef struct Stage89DrawContext {
    Stage89Surface *surface;
    Stage89View *view;
} Stage89DrawContext;

static int stage89_cache_find(const Stage89Runtime *runtime, int group, int item)
{
    int i;
    for (i = 0; i < runtime->cache_count; ++i) {
        if (runtime->cache[i].active && runtime->cache[i].group == group && runtime->cache[i].item == item) return i;
    }
    return -1;
}

static unsigned char stage89_clamp_byte(long value)
{
    if (value < 0L) return 0u;
    if (value > 255L) return 255u;
    return (unsigned char)value;
}

static unsigned long stage89_blend(unsigned long dst, unsigned char sr, unsigned char sg, unsigned char sb,
                                   int trans, int alpha_src, int alpha_dst)
{
    long dr;
    long dg;
    long db;
    long rr;
    long rg;
    long rb;
    dr = (long)((dst >> 16) & 255UL);
    dg = (long)((dst >> 8) & 255UL);
    db = (long)(dst & 255UL);
    if (trans == STAGE89_TRANS_ADD) {
        rr = dr + sr; rg = dg + sg; rb = db + sb;
    } else if (trans == STAGE89_TRANS_ADD1) {
        rr = (dr >> 1) + sr; rg = (dg >> 1) + sg; rb = (db >> 1) + sb;
    } else if (trans == STAGE89_TRANS_ADDALPHA) {
        if (alpha_src < 0) alpha_src = 0;
        if (alpha_src > 256) alpha_src = 256;
        if (alpha_dst < 0) alpha_dst = 0;
        if (alpha_dst > 256) alpha_dst = 256;
        rr = ((long)sr * alpha_src + dr * alpha_dst) >> 8;
        rg = ((long)sg * alpha_src + dg * alpha_dst) >> 8;
        rb = ((long)sb * alpha_src + db * alpha_dst) >> 8;
    } else if (trans == STAGE89_TRANS_SUB) {
        rr = dr - sr; rg = dg - sg; rb = db - sb;
    } else {
        rr = sr; rg = sg; rb = sb;
    }
    return STAGE89_RGB(stage89_clamp_byte(rr), stage89_clamp_byte(rg), stage89_clamp_byte(rb));
}

static void stage89_put_pixel(Stage89Runtime *runtime, Stage89Surface *surface, const Stage89Bg *bg,
                              const Stage89SpriteCache *cache, int sx, int sy, int dx, int dy)
{
    unsigned long pos;
    unsigned long src_pos;
    unsigned char index;
    unsigned char r;
    unsigned char g;
    unsigned char b;
    unsigned char a;
    const unsigned char *data;
    unsigned long *dst;

    if (dx < 0 || dy < 0 || dx >= surface->width || dy >= surface->height) return;
    if (sx < 0 || sy < 0 || sx >= (int)cache->width || sy >= (int)cache->height) return;
    data = runtime->pixel_arena + cache->arena_offset;
    dst = surface->pixels + (unsigned long)dy * (unsigned long)surface->stride + (unsigned long)dx;
    if (cache->format == STAGE89_CACHE_INDEXED) {
        pos = (unsigned long)sy * (unsigned long)cache->width + (unsigned long)sx;
        index = data[pos];
        if (index == 0u && (bg->mask || bg->trans != STAGE89_TRANS_NONE)) return;
        r = cache->palette[(unsigned long)index * 3UL + 0UL];
        g = cache->palette[(unsigned long)index * 3UL + 1UL];
        b = cache->palette[(unsigned long)index * 3UL + 2UL];
    } else {
        src_pos = ((unsigned long)sy * (unsigned long)cache->width + (unsigned long)sx) * 4UL;
        r = data[src_pos + 0UL];
        g = data[src_pos + 1UL];
        b = data[src_pos + 2UL];
        a = data[src_pos + 3UL];
        if (a == 0u) return;
    }
    *dst = stage89_blend(*dst, r, g, b, bg->trans, bg->alpha_src, bg->alpha_dst);
}

static stage89_q16 stage89_surface_scale(const Stage89Stage *stage, const Stage89View *view,
                                         const Stage89Surface *surface, stage89_q16 *out_off_x,
                                         stage89_q16 *out_off_y)
{
    stage89_q16 sx;
    stage89_q16 sy;
    stage89_q16 scale;
    stage89_q16 used_w;
    stage89_q16 used_h;
    int ok;
    sx = stage89_q16_div(stage89_q16_from_int((long)surface->width), stage89_q16_from_int((long)stage->localcoord_x), &ok);
    if (!ok) sx = STAGE89_Q16_ONE;
    sy = stage89_q16_div(stage89_q16_from_int((long)surface->height), stage89_q16_from_int((long)stage->localcoord_y), &ok);
    if (!ok) sy = STAGE89_Q16_ONE;
    scale = sx < sy ? sx : sy;
    scale = stage89_q16_mul(scale, view->zoom);
    used_w = stage89_q16_mul(stage89_q16_from_int((long)stage->localcoord_x), scale);
    used_h = stage89_q16_mul(stage89_q16_from_int((long)stage->localcoord_y), scale);
    *out_off_x = (stage89_q16_from_int((long)surface->width) - used_w) / 2L;
    *out_off_y = (stage89_q16_from_int((long)surface->height) - used_h) / 2L;
    return scale;
}

static long stage89_local_to_screen(stage89_q16 local, stage89_q16 scale, stage89_q16 offset)
{
    return stage89_q16_round(offset + stage89_q16_mul(local, scale));
}

static void stage89_draw_scaled(Stage89Runtime *runtime, Stage89Surface *surface, const Stage89Bg *bg,
                                const Stage89SpriteCache *cache, long left, long top,
                                long width, long height, int flip)
{
    long x;
    long y;
    long start_x;
    long start_y;
    long end_x;
    long end_y;
    int sx;
    int sy;

    if (width <= 0L || height <= 0L) return;
    if (left >= surface->width || top >= surface->height || left + width <= 0L || top + height <= 0L) return;
    start_x = left < 0L ? 0L : left;
    start_y = top < 0L ? 0L : top;
    end_x = left + width;
    end_y = top + height;
    if (end_x > surface->width) end_x = surface->width;
    if (end_y > surface->height) end_y = surface->height;
    for (y = start_y; y < end_y; ++y) {
        sy = (int)(((unsigned long)(y - top) * (unsigned long)cache->height) / (unsigned long)height);
        if (sy >= (int)cache->height) sy = (int)cache->height - 1;
        if ((flip & AAS_FLIP_V) != 0) sy = (int)cache->height - 1 - sy;
        for (x = start_x; x < end_x; ++x) {
            sx = (int)(((unsigned long)(x - left) * (unsigned long)cache->width) / (unsigned long)width);
            if (sx >= (int)cache->width) sx = (int)cache->width - 1;
            if ((flip & AAS_FLIP_H) != 0) sx = (int)cache->width - 1 - sx;
            stage89_put_pixel(runtime, surface, bg, cache, sx, sy, (int)x, (int)y);
        }
    }
}

static void stage89_draw_normal(Stage89Runtime *runtime, Stage89Surface *surface, Stage89View *view,
                                const Stage89Bg *bg, const Stage89SpriteCache *cache,
                                stage89_q16 frame_x, stage89_q16 frame_y, int flip, int anim_tiling)
{
    Stage89Stage *stage;
    stage89_q16 scale;
    stage89_q16 off_x;
    stage89_q16 off_y;
    stage89_q16 base_x;
    stage89_q16 base_y;
    stage89_q16 vel_tick_x;
    stage89_q16 vel_tick_y;
    stage89_q16 tile_step_x;
    stage89_q16 tile_step_y;
    stage89_q16 left_local;
    stage89_q16 top_local;
    long dw;
    long dh;
    long left;
    long top;
    int min_tx;
    int max_tx;
    int min_ty;
    int max_ty;
    int tx;
    int ty;

    stage = runtime->stage;
    scale = stage89_surface_scale(stage, view, surface, &off_x, &off_y);
    vel_tick_x = stage89_q16_mul(bg->velocity_x, stage89_q16_from_int((long)(view->tick & 32767UL)));
    vel_tick_y = stage89_q16_mul(bg->velocity_y, stage89_q16_from_int((long)(view->tick & 32767UL)));
    base_x = stage89_q16_from_int((long)(stage->localcoord_x / 2)) + bg->start_x + frame_x + vel_tick_x
           - stage89_q16_mul(view->camera_x, bg->delta_x);
    base_y = bg->start_y + frame_y + vel_tick_y - stage89_q16_mul(view->camera_y, bg->delta_y);
    if (anim_tiling) {
        tile_step_x = stage89_q16_from_int((long)(bg->tile_spacing_x != 0 ? bg->tile_spacing_x : (int)cache->width));
        tile_step_y = stage89_q16_from_int((long)(bg->tile_spacing_y != 0 ? bg->tile_spacing_y : (int)cache->height));
    } else {
        tile_step_x = stage89_q16_from_int((long)cache->width + (long)bg->tile_spacing_x);
        tile_step_y = stage89_q16_from_int((long)cache->height + (long)bg->tile_spacing_y);
    }
    dw = stage89_q16_round(stage89_q16_mul(stage89_q16_from_int((long)cache->width), scale));
    dh = stage89_q16_round(stage89_q16_mul(stage89_q16_from_int((long)cache->height), scale));

    min_tx = 0; max_tx = 0; min_ty = 0; max_ty = 0;
    if (bg->tile_x == 1) { min_tx = -STAGE89_TILE_LIMIT; max_tx = STAGE89_TILE_LIMIT; }
    else if (bg->tile_x > 1) { max_tx = bg->tile_x - 1; if (max_tx > STAGE89_TILE_LIMIT) max_tx = STAGE89_TILE_LIMIT; }
    if (bg->tile_y == 1) { min_ty = -STAGE89_TILE_LIMIT; max_ty = STAGE89_TILE_LIMIT; }
    else if (bg->tile_y > 1) { max_ty = bg->tile_y - 1; if (max_ty > STAGE89_TILE_LIMIT) max_ty = STAGE89_TILE_LIMIT; }

    for (ty = min_ty; ty <= max_ty; ++ty) {
        for (tx = min_tx; tx <= max_tx; ++tx) {
            left_local = base_x + stage89_q16_mul(tile_step_x, stage89_q16_from_int((long)tx))
                       - stage89_q16_from_int((long)cache->axis_x);
            top_local = base_y + stage89_q16_mul(tile_step_y, stage89_q16_from_int((long)ty))
                      - stage89_q16_from_int((long)cache->axis_y);
            left = stage89_local_to_screen(left_local, scale, off_x);
            top = stage89_local_to_screen(top_local, scale, off_y);
            stage89_draw_scaled(runtime, surface, bg, cache, left, top, dw, dh, flip);
        }
    }
}

static void stage89_draw_parallax(Stage89Runtime *runtime, Stage89Surface *surface, Stage89View *view,
                                  const Stage89Bg *bg, const Stage89SpriteCache *cache)
{
    Stage89Stage *stage;
    stage89_q16 scale;
    stage89_q16 off_x;
    stage89_q16 off_y;
    stage89_q16 tick_q;
    stage89_q16 base_anchor_x;
    stage89_q16 anchor_y;
    stage89_q16 anchor_y_screen;
    stage89_q16 inverse_start;
    stage89_q16 inverse_delta;
    stage89_q16 inverse_scale;
    stage89_q16 vertical_factor;
    stage89_q16 vertical_scale;
    stage89_q16 t;
    stage89_q16 row_motion;
    stage89_q16 row_width_local;
    stage89_q16 row_axis_local;
    stage89_q16 row_anchor_local;
    stage89_q16 row_left_screen;
    stage89_q16 tile_step_local;
    stage89_q16 tile_offset;
    stage89_q16 hundred;
    long dest_h;
    long row_width;
    long top_screen;
    long screen_y;
    long left;
    long x;
    long start_x;
    long end_x;
    long dy;
    int sy;
    int sx;
    int tx;
    int min_tx;
    int max_tx;
    int ok;

    stage = runtime->stage;
    scale = stage89_surface_scale(stage, view, surface, &off_x, &off_y);
    tick_q = stage89_q16_from_int((long)(view->tick & 32767UL));
    base_anchor_x = stage89_q16_from_int((long)(stage->localcoord_x / 2)) + bg->start_x
                  + stage89_q16_mul(bg->velocity_x, tick_q);
    anchor_y = bg->start_y + stage89_q16_mul(bg->velocity_y, tick_q)
             - stage89_q16_mul(view->camera_y, bg->delta_y);

    /* MUGEN legacy vertical parallax uses an inverse percentage scale:
       scale = 1 / (yscalestart/100 + yscaledelta/100 * camera_y). */
    hundred = stage89_q16_from_int(100L);
    inverse_start = stage89_q16_div(bg->yscale_start, hundred, &ok);
    if (!ok) inverse_start = STAGE89_Q16_ONE;
    inverse_delta = stage89_q16_div(bg->yscale_delta, hundred, &ok);
    if (!ok) inverse_delta = 0;
    inverse_scale = inverse_start + stage89_q16_mul(inverse_delta, view->camera_y);
    if (inverse_scale < 3277L) inverse_scale = 3277L; /* 0.05, avoids singularities. */
    vertical_factor = stage89_q16_div(STAGE89_Q16_ONE, inverse_scale, &ok);
    if (!ok || vertical_factor <= 0) vertical_factor = STAGE89_Q16_ONE;
    if (vertical_factor > 1048576L) vertical_factor = 1048576L; /* 16x safety cap. */
    vertical_scale = stage89_q16_mul(scale, vertical_factor);
    dest_h = stage89_q16_round(stage89_q16_mul(stage89_q16_from_int((long)cache->height), vertical_scale));
    if (dest_h <= 0L) return;

    anchor_y_screen = off_y + stage89_q16_mul(anchor_y, scale);
    top_screen = stage89_q16_round(anchor_y_screen
               - stage89_q16_mul(stage89_q16_from_int((long)cache->axis_y), vertical_scale));

    min_tx = 0;
    max_tx = 0;
    if (bg->tile_x == 1) {
        min_tx = -STAGE89_TILE_LIMIT;
        max_tx = STAGE89_TILE_LIMIT;
    } else if (bg->tile_x > 1) {
        max_tx = bg->tile_x - 1;
        if (max_tx > STAGE89_TILE_LIMIT) max_tx = STAGE89_TILE_LIMIT;
    }

    for (dy = 0L; dy < dest_h; ++dy) {
        screen_y = top_screen + dy;
        if (screen_y < 0L || screen_y >= surface->height) continue;
        sy = (int)(((unsigned long)dy * (unsigned long)cache->height) / (unsigned long)dest_h);
        if (sy >= (int)cache->height) sy = (int)cache->height - 1;
        if (cache->height > 1u) {
            t = stage89_q16_div(stage89_q16_from_int((long)sy),
                                stage89_q16_from_int((long)cache->height - 1L), &ok);
            if (!ok) t = 0;
        } else {
            t = 0;
        }

        if (bg->parallax_mode == STAGE89_PARALLAX_WIDTH &&
            bg->width_top > 0 && bg->width_bottom > 0) {
            row_width_local = bg->width_top
                            + stage89_q16_mul(bg->width_bottom - bg->width_top, t);
            row_motion = stage89_q16_div(row_width_local, bg->width_top, &ok);
            if (!ok || row_motion <= 0) row_motion = STAGE89_Q16_ONE;
            row_axis_local = row_width_local / 2;
            /* Parallax tiles repeat edge-to-edge after the row distortion.
               Legacy stages often write tilespacing as the source width, but
               MUGEN's parallax path does not use the normal-element gap rule. */
            tile_step_local = row_width_local;
        } else {
            row_motion = bg->xscale_top
                       + stage89_q16_mul(bg->xscale_bottom - bg->xscale_top, t);
            if (row_motion <= 0) row_motion = STAGE89_Q16_ONE;
            row_width_local = stage89_q16_from_int((long)cache->width);
            row_axis_local = stage89_q16_from_int((long)cache->axis_x);
            tile_step_local = row_width_local;
        }

        row_width = stage89_q16_round(stage89_q16_mul(row_width_local, scale));
        if (row_width <= 0L) continue;

        /* xscale/width alter horizontal camera delta per scanline. They do not
           blindly scale a pre-distorted xscale sprite's row width. */
        row_anchor_local = base_anchor_x
                         - stage89_q16_mul(stage89_q16_mul(view->camera_x, bg->delta_x), row_motion);

        for (tx = min_tx; tx <= max_tx; ++tx) {
            tile_offset = stage89_q16_mul(tile_step_local, stage89_q16_from_int((long)tx));
            row_left_screen = off_x
                            + stage89_q16_mul(row_anchor_local + tile_offset, scale)
                            - stage89_q16_mul(row_axis_local, scale);
            left = stage89_q16_round(row_left_screen);
            if (left >= surface->width || left + row_width <= 0L) continue;
            start_x = left < 0L ? 0L : left;
            end_x = left + row_width;
            if (end_x > surface->width) end_x = surface->width;
            for (x = start_x; x < end_x; ++x) {
                sx = (int)(((unsigned long)(x - left) * (unsigned long)cache->width) /
                           (unsigned long)row_width);
                if (sx >= (int)cache->width) sx = (int)cache->width - 1;
                stage89_put_pixel(runtime, surface, bg, cache, sx, sy, (int)x, (int)screen_y);
            }
        }
    }
}

static void stage89_fill_rect(Stage89Surface *surface, int x0, int y0, int x1, int y1, unsigned long color)
{
    int x;
    int y;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > surface->width) x1 = surface->width;
    if (y1 > surface->height) y1 = surface->height;
    for (y = y0; y < y1; ++y) {
        for (x = x0; x < x1; ++x) surface->pixels[(unsigned long)y * (unsigned long)surface->stride + (unsigned long)x] = color;
    }
}

static void stage89_draw_line_h(Stage89Surface *surface, int y, unsigned long color)
{
    int x;
    if (y < 0 || y >= surface->height) return;
    for (x = 0; x < surface->width; ++x) surface->pixels[(unsigned long)y * (unsigned long)surface->stride + (unsigned long)x] = color;
}

static void stage89_draw_line_v(Stage89Surface *surface, int x, unsigned long color)
{
    int y;
    if (x < 0 || x >= surface->width) return;
    for (y = 0; y < surface->height; ++y) surface->pixels[(unsigned long)y * (unsigned long)surface->stride + (unsigned long)x] = color;
}

static stage89_q16 stage89_runtime_zoffset(const Stage89Runtime *runtime)
{
    const Stage89Stage *stage;
    const BgcTargetState *state;
    int i;
    if (runtime == (const Stage89Runtime*)0 || runtime->stage == (Stage89Stage*)0) return 0;
    stage = runtime->stage;
    if (stage->zoffset_link >= 0L && runtime->bgctrl_ready) {
        for (i = 0; i < stage->bg_count; ++i) {
            if (stage->bg[i].id == stage->zoffset_link) {
                state = bgc_runtime_get_state(&runtime->bgctrl_runtime, i);
                if (state != (const BgcTargetState*)0) return (stage89_q16)state->computed_y;
            }
        }
    }
    return stage89_q16_from_int((long)stage->zoffset);
}

static void stage89_apply_positionlink_delta(const Stage89Stage *stage, int bg_index, Stage89Bg *draw_bg)
{
    int root;
    if (stage == (const Stage89Stage*)0 || draw_bg == (Stage89Bg*)0 || bg_index <= 0) return;
    if (!stage->bg[bg_index].position_link) return;
    root = bg_index - 1;
    while (root > 0 && stage->bg[root].position_link) --root;
    draw_bg->delta_x = stage->bg[root].delta_x;
    draw_bg->delta_y = stage->bg[root].delta_y;
}

static void stage89_layer_draw(void *graphic, const layer89_draw_context *context)
{
    Stage89LayerNode *node;
    Stage89DrawContext *draw;
    Stage89Runtime *runtime;
    Stage89Stage *stage;
    Stage89View *view;
    Stage89Surface *surface;
    Stage89Bg *bg;
    Stage89SpriteCache *cache;
    stage89_q16 scale;
    stage89_q16 ox;
    stage89_q16 oy;
    int floor_y;
    int p1x;
    int p2x;
    int top;
    int x;
    int y;
    int step;

    node = (Stage89LayerNode*)graphic;
    draw = (Stage89DrawContext*)context->render_target;
    runtime = node->runtime;
    stage = runtime->stage;
    view = draw->view;
    surface = draw->surface;

    if (node->kind == STAGE89_NODE_BG) {
        Stage89Bg draw_bg;
        AasSample sample;
        const BgcTargetState *state;
        unsigned long action_tick;
        long action_no;
        int action_index;
        int cache_index;
        bg = &stage->bg[node->bg_index];
        state = runtime->bgctrl_ready ? bgc_runtime_get_state(&runtime->bgctrl_runtime, node->bg_index) : (const BgcTargetState*)0;
        if (state != (const BgcTargetState*)0) {
            if (!state->enabled || !state->visible) return;
        } else if (!bg->visible) return;
        if (bg->layerno != 0 && !view->show_foreground) return;
        draw_bg = *bg;
        if (state != (const BgcTargetState*)0) {
            draw_bg.start_x = (stage89_q16)state->computed_x;
            draw_bg.start_y = (stage89_q16)state->computed_y;
            draw_bg.velocity_x = 0;
            draw_bg.velocity_y = 0;
        }
        stage89_apply_positionlink_delta(stage, node->bg_index, &draw_bg);
        if (bg->type == STAGE89_BG_DUMMY) return;
        if (bg->type == STAGE89_BG_ANIM) {
            action_no = state != (const BgcTargetState*)0 ? state->action_no : bg->action_no;
            action_tick = state != (const BgcTargetState*)0 ? state->action_tick : view->tick;
            action_index = aas_find_action(&stage->actions, action_no);
            if (action_index < 0 || !aas_sample_action(&stage->actions, action_index, action_tick, &sample)) return;
            if (sample.frame->group < 0 || sample.frame->item < 0) return;
            cache_index = stage89_cache_find(runtime, sample.frame->group, sample.frame->item);
            if (cache_index < 0 || cache_index >= runtime->cache_count) return;
            cache = &runtime->cache[cache_index];
            draw_bg.mask = 1;
            if (sample.frame->blend == AAS_BLEND_ADD) draw_bg.trans = STAGE89_TRANS_ADD;
            else if (sample.frame->blend == AAS_BLEND_ADD1) draw_bg.trans = STAGE89_TRANS_ADD1;
            else if (sample.frame->blend == AAS_BLEND_SUB) draw_bg.trans = STAGE89_TRANS_SUB;
            else if (sample.frame->blend == AAS_BLEND_ALPHA) {
                draw_bg.trans = STAGE89_TRANS_ADDALPHA;
                draw_bg.alpha_src = sample.frame->alpha_src;
                draw_bg.alpha_dst = sample.frame->alpha_dst;
            }
            stage89_draw_normal(runtime, surface, view, &draw_bg, cache,
                stage89_q16_from_int((long)sample.frame->offset_x),
                stage89_q16_from_int((long)sample.frame->offset_y),
                sample.frame->flip, 1);
        } else {
            if (bg->cache_index < 0 || bg->cache_index >= runtime->cache_count) return;
            cache = &runtime->cache[bg->cache_index];
            if (bg->type == STAGE89_BG_PARALLAX) stage89_draw_parallax(runtime, surface, view, &draw_bg, cache);
            else stage89_draw_normal(runtime, surface, view, &draw_bg, cache, 0, 0, AAS_FLIP_NONE, 0);
        }
    } else if (node->kind == STAGE89_NODE_PLAYERS) {
        if (!view->show_players) return;
        scale = stage89_surface_scale(stage, view, surface, &ox, &oy);
        floor_y = (int)stage89_local_to_screen(stage89_runtime_zoffset(runtime) - view->camera_y, scale, oy);
        p1x = (int)stage89_local_to_screen(stage89_q16_from_int((long)(stage->localcoord_x / 2 + stage->p1_start_x)) - view->camera_x, scale, ox);
        p2x = (int)stage89_local_to_screen(stage89_q16_from_int((long)(stage->localcoord_x / 2 + stage->p2_start_x)) - view->camera_x, scale, ox);
        top = floor_y - (int)stage89_q16_round(stage89_q16_mul(stage89_q16_from_int(58L), scale));
        stage89_fill_rect(surface, p1x - 7, top, p1x + 7, floor_y, STAGE89_RGB(235, 80, 80));
        stage89_fill_rect(surface, p2x - 7, top, p2x + 7, floor_y, STAGE89_RGB(80, 140, 245));
        stage89_fill_rect(surface, p1x - 10, top - 12, p1x + 10, top + 4, STAGE89_RGB(255, 190, 160));
        stage89_fill_rect(surface, p2x - 10, top - 12, p2x + 10, top + 4, STAGE89_RGB(255, 190, 160));
    } else if (node->kind == STAGE89_NODE_GRID) {
        if (!view->show_grid) return;
        scale = stage89_surface_scale(stage, view, surface, &ox, &oy);
        floor_y = (int)stage89_local_to_screen(stage89_runtime_zoffset(runtime) - view->camera_y, scale, oy);
        stage89_draw_line_h(surface, floor_y, STAGE89_RGB(255, 220, 40));
        step = 20;
        for (x = -stage->localcoord_x; x <= stage->localcoord_x * 2; x += step) {
            int sx;
            sx = (int)stage89_local_to_screen(stage89_q16_from_int((long)x) - view->camera_x, scale, ox);
            stage89_draw_line_v(surface, sx, STAGE89_RGB(45, 70, 70));
        }
        for (y = -stage->localcoord_y; y <= stage->localcoord_y * 2; y += step) {
            int sy;
            sy = (int)stage89_local_to_screen(stage89_q16_from_int((long)y) - view->camera_y, scale, oy);
            stage89_draw_line_h(surface, sy, STAGE89_RGB(45, 70, 70));
        }
    }
}

void stage89_view_reset(Stage89View *view, const Stage89Stage *stage)
{
    if (view == (Stage89View*)0 || stage == (const Stage89Stage*)0) return;
    memset(view, 0, sizeof(*view));
    view->camera_x = stage->camera_start_x;
    view->camera_y = stage->camera_start_y;
    view->zoom = stage->start_zoom > 0 ? stage->start_zoom : STAGE89_Q16_ONE;
    view->show_players = 1;
    view->show_grid = 0;
    view->show_foreground = 1;
}

void stage89_view_tick(Stage89View *view)
{
    if (view != (Stage89View*)0 && !view->paused) ++view->tick;
}

void stage89_runtime_init(Stage89Runtime *runtime, Stage89Stage *stage,
                          unsigned char *pixel_arena, unsigned long pixel_capacity,
                          unsigned char *decode_work, unsigned long decode_work_capacity)
{
    BgcTargetInit targets[STAGE89_MAX_BG];
    int i;
    if (runtime == (Stage89Runtime*)0) return;
    memset(runtime, 0, sizeof(*runtime));
    runtime->stage = stage;
    runtime->pixel_arena = pixel_arena;
    runtime->pixel_capacity = pixel_capacity;
    runtime->decode_work = decode_work;
    runtime->decode_work_capacity = decode_work_capacity;
    layer89_init(&runtime->layers);
    if (stage == (Stage89Stage*)0) return;
    memset(targets, 0, sizeof(targets));
    for (i = 0; i < stage->bg_count && i < STAGE89_MAX_BG; ++i) {
        targets[i].id = stage->bg[i].id;
        targets[i].start_x = (bgc_q16)stage->bg[i].start_x;
        targets[i].start_y = (bgc_q16)stage->bg[i].start_y;
        targets[i].velocity_x = (bgc_q16)stage->bg[i].velocity_x;
        targets[i].velocity_y = (bgc_q16)stage->bg[i].velocity_y;
        targets[i].visible = stage->bg[i].visible;
        targets[i].enabled = 1;
        targets[i].action_no = stage->bg[i].action_no;
        targets[i].sin_x = stage->bg[i].sin_x;
        targets[i].sin_y = stage->bg[i].sin_y;
        targets[i].has_sin_x = stage->bg[i].has_sin_x;
        targets[i].has_sin_y = stage->bg[i].has_sin_y;
        targets[i].position_link = stage->bg[i].position_link;
    }
    bgc_runtime_init(&runtime->bgctrl_runtime, &stage->bgctrls, targets, stage->bg_count);
    runtime->bgctrl_ready = 1;
}

static int stage89_decode_cache_sprite(Stage89Runtime *runtime, const SffFile *sff,
                                       int group, int item)
{
    int cache_index;
    int result;
    sff_u32 sprite_index;
    SffSpriteInfo info;
    Stage89SpriteCache *cache;
    unsigned long needed;
    sff_u16 out_w;
    sff_u16 out_h;
    int has_palette;

    if (group < 0 || item < 0) return -1;
    cache_index = stage89_cache_find(runtime, group, item);
    if (cache_index >= 0) return cache_index;
    if (runtime->cache_count >= STAGE89_MAX_SPRITE_CACHE) {
        ++runtime->decode_errors;
        runtime->last_sff_error = SFF_ERR_CAPACITY;
        return -1;
    }
    result = sff_find_sprite(sff, (sff_u16)group, (sff_u16)item, &sprite_index);
    if (result != SFF_OK || sff_get_sprite_info(sff, sprite_index, &info) != SFF_OK) {
        ++runtime->missing_sprites;
        runtime->last_sff_error = result;
        return -1;
    }
    cache = &runtime->cache[runtime->cache_count];
    memset(cache, 0, sizeof(*cache));
    cache->group = group;
    cache->item = item;
    cache->width = info.w;
    cache->height = info.h;
    cache->axis_x = info.axis_x;
    cache->axis_y = info.axis_y;
    needed = (unsigned long)info.w * (unsigned long)info.h;
    if (needed == 0UL || needed > runtime->pixel_capacity - runtime->pixel_used) {
        ++runtime->decode_errors;
        runtime->last_sff_error = SFF_ERR_BUFFER_TOO_SMALL;
        return -1;
    }
    cache->arena_offset = runtime->pixel_used;
    result = sff_decode_sprite_indexed_into(sff, sprite_index,
        runtime->pixel_arena + runtime->pixel_used, needed,
        &out_w, &out_h, cache->palette, &has_palette,
        runtime->decode_work, runtime->decode_work_capacity);
    if (result == SFF_OK) {
        cache->format = STAGE89_CACHE_INDEXED;
        cache->arena_size = needed;
        runtime->pixel_used += needed;
    } else {
        needed *= 4UL;
        if (needed == 0UL || needed > runtime->pixel_capacity - runtime->pixel_used) {
            ++runtime->decode_errors;
            runtime->last_sff_error = result;
            return -1;
        }
        result = sff_decode_sprite_rgba_into(sff, sprite_index,
            runtime->pixel_arena + runtime->pixel_used, needed,
            &out_w, &out_h, runtime->decode_work, runtime->decode_work_capacity);
        if (result != SFF_OK) {
            ++runtime->decode_errors;
            runtime->last_sff_error = result;
            return -1;
        }
        cache->format = STAGE89_CACHE_RGBA;
        cache->arena_size = needed;
        runtime->pixel_used += needed;
    }
    cache->width = out_w;
    cache->height = out_h;
    cache->active = 1;
    cache_index = runtime->cache_count++;
    return cache_index;
}

int stage89_runtime_decode(Stage89Runtime *runtime, const SffFile *sff)
{
    int i;
    int j;
    int cache_index;
    layer89_handle handle;

    if (runtime == (Stage89Runtime*)0 || runtime->stage == (Stage89Stage*)0 || sff == (const SffFile*)0) return 0;
    runtime->pixel_used = 0UL;
    runtime->cache_count = 0;
    runtime->missing_sprites = 0;
    runtime->decode_errors = 0;
    runtime->last_sff_error = SFF_OK;
    runtime->animated_bg_count = 0;
    runtime->decoded_action_frames = 0;
    memset(runtime->cache, 0, sizeof(runtime->cache));
    layer89_clear(&runtime->layers);

    for (i = 0; i < runtime->stage->bg_count; ++i) {
        Stage89Bg *bg;
        bg = &runtime->stage->bg[i];
        bg->cache_index = -1;
        if (bg->type == STAGE89_BG_DUMMY) {
            continue;
        } else if (bg->type == STAGE89_BG_ANIM) {
            const AasAction *action;
            ++runtime->animated_bg_count;
            if (bg->action_index < 0 || bg->action_index >= runtime->stage->actions.action_count) continue;
            action = &runtime->stage->actions.actions[bg->action_index];
            for (j = 0; j < (int)action->frame_count; ++j) {
                const AasFrame *frame;
                frame = &runtime->stage->actions.frames[(int)action->first_frame + j];
                if (frame->group < 0 || frame->item < 0) continue;
                cache_index = stage89_decode_cache_sprite(runtime, sff, frame->group, frame->item);
                if (cache_index >= 0) {
                    ++runtime->decoded_action_frames;
                    if (bg->cache_index < 0) bg->cache_index = cache_index;
                }
            }
        } else {
            bg->cache_index = stage89_decode_cache_sprite(runtime, sff, bg->group, bg->item);
        }
    }

    for (i = 0; i < runtime->stage->bgctrls.ctrl_count; ++i) {
        const BgcCtrl *ctrl;
        long action_no;
        int action_index;
        const AasAction *action;
        ctrl = &runtime->stage->bgctrls.ctrls[i];
        if (ctrl->type != BGC_CTRL_ANIM || ctrl->value_count <= 0) continue;
        action_no = bgc_q16_to_int(ctrl->value[0]);
        action_index = aas_find_action(&runtime->stage->actions, action_no);
        if (action_index < 0 || action_index >= runtime->stage->actions.action_count) continue;
        action = &runtime->stage->actions.actions[action_index];
        for (j = 0; j < (int)action->frame_count; ++j) {
            const AasFrame *frame;
            frame = &runtime->stage->actions.frames[(int)action->first_frame + j];
            if (frame->group < 0 || frame->item < 0) continue;
            cache_index = stage89_decode_cache_sprite(runtime, sff, frame->group, frame->item);
            if (cache_index >= 0) ++runtime->decoded_action_frames;
        }
    }

    for (i = 0; i < runtime->stage->bg_count; ++i) {
        runtime->nodes[i].runtime = runtime;
        runtime->nodes[i].kind = STAGE89_NODE_BG;
        runtime->nodes[i].bg_index = i;
        handle = layer89_add(&runtime->layers,
            runtime->stage->bg[i].layerno == 0 ? (-10000L + (long)i) : (10000L + (long)i),
            stage89_layer_draw, &runtime->nodes[i]);
        (void)handle;
    }
    runtime->nodes[STAGE89_MAX_BG].runtime = runtime;
    runtime->nodes[STAGE89_MAX_BG].kind = STAGE89_NODE_PLAYERS;
    runtime->nodes[STAGE89_MAX_BG].bg_index = -1;
    handle = layer89_add(&runtime->layers, 0L, stage89_layer_draw, &runtime->nodes[STAGE89_MAX_BG]);
    (void)handle;
    runtime->nodes[STAGE89_MAX_BG + 1].runtime = runtime;
    runtime->nodes[STAGE89_MAX_BG + 1].kind = STAGE89_NODE_GRID;
    runtime->nodes[STAGE89_MAX_BG + 1].bg_index = -1;
    handle = layer89_add(&runtime->layers, 30000L, stage89_layer_draw, &runtime->nodes[STAGE89_MAX_BG + 1]);
    (void)handle;
    return runtime->cache_count > 0;
}

void stage89_render(Stage89Runtime *runtime, Stage89View *view, Stage89Surface *surface)
{
    unsigned long clear_color;
    unsigned long count;
    unsigned long i;
    Stage89DrawContext draw;
    layer89_draw_context context;

    if (runtime == (Stage89Runtime*)0 || runtime->stage == (Stage89Stage*)0 || view == (Stage89View*)0 ||
        surface == (Stage89Surface*)0 || surface->pixels == (unsigned long*)0 || surface->width <= 0 || surface->height <= 0) return;
    if (runtime->bgctrl_ready) (void)bgc_runtime_seek(&runtime->bgctrl_runtime, view->tick);
    clear_color = runtime->stage->debug_bg ? STAGE89_RGB(255, 0, 255) : STAGE89_RGB(18, 21, 25);
    count = (unsigned long)surface->stride * (unsigned long)surface->height;
    for (i = 0UL; i < count; ++i) surface->pixels[i] = clear_color;
    draw.surface = surface;
    draw.view = view;
    context.render_target = &draw;
    context.viewport_width = surface->width;
    context.viewport_height = surface->height;
    context.frame_index = view->tick;
    layer89_render(&runtime->layers, &context);
}
