#include "stage89_stage.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

static void stage89_copy(char *dst, int cap, const char *src)
{
    int i;
    if (dst == (char*)0 || cap <= 0) return;
    if (src == (const char*)0) src = "";
    i = 0;
    while (i + 1 < cap && src[i] != '\0') { dst[i] = src[i]; ++i; }
    dst[i] = '\0';
}

static int stage89_eqi(const char *a, const char *b)
{
    unsigned char ca;
    unsigned char cb;
    if (a == (const char*)0 || b == (const char*)0) return 0;
    while (*a != '\0' && *b != '\0') {
        ca = (unsigned char)tolower((unsigned char)*a);
        cb = (unsigned char)tolower((unsigned char)*b);
        if (ca != cb) return 0;
        ++a;
        ++b;
    }
    return *a == '\0' && *b == '\0';
}

static int stage89_starts_i(const char *text, const char *prefix)
{
    unsigned char a;
    unsigned char b;
    while (*prefix != '\0') {
        if (*text == '\0') return 0;
        a = (unsigned char)tolower((unsigned char)*text);
        b = (unsigned char)tolower((unsigned char)*prefix);
        if (a != b) return 0;
        ++text;
        ++prefix;
    }
    return 1;
}

static char *stage89_trim(char *text)
{
    char *end;
    while (*text == ' ' || *text == '\t' || *text == '\r' || *text == '\n') ++text;
    end = text + strlen(text);
    while (end > text) {
        char c;
        c = end[-1];
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') --end;
        else break;
    }
    *end = '\0';
    return text;
}

static void stage89_strip_comment(char *line)
{
    int quote;
    quote = 0;
    while (*line != '\0') {
        if (*line == '"') quote = !quote;
        else if (*line == ';' && !quote) { *line = '\0'; return; }
        ++line;
    }
}

static void stage89_unquote(char *text)
{
    size_t len;
    text = stage89_trim(text);
    len = strlen(text);
    if (len >= 2u && text[0] == '"' && text[len - 1u] == '"') {
        memmove(text, text + 1, len - 2u);
        text[len - 2u] = '\0';
    }
}

static long stage89_parse_long(const char *text, int *ok)
{
    long sign;
    long value;
    int any;
    if (ok != (int*)0) *ok = 0;
    if (text == (const char*)0) return 0L;
    while (*text == ' ' || *text == '\t') ++text;
    sign = 1L;
    if (*text == '-') { sign = -1L; ++text; }
    else if (*text == '+') ++text;
    value = 0L;
    any = 0;
    while (*text >= '0' && *text <= '9') {
        value = value * 10L + (long)(*text - '0');
        any = 1;
        ++text;
    }
    if (ok != (int*)0) *ok = any;
    return value * sign;
}

static int stage89_next_value(const char **cursor, char *out, int cap)
{
    const char *p;
    int i;
    if (cursor == (const char**)0 || *cursor == (const char*)0 || out == (char*)0 || cap <= 0) return 0;
    p = *cursor;
    while (*p == ' ' || *p == '\t' || *p == ',') ++p;
    if (*p == '\0') { out[0] = '\0'; *cursor = p; return 0; }
    i = 0;
    while (*p != '\0' && *p != ',') {
        if (i + 1 < cap) out[i++] = *p;
        ++p;
    }
    out[i] = '\0';
    if (*p == ',') ++p;
    *cursor = p;
    stage89_copy(out, cap, stage89_trim(out));
    return 1;
}

static void stage89_parse_q16_pair(const char *text, stage89_q16 *a, stage89_q16 *b)
{
    const char *cursor;
    char part[64];
    int ok;
    cursor = text;
    if (stage89_next_value(&cursor, part, (int)sizeof(part))) {
        stage89_q16 q;
        q = stage89_q16_from_text(part, &ok);
        if (ok && a != (stage89_q16*)0) *a = q;
    }
    if (stage89_next_value(&cursor, part, (int)sizeof(part))) {
        stage89_q16 q;
        q = stage89_q16_from_text(part, &ok);
        if (ok && b != (stage89_q16*)0) *b = q;
    }
}

static void stage89_parse_int_pair(const char *text, int *a, int *b)
{
    const char *cursor;
    char part[64];
    int ok;
    cursor = text;
    if (stage89_next_value(&cursor, part, (int)sizeof(part))) {
        long v;
        v = stage89_parse_long(part, &ok);
        if (ok && a != (int*)0) *a = (int)v;
    }
    if (stage89_next_value(&cursor, part, (int)sizeof(part))) {
        long v;
        v = stage89_parse_long(part, &ok);
        if (ok && b != (int*)0) *b = (int)v;
    }
}

static int stage89_parse_osc(const char *text, BgcOsc *osc)
{
    const char *cursor;
    char part[64];
    int ok;
    int count;
    bgc_q16 values[3];
    if (text == (const char*)0 || osc == (BgcOsc*)0) return 0;
    cursor = text;
    count = 0;
    while (count < 3 && stage89_next_value(&cursor, part, (int)sizeof(part))) {
        values[count] = bgc_q16_from_text(part, &ok);
        if (!ok) return 0;
        ++count;
    }
    if (count < 2) return 0;
    osc->amplitude = values[0];
    osc->period = values[1];
    osc->phase = count > 2 ? values[2] : 0;
    return 1;
}

static void stage89_diag(Stage89Stage *stage, const char *message)
{
    if (stage->warning_count < STAGE89_MAX_DIAGNOSTICS) {
        stage89_copy(stage->diagnostics[stage->warning_count], STAGE89_DIAG_TEXT, message);
    }
    ++stage->warning_count;
}

static void stage89_bg_defaults(Stage89Bg *bg)
{
    memset(bg, 0, sizeof(*bg));
    bg->type = STAGE89_BG_NORMAL;
    bg->action_no = -1L;
    bg->action_index = -1;
    bg->layerno = 0;
    bg->mask = 0;
    bg->visible = 1;
    bg->trans = STAGE89_TRANS_NONE;
    bg->alpha_src = 256;
    bg->alpha_dst = 0;
    bg->delta_x = STAGE89_Q16_ONE;
    bg->delta_y = STAGE89_Q16_ONE;
    bg->parallax_mode = STAGE89_PARALLAX_XSCALE;
    bg->xscale_top = STAGE89_Q16_ONE;
    bg->xscale_bottom = STAGE89_Q16_ONE;
    bg->width_top = 0;
    bg->width_bottom = 0;
    bg->yscale_start = stage89_q16_from_int(100L);
    bg->yscale_delta = 0;
    bg->id = 0L;
    bg->cache_index = -1;
}

void stage89_stage_init(Stage89Stage *stage)
{
    if (stage == (Stage89Stage*)0) return;
    memset(stage, 0, sizeof(*stage));
    aas_init(&stage->actions);
    bgc_program_init(&stage->bgctrls);
    stage89_copy(stage->name, STAGE89_MAX_NAME, "Unnamed Stage");
    stage89_copy(stage->display_name, STAGE89_MAX_NAME, "Unnamed Stage");
    stage89_copy(stage->author, STAGE89_MAX_NAME, "Unknown");
    stage89_copy(stage->mugen_version, (int)sizeof(stage->mugen_version), "auto");
    stage->localcoord_x = 320;
    stage->localcoord_y = 240;
    stage->localcoord_explicit = 0;
    stage->hires = 0;
    stage->zoffset = 190;
    stage->zoffset_link = -1L;
    stage->p1_start_x = -70;
    stage->p1_start_y = 0;
    stage->p1_facing = 1;
    stage->p2_start_x = 70;
    stage->p2_start_y = 0;
    stage->p2_facing = -1;
    stage->bound_left = stage89_q16_from_int(-160L);
    stage->bound_right = stage89_q16_from_int(160L);
    stage->bound_high = stage89_q16_from_int(-25L);
    stage->bound_low = 0;
    stage->tension = stage89_q16_from_int(50L);
    stage->vertical_follow = 0;
    stage->start_zoom = STAGE89_Q16_ONE;
    stage->zoom_out = STAGE89_Q16_ONE;
    stage->zoom_in = STAGE89_Q16_ONE;
}

int stage89_path_is_absolute(const char *path)
{
    if (path == (const char*)0 || path[0] == '\0') return 0;
    if ((path[0] == '\\' && path[1] == '\\') || path[0] == '/') return 1;
    if (((path[0] >= 'A' && path[0] <= 'Z') || (path[0] >= 'a' && path[0] <= 'z')) && path[1] == ':') return 1;
    return 0;
}

void stage89_path_dirname(const char *path, char *out, int out_cap)
{
    int i;
    int last;
    if (out == (char*)0 || out_cap <= 0) return;
    out[0] = '\0';
    if (path == (const char*)0) return;
    last = -1;
    i = 0;
    while (path[i] != '\0') {
        if (path[i] == '/' || path[i] == '\\') last = i;
        ++i;
    }
    if (last < 0) { stage89_copy(out, out_cap, "."); return; }
    if (last == 0) { stage89_copy(out, out_cap, "\\"); return; }
    i = 0;
    while (i < last && i + 1 < out_cap) { out[i] = path[i]; ++i; }
    out[i] = '\0';
}


static void stage89_normalize_separators(char *path)
{
    while (*path != '\0') {
        if (*path == '\\') *path = '/';
        ++path;
    }
}

static const char *stage89_path_basename(const char *path)
{
    const char *base;
    const char *p;
    base = path;
    p = path;
    while (*p != '\0') {
        if (*p == '/' || *p == '\\') base = p + 1;
        ++p;
    }
    return base;
}

static int stage89_file_exists(const char *path)
{
    FILE *fp;
    fp = fopen(path, "rb");
    if (fp == (FILE*)0) return 0;
    fclose(fp);
    return 1;
}

void stage89_path_join(const char *base, const char *child, char *out, int out_cap)
{
    int len;
    char separator;
    if (out == (char*)0 || out_cap <= 0) return;
    out[0] = '\0';
    if (child == (const char*)0) child = "";
    if (stage89_path_is_absolute(child) || base == (const char*)0 || base[0] == '\0') {
        stage89_copy(out, out_cap, child);
        stage89_normalize_separators(out);
        return;
    }
    stage89_copy(out, out_cap, base);
    separator = (strchr(base, '/') != (const char*)0 && strchr(base, '\\') == (const char*)0) ? '/' : '\\';
    len = (int)strlen(out);
    if (len > 0 && out[len - 1] != '/' && out[len - 1] != '\\' && len + 1 < out_cap) {
        out[len++] = separator;
        out[len] = '\0';
    }
    if (len + 1 < out_cap) strncat(out, child, (size_t)(out_cap - len - 1));
    stage89_normalize_separators(out);
}

static void stage89_apply_general(Stage89Stage *stage, const char *section, const char *key, char *value)
{
    int ok;
    long lv;
    stage89_q16 q;

    if (stage89_eqi(section, "info")) {
        stage89_unquote(value);
        if (stage89_eqi(key, "name")) stage89_copy(stage->name, STAGE89_MAX_NAME, value);
        else if (stage89_eqi(key, "displayname")) stage89_copy(stage->display_name, STAGE89_MAX_NAME, value);
        else if (stage89_eqi(key, "author")) stage89_copy(stage->author, STAGE89_MAX_NAME, value);
        else if (stage89_eqi(key, "mugenversion")) stage89_copy(stage->mugen_version, (int)sizeof(stage->mugen_version), value);
        return;
    }

    if (stage89_eqi(section, "camera")) {
        q = stage89_q16_from_text(value, &ok);
        if (!ok) return;
        if (stage89_eqi(key, "startx")) stage->camera_start_x = q;
        else if (stage89_eqi(key, "starty")) stage->camera_start_y = q;
        else if (stage89_eqi(key, "boundleft")) stage->bound_left = q;
        else if (stage89_eqi(key, "boundright")) stage->bound_right = q;
        else if (stage89_eqi(key, "boundhigh")) stage->bound_high = q;
        else if (stage89_eqi(key, "boundlow")) stage->bound_low = q;
        else if (stage89_eqi(key, "tension")) stage->tension = q;
        else if (stage89_eqi(key, "verticalfollow")) stage->vertical_follow = q;
        else if (stage89_eqi(key, "startzoom")) stage->start_zoom = q;
        else if (stage89_eqi(key, "zoomout")) stage->zoom_out = q;
        else if (stage89_eqi(key, "zoomin")) stage->zoom_in = q;
        return;
    }

    if (stage89_eqi(section, "playerinfo")) {
        lv = stage89_parse_long(value, &ok);
        if (!ok) return;
        if (stage89_eqi(key, "p1startx")) stage->p1_start_x = (int)lv;
        else if (stage89_eqi(key, "p1starty")) stage->p1_start_y = (int)lv;
        else if (stage89_eqi(key, "p1facing")) stage->p1_facing = (int)lv;
        else if (stage89_eqi(key, "p2startx")) stage->p2_start_x = (int)lv;
        else if (stage89_eqi(key, "p2starty")) stage->p2_start_y = (int)lv;
        else if (stage89_eqi(key, "p2facing")) stage->p2_facing = (int)lv;
        return;
    }

    if (stage89_eqi(section, "stageinfo")) {
        if (stage89_eqi(key, "localcoord")) {
            stage89_parse_int_pair(value, &stage->localcoord_x, &stage->localcoord_y);
            stage->localcoord_explicit = 1;
        } else if (stage89_eqi(key, "hires")) {
            lv = stage89_parse_long(value, &ok);
            if (ok) stage->hires = (int)lv;
        } else if (stage89_eqi(key, "zoffset")) {
            lv = stage89_parse_long(value, &ok);
            if (ok) stage->zoffset = (int)lv;
        } else if (stage89_eqi(key, "zoffsetlink")) {
            lv = stage89_parse_long(value, &ok);
            if (ok) stage->zoffset_link = lv;
        }
        return;
    }

    if (stage89_eqi(section, "bgdef")) {
        if (stage89_eqi(key, "spr")) {
            stage89_unquote(value);
            stage89_copy(stage->sff_name, STAGE89_MAX_PATH, value);
        } else if (stage89_eqi(key, "debugbg")) {
            lv = stage89_parse_long(value, &ok);
            if (ok) stage->debug_bg = (int)lv;
        }
    }
}

static void stage89_apply_bg(Stage89Bg *bg, const char *key, char *value)
{
    int ok;
    long lv;
    stage89_q16 q;

    if (stage89_eqi(key, "type")) {
        if (stage89_starts_i(value, "parallax")) bg->type = STAGE89_BG_PARALLAX;
        else if (stage89_starts_i(value, "anim") || stage89_starts_i(value, "ani")) {
            bg->type = STAGE89_BG_ANIM;
            bg->mask = 1;
        } else if (stage89_starts_i(value, "dummy")) bg->type = STAGE89_BG_DUMMY;
        else bg->type = STAGE89_BG_NORMAL;
    } else if (stage89_eqi(key, "actionno")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->action_no = lv;
    } else if (stage89_eqi(key, "spriteno")) {
        stage89_parse_int_pair(value, &bg->group, &bg->item);
    } else if (stage89_eqi(key, "layerno")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->layerno = (int)lv;
    } else if (stage89_eqi(key, "start")) {
        stage89_parse_q16_pair(value, &bg->start_x, &bg->start_y);
    } else if (stage89_eqi(key, "delta")) {
        stage89_parse_q16_pair(value, &bg->delta_x, &bg->delta_y);
    } else if (stage89_eqi(key, "velocity")) {
        stage89_parse_q16_pair(value, &bg->velocity_x, &bg->velocity_y);
    } else if (stage89_eqi(key, "tile")) {
        stage89_parse_int_pair(value, &bg->tile_x, &bg->tile_y);
    } else if (stage89_eqi(key, "tilespacing")) {
        stage89_parse_int_pair(value, &bg->tile_spacing_x, &bg->tile_spacing_y);
    } else if (stage89_eqi(key, "mask")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->mask = (int)lv;
    } else if (stage89_eqi(key, "id")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->id = lv;
    } else if (stage89_eqi(key, "visible")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->visible = (int)lv;
    } else if (stage89_eqi(key, "positionlink")) {
        lv = stage89_parse_long(value, &ok); if (ok) bg->position_link = (int)lv;
    } else if (stage89_eqi(key, "sin.x")) {
        if (stage89_parse_osc(value, &bg->sin_x)) bg->has_sin_x = 1;
    } else if (stage89_eqi(key, "sin.y")) {
        if (stage89_parse_osc(value, &bg->sin_y)) bg->has_sin_y = 1;
    } else if (stage89_eqi(key, "xscale")) {
        stage89_parse_q16_pair(value, &bg->xscale_top, &bg->xscale_bottom);
        bg->parallax_mode = STAGE89_PARALLAX_XSCALE;
    } else if (stage89_eqi(key, "width")) {
        stage89_parse_q16_pair(value, &bg->width_top, &bg->width_bottom);
        if (bg->width_top > 0 && bg->width_bottom > 0) bg->parallax_mode = STAGE89_PARALLAX_WIDTH;
    } else if (stage89_eqi(key, "yscalestart")) {
        q = stage89_q16_from_text(value, &ok); if (ok) bg->yscale_start = q;
    } else if (stage89_eqi(key, "yscaledelta")) {
        q = stage89_q16_from_text(value, &ok); if (ok) bg->yscale_delta = q;
    } else if (stage89_eqi(key, "trans")) {
        if (stage89_starts_i(value, "addalpha")) bg->trans = STAGE89_TRANS_ADDALPHA;
        else if (stage89_starts_i(value, "add1")) bg->trans = STAGE89_TRANS_ADD1;
        else if (stage89_starts_i(value, "add")) bg->trans = STAGE89_TRANS_ADD;
        else if (stage89_starts_i(value, "sub")) bg->trans = STAGE89_TRANS_SUB;
        else bg->trans = STAGE89_TRANS_NONE;
    } else if (stage89_eqi(key, "alpha")) {
        stage89_parse_int_pair(value, &bg->alpha_src, &bg->alpha_dst);
    }
}

int stage89_stage_parse(Stage89Stage *stage, const char *def_path, char *text, unsigned long text_size)
{
    char section[STAGE89_MAX_NAME];
    char *line;
    char *next;
    char *eq;
    char *key;
    char *value;
    char *end;
    Stage89Bg *current_bg;
    unsigned long i;

    if (stage == (Stage89Stage*)0 || text == (char*)0 || text_size == 0UL) return 0;
    stage89_stage_init(stage);
    (void)aas_parse_text(&stage->actions, text, text_size);
    (void)bgc_parse_text(&stage->bgctrls, text, text_size);
    stage89_copy(stage->def_path, STAGE89_MAX_PATH, def_path != (const char*)0 ? def_path : "");
    stage89_path_dirname(stage->def_path, stage->base_dir, STAGE89_MAX_PATH);
    section[0] = '\0';
    current_bg = (Stage89Bg*)0;

    for (i = 0UL; i < text_size; ++i) {
        if (text[i] == '\0') break;
    }
    if (i == text_size) text[text_size - 1UL] = '\0';

    line = text;
    while (*line != '\0') {
        next = line;
        while (*next != '\0' && *next != '\n') ++next;
        if (*next == '\n') { *next = '\0'; ++next; }
        stage89_strip_comment(line);
        line = stage89_trim(line);
        if (*line != '\0') {
            if (*line == '[') {
                end = strchr(line + 1, ']');
                if (end != (char*)0) {
                    *end = '\0';
                    stage89_copy(section, STAGE89_MAX_NAME, stage89_trim(line + 1));
                    current_bg = (Stage89Bg*)0;
                    if (stage89_starts_i(section, "bg ") || stage89_eqi(section, "bg")) {
                        if (stage->bg_count < STAGE89_MAX_BG) {
                            current_bg = &stage->bg[stage->bg_count++];
                            stage89_bg_defaults(current_bg);
                            stage89_copy(current_bg->name, STAGE89_MAX_NAME, section);
                        } else {
                            stage89_diag(stage, "BG capacity reached; remaining background sections ignored.");
                        }
                    }
                }
            } else {
                eq = strchr(line, '=');
                if (eq != (char*)0) {
                    *eq = '\0';
                    key = stage89_trim(line);
                    value = stage89_trim(eq + 1);
                    if (current_bg != (Stage89Bg*)0) stage89_apply_bg(current_bg, key, value);
                    else stage89_apply_general(stage, section, key, value);
                }
            }
        }
        line = next;
    }

    if (stage->display_name[0] == '\0') stage89_copy(stage->display_name, STAGE89_MAX_NAME, stage->name);
    if (stage89_eqi(stage->display_name, "Unnamed Stage")) {
        stage89_copy(stage->display_name, STAGE89_MAX_NAME, stage->name);
    }

    /* WinMUGEN high-resolution stages use 640x480 stage coordinates when
       localcoord is absent. Explicit localcoord always wins. */
    if (stage->hires != 0 && !stage->localcoord_explicit) {
        stage->localcoord_x = 640;
        stage->localcoord_y = 480;
    }
    if (stage->localcoord_x <= 0) stage->localcoord_x = 320;
    if (stage->localcoord_y <= 0) stage->localcoord_y = 240;
    if (stage->sff_name[0] == '\0') {
        stage89_diag(stage, "No [BGDef] spr entry was found.");
        return 0;
    }
    stage89_path_join(stage->base_dir, stage->sff_name, stage->sff_path, STAGE89_MAX_PATH);
    stage89_path_join(stage->base_dir, stage89_path_basename(stage->sff_name),
                      stage->sff_fallback_path, STAGE89_MAX_PATH);
    stage->sff_used_fallback = 0;
    if (!stage89_file_exists(stage->sff_path) && stage89_file_exists(stage->sff_fallback_path)) {
        stage89_copy(stage->sff_path, STAGE89_MAX_PATH, stage->sff_fallback_path);
        stage->sff_used_fallback = 1;
        stage89_diag(stage, "SFF path recovered from sibling basename fallback.");
    }
    for (i = 0UL; i < (unsigned long)stage->bg_count; ++i) {
        Stage89Bg *bg;
        bg = &stage->bg[i];
        if (bg->type == STAGE89_BG_ANIM) {
            bg->action_index = aas_find_action(&stage->actions, bg->action_no);
            bg->mask = 1;
            if (bg->action_index < 0) stage89_diag(stage, "Animated BG references a missing action.");
        }
    }
    if (stage->bgctrls.truncated_def_count > 0) stage89_diag(stage, "BGCtrlDef capacity reached; remaining groups ignored.");
    if (stage->bgctrls.truncated_ctrl_count > 0) stage89_diag(stage, "BGCtrl capacity reached; remaining controllers ignored.");
    if (stage->bgctrls.unknown_type_count > 0) stage89_diag(stage, "Unknown BGCtrl types were ignored.");
    if (stage->bgctrls.malformed_count > 0) stage89_diag(stage, "Malformed BGCtrl values were tolerated or ignored.");
    if (stage->bg_count <= 0) stage89_diag(stage, "No [BG ...] sections were found.");
    return 1;
}
