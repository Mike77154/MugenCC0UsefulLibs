#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <stdio.h>
#include <string.h>

#include "stage89_stage.h"
#include "stage89_render.h"
#include "sff_api.h"

#define APP_CLASS "Stage89ViewerWindow"
#define APP_TITLE "stage89 v0.4.0 - MUGEN BGCtrl Flow Viewer"

#define ID_OPEN 1001
#define ID_RELOAD 1002
#define ID_RESET 1003
#define ID_PAUSE 1004
#define ID_GRID 1005
#define ID_PLAYERS 1006
#define ID_FOREGROUND 1007
#define ID_STAGE_LIST 1010
#define ID_PATH_EDIT 1011
#define ID_STATUS 1012

#define APP_TIMER 1
#define APP_TIMER_MS 16
#define APP_SIDEBAR 300
#define APP_STATUS_H 24
#define APP_BUTTON_H 25
#define APP_MARGIN 7

#define APP_DEF_CAP (2UL * 1024UL * 1024UL)
#define APP_PIXEL_CAP (64UL * 1024UL * 1024UL)
#define APP_WORK_CAP (16UL * 1024UL * 1024UL)
#define APP_FRAME_W 1600
#define APP_FRAME_H 900

typedef struct Stage89WinSource {
    HANDLE handle;
    sff_u32 size;
} Stage89WinSource;

typedef struct Stage89App {
    HINSTANCE instance;
    HWND window;
    HWND open_button;
    HWND reload_button;
    HWND reset_button;
    HWND pause_button;
    HWND grid_button;
    HWND players_button;
    HWND foreground_button;
    HWND path_edit;
    HWND stage_list;
    HWND status;
    RECT render_rect;
    HDC back_dc;
    HBITMAP back_bitmap;
    HBITMAP back_old_bitmap;
    void *back_bits;
    int back_width;
    int back_height;
    char current_path[STAGE89_MAX_PATH];
    char current_dir[STAGE89_MAX_PATH];
    int loaded;
    int dragging;
    int drag_x;
    int drag_y;
    Stage89Stage stage;
    Stage89Runtime runtime;
    Stage89View view;
    SffFile sff;
} Stage89App;

static Stage89App g_app;
static char g_def_text[APP_DEF_CAP];
static unsigned char g_pixel_arena[APP_PIXEL_CAP];
static unsigned char g_decode_work[APP_WORK_CAP];
static unsigned long g_framebuffer[APP_FRAME_W * APP_FRAME_H];
static char g_dialog_path[STAGE89_MAX_PATH];

static int app_win_read_at(void *user, sff_u32 offset, void *dst, sff_u32 len)
{
    Stage89WinSource *source;
    DWORD moved;
    DWORD got;
    source = (Stage89WinSource*)user;
    if (source == (Stage89WinSource*)0 || source->handle == INVALID_HANDLE_VALUE || dst == (void*)0) return 0;
    SetLastError(NO_ERROR);
    moved = SetFilePointer(source->handle, (LONG)offset, (PLONG)0, FILE_BEGIN);
    if (moved == INVALID_SET_FILE_POINTER && GetLastError() != NO_ERROR) return 0;
    got = 0u;
    if (!ReadFile(source->handle, dst, (DWORD)len, &got, (LPOVERLAPPED)0)) return 0;
    return got == (DWORD)len;
}

static int app_read_whole_file(const char *path, char *buffer, unsigned long capacity, unsigned long *out_size)
{
    HANDLE file;
    DWORD size_high;
    DWORD size_low;
    DWORD got;
    if (path == (const char*)0 || buffer == (char*)0 || capacity < 2UL) return 0;
    file = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, (LPSECURITY_ATTRIBUTES)0,
                       OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, (HANDLE)0);
    if (file == INVALID_HANDLE_VALUE) return 0;
    size_high = 0u;
    size_low = GetFileSize(file, &size_high);
    if (size_low == INVALID_FILE_SIZE && GetLastError() != NO_ERROR) { CloseHandle(file); return 0; }
    if (size_high != 0u || (unsigned long)size_low + 1UL > capacity) { CloseHandle(file); return 0; }
    got = 0u;
    if (!ReadFile(file, buffer, size_low, &got, (LPOVERLAPPED)0) || got != size_low) {
        CloseHandle(file);
        return 0;
    }
    buffer[got] = '\0';
    CloseHandle(file);
    if (out_size != (unsigned long*)0) *out_size = (unsigned long)got + 1UL;
    return 1;
}

static const char *app_basename(const char *path)
{
    const char *base;
    if (path == (const char*)0) return "";
    base = path;
    while (*path != '\0') {
        if (*path == '/' || *path == '\\') base = path + 1;
        ++path;
    }
    return base;
}

static int app_file_exists(const char *path)
{
    DWORD attr;
    attr = GetFileAttributesA(path);
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0u;
}

static void app_update_status(void)
{
    char camera_x[32];
    char camera_y[32];
    char zoom[32];
    char text[512];
    if (!g_app.loaded) {
        SetWindowTextA(g_app.status, "Abre un .def de MUGEN para comenzar.");
        return;
    }
    stage89_q16_to_text(g_app.view.camera_x, camera_x, (int)sizeof(camera_x));
    stage89_q16_to_text(g_app.view.camera_y, camera_y, (int)sizeof(camera_y));
    stage89_q16_to_text(g_app.view.zoom, zoom, (int)sizeof(zoom));
    wsprintfA(text, "%s | BG %d | anim %d | AIR %d | BGCtrl %d | sprites %d | %lu KB | miss %d | err %d | tick %lu | cam %s,%s | zoom %s",
              g_app.stage.display_name, g_app.stage.bg_count, g_app.runtime.animated_bg_count,
              g_app.stage.actions.action_count, g_app.stage.bgctrls.ctrl_count, g_app.runtime.cache_count,
              g_app.runtime.pixel_used / 1024UL, g_app.runtime.missing_sprites,
              g_app.runtime.decode_errors, g_app.view.tick, camera_x, camera_y, zoom);
    SetWindowTextA(g_app.status, text);
}

static void app_select_current_in_list(void)
{
    int count;
    int i;
    char item[MAX_PATH];
    const char *base;
    base = app_basename(g_app.current_path);
    count = (int)SendMessageA(g_app.stage_list, LB_GETCOUNT, 0u, 0L);
    for (i = 0; i < count; ++i) {
        item[0] = '\0';
        SendMessageA(g_app.stage_list, LB_GETTEXT, (WPARAM)i, (LPARAM)item);
        if (lstrcmpiA(item, base) == 0) {
            SendMessageA(g_app.stage_list, LB_SETCURSEL, (WPARAM)i, 0L);
            return;
        }
    }
}

static void app_populate_stage_list(const char *directory)
{
    char pattern[STAGE89_MAX_PATH];
    WIN32_FIND_DATAA data;
    HANDLE find;
    int len;
    SendMessageA(g_app.stage_list, LB_RESETCONTENT, 0u, 0L);
    lstrcpynA(g_app.current_dir, directory, STAGE89_MAX_PATH);
    stage89_path_join(directory, "*.def", pattern, STAGE89_MAX_PATH);
    len = lstrlenA(pattern);
    (void)len;
    find = FindFirstFileA(pattern, &data);
    if (find != INVALID_HANDLE_VALUE) {
        do {
            if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0u) {
                SendMessageA(g_app.stage_list, LB_ADDSTRING, 0u, (LPARAM)data.cFileName);
            }
        } while (FindNextFileA(find, &data));
        FindClose(find);
    }
    app_select_current_in_list();
}

static int app_open_sff(const char *path, Stage89WinSource *source, SffIo *io)
{
    DWORD high;
    DWORD low;
    source->handle = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, (LPSECURITY_ATTRIBUTES)0,
                                 OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS, (HANDLE)0);
    if (source->handle == INVALID_HANDLE_VALUE) return 0;
    high = 0u;
    low = GetFileSize(source->handle, &high);
    if ((low == INVALID_FILE_SIZE && GetLastError() != NO_ERROR) || high != 0u) {
        CloseHandle(source->handle);
        source->handle = INVALID_HANDLE_VALUE;
        return 0;
    }
    source->size = (sff_u32)low;
    io->read_at = app_win_read_at;
    io->user = source;
    io->size = source->size;
    return 1;
}

static void app_show_error(const char *title, const char *detail)
{
    MessageBoxA(g_app.window, detail, title, MB_OK | MB_ICONERROR);
}

static int app_load_stage(const char *path)
{
    unsigned long def_size;
    Stage89WinSource source;
    SffIo io;
    SffOpenOptions options;
    int result;
    char message[1400];
    char dir[STAGE89_MAX_PATH];

    g_app.loaded = 0;
    app_update_status();
    InvalidateRect(g_app.window, &g_app.render_rect, FALSE);
    if (!app_read_whole_file(path, g_def_text, APP_DEF_CAP, &def_size)) {
        app_show_error("No pude abrir el DEF", "El archivo no existe, es demasiado grande o Windows no permitió leerlo.");
        return 0;
    }
    if (!stage89_stage_parse(&g_app.stage, path, g_def_text, def_size)) {
        wsprintfA(message, "No pude convertir el stage.\r\n\r\nDEF: %s", path);
        app_show_error("DEF incompleto", message);
        return 0;
    }
    if (!app_open_sff(g_app.stage.sff_path, &source, &io)) {
        wsprintfA(message, "El DEF abrió, pero su SFF no.\r\n\r\n%s", g_app.stage.sff_path);
        app_show_error("SFF ausente", message);
        return 0;
    }
    options.tolerant = 1;
    options.codec = (const SffImageCodec*)0;
    sff_init(&g_app.sff);
    result = sff_open_io(&g_app.sff, &io, &options);
    if (result != SFF_OK) {
        wsprintfA(message, "sff_open_io devolvió %d.\r\n\r\n%s", result, g_app.stage.sff_path);
        CloseHandle(source.handle);
        app_show_error("SFF no compatible o dañado", message);
        return 0;
    }
    stage89_runtime_init(&g_app.runtime, &g_app.stage,
                         g_pixel_arena, APP_PIXEL_CAP, g_decode_work, APP_WORK_CAP);
    result = stage89_runtime_decode(&g_app.runtime, &g_app.sff);
    sff_close(&g_app.sff);
    CloseHandle(source.handle);
    if (!result) {
        wsprintfA(message, "El SFF abrió, pero ningún sprite usado por los BG pudo decodificarse.\r\n\r\nMissing: %d\r\nDecode errors: %d\r\nÚltimo SFF error: %d",
                  g_app.runtime.missing_sprites, g_app.runtime.decode_errors, g_app.runtime.last_sff_error);
        app_show_error("Stage sin sprites visibles", message);
        return 0;
    }
    lstrcpynA(g_app.current_path, path, STAGE89_MAX_PATH);
    stage89_path_dirname(path, dir, STAGE89_MAX_PATH);
    SetWindowTextA(g_app.path_edit, path);
    stage89_view_reset(&g_app.view, &g_app.stage);
    SendMessageA(g_app.grid_button, BM_SETCHECK, BST_UNCHECKED, 0L);
    SendMessageA(g_app.players_button, BM_SETCHECK, BST_CHECKED, 0L);
    SendMessageA(g_app.foreground_button, BM_SETCHECK, BST_CHECKED, 0L);
    SetWindowTextA(g_app.pause_button, "Pausa");
    g_app.loaded = 1;
    app_populate_stage_list(dir);
    app_update_status();
    InvalidateRect(g_app.window, &g_app.render_rect, FALSE);
    return 1;
}

static void app_open_dialog(void)
{
    OPENFILENAMEA ofn;
    ZeroMemory(&ofn, sizeof(ofn));
    g_dialog_path[0] = '\0';
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_app.window;
    ofn.lpstrFilter = "MUGEN Stage DEF\0*.def\0All files\0*.*\0\0";
    ofn.lpstrFile = g_dialog_path;
    ofn.nMaxFile = STAGE89_MAX_PATH;
    ofn.lpstrInitialDir = g_app.current_dir[0] != '\0' ? g_app.current_dir : (const char*)0;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
    if (GetOpenFileNameA(&ofn)) app_load_stage(g_dialog_path);
}

static void app_load_selected(void)
{
    int sel;
    char file[MAX_PATH];
    char full[STAGE89_MAX_PATH];
    sel = (int)SendMessageA(g_app.stage_list, LB_GETCURSEL, 0u, 0L);
    if (sel == LB_ERR) return;
    file[0] = '\0';
    SendMessageA(g_app.stage_list, LB_GETTEXT, (WPARAM)sel, (LPARAM)file);
    stage89_path_join(g_app.current_dir, file, full, STAGE89_MAX_PATH);
    app_load_stage(full);
}

static void app_layout(int width, int height)
{
    int x;
    int y;
    int half;
    int list_top;
    if (width < 420) width = 420;
    if (height < 260) height = 260;
    x = APP_MARGIN;
    y = APP_MARGIN;
    half = (APP_SIDEBAR - APP_MARGIN * 3) / 2;
    MoveWindow(g_app.open_button, x, y, half, APP_BUTTON_H, TRUE);
    MoveWindow(g_app.reload_button, x + half + APP_MARGIN, y, half, APP_BUTTON_H, TRUE);
    y += APP_BUTTON_H + APP_MARGIN;
    MoveWindow(g_app.reset_button, x, y, half, APP_BUTTON_H, TRUE);
    MoveWindow(g_app.pause_button, x + half + APP_MARGIN, y, half, APP_BUTTON_H, TRUE);
    y += APP_BUTTON_H + APP_MARGIN;
    MoveWindow(g_app.grid_button, x, y, half, APP_BUTTON_H, TRUE);
    MoveWindow(g_app.players_button, x + half + APP_MARGIN, y, half, APP_BUTTON_H, TRUE);
    y += APP_BUTTON_H + APP_MARGIN;
    MoveWindow(g_app.foreground_button, x, y, APP_SIDEBAR - APP_MARGIN * 2, APP_BUTTON_H, TRUE);
    y += APP_BUTTON_H + APP_MARGIN;
    MoveWindow(g_app.path_edit, x, y, APP_SIDEBAR - APP_MARGIN * 2, 23, TRUE);
    list_top = y + 23 + APP_MARGIN;
    MoveWindow(g_app.stage_list, x, list_top, APP_SIDEBAR - APP_MARGIN * 2,
               height - list_top - APP_STATUS_H - APP_MARGIN, TRUE);
    MoveWindow(g_app.status, 0, height - APP_STATUS_H, width, APP_STATUS_H, TRUE);
    g_app.render_rect.left = APP_SIDEBAR;
    g_app.render_rect.top = 0;
    g_app.render_rect.right = width;
    g_app.render_rect.bottom = height - APP_STATUS_H;
}

static void app_destroy_backbuffer(void)
{
    if (g_app.back_dc != (HDC)0) {
        if (g_app.back_old_bitmap != (HBITMAP)0) {
            SelectObject(g_app.back_dc, g_app.back_old_bitmap);
        }
        if (g_app.back_bitmap != (HBITMAP)0) DeleteObject(g_app.back_bitmap);
        DeleteDC(g_app.back_dc);
    }
    g_app.back_dc = (HDC)0;
    g_app.back_bitmap = (HBITMAP)0;
    g_app.back_old_bitmap = (HBITMAP)0;
    g_app.back_bits = (void*)0;
    g_app.back_width = 0;
    g_app.back_height = 0;
}

static int app_ensure_backbuffer(HWND window, int width, int height)
{
    HDC window_dc;
    HDC memory_dc;
    HBITMAP bitmap;
    HBITMAP old_bitmap;
    BITMAPINFO info;
    void *bits;

    if (width <= 0 || height <= 0) return 0;
    if (g_app.back_dc != (HDC)0 && g_app.back_width == width && g_app.back_height == height) return 1;
    app_destroy_backbuffer();

    window_dc = GetDC(window);
    if (window_dc == (HDC)0) return 0;
    memory_dc = CreateCompatibleDC(window_dc);
    if (memory_dc == (HDC)0) {
        ReleaseDC(window, window_dc);
        return 0;
    }
    ZeroMemory(&info, sizeof(info));
    info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    info.bmiHeader.biCompression = BI_RGB;
    bits = (void*)0;
    bitmap = CreateDIBSection(window_dc, &info, DIB_RGB_COLORS, &bits, (HANDLE)0, 0u);
    ReleaseDC(window, window_dc);
    if (bitmap == (HBITMAP)0 || bits == (void*)0) {
        if (bitmap != (HBITMAP)0) DeleteObject(bitmap);
        DeleteDC(memory_dc);
        return 0;
    }
    old_bitmap = (HBITMAP)SelectObject(memory_dc, bitmap);
    if (old_bitmap == (HBITMAP)0 || old_bitmap == (HBITMAP)HGDI_ERROR) {
        DeleteObject(bitmap);
        DeleteDC(memory_dc);
        return 0;
    }
    g_app.back_dc = memory_dc;
    g_app.back_bitmap = bitmap;
    g_app.back_old_bitmap = old_bitmap;
    g_app.back_bits = bits;
    g_app.back_width = width;
    g_app.back_height = height;
    return 1;
}

static void app_paint(HWND window)
{
    PAINTSTRUCT ps;
    HDC dc;
    RECT target;
    int rw;
    int rh;
    int sw;
    int sh;
    BITMAPINFO info;
    Stage89Surface surface;
    char overlay[512];
    int old_mode;
    COLORREF old_color;
    const char *hint;

    dc = BeginPaint(window, &ps);
    rw = g_app.render_rect.right - g_app.render_rect.left;
    rh = g_app.render_rect.bottom - g_app.render_rect.top;
    if (rw <= 0 || rh <= 0) {
        EndPaint(window, &ps);
        return;
    }
    if (!app_ensure_backbuffer(window, rw, rh)) {
        FillRect(dc, &g_app.render_rect, (HBRUSH)GetStockObject(BLACK_BRUSH));
        EndPaint(window, &ps);
        return;
    }

    target.left = 0;
    target.top = 0;
    target.right = rw;
    target.bottom = rh;
    FillRect(g_app.back_dc, &target, (HBRUSH)GetStockObject(BLACK_BRUSH));

    if (g_app.loaded) {
        sw = rw > APP_FRAME_W ? APP_FRAME_W : rw;
        sh = rh > APP_FRAME_H ? APP_FRAME_H : rh;
        surface.pixels = g_framebuffer;
        surface.width = sw;
        surface.height = sh;
        surface.stride = sw;
        stage89_render(&g_app.runtime, &g_app.view, &surface);
        ZeroMemory(&info, sizeof(info));
        info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        info.bmiHeader.biWidth = sw;
        info.bmiHeader.biHeight = -sh;
        info.bmiHeader.biPlanes = 1;
        info.bmiHeader.biBitCount = 32;
        info.bmiHeader.biCompression = BI_RGB;
        SetStretchBltMode(g_app.back_dc, COLORONCOLOR);
        StretchDIBits(g_app.back_dc, 0, 0, rw, rh,
                      0, 0, sw, sh, g_framebuffer, &info, DIB_RGB_COLORS, SRCCOPY);
        wsprintfA(overlay, "%s  |  %dx%d  |  %s  |  WASD/flechas: camara  rueda:+/-: zoom  espacio: pausa",
                  g_app.stage.display_name, g_app.stage.localcoord_x, g_app.stage.localcoord_y,
                  g_app.stage.mugen_version);
        old_mode = SetBkMode(g_app.back_dc, TRANSPARENT);
        old_color = SetTextColor(g_app.back_dc, RGB(255, 255, 255));
        TextOutA(g_app.back_dc, 10, 8, overlay, lstrlenA(overlay));
        SetTextColor(g_app.back_dc, old_color);
        SetBkMode(g_app.back_dc, old_mode);
    } else {
        hint = "Abre un stage .def o arrastralo aqui";
        old_mode = SetBkMode(g_app.back_dc, TRANSPARENT);
        old_color = SetTextColor(g_app.back_dc, RGB(220, 220, 220));
        TextOutA(g_app.back_dc, 30, 40, hint, lstrlenA(hint));
        SetTextColor(g_app.back_dc, old_color);
        SetBkMode(g_app.back_dc, old_mode);
    }

    /* Una sola copia visible: todo el cuadro y su overlay ya estan terminados. */
    BitBlt(dc, g_app.render_rect.left, g_app.render_rect.top, rw, rh,
           g_app.back_dc, 0, 0, SRCCOPY);
    EndPaint(window, &ps);
}

static void app_clamp_camera(void)
{
    g_app.view.camera_x = stage89_q16_clamp(g_app.view.camera_x, g_app.stage.bound_left, g_app.stage.bound_right);
    g_app.view.camera_y = stage89_q16_clamp(g_app.view.camera_y, g_app.stage.bound_high, g_app.stage.bound_low);
    g_app.view.zoom = stage89_q16_clamp(g_app.view.zoom, 16384L, 262144L);
}

static void app_poll_input(void)
{
    stage89_q16 speed;
    if (!g_app.loaded) return;
    speed = stage89_q16_from_int(3L);
    if ((GetAsyncKeyState(VK_LEFT) & 0x8000) || (GetAsyncKeyState('A') & 0x8000)) g_app.view.camera_x -= speed;
    if ((GetAsyncKeyState(VK_RIGHT) & 0x8000) || (GetAsyncKeyState('D') & 0x8000)) g_app.view.camera_x += speed;
    if ((GetAsyncKeyState(VK_UP) & 0x8000) || (GetAsyncKeyState('W') & 0x8000)) g_app.view.camera_y -= speed;
    if ((GetAsyncKeyState(VK_DOWN) & 0x8000) || (GetAsyncKeyState('S') & 0x8000)) g_app.view.camera_y += speed;
    app_clamp_camera();
    stage89_view_tick(&g_app.view);
}

static void app_toggle_pause(void)
{
    g_app.view.paused = !g_app.view.paused;
    SetWindowTextA(g_app.pause_button, g_app.view.paused ? "Continuar" : "Pausa");
}

static void app_mouse_drag(int x, int y)
{
    int dx;
    int dy;
    int rw;
    int rh;
    int ok;
    stage89_q16 qx;
    stage89_q16 qy;
    if (!g_app.loaded || !g_app.dragging) return;
    dx = x - g_app.drag_x;
    dy = y - g_app.drag_y;
    g_app.drag_x = x;
    g_app.drag_y = y;
    rw = g_app.render_rect.right - g_app.render_rect.left;
    rh = g_app.render_rect.bottom - g_app.render_rect.top;
    if (rw <= 0 || rh <= 0) return;
    qx = stage89_q16_div(stage89_q16_from_int((long)(dx * g_app.stage.localcoord_x)), stage89_q16_from_int((long)rw), &ok);
    if (!ok) qx = 0;
    qy = stage89_q16_div(stage89_q16_from_int((long)(dy * g_app.stage.localcoord_y)), stage89_q16_from_int((long)rh), &ok);
    if (!ok) qy = 0;
    qx = stage89_q16_div(qx, g_app.view.zoom, &ok);
    if (!ok) qx = 0;
    qy = stage89_q16_div(qy, g_app.view.zoom, &ok);
    if (!ok) qy = 0;
    g_app.view.camera_x -= qx;
    g_app.view.camera_y -= qy;
    app_clamp_camera();
}

static LRESULT CALLBACK app_window_proc(HWND window, UINT message, WPARAM wparam, LPARAM lparam)
{
    switch (message) {
    case WM_CREATE:
        DragAcceptFiles(window, TRUE);
        SetTimer(window, APP_TIMER, APP_TIMER_MS, (TIMERPROC)0);
        return 0;
    case WM_SIZE:
        app_layout(LOWORD(lparam), HIWORD(lparam));
        InvalidateRect(window, (const RECT*)0, FALSE);
        return 0;
    case WM_COMMAND:
        switch (LOWORD(wparam)) {
        case ID_OPEN: app_open_dialog(); return 0;
        case ID_RELOAD: if (g_app.current_path[0] != '\0') app_load_stage(g_app.current_path); return 0;
        case ID_RESET: if (g_app.loaded) { stage89_view_reset(&g_app.view, &g_app.stage); app_update_status(); } return 0;
        case ID_PAUSE: if (g_app.loaded) app_toggle_pause(); return 0;
        case ID_GRID:
            g_app.view.show_grid = SendMessageA(g_app.grid_button, BM_GETCHECK, 0u, 0L) == BST_CHECKED;
            return 0;
        case ID_PLAYERS:
            g_app.view.show_players = SendMessageA(g_app.players_button, BM_GETCHECK, 0u, 0L) == BST_CHECKED;
            return 0;
        case ID_FOREGROUND:
            g_app.view.show_foreground = SendMessageA(g_app.foreground_button, BM_GETCHECK, 0u, 0L) == BST_CHECKED;
            return 0;
        case ID_STAGE_LIST:
            if (HIWORD(wparam) == LBN_DBLCLK) app_load_selected();
            return 0;
        default: break;
        }
        break;
    case WM_TIMER:
        if (wparam == APP_TIMER) {
            app_poll_input();
            if ((g_app.view.tick & 15UL) == 0UL) app_update_status();
            InvalidateRect(window, &g_app.render_rect, FALSE);
        }
        return 0;
    case WM_KEYDOWN:
        if (wparam == VK_SPACE) { if (g_app.loaded) app_toggle_pause(); return 0; }
        if ((wparam == VK_OEM_PERIOD) && g_app.loaded && g_app.view.paused) {
            ++g_app.view.tick; app_update_status(); InvalidateRect(window, &g_app.render_rect, FALSE); return 0;
        }
        if ((wparam == VK_OEM_COMMA) && g_app.loaded && g_app.view.paused) {
            if (g_app.view.tick > 0UL) --g_app.view.tick;
            app_update_status(); InvalidateRect(window, &g_app.render_rect, FALSE); return 0;
        }
        if (wparam == 'R') { if (g_app.loaded) stage89_view_reset(&g_app.view, &g_app.stage); return 0; }
        if (wparam == 'G') {
            g_app.view.show_grid = !g_app.view.show_grid;
            SendMessageA(g_app.grid_button, BM_SETCHECK, g_app.view.show_grid ? BST_CHECKED : BST_UNCHECKED, 0L);
            return 0;
        }
        if (wparam == 'P') {
            g_app.view.show_players = !g_app.view.show_players;
            SendMessageA(g_app.players_button, BM_SETCHECK, g_app.view.show_players ? BST_CHECKED : BST_UNCHECKED, 0L);
            return 0;
        }
        if (wparam == 'F') {
            g_app.view.show_foreground = !g_app.view.show_foreground;
            SendMessageA(g_app.foreground_button, BM_SETCHECK, g_app.view.show_foreground ? BST_CHECKED : BST_UNCHECKED, 0L);
            return 0;
        }
        if (wparam == VK_ADD || wparam == VK_OEM_PLUS) {
            g_app.view.zoom = stage89_q16_mul(g_app.view.zoom, 72090L);
            app_clamp_camera();
            return 0;
        }
        if (wparam == VK_SUBTRACT || wparam == VK_OEM_MINUS) {
            g_app.view.zoom = stage89_q16_mul(g_app.view.zoom, 59578L);
            app_clamp_camera();
            return 0;
        }
        break;
    case WM_MOUSEWHEEL:
        if (GET_WHEEL_DELTA_WPARAM(wparam) > 0) g_app.view.zoom = stage89_q16_mul(g_app.view.zoom, 72090L);
        else g_app.view.zoom = stage89_q16_mul(g_app.view.zoom, 59578L);
        app_clamp_camera();
        return 0;
    case WM_LBUTTONDOWN:
        if (LOWORD(lparam) >= g_app.render_rect.left && LOWORD(lparam) < g_app.render_rect.right &&
            HIWORD(lparam) >= g_app.render_rect.top && HIWORD(lparam) < g_app.render_rect.bottom) {
            g_app.dragging = 1;
            g_app.drag_x = LOWORD(lparam);
            g_app.drag_y = HIWORD(lparam);
            SetCapture(window);
        }
        return 0;
    case WM_MOUSEMOVE:
        if (g_app.dragging) app_mouse_drag((short)LOWORD(lparam), (short)HIWORD(lparam));
        return 0;
    case WM_LBUTTONUP:
        if (g_app.dragging) { g_app.dragging = 0; ReleaseCapture(); }
        return 0;
    case WM_DROPFILES:
        {
            HDROP drop;
            char path[STAGE89_MAX_PATH];
            drop = (HDROP)wparam;
            path[0] = '\0';
            if (DragQueryFileA(drop, 0u, path, STAGE89_MAX_PATH) != 0u) app_load_stage(path);
            DragFinish(drop);
        }
        return 0;
    case WM_PAINT:
        app_paint(window);
        return 0;
    case WM_ERASEBKGND:
        return 1;
    case WM_DESTROY:
        KillTimer(window, APP_TIMER);
        app_destroy_backbuffer();
        PostQuitMessage(0);
        return 0;
    default: break;
    }
    return DefWindowProcA(window, message, wparam, lparam);
}

static HWND app_make_control(const char *klass, const char *text, DWORD style, int id)
{
    return CreateWindowExA(0u, klass, text, WS_CHILD | WS_VISIBLE | style,
                           0, 0, 10, 10, g_app.window, (HMENU)(INT_PTR)id,
                           g_app.instance, (LPVOID)0);
}

static void app_create_controls(void)
{
    HFONT font;
    g_app.open_button = app_make_control("BUTTON", "Abrir DEF...", BS_PUSHBUTTON, ID_OPEN);
    g_app.reload_button = app_make_control("BUTTON", "Recargar", BS_PUSHBUTTON, ID_RELOAD);
    g_app.reset_button = app_make_control("BUTTON", "Reiniciar vista", BS_PUSHBUTTON, ID_RESET);
    g_app.pause_button = app_make_control("BUTTON", "Pausa", BS_PUSHBUTTON, ID_PAUSE);
    g_app.grid_button = app_make_control("BUTTON", "Rejilla", BS_AUTOCHECKBOX, ID_GRID);
    g_app.players_button = app_make_control("BUTTON", "Muñecos", BS_AUTOCHECKBOX, ID_PLAYERS);
    g_app.foreground_button = app_make_control("BUTTON", "Mostrar foreground", BS_AUTOCHECKBOX, ID_FOREGROUND);
    g_app.path_edit = app_make_control("EDIT", "", ES_AUTOHSCROLL | ES_READONLY | WS_BORDER, ID_PATH_EDIT);
    g_app.stage_list = app_make_control("LISTBOX", "", LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | WS_BORDER | WS_VSCROLL, ID_STAGE_LIST);
    g_app.status = app_make_control("STATIC", "", SS_LEFT | SS_CENTERIMAGE | WS_BORDER, ID_STATUS);
    font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    SendMessageA(g_app.open_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.reload_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.reset_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.pause_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.grid_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.players_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.foreground_button, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.path_edit, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.stage_list, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.status, WM_SETFONT, (WPARAM)font, TRUE);
    SendMessageA(g_app.players_button, BM_SETCHECK, BST_CHECKED, 0L);
    SendMessageA(g_app.foreground_button, BM_SETCHECK, BST_CHECKED, 0L);
}

static void app_clean_command_line(const char *raw, char *out, int cap)
{
    int len;
    int i;
    while (*raw == ' ' || *raw == '\t') ++raw;
    lstrcpynA(out, raw, cap);
    len = lstrlenA(out);
    while (len > 0 && (out[len - 1] == ' ' || out[len - 1] == '\t')) out[--len] = '\0';
    if (len >= 2 && out[0] == '"' && out[len - 1] == '"') {
        for (i = 1; i < len - 1; ++i) out[i - 1] = out[i];
        out[len - 2] = '\0';
    }
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previous, LPSTR command_line, int show_command)
{
    WNDCLASSEXA wc;
    MSG message;
    char startup_path[STAGE89_MAX_PATH];
    char exe_path[STAGE89_MAX_PATH];
    char exe_dir[STAGE89_MAX_PATH];
    (void)previous;
    ZeroMemory(&g_app, sizeof(g_app));
    g_app.instance = instance;
    ZeroMemory(&wc, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = app_window_proc;
    wc.hInstance = instance;
    wc.hIcon = LoadIconA((HINSTANCE)0, IDI_APPLICATION);
    wc.hCursor = LoadCursorA((HINSTANCE)0, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = APP_CLASS;
    wc.hIconSm = wc.hIcon;
    if (!RegisterClassExA(&wc)) return 1;
    g_app.window = CreateWindowExA(WS_EX_ACCEPTFILES, APP_CLASS, APP_TITLE,
                                   WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                                   CW_USEDEFAULT, CW_USEDEFAULT, 1120, 720,
                                   (HWND)0, (HMENU)0, instance, (LPVOID)0);
    if (g_app.window == (HWND)0) return 2;
    app_create_controls();
    app_layout(1120, 720);
    app_update_status();
    ShowWindow(g_app.window, show_command);
    UpdateWindow(g_app.window);

    startup_path[0] = '\0';
    app_clean_command_line(command_line, startup_path, STAGE89_MAX_PATH);
    if (startup_path[0] != '\0' && app_file_exists(startup_path)) {
        app_load_stage(startup_path);
    } else {
        GetModuleFileNameA((HMODULE)0, exe_path, STAGE89_MAX_PATH);
        stage89_path_dirname(exe_path, exe_dir, STAGE89_MAX_PATH);
        stage89_path_join(exe_dir, "corpus\\stages\\kfm.def", startup_path, STAGE89_MAX_PATH);
        if (app_file_exists(startup_path)) app_load_stage(startup_path);
    }

    while (GetMessageA(&message, (HWND)0, 0u, 0u) > 0) {
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }
    return (int)message.wParam;
}
