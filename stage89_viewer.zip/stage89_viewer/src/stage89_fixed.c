#include "stage89_fixed.h"
#include <stdio.h>
#include <string.h>

stage89_q16 stage89_q16_from_int(long value)
{
    return (stage89_q16)(value << 16);
}

stage89_q16 stage89_q16_from_text(const char *text, int *ok)
{
    int sign;
    int seen_dot;
    int digits;
    unsigned long whole;
    unsigned long frac;
    unsigned long denom;
    unsigned char c;
    stage89_q16 value;

    if (ok != (int*)0) *ok = 0;
    if (text == (const char*)0) return 0;

    while (*text == ' ' || *text == '\t') ++text;
    sign = 1;
    if (*text == '-') { sign = -1; ++text; }
    else if (*text == '+') { ++text; }

    whole = 0UL;
    frac = 0UL;
    denom = 1UL;
    seen_dot = 0;
    digits = 0;

    while (*text != '\0' && *text != ',' && *text != ' ' && *text != '\t' && *text != '\r' && *text != '\n') {
        c = (unsigned char)*text;
        if (c == '.') {
            if (seen_dot) return 0;
            seen_dot = 1;
        } else if (c >= '0' && c <= '9') {
            if (!seen_dot) {
                if (whole < 32767UL) whole = whole * 10UL + (unsigned long)(c - '0');
            } else if (digits < 4) {
                frac = frac * 10UL + (unsigned long)(c - '0');
                denom *= 10UL;
                ++digits;
            }
        } else {
            return 0;
        }
        ++text;
    }

    value = (stage89_q16)(whole << 16);
    if (denom > 1UL) value += (stage89_q16)((frac * 65536UL) / denom);
    if (sign < 0) value = -value;
    if (ok != (int*)0) *ok = 1;
    return value;
}

stage89_q16 stage89_q16_mul(stage89_q16 a, stage89_q16 b)
{
    stage89_u32 ua;
    stage89_u32 ub;
    stage89_u32 ai;
    stage89_u32 af;
    stage89_u32 bi;
    stage89_u32 bf;
    stage89_u32 result;
    int neg;

    neg = 0;
    if (a < 0) { neg = !neg; ua = (stage89_u32)(-a); }
    else ua = (stage89_u32)a;
    if (b < 0) { neg = !neg; ub = (stage89_u32)(-b); }
    else ub = (stage89_u32)b;

    ai = ua >> 16;
    af = ua & 0xFFFFUL;
    bi = ub >> 16;
    bf = ub & 0xFFFFUL;
    result = ((ai * bi) << 16) + (ai * bf) + (bi * af) + ((af * bf) >> 16);
    return neg ? -(stage89_q16)result : (stage89_q16)result;
}

stage89_q16 stage89_q16_div(stage89_q16 a, stage89_q16 b, int *ok)
{
    stage89_u32 ua;
    stage89_u32 ub;
    stage89_u32 q;
    stage89_u32 r;
    int i;
    int neg;

    if (ok != (int*)0) *ok = 0;
    if (b == 0) return 0;
    neg = ((a < 0) != (b < 0));
    ua = (stage89_u32)(a < 0 ? -a : a);
    ub = (stage89_u32)(b < 0 ? -b : b);
    q = (ua / ub) << 16;
    r = ua % ub;
    for (i = 15; i >= 0; --i) {
        r <<= 1;
        if (r >= ub) { r -= ub; q |= (1UL << i); }
    }
    if (ok != (int*)0) *ok = 1;
    return neg ? -(stage89_q16)q : (stage89_q16)q;
}

long stage89_q16_to_int(stage89_q16 value)
{
    return (long)(value >> 16);
}

long stage89_q16_round(stage89_q16 value)
{
    if (value >= 0) return (long)((value + STAGE89_Q16_HALF) >> 16);
    return -(long)(((-value) + STAGE89_Q16_HALF) >> 16);
}

stage89_q16 stage89_q16_clamp(stage89_q16 value, stage89_q16 lo, stage89_q16 hi)
{
    if (value < lo) return lo;
    if (value > hi) return hi;
    return value;
}

void stage89_q16_to_text(stage89_q16 value, char *out, int out_cap)
{
    long whole;
    unsigned long frac;
    unsigned long dec;
    int neg;
    char temp[64];

    if (out == (char*)0 || out_cap <= 0) return;
    neg = value < 0;
    if (neg) value = -value;
    whole = (long)(value >> 16);
    frac = (unsigned long)(value & 0xFFFFL);
    dec = (frac * 1000UL + 32768UL) / 65536UL;
    if (dec >= 1000UL) { ++whole; dec = 0UL; }
    if (neg) sprintf(temp, "-%ld.%03lu", whole, dec);
    else sprintf(temp, "%ld.%03lu", whole, dec);
    temp[sizeof(temp) - 1u] = '\0';
    strncpy(out, temp, (size_t)(out_cap - 1));
    out[out_cap - 1] = '\0';
}
