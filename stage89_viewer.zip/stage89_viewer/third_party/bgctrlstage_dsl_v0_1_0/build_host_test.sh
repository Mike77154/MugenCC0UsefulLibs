#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$ROOT/build"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -I"$ROOT/include" \
  "$ROOT/tests/test_bgctrlstage_dsl.c" "$ROOT/src/bgctrlstage_dsl.c" \
  -o "$ROOT/build/test_bgctrlstage_dsl"
"$ROOT/build/test_bgctrlstage_dsl"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -I"$ROOT/include" \
  "$ROOT/examples/bgctrl_player_demo.c" "$ROOT/src/bgctrlstage_dsl.c" \
  -o "$ROOT/build/bgctrl_player_demo"
"$ROOT/build/bgctrl_player_demo"
