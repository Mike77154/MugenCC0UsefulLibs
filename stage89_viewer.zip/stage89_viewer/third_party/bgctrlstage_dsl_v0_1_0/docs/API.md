# API notes

```c
BgcProgram program;
BgcRuntime runtime;
BgcTargetInit target[BGC_MAX_TARGETS];

bgc_parse_text(&program, def_text, def_size);
bgc_runtime_init(&runtime, &program, target, target_count);
bgc_runtime_seek(&runtime, absolute_tick);
state = bgc_runtime_get_state(&runtime, bg_index);
```

The state supplies:

- integrated base position and velocity;
- position after `SinX`/`SinY` and `positionlink` composition;
- `visible` and `enabled` flags;
- selected AIR action and action-local tick;
- target-local time, frozen while disabled.
