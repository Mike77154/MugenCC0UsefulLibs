#ifndef BGCTRLSTAGE_DSL_H
#define BGCTRLSTAGE_DSL_H

/*
 * bgctrlstage_dsl v0.1.0
 * Small M.U.G.E.N BGCtrl parser and deterministic fixed-point runtime.
 * ISO C89, no heap, no float/double.
 */

#include <limits.h>

#if UINT_MAX == 0xFFFFFFFFu
typedef signed int bgc_q16;
typedef unsigned int bgc_u32;
#elif ULONG_MAX == 0xFFFFFFFFul
typedef signed long bgc_q16;
typedef unsigned long bgc_u32;
#else
#error "bgctrlstage_dsl requires a 32-bit unsigned integer type"
#endif

#define BGC_Q16_ONE ((bgc_q16)65536L)
#define BGC_Q16_HALF ((bgc_q16)32768L)

#define BGC_MAX_CTRLDEFS 64
#define BGC_MAX_CTRLS 256
#define BGC_MAX_CTRL_IDS 10
#define BGC_MAX_TARGETS 128
#define BGC_NAME_CAP 64
#define BGC_SNAPSHOT_INTERVAL 256L

typedef enum BgcCtrlType {
    BGC_CTRL_UNKNOWN = 0,
    BGC_CTRL_NULL,
    BGC_CTRL_VISIBLE,
    BGC_CTRL_ENABLED,
    BGC_CTRL_VELSET,
    BGC_CTRL_VELADD,
    BGC_CTRL_POSSET,
    BGC_CTRL_POSADD,
    BGC_CTRL_ANIM,
    BGC_CTRL_SINX,
    BGC_CTRL_SINY
} BgcCtrlType;

typedef struct BgcOsc {
    bgc_q16 amplitude;
    bgc_q16 period;
    bgc_q16 phase;
} BgcOsc;

typedef struct BgcCtrlDef {
    char name[BGC_NAME_CAP];
    long looptime;
    long ctrl_ids[BGC_MAX_CTRL_IDS];
    int ctrl_id_count;
    int first_ctrl;
    int ctrl_count;
} BgcCtrlDef;

typedef struct BgcCtrl {
    char name[BGC_NAME_CAP];
    BgcCtrlType type;
    int parent_def_index;
    long time_start;
    long time_end;
    long looptime;
    int has_time;
    long ctrl_ids[BGC_MAX_CTRL_IDS];
    int ctrl_id_count;
    bgc_q16 x;
    bgc_q16 y;
    int has_x;
    int has_y;
    bgc_q16 value[3];
    int value_count;
} BgcCtrl;

typedef struct BgcProgram {
    BgcCtrlDef defs[BGC_MAX_CTRLDEFS];
    int def_count;
    BgcCtrl ctrls[BGC_MAX_CTRLS];
    int ctrl_count;
    int unknown_type_count;
    int malformed_count;
    int truncated_def_count;
    int truncated_ctrl_count;
    int orphan_ctrl_count;
} BgcProgram;

typedef struct BgcTargetInit {
    long id;
    bgc_q16 start_x;
    bgc_q16 start_y;
    bgc_q16 velocity_x;
    bgc_q16 velocity_y;
    int visible;
    int enabled;
    long action_no;
    BgcOsc sin_x;
    BgcOsc sin_y;
    int has_sin_x;
    int has_sin_y;
    int position_link;
} BgcTargetInit;

typedef struct BgcTargetState {
    long id;
    bgc_q16 pos_x;
    bgc_q16 pos_y;
    bgc_q16 velocity_x;
    bgc_q16 velocity_y;
    bgc_q16 computed_x;
    bgc_q16 computed_y;
    int visible;
    int enabled;
    long action_no;
    unsigned long action_tick;
    unsigned long local_tick;
    BgcOsc sin_x;
    BgcOsc sin_y;
    int has_sin_x;
    int has_sin_y;
    int position_link;
} BgcTargetState;

typedef struct BgcRuntime {
    const BgcProgram *program;
    BgcTargetInit initial[BGC_MAX_TARGETS];
    BgcTargetState state[BGC_MAX_TARGETS];
    BgcTargetState snapshot_a[BGC_MAX_TARGETS];
    BgcTargetState snapshot_b[BGC_MAX_TARGETS];
    int target_count;
    long current_tick;
    long snapshot_a_tick;
    long snapshot_b_tick;
    int snapshot_a_valid;
    int snapshot_b_valid;
} BgcRuntime;

void bgc_program_init(BgcProgram *program);
int bgc_parse_text(BgcProgram *program, const char *text, unsigned long text_size);
BgcCtrlType bgc_ctrl_type_from_text(const char *text);
const char *bgc_ctrl_type_name(BgcCtrlType type);

void bgc_runtime_init(BgcRuntime *runtime, const BgcProgram *program,
                      const BgcTargetInit *targets, int target_count);
void bgc_runtime_reset(BgcRuntime *runtime);
int bgc_runtime_seek(BgcRuntime *runtime, unsigned long tick);
const BgcTargetState *bgc_runtime_get_state(const BgcRuntime *runtime, int target_index);

bgc_q16 bgc_q16_from_int(long value);
bgc_q16 bgc_q16_from_text(const char *text, int *ok);
bgc_q16 bgc_q16_mul(bgc_q16 a, bgc_q16 b);
bgc_q16 bgc_q16_div(bgc_q16 a, bgc_q16 b, int *ok);
long bgc_q16_to_int(bgc_q16 value);
bgc_q16 bgc_eval_osc(const BgcOsc *osc, unsigned long local_tick);

#endif
