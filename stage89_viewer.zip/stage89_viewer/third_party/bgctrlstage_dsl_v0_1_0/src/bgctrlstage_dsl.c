#include "bgctrlstage_dsl.h"
#include <string.h>
#include <ctype.h>

#define BGC_FIXED_PI ((bgc_q16)205887L)
#define BGC_FIXED_TWO_PI ((bgc_q16)411775L)
#define BGC_LINE_CAP 512

static void bgc_copy(char *dst, int cap, const char *src)
{
    int i;
    if (dst == (char*)0 || cap <= 0) return;
    if (src == (const char*)0) src = "";
    i = 0;
    while (i + 1 < cap && src[i] != '\0') { dst[i] = src[i]; ++i; }
    dst[i] = '\0';
}

static int bgc_eqi(const char *a, const char *b)
{
    unsigned char ca;
    unsigned char cb;
    if (a == (const char*)0 || b == (const char*)0) return 0;
    while (*a != '\0' && *b != '\0') {
        ca = (unsigned char)tolower((unsigned char)*a);
        cb = (unsigned char)tolower((unsigned char)*b);
        if (ca != cb) return 0;
        ++a;
        ++b;
    }
    return *a == '\0' && *b == '\0';
}

static int bgc_starts_i(const char *text, const char *prefix)
{
    unsigned char a;
    unsigned char b;
    if (text == (const char*)0 || prefix == (const char*)0) return 0;
    while (*prefix != '\0') {
        if (*text == '\0') return 0;
        a = (unsigned char)tolower((unsigned char)*text);
        b = (unsigned char)tolower((unsigned char)*prefix);
        if (a != b) return 0;
        ++text;
        ++prefix;
    }
    return 1;
}

static char *bgc_trim(char *text)
{
    char *end;
    while (*text == ' ' || *text == '\t' || *text == '\r' || *text == '\n') ++text;
    end = text + strlen(text);
    while (end > text) {
        char c;
        c = end[-1];
        if (c == ' ' || c == '\t' || c == '\r' || c == '\n') --end;
        else break;
    }
    *end = '\0';
    return text;
}

static void bgc_strip_comment(char *line)
{
    int quote;
    quote = 0;
    while (*line != '\0') {
        if (*line == '"') quote = !quote;
        else if (*line == ';' && !quote) { *line = '\0'; return; }
        ++line;
    }
}

static long bgc_parse_long(const char *text, int *ok)
{
    long sign;
    long value;
    int any;
    if (ok != (int*)0) *ok = 0;
    if (text == (const char*)0) return 0L;
    while (*text == ' ' || *text == '\t') ++text;
    sign = 1L;
    if (*text == '-') { sign = -1L; ++text; }
    else if (*text == '+') ++text;
    value = 0L;
    any = 0;
    while (*text >= '0' && *text <= '9') {
        value = value * 10L + (long)(*text - '0');
        any = 1;
        ++text;
    }
    while (*text == ' ' || *text == '\t') ++text;
    if (*text != '\0' && *text != ',') any = 0;
    if (ok != (int*)0) *ok = any;
    return value * sign;
}

static int bgc_next_value(const char **cursor, char *out, int cap)
{
    const char *p;
    int i;
    if (cursor == (const char**)0 || *cursor == (const char*)0 || out == (char*)0 || cap <= 0) return 0;
    p = *cursor;
    while (*p == ' ' || *p == '\t' || *p == ',') ++p;
    if (*p == '\0') { out[0] = '\0'; *cursor = p; return 0; }
    i = 0;
    while (*p != '\0' && *p != ',') {
        if (i + 1 < cap) out[i++] = *p;
        ++p;
    }
    out[i] = '\0';
    if (*p == ',') ++p;
    *cursor = p;
    bgc_copy(out, cap, bgc_trim(out));
    return 1;
}

bgc_q16 bgc_q16_from_int(long value)
{
    return (bgc_q16)(value << 16);
}

bgc_q16 bgc_q16_from_text(const char *text, int *ok)
{
    int sign;
    int seen_dot;
    int digits;
    unsigned long whole;
    unsigned long frac;
    unsigned long denom;
    unsigned char c;
    bgc_q16 value;

    if (ok != (int*)0) *ok = 0;
    if (text == (const char*)0) return 0;
    while (*text == ' ' || *text == '\t') ++text;
    sign = 1;
    if (*text == '-') { sign = -1; ++text; }
    else if (*text == '+') ++text;
    whole = 0UL;
    frac = 0UL;
    denom = 1UL;
    seen_dot = 0;
    digits = 0;
    while (*text != '\0' && *text != ',' && *text != ' ' && *text != '\t' && *text != '\r' && *text != '\n') {
        c = (unsigned char)*text;
        if (c == '.') {
            if (seen_dot) return 0;
            seen_dot = 1;
        } else if (c >= '0' && c <= '9') {
            if (!seen_dot) {
                if (whole < 32767UL) whole = whole * 10UL + (unsigned long)(c - '0');
            } else if (digits < 4) {
                frac = frac * 10UL + (unsigned long)(c - '0');
                denom *= 10UL;
                ++digits;
            }
        } else {
            return 0;
        }
        ++text;
    }
    value = (bgc_q16)(whole << 16);
    if (denom > 1UL) value += (bgc_q16)((frac * 65536UL) / denom);
    if (sign < 0) value = -value;
    if (ok != (int*)0) *ok = 1;
    return value;
}

bgc_q16 bgc_q16_mul(bgc_q16 a, bgc_q16 b)
{
    bgc_u32 ua;
    bgc_u32 ub;
    bgc_u32 ai;
    bgc_u32 af;
    bgc_u32 bi;
    bgc_u32 bf;
    bgc_u32 result;
    int neg;
    neg = 0;
    if (a < 0) { neg = !neg; ua = (bgc_u32)(-a); }
    else ua = (bgc_u32)a;
    if (b < 0) { neg = !neg; ub = (bgc_u32)(-b); }
    else ub = (bgc_u32)b;
    ai = ua >> 16;
    af = ua & 0xFFFFUL;
    bi = ub >> 16;
    bf = ub & 0xFFFFUL;
    result = ((ai * bi) << 16) + (ai * bf) + (bi * af) + ((af * bf) >> 16);
    return neg ? -(bgc_q16)result : (bgc_q16)result;
}

bgc_q16 bgc_q16_div(bgc_q16 a, bgc_q16 b, int *ok)
{
    bgc_u32 ua;
    bgc_u32 ub;
    bgc_u32 q;
    bgc_u32 r;
    int i;
    int neg;
    if (ok != (int*)0) *ok = 0;
    if (b == 0) return 0;
    neg = ((a < 0) != (b < 0));
    ua = (bgc_u32)(a < 0 ? -a : a);
    ub = (bgc_u32)(b < 0 ? -b : b);
    q = (ua / ub) << 16;
    r = ua % ub;
    for (i = 15; i >= 0; --i) {
        r <<= 1;
        if (r >= ub) { r -= ub; q |= (1UL << i); }
    }
    if (ok != (int*)0) *ok = 1;
    return neg ? -(bgc_q16)q : (bgc_q16)q;
}

long bgc_q16_to_int(bgc_q16 value)
{
    return (long)(value >> 16);
}

static bgc_q16 bgc_fixed_floor(bgc_q16 value)
{
    if (value >= 0) return (value / BGC_Q16_ONE) * BGC_Q16_ONE;
    return -(((-value + BGC_Q16_ONE - 1) / BGC_Q16_ONE) * BGC_Q16_ONE);
}

static bgc_q16 bgc_fixed_frac(bgc_q16 value)
{
    return value - bgc_fixed_floor(value);
}

static bgc_q16 bgc_fixed_sin_approx(bgc_q16 x)
{
    int ok;
    int neg;
    bgc_q16 y;
    bgc_q16 xy;
    bgc_q16 num;
    bgc_q16 den;
    bgc_q16 pi_sq;
    bgc_q16 result;
    while (x > BGC_FIXED_PI) x -= BGC_FIXED_TWO_PI;
    while (x < -BGC_FIXED_PI) x += BGC_FIXED_TWO_PI;
    neg = 0;
    if (x < 0) { neg = 1; x = -x; }
    y = BGC_FIXED_PI - x;
    xy = bgc_q16_mul(x, y);
    num = bgc_q16_mul(bgc_q16_from_int(16L), xy);
    pi_sq = bgc_q16_mul(BGC_FIXED_PI, BGC_FIXED_PI);
    den = bgc_q16_mul(bgc_q16_from_int(5L), pi_sq) - bgc_q16_mul(bgc_q16_from_int(4L), xy);
    result = bgc_q16_div(num, den, &ok);
    if (!ok) result = 0;
    if (neg) result = -result;
    return result;
}

bgc_q16 bgc_eval_osc(const BgcOsc *osc, unsigned long local_tick)
{
    int ok;
    long period_whole;
    unsigned long reduced_tick;
    bgc_q16 t;
    bgc_q16 ratio;
    bgc_q16 frac;
    bgc_q16 angle;
    bgc_q16 sine;
    if (osc == (const BgcOsc*)0 || osc->period <= 0 || osc->amplitude == 0) return 0;
    period_whole = bgc_q16_to_int(osc->period);
    if (period_whole > 0L) reduced_tick = local_tick % (unsigned long)period_whole;
    else reduced_tick = local_tick & 32767UL;
    t = bgc_q16_from_int((long)reduced_tick) + osc->phase;
    ratio = bgc_q16_div(t, osc->period, &ok);
    if (!ok) return 0;
    frac = bgc_fixed_frac(ratio);
    angle = bgc_q16_mul(frac, BGC_FIXED_TWO_PI);
    sine = bgc_fixed_sin_approx(angle);
    return bgc_q16_mul(osc->amplitude, sine);
}

BgcCtrlType bgc_ctrl_type_from_text(const char *text)
{
    if (bgc_eqi(text, "null")) return BGC_CTRL_NULL;
    if (bgc_eqi(text, "visible")) return BGC_CTRL_VISIBLE;
    if (bgc_eqi(text, "enabled") || bgc_eqi(text, "enable")) return BGC_CTRL_ENABLED;
    if (bgc_eqi(text, "velset")) return BGC_CTRL_VELSET;
    if (bgc_eqi(text, "veladd")) return BGC_CTRL_VELADD;
    if (bgc_eqi(text, "posset")) return BGC_CTRL_POSSET;
    if (bgc_eqi(text, "posadd")) return BGC_CTRL_POSADD;
    if (bgc_eqi(text, "anim")) return BGC_CTRL_ANIM;
    if (bgc_eqi(text, "sinx")) return BGC_CTRL_SINX;
    if (bgc_eqi(text, "siny")) return BGC_CTRL_SINY;
    return BGC_CTRL_UNKNOWN;
}

const char *bgc_ctrl_type_name(BgcCtrlType type)
{
    switch (type) {
    case BGC_CTRL_NULL: return "null";
    case BGC_CTRL_VISIBLE: return "visible";
    case BGC_CTRL_ENABLED: return "enabled";
    case BGC_CTRL_VELSET: return "velset";
    case BGC_CTRL_VELADD: return "veladd";
    case BGC_CTRL_POSSET: return "posset";
    case BGC_CTRL_POSADD: return "posadd";
    case BGC_CTRL_ANIM: return "anim";
    case BGC_CTRL_SINX: return "sinx";
    case BGC_CTRL_SINY: return "siny";
    default: return "unknown";
    }
}

void bgc_program_init(BgcProgram *program)
{
    if (program == (BgcProgram*)0) return;
    memset(program, 0, sizeof(*program));
}

static int bgc_parse_long_list(const char *text, long *out, int cap)
{
    const char *cursor;
    char part[64];
    int count;
    int ok;
    long value;
    cursor = text;
    count = 0;
    while (count < cap && bgc_next_value(&cursor, part, (int)sizeof(part))) {
        value = bgc_parse_long(part, &ok);
        if (ok) out[count++] = value;
    }
    return count;
}

static int bgc_parse_q16_list(const char *text, bgc_q16 *out, int cap)
{
    const char *cursor;
    char part[64];
    int count;
    int ok;
    bgc_q16 value;
    cursor = text;
    count = 0;
    while (count < cap && bgc_next_value(&cursor, part, (int)sizeof(part))) {
        value = bgc_q16_from_text(part, &ok);
        if (ok) out[count++] = value;
    }
    return count;
}

static void bgc_ctrl_defaults(BgcCtrl *ctrl)
{
    memset(ctrl, 0, sizeof(*ctrl));
    ctrl->type = BGC_CTRL_UNKNOWN;
    ctrl->parent_def_index = -1;
    ctrl->looptime = -1L;
}

static void bgc_def_defaults(BgcCtrlDef *def)
{
    memset(def, 0, sizeof(*def));
    def->looptime = -1L;
    def->first_ctrl = -1;
}

static void bgc_apply_def_key(BgcProgram *program, BgcCtrlDef *def, const char *key, const char *value)
{
    int ok;
    long lv;
    if (bgc_eqi(key, "looptime")) {
        lv = bgc_parse_long(value, &ok);
        if (ok) def->looptime = lv;
        else ++program->malformed_count;
    } else if (bgc_eqi(key, "ctrlid")) {
        def->ctrl_id_count = bgc_parse_long_list(value, def->ctrl_ids, BGC_MAX_CTRL_IDS);
    }
}

static void bgc_apply_ctrl_key(BgcProgram *program, BgcCtrl *ctrl, const char *key, const char *value)
{
    int ok;
    bgc_q16 q;
    long times[3];
    int count;
    char temp[64];
    if (bgc_eqi(key, "type")) {
        bgc_copy(temp, (int)sizeof(temp), value);
        ctrl->type = bgc_ctrl_type_from_text(bgc_trim(temp));
        if (ctrl->type == BGC_CTRL_UNKNOWN) ++program->unknown_type_count;
    } else if (bgc_eqi(key, "time")) {
        count = bgc_parse_long_list(value, times, 3);
        if (count > 0) {
            ctrl->has_time = 1;
            ctrl->time_start = times[0];
            ctrl->time_end = count > 1 ? times[1] : times[0];
            ctrl->looptime = count > 2 ? times[2] : -1L;
        } else {
            ++program->malformed_count;
        }
    } else if (bgc_eqi(key, "ctrlid")) {
        ctrl->ctrl_id_count = bgc_parse_long_list(value, ctrl->ctrl_ids, BGC_MAX_CTRL_IDS);
    } else if (bgc_eqi(key, "x")) {
        q = bgc_q16_from_text(value, &ok);
        if (ok) { ctrl->x = q; ctrl->has_x = 1; }
        else ++program->malformed_count;
    } else if (bgc_eqi(key, "y")) {
        q = bgc_q16_from_text(value, &ok);
        if (ok) { ctrl->y = q; ctrl->has_y = 1; }
        else ++program->malformed_count;
    } else if (bgc_eqi(key, "value")) {
        ctrl->value_count = bgc_parse_q16_list(value, ctrl->value, 3);
        if (ctrl->value_count <= 0) ++program->malformed_count;
    }
}

int bgc_parse_text(BgcProgram *program, const char *text, unsigned long text_size)
{
    unsigned long pos;
    int current_def;
    int current_ctrl;
    char line[BGC_LINE_CAP];
    int line_len;
    char *trimmed;
    char *end;
    char *eq;
    char *key;
    char *value;
    char section[BGC_NAME_CAP];
    BgcCtrlDef *def;
    BgcCtrl *ctrl;

    if (program == (BgcProgram*)0 || text == (const char*)0 || text_size == 0UL) return 0;
    bgc_program_init(program);
    pos = 0UL;
    current_def = -1;
    current_ctrl = -1;
    while (pos < text_size && text[pos] != '\0') {
        line_len = 0;
        while (pos < text_size && text[pos] != '\0' && text[pos] != '\n') {
            if (line_len + 1 < BGC_LINE_CAP) line[line_len++] = text[pos];
            else ++program->malformed_count;
            ++pos;
        }
        if (pos < text_size && text[pos] == '\n') ++pos;
        line[line_len] = '\0';
        bgc_strip_comment(line);
        trimmed = bgc_trim(line);
        if (*trimmed == '\0') continue;
        if (*trimmed == '[') {
            end = strchr(trimmed + 1, ']');
            current_ctrl = -1;
            if (end == (char*)0) { ++program->malformed_count; current_def = -1; continue; }
            *end = '\0';
            bgc_copy(section, BGC_NAME_CAP, bgc_trim(trimmed + 1));
            if (bgc_starts_i(section, "bgctrldef")) {
                if (program->def_count >= BGC_MAX_CTRLDEFS) {
                    ++program->truncated_def_count;
                    current_def = -1;
                } else {
                    current_def = program->def_count++;
                    def = &program->defs[current_def];
                    bgc_def_defaults(def);
                    bgc_copy(def->name, BGC_NAME_CAP, section);
                }
            } else if (bgc_starts_i(section, "bgctrl")) {
                if (program->ctrl_count >= BGC_MAX_CTRLS) {
                    ++program->truncated_ctrl_count;
                } else {
                    current_ctrl = program->ctrl_count++;
                    ctrl = &program->ctrls[current_ctrl];
                    bgc_ctrl_defaults(ctrl);
                    bgc_copy(ctrl->name, BGC_NAME_CAP, section);
                    ctrl->parent_def_index = current_def;
                    if (current_def >= 0) {
                        def = &program->defs[current_def];
                        if (def->first_ctrl < 0) def->first_ctrl = current_ctrl;
                        ++def->ctrl_count;
                    } else {
                        ++program->orphan_ctrl_count;
                    }
                }
            } else {
                current_def = -1;
            }
            continue;
        }
        eq = strchr(trimmed, '=');
        if (eq == (char*)0) continue;
        *eq = '\0';
        key = bgc_trim(trimmed);
        value = bgc_trim(eq + 1);
        if (current_ctrl >= 0) bgc_apply_ctrl_key(program, &program->ctrls[current_ctrl], key, value);
        else if (current_def >= 0) bgc_apply_def_key(program, &program->defs[current_def], key, value);
    }
    return 1;
}

static void bgc_state_from_init(BgcTargetState *state, const BgcTargetInit *init)
{
    memset(state, 0, sizeof(*state));
    state->id = init->id;
    state->pos_x = init->start_x;
    state->pos_y = init->start_y;
    state->velocity_x = init->velocity_x;
    state->velocity_y = init->velocity_y;
    state->computed_x = init->start_x;
    state->computed_y = init->start_y;
    state->visible = init->visible != 0;
    state->enabled = init->enabled != 0;
    state->action_no = init->action_no;
    state->sin_x = init->sin_x;
    state->sin_y = init->sin_y;
    state->has_sin_x = init->has_sin_x != 0;
    state->has_sin_y = init->has_sin_y != 0;
    state->position_link = init->position_link != 0;
}

static void bgc_refresh_positions(BgcRuntime *runtime)
{
    int i;
    BgcTargetState *state;
    bgc_q16 sx;
    bgc_q16 sy;
    if (runtime == (BgcRuntime*)0) return;
    for (i = 0; i < runtime->target_count; ++i) {
        state = &runtime->state[i];
        sx = state->has_sin_x ? bgc_eval_osc(&state->sin_x, state->local_tick) : 0;
        sy = state->has_sin_y ? bgc_eval_osc(&state->sin_y, state->local_tick) : 0;
        state->computed_x = state->pos_x + sx;
        state->computed_y = state->pos_y + sy;
        if (state->position_link && i > 0) {
            state->computed_x += runtime->state[i - 1].computed_x;
            state->computed_y += runtime->state[i - 1].computed_y;
        }
    }
}

void bgc_runtime_reset(BgcRuntime *runtime)
{
    int i;
    if (runtime == (BgcRuntime*)0) return;
    for (i = 0; i < runtime->target_count; ++i) bgc_state_from_init(&runtime->state[i], &runtime->initial[i]);
    runtime->current_tick = -1L;
    runtime->snapshot_a_valid = 0;
    runtime->snapshot_b_valid = 0;
    runtime->snapshot_a_tick = -1L;
    runtime->snapshot_b_tick = -1L;
    bgc_refresh_positions(runtime);
}

void bgc_runtime_init(BgcRuntime *runtime, const BgcProgram *program,
                      const BgcTargetInit *targets, int target_count)
{
    int i;
    if (runtime == (BgcRuntime*)0) return;
    memset(runtime, 0, sizeof(*runtime));
    runtime->program = program;
    if (target_count < 0) target_count = 0;
    if (target_count > BGC_MAX_TARGETS) target_count = BGC_MAX_TARGETS;
    runtime->target_count = target_count;
    for (i = 0; i < target_count; ++i) runtime->initial[i] = targets[i];
    bgc_runtime_reset(runtime);
}

static int bgc_target_matches(const BgcTargetState *state, const BgcCtrlDef *def, const BgcCtrl *ctrl)
{
    const long *ids;
    int count;
    int i;
    if (ctrl->ctrl_id_count > 0) {
        ids = ctrl->ctrl_ids;
        count = ctrl->ctrl_id_count;
    } else if (def != (const BgcCtrlDef*)0 && def->ctrl_id_count > 0) {
        ids = def->ctrl_ids;
        count = def->ctrl_id_count;
    } else {
        return 1;
    }
    for (i = 0; i < count; ++i) if (state->id == ids[i]) return 1;
    return 0;
}

static long bgc_ctrl_local_tick(const BgcCtrlDef *def, const BgcCtrl *ctrl, long tick)
{
    long local;
    local = tick;
    if (def != (const BgcCtrlDef*)0 && def->looptime > 0L) local %= def->looptime;
    if (ctrl->looptime > 0L) local %= ctrl->looptime;
    return local;
}

static int bgc_ctrl_active(const BgcCtrlDef *def, const BgcCtrl *ctrl, long tick)
{
    long local;
    if (!ctrl->has_time) return 0;
    local = bgc_ctrl_local_tick(def, ctrl, tick);
    return local >= ctrl->time_start && local <= ctrl->time_end;
}

static void bgc_apply_ctrl(BgcTargetState *state, const BgcCtrl *ctrl)
{
    long value;
    switch (ctrl->type) {
    case BGC_CTRL_NULL:
        break;
    case BGC_CTRL_VISIBLE:
        if (ctrl->value_count > 0) state->visible = bgc_q16_to_int(ctrl->value[0]) != 0L;
        break;
    case BGC_CTRL_ENABLED:
        if (ctrl->value_count > 0) state->enabled = bgc_q16_to_int(ctrl->value[0]) != 0L;
        break;
    case BGC_CTRL_VELSET:
        if (ctrl->has_x) state->velocity_x = ctrl->x;
        if (ctrl->has_y) state->velocity_y = ctrl->y;
        break;
    case BGC_CTRL_VELADD:
        if (ctrl->has_x) state->velocity_x += ctrl->x;
        if (ctrl->has_y) state->velocity_y += ctrl->y;
        break;
    case BGC_CTRL_POSSET:
        if (ctrl->has_x) state->pos_x = ctrl->x;
        if (ctrl->has_y) state->pos_y = ctrl->y;
        break;
    case BGC_CTRL_POSADD:
        if (ctrl->has_x) state->pos_x += ctrl->x;
        if (ctrl->has_y) state->pos_y += ctrl->y;
        break;
    case BGC_CTRL_ANIM:
        if (ctrl->value_count > 0) {
            value = bgc_q16_to_int(ctrl->value[0]);
            if (state->action_no != value) {
                state->action_no = value;
                state->action_tick = 0UL;
            }
        }
        break;
    case BGC_CTRL_SINX:
        state->has_sin_x = 1;
        state->sin_x.amplitude = ctrl->value_count > 0 ? ctrl->value[0] : 0;
        state->sin_x.period = ctrl->value_count > 1 ? ctrl->value[1] : 0;
        state->sin_x.phase = ctrl->value_count > 2 ? ctrl->value[2] : 0;
        break;
    case BGC_CTRL_SINY:
        state->has_sin_y = 1;
        state->sin_y.amplitude = ctrl->value_count > 0 ? ctrl->value[0] : 0;
        state->sin_y.period = ctrl->value_count > 1 ? ctrl->value[1] : 0;
        state->sin_y.phase = ctrl->value_count > 2 ? ctrl->value[2] : 0;
        break;
    default:
        break;
    }
}

static void bgc_apply_tick(BgcRuntime *runtime, long tick)
{
    int i;
    int j;
    const BgcCtrl *ctrl;
    const BgcCtrlDef *def;
    if (runtime->program == (const BgcProgram*)0) { bgc_refresh_positions(runtime); return; }
    for (i = 0; i < runtime->program->ctrl_count; ++i) {
        ctrl = &runtime->program->ctrls[i];
        def = (const BgcCtrlDef*)0;
        if (ctrl->parent_def_index >= 0 && ctrl->parent_def_index < runtime->program->def_count) {
            def = &runtime->program->defs[ctrl->parent_def_index];
        }
        if (!bgc_ctrl_active(def, ctrl, tick)) continue;
        for (j = 0; j < runtime->target_count; ++j) {
            if (bgc_target_matches(&runtime->state[j], def, ctrl)) bgc_apply_ctrl(&runtime->state[j], ctrl);
        }
    }
    bgc_refresh_positions(runtime);
}

static void bgc_advance_targets(BgcRuntime *runtime)
{
    int i;
    BgcTargetState *state;
    for (i = 0; i < runtime->target_count; ++i) {
        state = &runtime->state[i];
        if (state->enabled) {
            state->pos_x += state->velocity_x;
            state->pos_y += state->velocity_y;
            ++state->local_tick;
            ++state->action_tick;
        }
    }
}

static void bgc_capture_snapshot(BgcRuntime *runtime)
{
    size_t bytes;
    if (runtime->current_tick < 0L || (runtime->current_tick % BGC_SNAPSHOT_INTERVAL) != 0L) return;
    bytes = (size_t)runtime->target_count * sizeof(BgcTargetState);
    if (runtime->snapshot_a_valid && runtime->snapshot_a_tick == runtime->current_tick) {
        memcpy(runtime->snapshot_a, runtime->state, bytes);
        return;
    }
    if (runtime->snapshot_a_valid) {
        memcpy(runtime->snapshot_b, runtime->snapshot_a, bytes);
        runtime->snapshot_b_tick = runtime->snapshot_a_tick;
        runtime->snapshot_b_valid = 1;
    }
    memcpy(runtime->snapshot_a, runtime->state, bytes);
    runtime->snapshot_a_tick = runtime->current_tick;
    runtime->snapshot_a_valid = 1;
}

static int bgc_restore_best_snapshot(BgcRuntime *runtime, long target)
{
    const BgcTargetState *snapshot;
    long tick;
    int valid;
    size_t bytes;
    snapshot = (const BgcTargetState*)0;
    tick = -1L;
    valid = 0;
    if (runtime->snapshot_a_valid && runtime->snapshot_a_tick <= target) {
        snapshot = runtime->snapshot_a;
        tick = runtime->snapshot_a_tick;
        valid = 1;
    }
    if (runtime->snapshot_b_valid && runtime->snapshot_b_tick <= target && runtime->snapshot_b_tick > tick) {
        snapshot = runtime->snapshot_b;
        tick = runtime->snapshot_b_tick;
        valid = 1;
    }
    if (!valid) return 0;
    bytes = (size_t)runtime->target_count * sizeof(BgcTargetState);
    memcpy(runtime->state, snapshot, bytes);
    runtime->current_tick = tick;
    return 1;
}

int bgc_runtime_seek(BgcRuntime *runtime, unsigned long tick)
{
    long target;
    long next_tick;
    if (runtime == (BgcRuntime*)0) return 0;
    if (tick > (unsigned long)LONG_MAX) target = LONG_MAX;
    else target = (long)tick;
    if (runtime->current_tick > target) {
        if (!bgc_restore_best_snapshot(runtime, target)) bgc_runtime_reset(runtime);
    }
    while (runtime->current_tick < target) {
        if (runtime->current_tick >= 0L) bgc_advance_targets(runtime);
        next_tick = runtime->current_tick + 1L;
        bgc_apply_tick(runtime, next_tick);
        runtime->current_tick = next_tick;
        bgc_capture_snapshot(runtime);
    }
    return 1;
}

const BgcTargetState *bgc_runtime_get_state(const BgcRuntime *runtime, int target_index)
{
    if (runtime == (const BgcRuntime*)0 || target_index < 0 || target_index >= runtime->target_count) return (const BgcTargetState*)0;
    return &runtime->state[target_index];
}
