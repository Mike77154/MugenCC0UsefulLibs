# bgctrlstage_dsl v0.1.0

Small vendorizable parser and runtime for M.U.G.E.N stage background controllers.

## Constraints

- ISO C89.
- Q16.16 fixed point.
- No `malloc`, `realloc`, `free`, heap, `float`, or `double`.
- Fixed capacities and two rolling seek snapshots.
- No Win32, GDI, SFF, AIR, or renderer dependency.

## Implemented syntax

- `[BGCtrlDef name]`
- `looptime`
- inherited `ctrlID` lists
- `[BGCtrl name]`
- `time = start, end, looptime`
- controller-level `ctrlID` override
- `null`
- `Visible`
- `Enabled`, plus common community alias `Enable`
- `VelSet`, `VelAdd`
- `PosSet`, `PosAdd`
- `Anim`
- `SinX`, `SinY`

`Visible` leaves target time running. `Enabled = 0` freezes velocity integration,
local oscillator time and AIR action time until re-enabled.

## Runtime model

The library receives fixed target descriptors identified by M.U.G.E.N BG `id`.
Call `bgc_runtime_seek()` with an absolute game tick and read each resulting
`BgcTargetState`. Forward playback is incremental. Backward seeking restores one
of two rolling 256-tick snapshots and replays only the remainder when possible.

Oscillators use an integer Bhaskara sine approximation. The `phase` field is
interpreted as a time offset in ticks, matching the official `(amplitude,
period, phase)` stage model.

## Integration

The host owns graphics and AIR data. `Anim` only emits the selected action
number and a target-local `action_tick`; the host resolves that through its AIR
player. This keeps the library renderer-agnostic.
