#include "bgctrlstage_dsl.h"
#include <stdio.h>
#include <string.h>

static int fail(const char *message)
{
    fprintf(stderr, "FAIL: %s\n", message);
    return 1;
}

static int near_int(bgc_q16 value, long expected, long tolerance)
{
    long actual;
    actual = bgc_q16_to_int(value);
    return actual >= expected - tolerance && actual <= expected + tolerance;
}

int main(void)
{
    static const char text[] =
        "[BGCtrlDef Walker]\n"
        "looptime = 600\n"
        "ctrlID = 10\n"
        "[BGCtrl right]\n"
        "type = VelSet\n"
        "time = 0\n"
        "x = 2\n"
        "[BGCtrl left]\n"
        "type = VelSet\n"
        "time = 300\n"
        "x = -2\n"
        "[BGCtrl hide]\n"
        "type = Visible\n"
        "time = 20\n"
        "value = 0\n"
        "[BGCtrl freeze]\n"
        "type = Enable\n"
        "time = 30\n"
        "value = 0\n"
        "[BGCtrl thaw]\n"
        "type = Enabled\n"
        "time = 40\n"
        "value = 1\n"
        "[BGCtrl wave]\n"
        "type = SinY\n"
        "time = 0\n"
        "value = 10, 40, 0\n";
    BgcProgram program;
    BgcRuntime runtime;
    BgcTargetInit init;
    const BgcTargetState *state;

    if (!bgc_parse_text(&program, text, (unsigned long)sizeof(text))) return fail("parse returned false");
    if (program.def_count != 1) return fail("def count");
    if (program.ctrl_count != 6) return fail("ctrl count");
    if (program.unknown_type_count != 0) return fail("known type aliases");

    memset(&init, 0, sizeof(init));
    init.id = 10;
    init.start_x = bgc_q16_from_int(-300L);
    init.visible = 1;
    init.enabled = 1;
    init.action_no = 5;
    bgc_runtime_init(&runtime, &program, &init, 1);

    if (!bgc_runtime_seek(&runtime, 0UL)) return fail("seek 0");
    state = bgc_runtime_get_state(&runtime, 0);
    if (!near_int(state->computed_x, -300L, 0L)) return fail("tick0 position");
    if (!near_int(state->velocity_x, 2L, 0L)) return fail("tick0 velocity");

    if (!bgc_runtime_seek(&runtime, 20UL)) return fail("seek 20");
    state = bgc_runtime_get_state(&runtime, 0);
    if (state->visible != 0) return fail("visible controller");
    if (state->local_tick != 20UL) return fail("visible must not pause time");

    if (!bgc_runtime_seek(&runtime, 35UL)) return fail("seek 35");
    state = bgc_runtime_get_state(&runtime, 0);
    if (state->enabled != 0) return fail("enable alias disables");
    if (state->local_tick != 30UL) return fail("disabled target freezes local time");

    if (!bgc_runtime_seek(&runtime, 41UL)) return fail("seek 41");
    state = bgc_runtime_get_state(&runtime, 0);
    if (state->enabled == 0) return fail("enabled alias reenables");
    if (state->local_tick != 31UL) return fail("time resumes after enable");

    if (!bgc_runtime_seek(&runtime, 300UL)) return fail("seek 300");
    state = bgc_runtime_get_state(&runtime, 0);
    if (!near_int(state->velocity_x, -2L, 0L)) return fail("reverse velocity");

    if (!bgc_runtime_seek(&runtime, 600UL)) return fail("seek 600");
    state = bgc_runtime_get_state(&runtime, 0);
    if (!near_int(state->velocity_x, 2L, 0L)) return fail("parent looptime");

    if (!bgc_runtime_seek(&runtime, 299UL)) return fail("rewind snapshot");
    state = bgc_runtime_get_state(&runtime, 0);
    if (runtime.current_tick != 299L) return fail("rewind tick");
    if (!near_int(state->velocity_x, 2L, 0L)) return fail("rewind state");

    {
        BgcOsc osc;
        osc.amplitude = bgc_q16_from_int(10L);
        osc.period = bgc_q16_from_int(40L);
        osc.phase = 0;
        if (!near_int(bgc_eval_osc(&osc, 10UL), 10L, 1L)) return fail("sine quarter wave");
        if (!near_int(bgc_eval_osc(&osc, 30UL), -10L, 1L)) return fail("sine three-quarter wave");
    }

    printf("OK bgctrlstage_dsl defs=%d ctrls=%d\n", program.def_count, program.ctrl_count);
    return 0;
}
