#include "bgctrlstage_dsl.h"
#include <stdio.h>
#include <string.h>

int main(void)
{
    static const char source[] =
        "[BGCtrlDef demo]\nlooptime=120\nctrlID=7\n"
        "[BGCtrl move]\ntype=velset\ntime=0\nx=1\n"
        "[BGCtrl back]\ntype=velset\ntime=60\nx=-1\n";
    BgcProgram program;
    BgcRuntime runtime;
    BgcTargetInit target;
    const BgcTargetState *state;
    unsigned long tick;
    memset(&target, 0, sizeof(target));
    target.id = 7;
    target.visible = 1;
    target.enabled = 1;
    target.action_no = -1L;
    bgc_parse_text(&program, source, (unsigned long)sizeof(source));
    bgc_runtime_init(&runtime, &program, &target, 1);
    for (tick = 0UL; tick <= 120UL; tick += 30UL) {
        bgc_runtime_seek(&runtime, tick);
        state = bgc_runtime_get_state(&runtime, 0);
        printf("tick=%lu x=%ld vel=%ld\n", tick,
            bgc_q16_to_int(state->computed_x), bgc_q16_to_int(state->velocity_x));
    }
    return 0;
}
