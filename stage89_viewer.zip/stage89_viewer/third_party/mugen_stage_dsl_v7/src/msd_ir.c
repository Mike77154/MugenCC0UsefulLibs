#include "msd_ir.h"
#include "msd_profile.h"

int msd_lower_to_ir(const MsdSource *src, MsdArena *arena, MsdIRInstr *storage, int storage_cap)
{
    int si;
    int ii;
    int out_count;
    MsdIRInstr instr;
    const MsdAstSection *sec;
    const MsdAstItem *item;

    (void) src;
    if (!arena || !storage || storage_cap <= 0) {
        return 0;
    }

    out_count = 0;
    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_IR_BEGIN_SECTION;
        instr.section_kind = sec->kind;
        instr.header_start = sec->header_start;
        instr.header_count = sec->header_count;
        instr.line = sec->line;
        instr.col = sec->col;
        instr.profile_tag = msd_profile_get_active();
        if (out_count >= storage_cap) return 0;
        storage[out_count++] = instr;

        for (ii = 0; ii < sec->item_count; ++ii) {
            item = &arena->items[sec->first_item + ii];
            memset(&instr, 0, sizeof(instr));
            instr.op = item->kind == MSD_ITEM_ASSIGN ? MSD_IR_SET : MSD_IR_ROW;
            instr.section_kind = sec->kind;
            instr.key_atom = item->key_atom;
            instr.value_start = item->value_start;
            instr.value_count = item->value_count;
            instr.line = item->line;
            instr.col = item->col;
            instr.profile_tag = msd_profile_get_active();
            if (out_count >= storage_cap) return 0;
            storage[out_count++] = instr;
        }

        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_IR_END_SECTION;
        instr.section_kind = sec->kind;
        instr.line = sec->line;
        instr.col = sec->col;
        instr.profile_tag = msd_profile_get_active();
        if (out_count >= storage_cap) return 0;
        storage[out_count++] = instr;
    }

    arena->ir = storage;
    arena->ir_count = out_count;
    return 1;
}

void msd_ir_dump(const MsdSource *src, const MsdArena *arena, FILE *out)
{
    int i;
    int j;
    char buf[128];
    const MsdIRInstr *instr;

    if (!src || !arena || !arena->ir || !out) {
        return;
    }

    for (i = 0; i < arena->ir_count; ++i) {
        instr = &arena->ir[i];
        fprintf(out, "%4d  ", i);
        if (instr->op == MSD_IR_BEGIN_SECTION) {
            fprintf(out, "BEGIN %-12s [%s] ", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
            for (j = 0; j < instr->header_count; ++j) {
                msd_atom_to_text(src, &arena->atoms[instr->header_start + j], buf, sizeof(buf));
                if (j > 0) fprintf(out, " ");
                fprintf(out, "%s", buf);
            }
        } else if (instr->op == MSD_IR_SET) {
            fprintf(out, "SET   %-12s [%s] ", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
            msd_atom_to_text(src, &arena->atoms[instr->key_atom], buf, sizeof(buf));
            fprintf(out, "%s = ", buf);
            for (j = 0; j < instr->value_count; ++j) {
                msd_atom_to_text(src, &arena->atoms[instr->value_start + j], buf, sizeof(buf));
                if (j > 0) fprintf(out, ", ");
                fprintf(out, "%s", buf);
            }
        } else if (instr->op == MSD_IR_ROW) {
            fprintf(out, "ROW   %-12s [%s] ", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
            for (j = 0; j < instr->value_count; ++j) {
                msd_atom_to_text(src, &arena->atoms[instr->value_start + j], buf, sizeof(buf));
                if (j > 0) fprintf(out, ", ");
                fprintf(out, "%s", buf);
            }
        } else {
            fprintf(out, "END   %-12s [%s]", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
        }
        fprintf(out, "\n");
    }
}
