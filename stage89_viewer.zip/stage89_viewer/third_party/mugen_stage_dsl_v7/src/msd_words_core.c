#include "msd_runtime.h"

static void msd_core_atom_text(const MsdSource *src, const MsdBCAtom *atom, char *buf, int cap)
{
    if (atom->type == MSD_ATOM_NUMBER) {
        if (atom->is_fixed) {
            msd_fixed_to_string(atom->number, buf, cap);
        } else {
            sprintf(buf, "%ld", msd_fixed_to_int(atom->number));
        }
    } else if (atom->type == MSD_ATOM_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, atom->offset, atom->length);
    } else {
        msd_copy_span(buf, cap, src->data, atom->offset, atom->length);
    }
}

static void msd_core_values_text(const MsdSource *src, const MsdBCAtom *atoms, int start, int count, char *buf, int cap)
{
    int i;
    int len;
    char part[64];
    buf[0] = '\0';
    len = 0;
    for (i = 0; i < count; ++i) {
        if (i > 0) {
            msd_append_cstr(buf, cap, &len, ", ");
        }
        msd_core_atom_text(src, &atoms[start + i], part, sizeof(part));
        msd_append_cstr(buf, cap, &len, part);
    }
}

const char *msd_builtin_name(MsdBuiltinId id)
{
    switch (id) {
    case MSD_BUILTIN_NONE: return "none";
    case MSD_BUILTIN_CORE_RAW_ASSIGN: return "core.raw.assign";
    case MSD_BUILTIN_CORE_RAW_ROW: return "core.raw.row";
    case MSD_BUILTIN_CORE_TIME_TICKS: return "core.time.ticks";
    case MSD_BUILTIN_CORE_TIME_MS: return "core.time.ms";
    case MSD_BUILTIN_GAME_STAGE_NAME: return "game.stage.name";
    case MSD_BUILTIN_GAME_STAGE_DISPLAYNAME: return "game.stage.displayname";
    case MSD_BUILTIN_GAME_STAGE_AUTHOR: return "game.stage.author";
    case MSD_BUILTIN_GAME_STAGE_VERSIONDATE: return "game.stage.versiondate";
    case MSD_BUILTIN_GAME_STAGE_MUGENVERSION: return "game.stage.mugenversion";
    case MSD_BUILTIN_GAME_STAGE_ZOFFSET: return "game.stage.zoffset";
    case MSD_BUILTIN_GAME_STAGE_ZOFFSETLINK: return "game.stage.zoffsetlink";
    case MSD_BUILTIN_GAME_STAGE_AUTOTURN: return "game.stage.autoturn";
    case MSD_BUILTIN_GAME_STAGE_RESETBG: return "game.stage.resetbg";
    case MSD_BUILTIN_GAME_STAGE_LOCALCOORD: return "game.stage.localcoord";
    case MSD_BUILTIN_GAME_STAGE_XSCALE: return "game.stage.xscale";
    case MSD_BUILTIN_GAME_STAGE_YSCALE: return "game.stage.yscale";
    case MSD_BUILTIN_GAME_STAGE_SPR: return "game.stage.spr";
    case MSD_BUILTIN_GAME_STAGE_DEBUGBG: return "game.stage.debugbg";
    case MSD_BUILTIN_GAME_STAGE_BGMUSIC: return "game.stage.bgmusic";
    case MSD_BUILTIN_GAME_STAGE_BGVOLUME: return "game.stage.bgvolume";
    case MSD_BUILTIN_GAME_SHADOW_INTENSITY: return "game.shadow.intensity";
    case MSD_BUILTIN_GAME_SHADOW_COLOR: return "game.shadow.color";
    case MSD_BUILTIN_GAME_SHADOW_YSCALE: return "game.shadow.yscale";
    case MSD_BUILTIN_GAME_SHADOW_FADERANGE: return "game.shadow.fade.range";
    case MSD_BUILTIN_GAME_SHADOW_XSHEAR: return "game.shadow.xshear";
    case MSD_BUILTIN_GAME_REFLECTION_REFLECT: return "game.reflection.reflect";
    case MSD_BUILTIN_GAME_CAMERA_STARTX: return "game.camera.startx";
    case MSD_BUILTIN_GAME_CAMERA_STARTY: return "game.camera.starty";
    case MSD_BUILTIN_GAME_CAMERA_BOUNDLEFT: return "game.camera.boundleft";
    case MSD_BUILTIN_GAME_CAMERA_BOUNDRIGHT: return "game.camera.boundright";
    case MSD_BUILTIN_GAME_CAMERA_BOUNDHIGH: return "game.camera.boundhigh";
    case MSD_BUILTIN_GAME_CAMERA_BOUNDLOW: return "game.camera.boundlow";
    case MSD_BUILTIN_GAME_CAMERA_TENSION: return "game.camera.tension";
    case MSD_BUILTIN_GAME_CAMERA_OVERDRAWHIGH: return "game.camera.overdrawhigh";
    case MSD_BUILTIN_GAME_CAMERA_OVERDRAWLOW: return "game.camera.overdrawlow";
    case MSD_BUILTIN_GAME_CAMERA_CUTHIGH: return "game.camera.cuthigh";
    case MSD_BUILTIN_GAME_CAMERA_CUTLOW: return "game.camera.cutlow";
    case MSD_BUILTIN_GAME_CAMERA_TENSIONHIGH: return "game.camera.tensionhigh";
    case MSD_BUILTIN_GAME_CAMERA_TENSIONLOW: return "game.camera.tensionlow";
    case MSD_BUILTIN_GAME_CAMERA_VERTICALFOLLOW: return "game.camera.verticalfollow";
    case MSD_BUILTIN_GAME_CAMERA_FLOORTENSION: return "game.camera.floortension";
    case MSD_BUILTIN_GAME_CAMERA_STARTZOOM: return "game.camera.startzoom";
    case MSD_BUILTIN_GAME_CAMERA_ZOOMOUT: return "game.camera.zoomout";
    case MSD_BUILTIN_GAME_CAMERA_ZOOMIN: return "game.camera.zoomin";
    case MSD_BUILTIN_GAME_PLAYER_P1STARTX: return "game.player.p1startx";
    case MSD_BUILTIN_GAME_PLAYER_P1STARTY: return "game.player.p1starty";
    case MSD_BUILTIN_GAME_PLAYER_P1FACING: return "game.player.p1facing";
    case MSD_BUILTIN_GAME_PLAYER_P2STARTX: return "game.player.p2startx";
    case MSD_BUILTIN_GAME_PLAYER_P2STARTY: return "game.player.p2starty";
    case MSD_BUILTIN_GAME_PLAYER_P2FACING: return "game.player.p2facing";
    case MSD_BUILTIN_GAME_PLAYER_LEFTBOUND: return "game.player.leftbound";
    case MSD_BUILTIN_GAME_PLAYER_RIGHTBOUND: return "game.player.rightbound";
    case MSD_BUILTIN_GAME_BOUND_SCREENLEFT: return "game.bound.screenleft";
    case MSD_BUILTIN_GAME_BOUND_SCREENRIGHT: return "game.bound.screenright";
    case MSD_BUILTIN_GAME_BG_BEGIN: return "game.bg.begin";
    case MSD_BUILTIN_GAME_BG_TYPE: return "game.bg.type";
    case MSD_BUILTIN_GAME_BG_SPRITENO: return "game.bg.spriteno";
    case MSD_BUILTIN_GAME_BG_ACTIONNO: return "game.bg.actionno";
    case MSD_BUILTIN_GAME_BG_START: return "game.bg.start";
    case MSD_BUILTIN_GAME_BG_DELTA: return "game.bg.delta";
    case MSD_BUILTIN_GAME_BG_MASK: return "game.bg.mask";
    case MSD_BUILTIN_GAME_BG_LAYERNO: return "game.bg.layerno";
    case MSD_BUILTIN_GAME_BG_ID: return "game.bg.id";
    case MSD_BUILTIN_GAME_BG_TILE: return "game.bg.tile";
    case MSD_BUILTIN_GAME_BG_TILESPACING: return "game.bg.tilespacing";
    case MSD_BUILTIN_GAME_BG_WINDOW: return "game.bg.window";
    case MSD_BUILTIN_GAME_BG_WINDOWDELTA: return "game.bg.windowdelta";
    case MSD_BUILTIN_GAME_BG_TRANS: return "game.bg.trans";
    case MSD_BUILTIN_GAME_BG_ALPHA: return "game.bg.alpha";
    case MSD_BUILTIN_GAME_BG_VELOCITY: return "game.bg.velocity";
    case MSD_BUILTIN_GAME_BG_POSITIONLINK: return "game.bg.positionlink";
    case MSD_BUILTIN_GAME_BG_WIDTH: return "game.bg.width";
    case MSD_BUILTIN_GAME_BG_XSCALE: return "game.bg.xscale";
    case MSD_BUILTIN_GAME_BG_YSCALESTART: return "game.bg.yscalestart";
    case MSD_BUILTIN_GAME_BG_YSCALEDELTA: return "game.bg.yscaledelta";
    case MSD_BUILTIN_GAME_BG_SCALESTART: return "game.bg.scalestart";
    case MSD_BUILTIN_GAME_BG_SCALEDELTA: return "game.bg.scaledelta";
    case MSD_BUILTIN_GAME_BG_MASKWINDOW: return "game.bg.maskwindow";
    case MSD_BUILTIN_GAME_BG_ZOOMDELTA: return "game.bg.zoomdelta";
    case MSD_BUILTIN_GAME_BG_SINX: return "game.bg.sinx";
    case MSD_BUILTIN_GAME_BG_SINY: return "game.bg.siny";
    case MSD_BUILTIN_GAME_BG_TRACKCHAR: return "game.bg.trackchar";
    case MSD_BUILTIN_GAME_BGCTRLDEF_BEGIN: return "game.bgctrldef.begin";
    case MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME: return "game.bgctrldef.looptime";
    case MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID: return "game.bgctrldef.ctrlid";
    case MSD_BUILTIN_GAME_BGCTRL_BEGIN: return "game.bgctrl.begin";
    case MSD_BUILTIN_GAME_BGCTRL_TYPE: return "game.bgctrl.type";
    case MSD_BUILTIN_GAME_BGCTRL_TIME: return "game.bgctrl.time";
    case MSD_BUILTIN_GAME_BGCTRL_CTRLID: return "game.bgctrl.ctrlid";
    case MSD_BUILTIN_GAME_BGCTRL_X: return "game.bgctrl.x";
    case MSD_BUILTIN_GAME_BGCTRL_Y: return "game.bgctrl.y";
    case MSD_BUILTIN_GAME_BGCTRL_VALUE: return "game.bgctrl.value";
    case MSD_BUILTIN_GAME_BGCTRL_ATTACHEDCHAR: return "game.bgctrl.attachedchar";
    case MSD_BUILTIN_GAME_BGCTRL_ATTACHEDID: return "game.bgctrl.attachedid";
    case MSD_BUILTIN_GAME_BGCTRL_SCTRLID: return "game.bgctrl.sctrlid";
    case MSD_BUILTIN_GAME_BGCTRL_MODIFYBGCTRL: return "game.bgctrl.modifybgctrl";
    case MSD_BUILTIN_GAME_BGCTRL_CHAROFFSET: return "game.bgctrl.charoffset";
    case MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR: return "game.bgctrl.followchar";
    case MSD_BUILTIN_GAME_ACTION_BEGIN: return "game.action.begin";
    case MSD_BUILTIN_GAME_ACTION_FRAME: return "game.action.frame";
    }
    return "unknown";
}

int msd_builtin_is_core(MsdBuiltinId id)
{
    return id == MSD_BUILTIN_CORE_RAW_ASSIGN || id == MSD_BUILTIN_CORE_RAW_ROW || id == MSD_BUILTIN_CORE_TIME_TICKS || id == MSD_BUILTIN_CORE_TIME_MS;
}

int msd_core_execute(struct MsdRuntime *rt, const MsdSource *src, const struct MsdBCInstr *instr, const struct MsdBCAtom *atoms)
{
    char key[64];
    char values[160];
    if (!rt || !src || !instr || !atoms) {
        return 0;
    }
    if (instr->word_id == MSD_BUILTIN_CORE_RAW_ASSIGN) {
        if (instr->name_atom >= 0) {
            msd_core_atom_text(src, &atoms[instr->name_atom], key, sizeof(key));
        } else {
            key[0] = '\0';
        }
        msd_core_values_text(src, atoms, instr->const_start, instr->const_count, values, sizeof(values));
        return msd_runtime_store_raw_assign(rt, rt->ctx.section_name, rt->ctx.section_kind, key, values);
    }
    if (instr->word_id == MSD_BUILTIN_CORE_RAW_ROW) {
        msd_core_values_text(src, atoms, instr->const_start, instr->const_count, values, sizeof(values));
        return msd_runtime_store_raw_row(rt, rt->ctx.section_name, rt->ctx.section_kind, values);
    }
    if (instr->word_id == MSD_BUILTIN_CORE_TIME_TICKS || instr->word_id == MSD_BUILTIN_CORE_TIME_MS) {
        return 1;
    }
    return 0;
}
