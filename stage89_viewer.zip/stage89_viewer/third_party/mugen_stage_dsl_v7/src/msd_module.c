#include "msd_module.h"

#define MSD_MODULE_HASH_INIT 2166136261UL
#define MSD_MODULE_HASH_MULT 16777619UL

static int msd_module_append_bytes(MsdSource *dst, int *len, const char *src, int count)
{
    int i;
    if (!dst || !len || !src || count < 0) return 0;
    if (*len + count > MSD_MAX_SOURCE_BYTES) return 0;
    for (i = 0; i < count; ++i) {
        dst->data[*len + i] = src[i];
    }
    *len += count;
    dst->data[*len] = '\0';
    return 1;
}

static int msd_module_append_char_local(MsdSource *dst, int *len, char ch)
{
    if (!dst || !len) return 0;
    if (*len >= MSD_MAX_SOURCE_BYTES) return 0;
    dst->data[*len] = ch;
    *len += 1;
    dst->data[*len] = '\0';
    return 1;
}

static int msd_module_is_abs_path(const char *path)
{
    if (!path || path[0] == '\0') return 0;
    if (path[0] == '/' || path[0] == '\\') return 1;
    if (((path[0] >= 'A' && path[0] <= 'Z') || (path[0] >= 'a' && path[0] <= 'z')) && path[1] == ':') {
        return 1;
    }
    return 0;
}

static void msd_module_dirname(const char *path, char *out, int cap)
{
    int i;
    int last;
    if (!out || cap <= 0) return;
    out[0] = '\0';
    if (!path) return;
    last = -1;
    for (i = 0; path[i] != '\0'; ++i) {
        if (path[i] == '/' || path[i] == '\\') {
            last = i;
        }
    }
    if (last < 0) {
        strcpy(out, ".");
        return;
    }
    if (last >= cap) last = cap - 1;
    for (i = 0; i < last; ++i) {
        out[i] = path[i];
    }
    out[last] = '\0';
}

static int msd_module_join_path(char *out, int cap, const char *base_dir, const char *rel)
{
    int len;
    if (!out || cap <= 0 || !rel) return 0;
    out[0] = '\0';
    if (msd_module_is_abs_path(rel)) {
        if ((int) strlen(rel) >= cap) return 0;
        strcpy(out, rel);
        return 1;
    }
    if (!base_dir || base_dir[0] == '\0') base_dir = ".";
    if ((int) strlen(base_dir) + 1 + (int) strlen(rel) >= cap) return 0;
    strcpy(out, base_dir);
    len = (int) strlen(out);
    if (len > 0 && out[len - 1] != '/' && out[len - 1] != '\\') {
        out[len++] = '/';
        out[len] = '\0';
    }
    strcat(out, rel);
    return 1;
}

static int msd_module_same_path(const char *a, const char *b)
{
    int i;
    if (!a || !b) return 0;
    i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (a[i] != b[i]) return 0;
        ++i;
    }
    return a[i] == '\0' && b[i] == '\0';
}

static int msd_module_parse_include(const char *line, int len, char *out_path, int cap)
{
    int i;
    int start;
    int n;
    if (!line || len <= 0 || !out_path || cap <= 0) return 0;
    out_path[0] = '\0';
    i = 0;
    while (i < len && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r')) ++i;
    if (i >= len) return 0;
    if (line[i] == ';') return 0;
    if (line[i] == '@') {
        if (i + 8 > len) return 0;
        if (strncmp(line + i, "@include", 8u) != 0) return 0;
        i += 8;
    } else if (line[i] == '#') {
        if (i + 8 > len) return 0;
        if (strncmp(line + i, "#include", 8u) != 0) return 0;
        i += 8;
    } else {
        return 0;
    }
    while (i < len && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r')) ++i;
    if (i >= len || line[i] != '"') return 0;
    ++i;
    start = i;
    while (i < len && line[i] != '"') ++i;
    if (i >= len) return 0;
    n = i - start;
    if (n <= 0 || n >= cap) return 0;
    memcpy(out_path, line + start, (size_t) n);
    out_path[n] = '\0';
    return 1;
}

unsigned long msd_module_hash_buffer(const char *data, int size)
{
    unsigned long hash;
    int i;
    hash = MSD_MODULE_HASH_INIT;
    if (!data || size < 0) return 0UL;
    for (i = 0; i < size; ++i) {
        hash ^= (unsigned char) data[i];
        hash *= MSD_MODULE_HASH_MULT;
    }
    return hash;
}

unsigned long msd_module_hash_source(const MsdSource *src)
{
    if (!src) return 0UL;
    return msd_module_hash_buffer(src->data, src->size);
}

static int msd_module_add_dep(MsdModuleInfo *info, const char *path, int size, unsigned long hash, int parent_index, int depth)
{
    int index;
    if (!info || !path) return -1;
    if (info->dep_count >= MSD_MAX_DEPS) return -1;
    index = info->dep_count;
    memset(&info->deps[index], 0, sizeof(info->deps[index]));
    strncpy(info->deps[index].path, path, sizeof(info->deps[index].path) - 1u);
    info->deps[index].size = size;
    info->deps[index].hash = hash;
    info->deps[index].parent_index = parent_index;
    info->deps[index].depth = depth;
    info->dep_count += 1;
    return index;
}

static int msd_module_load_rec(MsdSource *dst, int *dst_len, MsdModuleInfo *info, const char *path, int parent_index, int depth, char stack[MSD_MAX_MODULE_DEPTH][260], int stack_depth)
{
    MsdSource src;
    char base_dir[260];
    int dep_index;
    int line_start;
    int i;

    if (!dst || !dst_len || !info || !path) return 0;
    if (depth >= MSD_MAX_MODULE_DEPTH) return 0;
    for (i = 0; i < stack_depth; ++i) {
        if (msd_module_same_path(stack[i], path)) {
            return 0;
        }
    }
    if (!msd_source_load(&src, path)) return 0;
    dep_index = msd_module_add_dep(info, path, src.size, msd_module_hash_source(&src), parent_index, depth);
    if (dep_index < 0) return 0;
    strncpy(stack[stack_depth], path, 259u);
    stack[stack_depth][259] = '\0';
    msd_module_dirname(path, base_dir, sizeof(base_dir));

    line_start = 0;
    while (line_start < src.size) {
        int line_end;
        int line_len;
        int full_len;
        char include_rel[260];
        char include_path[260];
        line_end = line_start;
        while (line_end < src.size && src.data[line_end] != '\n') ++line_end;
        line_len = line_end - line_start;
        full_len = line_len;
        if (line_end < src.size && src.data[line_end] == '\n') {
            full_len += 1;
        }
        if (msd_module_parse_include(src.data + line_start, line_len, include_rel, sizeof(include_rel))) {
            if (!msd_module_join_path(include_path, sizeof(include_path), base_dir, include_rel)) return 0;
            if (!msd_module_load_rec(dst, dst_len, info, include_path, dep_index, depth + 1, stack, stack_depth + 1)) return 0;
            if (*dst_len > 0 && dst->data[*dst_len - 1] != '\n') {
                if (!msd_module_append_char_local(dst, dst_len, '\n')) return 0;
            }
        } else {
            if (!msd_module_append_bytes(dst, dst_len, src.data + line_start, full_len)) return 0;
        }
        line_start += full_len;
    }
    return 1;
}

int msd_module_load(MsdSource *dst, MsdModuleInfo *info, const char *path)
{
    int i;
    int len;
    char stack[MSD_MAX_MODULE_DEPTH][260];
    if (!dst || !info || !path) return 0;
    memset(dst, 0, sizeof(*dst));
    memset(info, 0, sizeof(*info));
    for (i = 0; path[i] != '\0' && i < (int) sizeof(dst->path) - 1; ++i) {
        dst->path[i] = path[i];
    }
    dst->path[i] = '\0';
    len = 0;
    if (!msd_module_load_rec(dst, &len, info, path, -1, 0, stack, 0)) {
        return 0;
    }
    dst->size = len;
    dst->data[len] = '\0';
    info->merged_size = len;
    info->merged_hash = msd_module_hash_source(dst);
    return 1;
}

int msd_module_default_link_path(const char *input_path, char *out, int cap)
{
    int len;
    if (!input_path || !out || cap <= 0) return 0;
    len = (int) strlen(input_path);
    if (len >= 4 && msd_ascii_tolower((unsigned char) input_path[len - 4]) == '.' &&
        msd_ascii_tolower((unsigned char) input_path[len - 3]) == 'd' &&
        msd_ascii_tolower((unsigned char) input_path[len - 2]) == 'e' &&
        msd_ascii_tolower((unsigned char) input_path[len - 1]) == 'f') {
        if (len + 4 >= cap) return 0;
        memcpy(out, input_path, (size_t) (len - 3));
        strcpy(out + (len - 3), "linked.def");
        return 1;
    }
    if (len + 12 >= cap) return 0;
    strcpy(out, input_path);
    strcat(out, ".linked.def");
    return 1;
}

int msd_module_write_linked(const MsdSource *src, const char *path)
{
    FILE *fp;
    size_t nwritten;
    if (!src || !path) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;
    nwritten = fwrite(src->data, 1u, (size_t) src->size, fp);
    fclose(fp);
    return nwritten == (size_t) src->size;
}

void msd_module_print_info(const MsdModuleInfo *info, FILE *out)
{
    int i;
    if (!info || !out) return;
    fprintf(out, "deps=%d merged_size=%d merged_hash=%lu\n", info->dep_count, info->merged_size, info->merged_hash);
    for (i = 0; i < info->dep_count; ++i) {
        fprintf(out, "  [%d] depth=%d parent=%d size=%d hash=%lu path=%s\n",
            i,
            info->deps[i].depth,
            info->deps[i].parent_index,
            info->deps[i].size,
            info->deps[i].hash,
            info->deps[i].path);
    }
}
