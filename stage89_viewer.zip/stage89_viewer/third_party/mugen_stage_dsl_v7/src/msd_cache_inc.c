#include "msd_cache_inc.h"
#include "msd_cache.h"

#define MSD_INC_CACHE_VERSION 1

static const char msd_inc_magic[8] = { 'M', 'S', 'D', 'C', 'I', '4', '0', '\0' };

static int msd_write_int(FILE *fp, int value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_read_int(FILE *fp, int *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_write_ulong(FILE *fp, unsigned long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_read_ulong(FILE *fp, unsigned long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_write_canon_plan(FILE *fp, const MsdCanonPlanInstr *plan)
{
    if (!msd_write_int(fp, (int) plan->item_kind)) return 0;
    if (!msd_write_int(fp, plan->item_ordinal)) return 0;
    if (!msd_write_int(fp, (int) plan->word_id)) return 0;
    return 1;
}

static int msd_read_canon_plan(FILE *fp, MsdCanonPlanInstr *plan)
{
    int value;
    if (!msd_read_int(fp, &value)) return 0;
    plan->item_kind = (MsdItemKind) value;
    if (!msd_read_int(fp, &plan->item_ordinal)) return 0;
    if (!msd_read_int(fp, &value)) return 0;
    plan->word_id = (MsdBuiltinId) value;
    return 1;
}

static int msd_write_section(FILE *fp, const MsdCanonSection *sec)
{
    int len;
    len = (int) strlen(sec->header_text);
    if (len >= 64) len = 63;
    if (!msd_write_int(fp, (int) sec->kind)) return 0;
    if (!msd_write_ulong(fp, sec->plan_hash)) return 0;
    if (!msd_write_ulong(fp, sec->canon_hash)) return 0;
    if (!msd_write_int(fp, sec->plan_start)) return 0;
    if (!msd_write_int(fp, sec->plan_count)) return 0;
    if (!msd_write_int(fp, len)) return 0;
    if (len > 0 && fwrite(sec->header_text, 1u, (size_t) len, fp) != (size_t) len) return 0;
    return 1;
}

static int msd_read_section(FILE *fp, MsdIncCacheSection *sec)
{
    int kind;
    int len;
    if (!msd_read_int(fp, &kind)) return 0;
    sec->kind = (MsdSectionKind) kind;
    if (!msd_read_ulong(fp, &sec->plan_hash)) return 0;
    if (!msd_read_ulong(fp, &sec->canon_hash)) return 0;
    if (!msd_read_int(fp, &sec->plan_start)) return 0;
    if (!msd_read_int(fp, &sec->plan_count)) return 0;
    if (!msd_read_int(fp, &len)) return 0;
    if (len < 0 || len >= (int) sizeof(sec->header_text)) return 0;
    if (len > 0 && fread(sec->header_text, 1u, (size_t) len, fp) != (size_t) len) return 0;
    sec->header_text[len] = '\0';
    return 1;
}

int msd_cache_inc_default_path(const char *input_path, char *out, int cap)
{
    int len;
    if (!input_path || !out || cap <= 0) return 0;
    len = (int) strlen(input_path);
    if (len >= 4 && msd_ascii_tolower((unsigned char) input_path[len - 4]) == '.' &&
        msd_ascii_tolower((unsigned char) input_path[len - 3]) == 'd' &&
        msd_ascii_tolower((unsigned char) input_path[len - 2]) == 'e' &&
        msd_ascii_tolower((unsigned char) input_path[len - 1]) == 'f') {
        if (len + 2 >= cap) return 0;
        memcpy(out, input_path, (size_t) (len - 3));
        strcpy(out + (len - 3), "msdci");
        return 1;
    }
    if (len + 6 >= cap) return 0;
    strcpy(out, input_path);
    strcat(out, ".msdci");
    return 1;
}

int msd_cache_inc_save(const char *path, const MsdSource *src, const MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, int plan_count)
{
    FILE *fp;
    int i;
    int path_len;
    if (!path || !src || !sections || !plans) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;
    if (fwrite(msd_inc_magic, sizeof(msd_inc_magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    if (!msd_write_int(fp, MSD_INC_CACHE_VERSION)) { fclose(fp); return 0; }
    if (!msd_write_int(fp, 0)) { fclose(fp); return 0; }
    if (!msd_write_int(fp, (int) sizeof(int))) { fclose(fp); return 0; }
    if (!msd_write_int(fp, (int) sizeof(long))) { fclose(fp); return 0; }
    if (!msd_write_int(fp, MSD_FIXED_FRAC_BITS)) { fclose(fp); return 0; }
    if (!msd_write_ulong(fp, msd_hash_buffer(src->data, src->size))) { fclose(fp); return 0; }
    if (!msd_write_int(fp, section_count)) { fclose(fp); return 0; }
    if (!msd_write_int(fp, plan_count)) { fclose(fp); return 0; }
    path_len = (int) strlen(src->path);
    if (path_len >= (int) sizeof(src->path)) path_len = (int) sizeof(src->path) - 1;
    if (!msd_write_int(fp, path_len)) { fclose(fp); return 0; }
    if (path_len > 0 && fwrite(src->path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    for (i = 0; i < section_count; ++i) {
        if (!msd_write_section(fp, &sections[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < plan_count; ++i) {
        if (!msd_write_canon_plan(fp, &plans[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_cache_inc_read_info(const char *path, MsdIncCacheInfo *info)
{
    FILE *fp;
    int i;
    int path_len;
    char magic[8];
    if (!path || !info) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fread(magic, sizeof(magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    for (i = 0; i < 8; ++i) {
        if (magic[i] != msd_inc_magic[i]) { fclose(fp); return 0; }
    }
    memset(info, 0, sizeof(*info));
    if (!msd_read_int(fp, &info->version)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->flags)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->int_size)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->long_size)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->fixed_frac_bits)) { fclose(fp); return 0; }
    if (!msd_read_ulong(fp, &info->source_hash)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->section_count)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->plan_count)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &path_len)) { fclose(fp); return 0; }
    if (path_len < 0 || path_len >= (int) sizeof(info->source_path)) { fclose(fp); return 0; }
    if (path_len > 0 && fread(info->source_path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    info->source_path[path_len] = '\0';
    if (info->section_count < 0 || info->section_count > MSD_MAX_SECTIONS || info->plan_count < 0 || info->plan_count > MSD_MAX_ITEMS) { fclose(fp); return 0; }
    for (i = 0; i < info->section_count; ++i) {
        if (!msd_read_section(fp, &info->sections[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_cache_inc_load(const char *path, MsdIncCacheInfo *info, MsdCanonPlanInstr *plans, int plan_cap)
{
    FILE *fp;
    int i;
    int path_len;
    char magic[8];
    if (!path || !info || !plans) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fread(magic, sizeof(magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    for (i = 0; i < 8; ++i) {
        if (magic[i] != msd_inc_magic[i]) { fclose(fp); return 0; }
    }
    memset(info, 0, sizeof(*info));
    if (!msd_read_int(fp, &info->version)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->flags)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->int_size)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->long_size)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->fixed_frac_bits)) { fclose(fp); return 0; }
    if (!msd_read_ulong(fp, &info->source_hash)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->section_count)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &info->plan_count)) { fclose(fp); return 0; }
    if (!msd_read_int(fp, &path_len)) { fclose(fp); return 0; }
    if (path_len < 0 || path_len >= (int) sizeof(info->source_path)) { fclose(fp); return 0; }
    if (path_len > 0 && fread(info->source_path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    info->source_path[path_len] = '\0';
    if (info->version != MSD_INC_CACHE_VERSION || info->int_size != (int) sizeof(int) || info->long_size != (int) sizeof(long) || info->fixed_frac_bits != MSD_FIXED_FRAC_BITS) { fclose(fp); return 0; }
    if (info->section_count < 0 || info->section_count > MSD_MAX_SECTIONS || info->plan_count < 0 || info->plan_count > plan_cap) { fclose(fp); return 0; }
    for (i = 0; i < info->section_count; ++i) {
        if (!msd_read_section(fp, &info->sections[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < info->plan_count; ++i) {
        if (!msd_read_canon_plan(fp, &plans[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_cache_inc_find_match(const MsdIncCacheInfo *info, MsdSectionKind kind, unsigned long plan_hash, const char *header_text)
{
    int i;
    if (!info) return -1;
    for (i = 0; i < info->section_count; ++i) {
        if (info->sections[i].kind == kind && info->sections[i].plan_hash == plan_hash) {
            if (!header_text || strcmp(info->sections[i].header_text, header_text) == 0) {
                return i;
            }
        }
    }
    return -1;
}

void msd_cache_inc_print_info(const MsdIncCacheInfo *info, FILE *out)
{
    int i;
    if (!info || !out) return;
    fprintf(out, "inc-cache version: %d\n", info->version);
    fprintf(out, "abi: int=%d long=%d fixed=%d\n", info->int_size, info->long_size, info->fixed_frac_bits);
    fprintf(out, "source: %s\n", info->source_path);
    fprintf(out, "source_hash: %lu\n", info->source_hash);
    fprintf(out, "sections=%d plans=%d\n", info->section_count, info->plan_count);
    for (i = 0; i < info->section_count; ++i) {
        fprintf(out, "  [%d] kind=%s header=%s plan_hash=%lu canon_hash=%lu plans=%d\n",
            i,
            msd_section_kind_name(info->sections[i].kind),
            info->sections[i].header_text,
            info->sections[i].plan_hash,
            info->sections[i].canon_hash,
            info->sections[i].plan_count);
    }
}
