#include "msd_arena.h"

void msd_arena_init(MsdArena *arena)
{
    if (!arena) {
        return;
    }
    memset(arena, 0, sizeof(*arena));
}

int msd_arena_add_error(MsdArena *arena, int line, int col, const char *message)
{
    MsdError *err;
    if (!arena || arena->error_count >= MSD_MAX_ERRORS) {
        return 0;
    }
    err = &arena->errors[arena->error_count++];
    err->line = line;
    err->col = col;
    msd_copy_span(err->message, MSD_MAX_TEXT, message, 0, (int) strlen(message));
    return 1;
}

int msd_arena_add_token(MsdArena *arena, const MsdToken *tok)
{
    if (!arena || !tok || arena->token_count >= MSD_MAX_TOKENS) {
        return -1;
    }
    arena->tokens[arena->token_count] = *tok;
    return arena->token_count++;
}

int msd_arena_add_atom(MsdArena *arena, const MsdAtom *atom)
{
    if (!arena || !atom || arena->atom_count >= MSD_MAX_ATOMS) {
        return -1;
    }
    arena->atoms[arena->atom_count] = *atom;
    return arena->atom_count++;
}

int msd_arena_add_section(MsdArena *arena, const MsdAstSection *section)
{
    if (!arena || !section || arena->section_count >= MSD_MAX_SECTIONS) {
        return -1;
    }
    arena->sections[arena->section_count] = *section;
    return arena->section_count++;
}

int msd_arena_add_item(MsdArena *arena, const MsdAstItem *item)
{
    if (!arena || !item || arena->item_count >= MSD_MAX_ITEMS) {
        return -1;
    }
    arena->items[arena->item_count] = *item;
    return arena->item_count++;
}
