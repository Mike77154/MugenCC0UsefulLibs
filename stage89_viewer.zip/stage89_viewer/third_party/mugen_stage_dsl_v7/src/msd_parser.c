#include "msd_parser.h"

static int msd_make_atom_from_token(const MsdToken *tok, MsdAtom *atom)
{
    if (!tok || !atom) {
        return 0;
    }
    if (tok->type == MSD_TOK_IDENT) {
        atom->type = MSD_ATOM_IDENT;
    } else if (tok->type == MSD_TOK_STRING) {
        atom->type = MSD_ATOM_STRING;
    } else if (tok->type == MSD_TOK_NUMBER) {
        atom->type = MSD_ATOM_NUMBER;
    } else {
        return 0;
    }
    atom->offset = tok->offset;
    atom->length = tok->length;
    atom->number = tok->number;
    atom->is_fixed = tok->is_fixed;
    atom->line = tok->line;
    atom->col = tok->col;
    return 1;
}

static int msd_token_can_atom(MsdTokenType type)
{
    return type == MSD_TOK_IDENT || type == MSD_TOK_STRING || type == MSD_TOK_NUMBER;
}

int msd_parse_tokens(const MsdSource *src, MsdArena *arena)
{
    int pos;
    int current_section;
    MsdAstSection sec;
    MsdAstItem item;
    MsdAtom atom;
    int atom_index;
    int header_start;
    int header_count;
    const MsdToken *tok;

    if (!src || !arena) {
        return 0;
    }

    pos = 0;
    current_section = -1;

    while (pos < arena->token_count) {
        tok = &arena->tokens[pos];
        if (tok->type == MSD_TOK_EOF) {
            break;
        }
        if (tok->type == MSD_TOK_NEWLINE) {
            ++pos;
            continue;
        }
        if (tok->type == MSD_TOK_LBRACKET) {
            memset(&sec, 0, sizeof(sec));
            sec.line = tok->line;
            sec.col = tok->col;
            sec.first_item = arena->item_count;
            ++pos;
            header_start = arena->atom_count;
            header_count = 0;
            while (pos < arena->token_count && arena->tokens[pos].type != MSD_TOK_RBRACKET && arena->tokens[pos].type != MSD_TOK_EOF) {
                if (!msd_token_can_atom(arena->tokens[pos].type)) {
                    msd_arena_add_error(arena, arena->tokens[pos].line, arena->tokens[pos].col, "invalid token in section header");
                    return 0;
                }
                if (!msd_make_atom_from_token(&arena->tokens[pos], &atom)) {
                    return 0;
                }
                if (msd_arena_add_atom(arena, &atom) < 0) {
                    return 0;
                }
                ++header_count;
                ++pos;
            }
            if (pos >= arena->token_count || arena->tokens[pos].type != MSD_TOK_RBRACKET) {
                msd_arena_add_error(arena, sec.line, sec.col, "unterminated section header");
                return 0;
            }
            ++pos;
            sec.header_start = header_start;
            sec.header_count = header_count;
            sec.kind = msd_section_kind_from_header(src, arena, header_start, header_count);
            sec.item_count = 0;
            current_section = msd_arena_add_section(arena, &sec);
            if (current_section < 0) {
                return 0;
            }
            while (pos < arena->token_count && arena->tokens[pos].type != MSD_TOK_NEWLINE && arena->tokens[pos].type != MSD_TOK_EOF) {
                ++pos;
            }
            continue;
        }
        if (current_section < 0) {
            msd_arena_add_error(arena, tok->line, tok->col, "content outside any section");
            return 0;
        }
        if (!msd_token_can_atom(tok->type)) {
            msd_arena_add_error(arena, tok->line, tok->col, "expected atom");
            return 0;
        }

        memset(&item, 0, sizeof(item));
        item.line = tok->line;
        item.col = tok->col;

        if (!msd_make_atom_from_token(tok, &atom)) {
            return 0;
        }
        atom_index = msd_arena_add_atom(arena, &atom);
        if (atom_index < 0) {
            return 0;
        }
        ++pos;

        if (pos < arena->token_count && arena->tokens[pos].type == MSD_TOK_EQUALS) {
            item.kind = MSD_ITEM_ASSIGN;
            item.key_atom = atom_index;
            ++pos;
        } else {
            item.kind = MSD_ITEM_ROW;
            item.key_atom = -1;
            item.value_start = atom_index;
            item.value_count = 1;
        }

        if (item.kind == MSD_ITEM_ASSIGN) {
            item.value_start = arena->atom_count;
            item.value_count = 0;
            while (pos < arena->token_count && arena->tokens[pos].type != MSD_TOK_NEWLINE && arena->tokens[pos].type != MSD_TOK_EOF) {
                if (arena->tokens[pos].type == MSD_TOK_COMMA) {
                    ++pos;
                    continue;
                }
                if (!msd_token_can_atom(arena->tokens[pos].type)) {
                    msd_arena_add_error(arena, arena->tokens[pos].line, arena->tokens[pos].col, "expected value atom");
                    return 0;
                }
                if (!msd_make_atom_from_token(&arena->tokens[pos], &atom)) {
                    return 0;
                }
                if (msd_arena_add_atom(arena, &atom) < 0) {
                    return 0;
                }
                ++item.value_count;
                ++pos;
            }
        } else {
            while (pos < arena->token_count && arena->tokens[pos].type != MSD_TOK_NEWLINE && arena->tokens[pos].type != MSD_TOK_EOF) {
                if (arena->tokens[pos].type == MSD_TOK_COMMA) {
                    ++pos;
                    continue;
                }
                if (!msd_token_can_atom(arena->tokens[pos].type)) {
                    msd_arena_add_error(arena, arena->tokens[pos].line, arena->tokens[pos].col, "expected row atom");
                    return 0;
                }
                if (!msd_make_atom_from_token(&arena->tokens[pos], &atom)) {
                    return 0;
                }
                if (msd_arena_add_atom(arena, &atom) < 0) {
                    return 0;
                }
                ++item.value_count;
                ++pos;
            }
        }

        if (msd_arena_add_item(arena, &item) < 0) {
            return 0;
        }
        arena->sections[current_section].item_count += 1;
    }

    return 1;
}
