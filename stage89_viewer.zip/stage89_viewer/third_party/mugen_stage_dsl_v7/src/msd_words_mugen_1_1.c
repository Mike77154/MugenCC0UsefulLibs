#include "msd_words_mugen_1_1.h"

static const MsdProfileWord g_keys[] = {
    { MSD_SECTION_INFO, "name" },
    { MSD_SECTION_INFO, "displayname" },
    { MSD_SECTION_INFO, "author" },
    { MSD_SECTION_INFO, "versiondate" },
    { MSD_SECTION_INFO, "mugenversion" },

    { MSD_SECTION_CAMERA, "startx" },
    { MSD_SECTION_CAMERA, "starty" },
    { MSD_SECTION_CAMERA, "boundleft" },
    { MSD_SECTION_CAMERA, "boundright" },
    { MSD_SECTION_CAMERA, "boundhigh" },
    { MSD_SECTION_CAMERA, "boundlow" },
    { MSD_SECTION_CAMERA, "tension" },
    { MSD_SECTION_CAMERA, "tensionhigh" },
    { MSD_SECTION_CAMERA, "tensionlow" },
    { MSD_SECTION_CAMERA, "verticalfollow" },
    { MSD_SECTION_CAMERA, "floortension" },
    { MSD_SECTION_CAMERA, "overdrawhigh" },
    { MSD_SECTION_CAMERA, "overdrawlow" },
    { MSD_SECTION_CAMERA, "cuthigh" },
    { MSD_SECTION_CAMERA, "cutlow" },
    { MSD_SECTION_CAMERA, "startzoom" },
    { MSD_SECTION_CAMERA, "zoomout" },
    { MSD_SECTION_CAMERA, "zoomin" },

    { MSD_SECTION_PLAYERINFO, "p1startx" },
    { MSD_SECTION_PLAYERINFO, "p1starty" },
    { MSD_SECTION_PLAYERINFO, "p1facing" },
    { MSD_SECTION_PLAYERINFO, "p2startx" },
    { MSD_SECTION_PLAYERINFO, "p2starty" },
    { MSD_SECTION_PLAYERINFO, "p2facing" },
    { MSD_SECTION_PLAYERINFO, "leftbound" },
    { MSD_SECTION_PLAYERINFO, "rightbound" },

    { MSD_SECTION_BOUND, "screenleft" },
    { MSD_SECTION_BOUND, "screenright" },

    { MSD_SECTION_STAGEINFO, "zoffset" },
    { MSD_SECTION_STAGEINFO, "zoffsetlink" },
    { MSD_SECTION_STAGEINFO, "autoturn" },
    { MSD_SECTION_STAGEINFO, "resetbg" },
    { MSD_SECTION_STAGEINFO, "localcoord" },
    { MSD_SECTION_STAGEINFO, "xscale" },
    { MSD_SECTION_STAGEINFO, "yscale" },

    { MSD_SECTION_SHADOW, "intensity" },
    { MSD_SECTION_SHADOW, "color" },
    { MSD_SECTION_SHADOW, "yscale" },
    { MSD_SECTION_SHADOW, "fade.range" },
    { MSD_SECTION_SHADOW, "xshear" },

    { MSD_SECTION_REFLECTION, "reflect" },

    { MSD_SECTION_MUSIC, "bgmusic" },
    { MSD_SECTION_MUSIC, "bgvolume" },

    { MSD_SECTION_BGDEF, "spr" },
    { MSD_SECTION_BGDEF, "debugbg" },

    { MSD_SECTION_BG, "type" },
    { MSD_SECTION_BG, "spriteno" },
    { MSD_SECTION_BG, "actionno" },
    { MSD_SECTION_BG, "start" },
    { MSD_SECTION_BG, "delta" },
    { MSD_SECTION_BG, "mask" },
    { MSD_SECTION_BG, "layerno" },
    { MSD_SECTION_BG, "id" },
    { MSD_SECTION_BG, "tile" },
    { MSD_SECTION_BG, "tilespacing" },
    { MSD_SECTION_BG, "window" },
    { MSD_SECTION_BG, "windowdelta" },
    { MSD_SECTION_BG, "trans" },
    { MSD_SECTION_BG, "alpha" },
    { MSD_SECTION_BG, "velocity" },
    { MSD_SECTION_BG, "positionlink" },
    { MSD_SECTION_BG, "width" },
    { MSD_SECTION_BG, "xscale" },
    { MSD_SECTION_BG, "scalestart" },
    { MSD_SECTION_BG, "scaledelta" },
    { MSD_SECTION_BG, "maskwindow" },
    { MSD_SECTION_BG, "zoomdelta" },
    { MSD_SECTION_BG, "yscalestart" },
    { MSD_SECTION_BG, "yscaledelta" },
    { MSD_SECTION_BG, "sin.x" },
    { MSD_SECTION_BG, "sin.y" },

    { MSD_SECTION_BGCTRLDEF, "looptime" },
    { MSD_SECTION_BGCTRLDEF, "ctrlid" },

    { MSD_SECTION_BGCTRL, "type" },
    { MSD_SECTION_BGCTRL, "time" },
    { MSD_SECTION_BGCTRL, "ctrlid" },
    { MSD_SECTION_BGCTRL, "x" },
    { MSD_SECTION_BGCTRL, "y" },
    { MSD_SECTION_BGCTRL, "value" }
};

static const char *const g_bgctrl_types[] = {
    "null", "visible", "enabled", "velset", "veladd", "posset", "posadd", "anim", "sinx", "siny"
};

static const MsdProfileLib g_lib = {
    "mugen1.1",
    "1.1 adds zoom camera and modern parallax/window/shadow words",
    g_keys,
    (int) (sizeof(g_keys) / sizeof(g_keys[0])),
    g_bgctrl_types,
    (int) (sizeof(g_bgctrl_types) / sizeof(g_bgctrl_types[0])),
    0,
    0
};

const MsdProfileLib *msd_words_mugen_1_1_lib(void)
{
    return &g_lib;
}
