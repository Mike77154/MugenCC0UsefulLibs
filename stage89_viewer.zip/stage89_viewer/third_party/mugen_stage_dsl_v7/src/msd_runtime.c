#include "msd_runtime.h"

#define MSD_FIXED_PI      ((msd_fixed_t)205887L)
#define MSD_FIXED_TWO_PI  ((msd_fixed_t)411775L)

static int msd_ieq_cstr(const char *a, const char *b)
{
    int i;
    if (!a || !b) {
        return 0;
    }
    i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (msd_ascii_tolower((unsigned char) a[i]) != msd_ascii_tolower((unsigned char) b[i])) {
            return 0;
        }
        ++i;
    }
    return a[i] == '\0' && b[i] == '\0';
}

static int msd_is_number_cstr(const char *text)
{
    int i;
    if (!text || text[0] == '\0') return 0;
    i = 0;
    if (text[i] == '-' || text[i] == '+') ++i;
    if (text[i] == '\0') return 0;
    while (text[i] != '\0') {
        if (text[i] < '0' || text[i] > '9') return 0;
        ++i;
    }
    return 1;
}

const char *msd_bgctrl_type_name(MsdBGCtrlType type)
{
    switch (type) {
    case MSD_BGCTRL_KIND_NULL: return "null";
    case MSD_BGCTRL_KIND_VISIBLE: return "visible";
    case MSD_BGCTRL_KIND_ENABLED: return "enabled";
    case MSD_BGCTRL_KIND_VELSET: return "velset";
    case MSD_BGCTRL_KIND_VELADD: return "veladd";
    case MSD_BGCTRL_KIND_POSSET: return "posset";
    case MSD_BGCTRL_KIND_POSADD: return "posadd";
    case MSD_BGCTRL_KIND_ANIM: return "anim";
    case MSD_BGCTRL_KIND_SINX: return "sinx";
    case MSD_BGCTRL_KIND_SINY: return "siny";
    default: return "unknown";
    }
}

MsdBGCtrlType msd_bgctrl_type_from_cstr(const char *text)
{
    if (msd_ieq_cstr(text, "null")) return MSD_BGCTRL_KIND_NULL;
    if (msd_ieq_cstr(text, "visible")) return MSD_BGCTRL_KIND_VISIBLE;
    if (msd_ieq_cstr(text, "enabled")) return MSD_BGCTRL_KIND_ENABLED;
    if (msd_ieq_cstr(text, "velset")) return MSD_BGCTRL_KIND_VELSET;
    if (msd_ieq_cstr(text, "veladd")) return MSD_BGCTRL_KIND_VELADD;
    if (msd_ieq_cstr(text, "posset")) return MSD_BGCTRL_KIND_POSSET;
    if (msd_ieq_cstr(text, "posadd")) return MSD_BGCTRL_KIND_POSADD;
    if (msd_ieq_cstr(text, "anim")) return MSD_BGCTRL_KIND_ANIM;
    if (msd_ieq_cstr(text, "sinx")) return MSD_BGCTRL_KIND_SINX;
    if (msd_ieq_cstr(text, "siny")) return MSD_BGCTRL_KIND_SINY;
    return MSD_BGCTRL_KIND_UNKNOWN;
}

static void msd_rt_bc_atom_text(const MsdSource *src, const MsdBCAtom *atom, char *buf, int cap)
{
    if (atom->type == MSD_ATOM_NUMBER) {
        if (atom->is_fixed) {
            msd_fixed_to_string(atom->number, buf, cap);
        } else {
            sprintf(buf, "%ld", msd_fixed_to_int(atom->number));
        }
    } else if (atom->type == MSD_ATOM_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, atom->offset, atom->length);
    } else {
        msd_copy_span(buf, cap, src->data, atom->offset, atom->length);
    }
}

static void msd_print_fixed(FILE *out, msd_fixed_t value)
{
    char buf[64];
    msd_fixed_to_string(value, buf, sizeof(buf));
    fprintf(out, "%s", buf);
}

static void msd_print_vec2(FILE *out, msd_fixed_t x, msd_fixed_t y)
{
    msd_print_fixed(out, x);
    fprintf(out, ", ");
    msd_print_fixed(out, y);
}

static msd_fixed_t msd_fixed_floor_value(msd_fixed_t value)
{
    if (value >= 0) {
        return (value / MSD_FIXED_ONE) * MSD_FIXED_ONE;
    }
    return -(((-value + MSD_FIXED_ONE - 1) / MSD_FIXED_ONE) * MSD_FIXED_ONE);
}

static msd_fixed_t msd_fixed_frac_value(msd_fixed_t value)
{
    return value - msd_fixed_floor_value(value);
}

static msd_fixed_t msd_fixed_sin_approx(msd_fixed_t x)
{
    int ok;
    int neg;
    msd_fixed_t y;
    msd_fixed_t xy;
    msd_fixed_t num;
    msd_fixed_t den;
    msd_fixed_t pi_sq;
    msd_fixed_t res;

    while (x > MSD_FIXED_PI) x -= MSD_FIXED_TWO_PI;
    while (x < -MSD_FIXED_PI) x += MSD_FIXED_TWO_PI;

    neg = 0;
    if (x < 0) {
        neg = 1;
        x = -x;
    }

    y = MSD_FIXED_PI - x;
    xy = msd_fixed_mul(x, y);
    num = msd_fixed_mul(msd_fixed_from_int(16), xy);
    pi_sq = msd_fixed_mul(MSD_FIXED_PI, MSD_FIXED_PI);
    den = msd_fixed_mul(msd_fixed_from_int(5), pi_sq) - msd_fixed_mul(msd_fixed_from_int(4), xy);
    res = msd_fixed_div(num, den, &ok);
    if (!ok) res = 0;
    if (neg) res = -res;
    return res;
}

static msd_fixed_t msd_runtime_eval_osc(const MsdOsc *osc, int tick)
{
    int ok;
    msd_fixed_t t;
    msd_fixed_t ratio;
    msd_fixed_t frac;
    msd_fixed_t angle;
    msd_fixed_t sine;

    if (!osc || osc->period <= 0 || osc->amplitude == 0) {
        return 0;
    }
    t = msd_fixed_from_int((long) tick) + osc->phase;
    ratio = msd_fixed_div(t, osc->period, &ok);
    if (!ok) return 0;
    frac = msd_fixed_frac_value(ratio);
    angle = msd_fixed_mul(frac, MSD_FIXED_TWO_PI);
    sine = msd_fixed_sin_approx(angle);
    return msd_fixed_mul(osc->amplitude, sine);
}

static int msd_runtime_find_action_index(const MsdStage *stage, int actionno)
{
    int i;
    if (!stage) return -1;
    for (i = 0; i < stage->action_count; ++i) {
        if (stage->actions[i].number == actionno) return i;
    }
    return -1;
}

static int msd_runtime_frame_for_bg(const MsdStage *stage, const MsdBG *bg)
{
    int action_index;
    const MsdAction *action;
    int i;
    int total;
    int t;
    int ticks;

    if (!stage || !bg || bg->current_actionno < 0) return -1;
    action_index = msd_runtime_find_action_index(stage, bg->current_actionno);
    if (action_index < 0) return -1;
    action = &stage->actions[action_index];
    if (action->frame_count <= 0) return -1;

    total = 0;
    for (i = 0; i < action->frame_count; ++i) {
        ticks = stage->action_frames[action->first_frame + i].ticks;
        if (ticks < 0) {
            if (bg->anim_time >= total) return i;
            break;
        }
        if (ticks == 0) ticks = 1;
        total += ticks;
    }
    if (total <= 0) return 0;
    t = bg->anim_time % total;
    for (i = 0; i < action->frame_count; ++i) {
        ticks = stage->action_frames[action->first_frame + i].ticks;
        if (ticks < 0) return i;
        if (ticks == 0) ticks = 1;
        if (t < ticks) return i;
        t -= ticks;
    }
    return action->frame_count - 1;
}

static MsdAttachment *msd_runtime_find_attachment(MsdRuntime *rt, int id)
{
    int i;
    if (!rt) return 0;
    for (i = 0; i < rt->attachment_count; ++i) {
        if (rt->attachments[i].in_use && rt->attachments[i].id == id) return &rt->attachments[i];
    }
    return 0;
}

static MsdAttachment *msd_runtime_ensure_attachment(MsdRuntime *rt, int id)
{
    MsdAttachment *a;
    if (!rt) return 0;
    a = msd_runtime_find_attachment(rt, id);
    if (a) return a;
    if (rt->attachment_count >= MSD_MAX_ATTACHMENTS) return 0;
    a = &rt->attachments[rt->attachment_count++];
    memset(a, 0, sizeof(*a));
    a->in_use = 1;
    a->id = id;
    return a;
}

void msd_runtime_set_profile(MsdRuntime *rt, MsdProfile profile)
{
    if (!rt) return;
    rt->stage.profile = profile;
    rt->stage.caps = *msd_profile_caps(profile);
}

static msd_fixed_t msd_runtime_zoom_value(const MsdStage *stage, int tick)
{
    msd_fixed_t lo;
    msd_fixed_t hi;
    msd_fixed_t mid;
    msd_fixed_t amp;
    msd_fixed_t wobble;
    if (!stage) return MSD_FIXED_ONE;
    if (!stage->caps.zoom_runtime) return MSD_FIXED_ONE;
    lo = stage->camera_zoomout != 0 ? stage->camera_zoomout : MSD_FIXED_ONE;
    hi = stage->camera_zoomin != 0 ? stage->camera_zoomin : MSD_FIXED_ONE;
    if (lo > hi) {
        msd_fixed_t tmp = lo;
        lo = hi;
        hi = tmp;
    }
    mid = stage->camera_startzoom != 0 ? stage->camera_startzoom : (lo + hi) / 2;
    amp = (hi - lo) / 2;
    if (amp == 0) return mid;
    {
        MsdOsc osc;
        osc.amplitude = amp;
        osc.period = msd_fixed_from_int(120);
        osc.phase = 0;
        wobble = msd_runtime_eval_osc(&osc, tick);
    }
    return mid + wobble;
}

static void msd_runtime_refresh_positions(MsdRuntime *rt, int tick)
{
    int i;
    MsdBG *bg;
    MsdBG *prev;
    MsdAttachment *att;
    msd_fixed_t ox;
    msd_fixed_t oy;
    msd_fixed_t zoom_minus_one;

    if (!rt) return;

    rt->stage.live_camera_x = rt->stage.camera_startx;
    rt->stage.live_camera_y = rt->stage.camera_starty;
    rt->stage.live_camera_zoom = msd_runtime_zoom_value(&rt->stage, tick);
    rt->stage.live_clip_top = rt->stage.caps.overdraw_cut_runtime ? (-rt->stage.camera_overdrawhigh + rt->stage.camera_cuthigh) : 0;
    rt->stage.live_clip_bottom = rt->stage.caps.overdraw_cut_runtime ? (msd_fixed_from_int(rt->stage.localcoord[1]) + rt->stage.camera_overdrawlow - rt->stage.camera_cutlow) : msd_fixed_from_int(rt->stage.localcoord[1]);
    rt->stage.live_shadow_skew = rt->stage.caps.shadow_xshear_runtime ? rt->stage.shadow_xshear : 0;
    zoom_minus_one = rt->stage.live_camera_zoom - MSD_FIXED_ONE;

    if (rt->stage.caps.integer_camera) {
        rt->stage.live_camera_x = msd_fixed_floor_value(rt->stage.live_camera_x);
        rt->stage.live_camera_y = msd_fixed_floor_value(rt->stage.live_camera_y);
    }

    for (i = 0; i < rt->stage.background_count; ++i) {
        bg = &rt->stage.backgrounds[i];
        ox = bg->current_has_sinx ? msd_runtime_eval_osc(&bg->current_sinx, tick) : 0;
        oy = bg->current_has_siny ? msd_runtime_eval_osc(&bg->current_siny, tick) : 0;
        if (bg->positionlink && i > 0) {
            prev = &rt->stage.backgrounds[i - 1];
            bg->computed_x = prev->computed_x + bg->current_start.x + ox;
            bg->computed_y = prev->computed_y + bg->current_start.y + oy;
        } else {
            bg->computed_x = bg->current_start.x + ox;
            bg->computed_y = bg->current_start.y + oy;
        }

        bg->computed_scale_x = MSD_FIXED_ONE;
        bg->computed_scale_y = MSD_FIXED_ONE;
        bg->computed_zoomscale = MSD_FIXED_ONE;
        if (msd_ieq_cstr(bg->type, "parallax")) {
            if (rt->stage.caps.modern_parallax_runtime) {
                bg->computed_scale_x = bg->scalestart.x != 0 ? bg->scalestart.x : (bg->xscale.x != 0 ? bg->xscale.x : MSD_FIXED_ONE);
                bg->computed_scale_y = bg->scalestart.y != 0 ? bg->scalestart.y : (bg->yscalestart != 0 ? bg->yscalestart : MSD_FIXED_ONE);
                bg->computed_scale_x += msd_fixed_mul(bg->scaledelta.x, zoom_minus_one);
                bg->computed_scale_y += msd_fixed_mul(bg->scaledelta.y, zoom_minus_one);
                bg->computed_zoomscale = MSD_FIXED_ONE + msd_fixed_mul(bg->zoomdelta, zoom_minus_one);
            } else {
                bg->computed_scale_x = bg->xscale.x != 0 ? bg->xscale.x : MSD_FIXED_ONE;
                bg->computed_scale_y = bg->yscalestart != 0 ? bg->yscalestart : (bg->xscale.y != 0 ? bg->xscale.y : MSD_FIXED_ONE);
                if (bg->yscaledelta != 0) {
                    bg->computed_scale_y += msd_fixed_mul(bg->yscaledelta, msd_fixed_from_int(tick));
                }
            }
        } else if (rt->stage.caps.zoom_runtime) {
            bg->computed_zoomscale = MSD_FIXED_ONE + msd_fixed_mul(bg->zoomdelta, zoom_minus_one);
        }

        if (bg->trackchar > 0) {
            att = msd_runtime_find_attachment(rt, bg->trackchar);
            if (att) {
                bg->computed_x += att->pos.x;
                bg->computed_y += att->pos.y;
            }
        }

        if (rt->stage.caps.zoom_runtime) {
            bg->computed_x = msd_fixed_mul(bg->computed_x, bg->computed_zoomscale);
            bg->computed_y = msd_fixed_mul(bg->computed_y, bg->computed_zoomscale);
        }
        if (rt->stage.caps.integer_camera) {
            bg->computed_x = msd_fixed_floor_value(bg->computed_x);
            bg->computed_y = msd_fixed_floor_value(bg->computed_y);
        }
        bg->current_frame_index = msd_runtime_frame_for_bg(&rt->stage, bg);
    }

    rt->stage.dynamic_zoffset = rt->stage.zoffset;
    if (rt->stage.zoffsetlink >= 0) {
        for (i = 0; i < rt->stage.background_count; ++i) {
            bg = &rt->stage.backgrounds[i];
            if (bg->id == rt->stage.zoffsetlink) {
                rt->stage.dynamic_zoffset = bg->computed_y;
                break;
            }
        }
    }
    if (rt->stage.caps.integer_camera) {
        rt->stage.dynamic_zoffset = msd_fixed_floor_value(rt->stage.dynamic_zoffset);
    }
}

static int msd_runtime_bg_matches(const MsdBG *bg, const MsdBGCtrlDef *def, const MsdBGCtrl *ctrl)
{
    int i;
    const int *ids;
    int count;
    if (!bg || !ctrl) return 0;
    if (ctrl->ctrl_id_count > 0) {
        ids = ctrl->ctrl_ids;
        count = ctrl->ctrl_id_count;
    } else if (def && def->ctrl_id_count > 0) {
        ids = def->ctrl_ids;
        count = def->ctrl_id_count;
    } else {
        return 1;
    }
    for (i = 0; i < count; ++i) {
        if (bg->id == ids[i]) return 1;
    }
    return 0;
}

static int msd_runtime_ctrl_timer(const MsdBGCtrlDef *def, const MsdBGCtrl *ctrl, int tick)
{
    int t;
    t = tick;
    if (def && def->looptime > 0) t %= def->looptime;
    if (ctrl && ctrl->time_count > 2 && ctrl->time[2] > 0) t %= ctrl->time[2];
    return t;
}

static int msd_runtime_ctrl_active(const MsdBGCtrlDef *def, const MsdBGCtrl *ctrl, int tick)
{
    int t;
    int start;
    int end;
    if (!ctrl || ctrl->time_count <= 0) return 0;
    t = msd_runtime_ctrl_timer(def, ctrl, tick);
    start = ctrl->time[0];
    end = ctrl->time_count > 1 ? ctrl->time[1] : ctrl->time[0];
    return t >= start && t <= end;
}

static MsdAttachment *msd_runtime_register_ctrl_attachment(MsdRuntime *rt, const MsdBGCtrlDef *def, const MsdBGCtrl *ctrl, int ctrl_index, int tick)
{
    int j;
    MsdAttachment *att;
    MsdBG *bg;
    int id;
    if (!rt || !ctrl || !rt->stage.caps.attachedchar_runtime) return 0;
    if (ctrl->attachedchar[0] == '\0' && !ctrl->has_attachedid && !ctrl->has_charoffset) return 0;
    id = ctrl->has_attachedid ? ctrl->attachedid : (ctrl->has_followchar ? ctrl->followchar : 0);
    att = msd_runtime_ensure_attachment(rt, id);
    if (!att) return 0;
    strncpy(att->kind, ctrl->attachedchar[0] ? ctrl->attachedchar : "attachedchar", sizeof(att->kind) - 1);
    att->source_ctrl_index = ctrl_index;
    if (ctrl->has_charoffset) {
        att->offset = ctrl->charoffset;
    } else {
        att->offset.x = 0;
        att->offset.y = 0;
    }
    att->pos.x = msd_fixed_from_int((long) (tick * (id + 1)));
    {
        MsdOsc osc;
        osc.amplitude = msd_fixed_from_int(4);
        osc.period = msd_fixed_from_int(60);
        osc.phase = 0;
        att->pos.y = msd_runtime_eval_osc(&osc, tick);
    }
    for (j = 0; j < rt->stage.background_count; ++j) {
        bg = &rt->stage.backgrounds[j];
        if (msd_runtime_bg_matches(bg, def, ctrl)) {
            att->pos.x = bg->computed_x;
            att->pos.y = bg->computed_y;
            break;
        }
    }
    att->pos.x += att->offset.x;
    att->pos.y += att->offset.y;
    return att;
}

static void msd_runtime_mutate_ctrl(MsdRuntime *rt, const MsdBGCtrl *ctrl)
{
    int i;
    MsdBGCtrl *target;
    if (!rt || !ctrl || !rt->stage.caps.bgctrl_mutation_runtime || !ctrl->has_modifybgctrl) return;
    target = 0;
    for (i = 0; i < rt->stage.ctrl_count; ++i) {
        if (msd_ieq_cstr(rt->stage.ctrls[i].name, ctrl->modify_target)) {
            target = &rt->stage.ctrls[i];
            break;
        }
        if (ctrl->modify_target[0] != '\0' && msd_is_number_cstr(ctrl->modify_target) && rt->stage.ctrls[i].has_sctrlid && rt->stage.ctrls[i].sctrlid == atoi(ctrl->modify_target)) {
            target = &rt->stage.ctrls[i];
            break;
        }
    }
    if (!target) return;
    if (msd_ieq_cstr(ctrl->modify_field, "x") && ctrl->modify_value_count > 0) {
        target->x = ctrl->modify_values[0];
        target->has_x = 1;
    } else if (msd_ieq_cstr(ctrl->modify_field, "y") && ctrl->modify_value_count > 0) {
        target->y = ctrl->modify_values[0];
        target->has_y = 1;
    } else if (msd_ieq_cstr(ctrl->modify_field, "value") && ctrl->modify_value_count > 0) {
        target->value[0] = ctrl->modify_values[0];
        target->value_count = 1;
    } else if (msd_ieq_cstr(ctrl->modify_field, "time") && ctrl->modify_value_count > 0) {
        target->time[0] = (int) msd_fixed_to_int(ctrl->modify_values[0]);
        if (ctrl->modify_value_count > 1) target->time[1] = (int) msd_fixed_to_int(ctrl->modify_values[1]);
    }
}

static void msd_runtime_apply_ctrl_to_bg(MsdRuntime *rt, MsdBG *bg, const MsdBGCtrl *ctrl)
{
    int value;
    MsdAttachment *att;
    msd_fixed_t px;
    msd_fixed_t py;
    if (!bg || !ctrl) return;
    px = ctrl->has_x ? ctrl->x : 0;
    py = ctrl->has_y ? ctrl->y : 0;
    if (rt && rt->stage.caps.followchar_runtime && ctrl->has_followchar) {
        att = msd_runtime_find_attachment(rt, ctrl->followchar);
        if (att) {
            px += att->pos.x;
            py += att->pos.y;
        }
    }
    switch (ctrl->resolved_type) {
    case MSD_BGCTRL_KIND_NULL:
        break;
    case MSD_BGCTRL_KIND_VISIBLE:
        if (ctrl->value_count > 0) { value = (int) msd_fixed_to_int(ctrl->value[0]); bg->visible = value != 0; }
        break;
    case MSD_BGCTRL_KIND_ENABLED:
        if (ctrl->value_count > 0) { value = (int) msd_fixed_to_int(ctrl->value[0]); bg->enabled = value != 0; }
        break;
    case MSD_BGCTRL_KIND_VELSET:
        if (ctrl->has_x) bg->current_velocity.x = px;
        if (ctrl->has_y) bg->current_velocity.y = py;
        break;
    case MSD_BGCTRL_KIND_VELADD:
        if (ctrl->has_x) bg->current_velocity.x += px;
        if (ctrl->has_y) bg->current_velocity.y += py;
        break;
    case MSD_BGCTRL_KIND_POSSET:
        if (ctrl->has_x) bg->current_start.x = px;
        if (ctrl->has_y) bg->current_start.y = py;
        break;
    case MSD_BGCTRL_KIND_POSADD:
        if (ctrl->has_x) bg->current_start.x += px;
        if (ctrl->has_y) bg->current_start.y += py;
        break;
    case MSD_BGCTRL_KIND_ANIM:
        if (ctrl->value_count > 0) {
            value = (int) msd_fixed_to_int(ctrl->value[0]);
            if (bg->current_actionno != value) { bg->current_actionno = value; bg->anim_time = 0; }
        }
        break;
    case MSD_BGCTRL_KIND_SINX:
        bg->current_has_sinx = 1;
        if (ctrl->value_count > 0) bg->current_sinx.amplitude = ctrl->value[0];
        if (ctrl->value_count > 1) bg->current_sinx.period = ctrl->value[1];
        bg->current_sinx.phase = ctrl->value_count > 2 ? ctrl->value[2] : 0;
        break;
    case MSD_BGCTRL_KIND_SINY:
        bg->current_has_siny = 1;
        if (ctrl->value_count > 0) bg->current_siny.amplitude = ctrl->value[0];
        if (ctrl->value_count > 1) bg->current_siny.period = ctrl->value[1];
        bg->current_siny.phase = ctrl->value_count > 2 ? ctrl->value[2] : 0;
        break;
    default:
        break;
    }
}

void msd_runtime_init(MsdRuntime *rt, MsdArena *arena)
{
    if (!rt) return;
    memset(rt, 0, sizeof(*rt));
    rt->arena = arena;
    rt->ctx.current_bg = -1;
    rt->ctx.current_ctrl_def = -1;
    rt->ctx.current_ctrl = -1;
    rt->ctx.current_action = -1;
    rt->stage.zoffsetlink = -1;
    rt->stage.localcoord[0] = 320;
    rt->stage.localcoord[1] = 240;
    rt->stage.stage_xscale = MSD_FIXED_ONE;
    rt->stage.stage_yscale = MSD_FIXED_ONE;
    rt->stage.shadow_intensity = 128;
    rt->stage.shadow_yscale = msd_fixed_from_parts(0, 4, 10);
    rt->stage.camera_startzoom = MSD_FIXED_ONE;
    rt->stage.camera_zoomout = MSD_FIXED_ONE;
    rt->stage.camera_zoomin = MSD_FIXED_ONE;
    msd_runtime_set_profile(rt, msd_profile_get_active());
}

void msd_runtime_finalize_stage(MsdRuntime *rt)
{
    int i;
    MsdBG *bg;
    MsdBGCtrl *ctrl;
    if (!rt) return;
    if (rt->stage.displayname[0] == '\0') {
        strncpy(rt->stage.displayname, rt->stage.name, sizeof(rt->stage.displayname) - 1);
        rt->stage.displayname[sizeof(rt->stage.displayname) - 1] = '\0';
    }
    if (rt->stage.mugenversion[0] == '\0') {
        if (rt->stage.profile == MSD_PROFILE_MUGEN1_0) strncpy(rt->stage.mugenversion, "1.0", sizeof(rt->stage.mugenversion) - 1);
        else if (rt->stage.profile == MSD_PROFILE_MUGEN1_1 || rt->stage.profile == MSD_PROFILE_IKEMENGOPLUS || rt->stage.profile == MSD_PROFILE_IKEMENPLUSULTRA) strncpy(rt->stage.mugenversion, "1.1", sizeof(rt->stage.mugenversion) - 1);
        else strncpy(rt->stage.mugenversion, "2002,02,14", sizeof(rt->stage.mugenversion) - 1);
        rt->stage.mugenversion[sizeof(rt->stage.mugenversion) - 1] = '\0';
    }
    for (i = 0; i < rt->stage.background_count; ++i) {
        bg = &rt->stage.backgrounds[i];
        if (msd_ieq_cstr(bg->type, "anim")) bg->mask = 1;
    }
    for (i = 0; i < rt->stage.ctrl_count; ++i) {
        ctrl = &rt->stage.ctrls[i];
        if (ctrl->time_count == 1) {
            ctrl->time[1] = ctrl->time[0];
            ctrl->time[2] = -1;
        } else if (ctrl->time_count == 2) {
            ctrl->time[2] = -1;
        }
    }
    if (!rt->stage.caps.zoom_runtime) {
        rt->stage.camera_startzoom = MSD_FIXED_ONE;
        rt->stage.camera_zoomout = MSD_FIXED_ONE;
        rt->stage.camera_zoomin = MSD_FIXED_ONE;
    }
    if (!rt->stage.caps.shadow_xshear_runtime) rt->stage.shadow_xshear = 0;
    rt->stage.dynamic_zoffset = rt->stage.zoffset;
}

void msd_runtime_reset_live(MsdRuntime *rt)
{
    int i;
    MsdBG *bg;
    if (!rt) return;
    rt->sim_tick = 0;
    rt->attachment_count = 0;
    memset(rt->attachments, 0, sizeof(rt->attachments));
    for (i = 0; i < rt->stage.background_count; ++i) {
        bg = &rt->stage.backgrounds[i];
        bg->current_start = bg->start;
        bg->current_velocity = bg->velocity;
        bg->visible = 1;
        bg->enabled = 1;
        bg->current_actionno = bg->actionno;
        bg->anim_time = 0;
        bg->current_frame_index = -1;
        bg->current_sinx = bg->sinx;
        bg->current_has_sinx = bg->has_sinx;
        bg->current_siny = bg->siny;
        bg->current_has_siny = bg->has_siny;
        bg->computed_x = bg->current_start.x;
        bg->computed_y = bg->current_start.y;
        bg->computed_scale_x = MSD_FIXED_ONE;
        bg->computed_scale_y = MSD_FIXED_ONE;
        bg->computed_zoomscale = MSD_FIXED_ONE;
    }
    msd_runtime_refresh_positions(rt, 0);
}

int msd_runtime_apply_tick(MsdRuntime *rt, int tick)
{
    int i;
    int j;
    MsdBGCtrlDef *def;
    MsdBGCtrl *ctrl;
    MsdBG *bg;
    if (!rt) return 0;
    rt->attachment_count = 0;
    memset(rt->attachments, 0, sizeof(rt->attachments));

    for (i = 0; i < rt->stage.ctrl_count; ++i) {
        ctrl = &rt->stage.ctrls[i];
        def = 0;
        if (ctrl->parent_def_index >= 0 && ctrl->parent_def_index < rt->stage.ctrl_def_count) def = &rt->stage.ctrl_defs[ctrl->parent_def_index];
        if (!msd_runtime_ctrl_active(def, ctrl, tick)) continue;
        msd_runtime_register_ctrl_attachment(rt, def, ctrl, i, tick);
        msd_runtime_mutate_ctrl(rt, ctrl);
    }

    for (i = 0; i < rt->stage.ctrl_count; ++i) {
        ctrl = &rt->stage.ctrls[i];
        def = 0;
        if (ctrl->parent_def_index >= 0 && ctrl->parent_def_index < rt->stage.ctrl_def_count) def = &rt->stage.ctrl_defs[ctrl->parent_def_index];
        if (!msd_runtime_ctrl_active(def, ctrl, tick)) continue;
        for (j = 0; j < rt->stage.background_count; ++j) {
            bg = &rt->stage.backgrounds[j];
            if (msd_runtime_bg_matches(bg, def, ctrl)) {
                msd_runtime_apply_ctrl_to_bg(rt, bg, ctrl);
            }
        }
    }
    rt->sim_tick = tick;
    msd_runtime_refresh_positions(rt, tick);
    return 1;
}

int msd_runtime_advance(MsdRuntime *rt)
{
    int i;
    MsdBG *bg;
    if (!rt) return 0;
    for (i = 0; i < rt->stage.background_count; ++i) {
        bg = &rt->stage.backgrounds[i];
        if (bg->enabled) {
            bg->current_start.x += bg->current_velocity.x;
            bg->current_start.y += bg->current_velocity.y;
            if (bg->current_actionno >= 0) bg->anim_time += 1;
        }
    }
    return 1;
}

int msd_runtime_store_raw_assign(MsdRuntime *rt, const char *section_name, MsdSectionKind kind, const char *key, const char *values)
{
    MsdRawEntry *entry;
    if (!rt || rt->stage.raw_count >= MSD_MAX_RAW) return 0;
    entry = &rt->stage.raw[rt->stage.raw_count++];
    memset(entry, 0, sizeof(*entry));
    entry->is_row = 0;
    entry->section_kind = kind;
    strncpy(entry->section_name, section_name ? section_name : "", sizeof(entry->section_name) - 1);
    strncpy(entry->key, key ? key : "", sizeof(entry->key) - 1);
    strncpy(entry->values, values ? values : "", sizeof(entry->values) - 1);
    return 1;
}

int msd_runtime_store_raw_row(MsdRuntime *rt, const char *section_name, MsdSectionKind kind, const char *values)
{
    MsdRawEntry *entry;
    if (!rt || rt->stage.raw_count >= MSD_MAX_RAW) return 0;
    entry = &rt->stage.raw[rt->stage.raw_count++];
    memset(entry, 0, sizeof(*entry));
    entry->is_row = 1;
    entry->section_kind = kind;
    strncpy(entry->section_name, section_name ? section_name : "", sizeof(entry->section_name) - 1);
    strncpy(entry->values, values ? values : "", sizeof(entry->values) - 1);
    return 1;
}

int msd_runtime_begin_section(MsdRuntime *rt, const MsdSource *src, MsdSectionKind kind, const MsdBCAtom *atoms, int start, int count)
{
    char name[64];
    char extra[64];
    MsdBG *bg;
    MsdBGCtrlDef *def;
    MsdBGCtrl *ctrl;
    MsdAction *action;

    if (!rt) return 0;
    rt->ctx.section_kind = kind;
    rt->ctx.section_name[0] = '\0';
    if (count > 0) msd_rt_bc_atom_text(src, &atoms[start], name, sizeof(name));
    else strcpy(name, msd_section_kind_name(kind));

    if (kind == MSD_SECTION_BG && count > 1) {
        msd_rt_bc_atom_text(src, &atoms[start + 1], extra, sizeof(extra));
        strncpy(rt->ctx.section_name, extra, sizeof(rt->ctx.section_name) - 1);
        if (rt->stage.background_count >= MSD_MAX_BG) return 0;
        rt->ctx.current_bg = rt->stage.background_count;
        bg = &rt->stage.backgrounds[rt->stage.background_count++];
        memset(bg, 0, sizeof(*bg));
        msd_copy_span(bg->name, (int) sizeof(bg->name), extra, 0, (int) strlen(extra));
        bg->actionno = -1;
        bg->delta.x = MSD_FIXED_ONE;
        bg->delta.y = MSD_FIXED_ONE;
        bg->alpha[0] = 256;
        bg->alpha[1] = 256;
        bg->scalestart.x = MSD_FIXED_ONE;
        bg->scalestart.y = MSD_FIXED_ONE;
        bg->zoomdelta = MSD_FIXED_ONE;
        bg->visible = 1;
        bg->enabled = 1;
        bg->current_actionno = -1;
        strncpy(bg->trans, "default", sizeof(bg->trans) - 1);
    } else if (kind == MSD_SECTION_BGCTRLDEF && count > 1) {
        msd_rt_bc_atom_text(src, &atoms[start + 1], extra, sizeof(extra));
        strncpy(rt->ctx.section_name, extra, sizeof(rt->ctx.section_name) - 1);
        if (rt->stage.ctrl_def_count >= MSD_MAX_BGCTRLDEF) return 0;
        rt->ctx.current_ctrl_def = rt->stage.ctrl_def_count;
        def = &rt->stage.ctrl_defs[rt->stage.ctrl_def_count++];
        memset(def, 0, sizeof(*def));
        msd_copy_span(def->name, (int) sizeof(def->name), extra, 0, (int) strlen(extra));
        def->looptime = -1;
        def->first_ctrl = rt->stage.ctrl_count;
    } else if (kind == MSD_SECTION_BGCTRL && count > 1) {
        msd_rt_bc_atom_text(src, &atoms[start + 1], extra, sizeof(extra));
        strncpy(rt->ctx.section_name, extra, sizeof(rt->ctx.section_name) - 1);
        if (rt->stage.ctrl_count >= MSD_MAX_BGCTRL) return 0;
        rt->ctx.current_ctrl = rt->stage.ctrl_count;
        ctrl = &rt->stage.ctrls[rt->stage.ctrl_count++];
        memset(ctrl, 0, sizeof(*ctrl));
        msd_copy_span(ctrl->name, (int) sizeof(ctrl->name), extra, 0, (int) strlen(extra));
        ctrl->parent_def_index = rt->ctx.current_ctrl_def;
        ctrl->time[2] = -1;
        if (ctrl->parent_def_index >= 0 && ctrl->parent_def_index < rt->stage.ctrl_def_count) {
            rt->stage.ctrl_defs[ctrl->parent_def_index].ctrl_count += 1;
        }
    } else if (kind == MSD_SECTION_BEGIN_ACTION) {
        strcpy(rt->ctx.section_name, "Begin Action");
        if (rt->stage.action_count >= MSD_MAX_ACTIONS) return 0;
        rt->ctx.current_action = rt->stage.action_count;
        action = &rt->stage.actions[rt->stage.action_count++];
        memset(action, 0, sizeof(*action));
        action->first_frame = rt->stage.action_frame_count;
        if (count > 2 && atoms[start + 2].type == MSD_ATOM_NUMBER) action->number = (int) msd_fixed_to_int(atoms[start + 2].number);
    } else {
        strncpy(rt->ctx.section_name, name, sizeof(rt->ctx.section_name) - 1);
    }
    rt->ctx.section_name[sizeof(rt->ctx.section_name) - 1] = '\0';
    return 1;
}

void msd_runtime_dump(const MsdStage *stage, FILE *out)
{
    int i;
    if (!stage || !out) return;
    fprintf(out, "Stage\n");
    fprintf(out, "  profile      : %s\n", msd_profile_name(stage->profile));
    fprintf(out, "  name         : %s\n", stage->name);
    fprintf(out, "  displayname  : %s\n", stage->displayname);
    fprintf(out, "  author       : %s\n", stage->author);
    fprintf(out, "  versiondate  : %s\n", stage->versiondate);
    fprintf(out, "  mugenversion : %s\n", stage->mugenversion);
    fprintf(out, "  zoffset      : "); msd_print_fixed(out, stage->zoffset); fprintf(out, "\n");
    fprintf(out, "  zoffsetlink  : %d\n", stage->zoffsetlink);
    fprintf(out, "  localcoord   : %d, %d\n", stage->localcoord[0], stage->localcoord[1]);
    fprintf(out, "  stage scale  : "); msd_print_vec2(out, stage->stage_xscale, stage->stage_yscale); fprintf(out, "\n");
    fprintf(out, "  spr          : %s\n", stage->spr);
    fprintf(out, "  debugbg      : %d\n", stage->debugbg);
    fprintf(out, "  bgmusic      : %s\n", stage->bgmusic);
    fprintf(out, "  bgvolume     : %d\n", stage->bgvolume);
    fprintf(out, "\nCamera\n");
    fprintf(out, "  start        : "); msd_print_vec2(out, stage->camera_startx, stage->camera_starty); fprintf(out, "\n");
    fprintf(out, "  bounds       : "); msd_print_fixed(out, stage->camera_boundleft); fprintf(out, ", "); msd_print_fixed(out, stage->camera_boundright); fprintf(out, ", "); msd_print_fixed(out, stage->camera_boundhigh); fprintf(out, ", "); msd_print_fixed(out, stage->camera_boundlow); fprintf(out, "\n");
    fprintf(out, "  live         : pos="); msd_print_vec2(out, stage->live_camera_x, stage->live_camera_y); fprintf(out, " zoom="); msd_print_fixed(out, stage->live_camera_zoom); fprintf(out, " clip="); msd_print_fixed(out, stage->live_clip_top); fprintf(out, ".."); msd_print_fixed(out, stage->live_clip_bottom); fprintf(out, " shadowSkew="); msd_print_fixed(out, stage->live_shadow_skew); fprintf(out, "\n");
    fprintf(out, "\nBackgrounds (%d)\n", stage->background_count);
    for (i = 0; i < stage->background_count; ++i) {
        const MsdBG *bg = &stage->backgrounds[i];
        fprintf(out, "  [%d] %s type=%s start=", i, bg->name, bg->type);
        msd_print_vec2(out, bg->start.x, bg->start.y);
        fprintf(out, " delta="); msd_print_vec2(out, bg->delta.x, bg->delta.y);
        fprintf(out, " vel="); msd_print_vec2(out, bg->velocity.x, bg->velocity.y);
        fprintf(out, " scale="); msd_print_vec2(out, bg->computed_scale_x, bg->computed_scale_y);
        fprintf(out, " zoom="); msd_print_fixed(out, bg->computed_zoomscale);
        fprintf(out, " trackchar=%d layer=%d id=%d action=%d\n", bg->trackchar, bg->layerno, bg->id, bg->actionno);
    }
    fprintf(out, "\nBGCtrlDefs (%d)\n", stage->ctrl_def_count);
    for (i = 0; i < stage->ctrl_def_count; ++i) {
        fprintf(out, "  [%d] %s looptime=%d ctrlIDs=%d firstCtrl=%d count=%d\n", i, stage->ctrl_defs[i].name, stage->ctrl_defs[i].looptime, stage->ctrl_defs[i].ctrl_id_count, stage->ctrl_defs[i].first_ctrl, stage->ctrl_defs[i].ctrl_count);
    }
    fprintf(out, "\nBGCtrls (%d)\n", stage->ctrl_count);
    for (i = 0; i < stage->ctrl_count; ++i) {
        const MsdBGCtrl *ctrl = &stage->ctrls[i];
        fprintf(out, "  [%d] %s type=%s parent=%d time=%d,%d,%d sctrlid=%d attachedid=%d followchar=%d modify=%s/%s\n", i, ctrl->name, msd_bgctrl_type_name(ctrl->resolved_type), ctrl->parent_def_index, ctrl->time[0], ctrl->time[1], ctrl->time[2], ctrl->sctrlid, ctrl->attachedid, ctrl->followchar, ctrl->modify_target, ctrl->modify_field);
    }
    fprintf(out, "\nActions (%d)\n", stage->action_count);
    for (i = 0; i < stage->action_count; ++i) {
        fprintf(out, "  [%d] action %d frames=%d\n", i, stage->actions[i].number, stage->actions[i].frame_count);
    }
    fprintf(out, "\nRaw passthrough entries (%d)\n", stage->raw_count);
}

void msd_runtime_dump_live(const MsdStage *stage, FILE *out)
{
    int i;
    if (!stage || !out) return;
    fprintf(out, "Live state\n");
    fprintf(out, "  profile        : %s\n", msd_profile_name(stage->profile));
    fprintf(out, "  dynamic zoffset: "); msd_print_fixed(out, stage->dynamic_zoffset); fprintf(out, "\n");
    fprintf(out, "  camera         : pos="); msd_print_vec2(out, stage->live_camera_x, stage->live_camera_y); fprintf(out, " zoom="); msd_print_fixed(out, stage->live_camera_zoom); fprintf(out, " clip="); msd_print_fixed(out, stage->live_clip_top); fprintf(out, ".."); msd_print_fixed(out, stage->live_clip_bottom); fprintf(out, "\n");
    for (i = 0; i < stage->background_count; ++i) {
        const MsdBG *bg = &stage->backgrounds[i];
        fprintf(out, "  [%d] %s pos=", i, bg->name);
        msd_print_vec2(out, bg->computed_x, bg->computed_y);
        fprintf(out, " vel="); msd_print_vec2(out, bg->current_velocity.x, bg->current_velocity.y);
        fprintf(out, " scale="); msd_print_vec2(out, bg->computed_scale_x, bg->computed_scale_y);
        fprintf(out, " zoom="); msd_print_fixed(out, bg->computed_zoomscale);
        fprintf(out, " visible=%d enabled=%d action=%d frame=%d\n", bg->visible, bg->enabled, bg->current_actionno, bg->current_frame_index);
    }
}

void msd_runtime_dump_timeline(MsdRuntime *rt, FILE *out, int ticks)
{
    int tick;
    int i;
    MsdBG *bg;
    if (!rt || !out) return;
    if (ticks < 0) ticks = 0;
    msd_runtime_reset_live(rt);
    for (tick = 0; tick < ticks; ++tick) {
        msd_runtime_apply_tick(rt, tick);
        fprintf(out, "tick %d profile=%s zoffset=", tick, msd_profile_name(rt->stage.profile));
        msd_print_fixed(out, rt->stage.dynamic_zoffset);
        fprintf(out, " cam="); msd_print_vec2(out, rt->stage.live_camera_x, rt->stage.live_camera_y);
        fprintf(out, " zoom="); msd_print_fixed(out, rt->stage.live_camera_zoom);
        fprintf(out, " attachments=%d\n", rt->attachment_count);
        for (i = 0; i < rt->attachment_count; ++i) {
            fprintf(out, "  attach[%d] id=%d kind=%s pos=", i, rt->attachments[i].id, rt->attachments[i].kind);
            msd_print_vec2(out, rt->attachments[i].pos.x, rt->attachments[i].pos.y);
            fprintf(out, "\n");
        }
        for (i = 0; i < rt->stage.background_count; ++i) {
            bg = &rt->stage.backgrounds[i];
            fprintf(out, "  bg[%d] %-16s pos=", i, bg->name);
            msd_print_vec2(out, bg->computed_x, bg->computed_y);
            fprintf(out, " vel="); msd_print_vec2(out, bg->current_velocity.x, bg->current_velocity.y);
            fprintf(out, " scale="); msd_print_vec2(out, bg->computed_scale_x, bg->computed_scale_y);
            fprintf(out, " zoom="); msd_print_fixed(out, bg->computed_zoomscale);
            fprintf(out, " vis=%d en=%d act=%d frame=%d\n", bg->visible, bg->enabled, bg->current_actionno, bg->current_frame_index);
        }
        msd_runtime_advance(rt);
    }
}
