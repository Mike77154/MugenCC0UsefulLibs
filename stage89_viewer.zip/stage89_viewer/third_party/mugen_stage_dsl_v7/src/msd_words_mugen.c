#include "msd_words_mugen.h"

static int msd_key_is(const MsdSource *src, const MsdAtom *key, const char *text)
{
    return key && key->type != MSD_ATOM_NUMBER && msd_span_ieq(src->data, key->offset, key->length, text);
}

MsdBuiltinId msd_mugen_resolve_begin(MsdSectionKind kind)
{
    switch (kind) {
    case MSD_SECTION_BG: return MSD_BUILTIN_GAME_BG_BEGIN;
    case MSD_SECTION_BGCTRLDEF: return MSD_BUILTIN_GAME_BGCTRLDEF_BEGIN;
    case MSD_SECTION_BGCTRL: return MSD_BUILTIN_GAME_BGCTRL_BEGIN;
    case MSD_SECTION_BEGIN_ACTION: return MSD_BUILTIN_GAME_ACTION_BEGIN;
    default: return MSD_BUILTIN_NONE;
    }
}

MsdBuiltinId msd_mugen_resolve_key(MsdSectionKind kind, const MsdSource *src, const MsdAtom *key)
{
    switch (kind) {
    case MSD_SECTION_INFO:
        if (msd_key_is(src, key, "name")) return MSD_BUILTIN_GAME_STAGE_NAME;
        if (msd_key_is(src, key, "displayname")) return MSD_BUILTIN_GAME_STAGE_DISPLAYNAME;
        if (msd_key_is(src, key, "author")) return MSD_BUILTIN_GAME_STAGE_AUTHOR;
        if (msd_key_is(src, key, "versiondate")) return MSD_BUILTIN_GAME_STAGE_VERSIONDATE;
        if (msd_key_is(src, key, "mugenversion")) return MSD_BUILTIN_GAME_STAGE_MUGENVERSION;
        break;
    case MSD_SECTION_STAGEINFO:
        if (msd_key_is(src, key, "zoffset")) return MSD_BUILTIN_GAME_STAGE_ZOFFSET;
        if (msd_key_is(src, key, "zoffsetlink")) return MSD_BUILTIN_GAME_STAGE_ZOFFSETLINK;
        if (msd_key_is(src, key, "autoturn")) return MSD_BUILTIN_GAME_STAGE_AUTOTURN;
        if (msd_key_is(src, key, "resetbg")) return MSD_BUILTIN_GAME_STAGE_RESETBG;
        if (msd_key_is(src, key, "localcoord")) return MSD_BUILTIN_GAME_STAGE_LOCALCOORD;
        if (msd_key_is(src, key, "xscale")) return MSD_BUILTIN_GAME_STAGE_XSCALE;
        if (msd_key_is(src, key, "yscale")) return MSD_BUILTIN_GAME_STAGE_YSCALE;
        break;
    case MSD_SECTION_BGDEF:
        if (msd_key_is(src, key, "spr")) return MSD_BUILTIN_GAME_STAGE_SPR;
        if (msd_key_is(src, key, "debugbg")) return MSD_BUILTIN_GAME_STAGE_DEBUGBG;
        break;
    case MSD_SECTION_SHADOW:
        if (msd_key_is(src, key, "intensity")) return MSD_BUILTIN_GAME_SHADOW_INTENSITY;
        if (msd_key_is(src, key, "color")) return MSD_BUILTIN_GAME_SHADOW_COLOR;
        if (msd_key_is(src, key, "yscale")) return MSD_BUILTIN_GAME_SHADOW_YSCALE;
        if (msd_key_is(src, key, "fade.range")) return MSD_BUILTIN_GAME_SHADOW_FADERANGE;
        if (msd_key_is(src, key, "xshear")) return MSD_BUILTIN_GAME_SHADOW_XSHEAR;
        break;
    case MSD_SECTION_REFLECTION:
        if (msd_key_is(src, key, "reflect")) return MSD_BUILTIN_GAME_REFLECTION_REFLECT;
        break;
    case MSD_SECTION_MUSIC:
        if (msd_key_is(src, key, "bgmusic")) return MSD_BUILTIN_GAME_STAGE_BGMUSIC;
        if (msd_key_is(src, key, "bgvolume")) return MSD_BUILTIN_GAME_STAGE_BGVOLUME;
        break;
    case MSD_SECTION_CAMERA:
        if (msd_key_is(src, key, "startx")) return MSD_BUILTIN_GAME_CAMERA_STARTX;
        if (msd_key_is(src, key, "starty")) return MSD_BUILTIN_GAME_CAMERA_STARTY;
        if (msd_key_is(src, key, "boundleft")) return MSD_BUILTIN_GAME_CAMERA_BOUNDLEFT;
        if (msd_key_is(src, key, "boundright")) return MSD_BUILTIN_GAME_CAMERA_BOUNDRIGHT;
        if (msd_key_is(src, key, "boundhigh")) return MSD_BUILTIN_GAME_CAMERA_BOUNDHIGH;
        if (msd_key_is(src, key, "boundlow")) return MSD_BUILTIN_GAME_CAMERA_BOUNDLOW;
        if (msd_key_is(src, key, "tension")) return MSD_BUILTIN_GAME_CAMERA_TENSION;
        if (msd_key_is(src, key, "overdrawhigh")) return MSD_BUILTIN_GAME_CAMERA_OVERDRAWHIGH;
        if (msd_key_is(src, key, "overdrawlow")) return MSD_BUILTIN_GAME_CAMERA_OVERDRAWLOW;
        if (msd_key_is(src, key, "cuthigh")) return MSD_BUILTIN_GAME_CAMERA_CUTHIGH;
        if (msd_key_is(src, key, "cutlow")) return MSD_BUILTIN_GAME_CAMERA_CUTLOW;
        if (msd_key_is(src, key, "tensionhigh")) return MSD_BUILTIN_GAME_CAMERA_TENSIONHIGH;
        if (msd_key_is(src, key, "tensionlow")) return MSD_BUILTIN_GAME_CAMERA_TENSIONLOW;
        if (msd_key_is(src, key, "verticalfollow")) return MSD_BUILTIN_GAME_CAMERA_VERTICALFOLLOW;
        if (msd_key_is(src, key, "floortension")) return MSD_BUILTIN_GAME_CAMERA_FLOORTENSION;
        if (msd_key_is(src, key, "startzoom")) return MSD_BUILTIN_GAME_CAMERA_STARTZOOM;
        if (msd_key_is(src, key, "zoomout")) return MSD_BUILTIN_GAME_CAMERA_ZOOMOUT;
        if (msd_key_is(src, key, "zoomin")) return MSD_BUILTIN_GAME_CAMERA_ZOOMIN;
        break;
    case MSD_SECTION_PLAYERINFO:
        if (msd_key_is(src, key, "p1startx")) return MSD_BUILTIN_GAME_PLAYER_P1STARTX;
        if (msd_key_is(src, key, "p1starty")) return MSD_BUILTIN_GAME_PLAYER_P1STARTY;
        if (msd_key_is(src, key, "p1facing")) return MSD_BUILTIN_GAME_PLAYER_P1FACING;
        if (msd_key_is(src, key, "p2startx")) return MSD_BUILTIN_GAME_PLAYER_P2STARTX;
        if (msd_key_is(src, key, "p2starty")) return MSD_BUILTIN_GAME_PLAYER_P2STARTY;
        if (msd_key_is(src, key, "p2facing")) return MSD_BUILTIN_GAME_PLAYER_P2FACING;
        if (msd_key_is(src, key, "leftbound")) return MSD_BUILTIN_GAME_PLAYER_LEFTBOUND;
        if (msd_key_is(src, key, "rightbound")) return MSD_BUILTIN_GAME_PLAYER_RIGHTBOUND;
        break;
    case MSD_SECTION_BOUND:
        if (msd_key_is(src, key, "screenleft")) return MSD_BUILTIN_GAME_BOUND_SCREENLEFT;
        if (msd_key_is(src, key, "screenright")) return MSD_BUILTIN_GAME_BOUND_SCREENRIGHT;
        break;
    case MSD_SECTION_BG:
        if (msd_key_is(src, key, "type")) return MSD_BUILTIN_GAME_BG_TYPE;
        if (msd_key_is(src, key, "spriteno")) return MSD_BUILTIN_GAME_BG_SPRITENO;
        if (msd_key_is(src, key, "actionno")) return MSD_BUILTIN_GAME_BG_ACTIONNO;
        if (msd_key_is(src, key, "start")) return MSD_BUILTIN_GAME_BG_START;
        if (msd_key_is(src, key, "delta")) return MSD_BUILTIN_GAME_BG_DELTA;
        if (msd_key_is(src, key, "mask")) return MSD_BUILTIN_GAME_BG_MASK;
        if (msd_key_is(src, key, "layerno")) return MSD_BUILTIN_GAME_BG_LAYERNO;
        if (msd_key_is(src, key, "id")) return MSD_BUILTIN_GAME_BG_ID;
        if (msd_key_is(src, key, "tile")) return MSD_BUILTIN_GAME_BG_TILE;
        if (msd_key_is(src, key, "tilespacing")) return MSD_BUILTIN_GAME_BG_TILESPACING;
        if (msd_key_is(src, key, "window")) return MSD_BUILTIN_GAME_BG_WINDOW;
        if (msd_key_is(src, key, "windowdelta")) return MSD_BUILTIN_GAME_BG_WINDOWDELTA;
        if (msd_key_is(src, key, "trans")) return MSD_BUILTIN_GAME_BG_TRANS;
        if (msd_key_is(src, key, "alpha")) return MSD_BUILTIN_GAME_BG_ALPHA;
        if (msd_key_is(src, key, "velocity")) return MSD_BUILTIN_GAME_BG_VELOCITY;
        if (msd_key_is(src, key, "positionlink")) return MSD_BUILTIN_GAME_BG_POSITIONLINK;
        if (msd_key_is(src, key, "width")) return MSD_BUILTIN_GAME_BG_WIDTH;
        if (msd_key_is(src, key, "xscale")) return MSD_BUILTIN_GAME_BG_XSCALE;
        if (msd_key_is(src, key, "yscalestart")) return MSD_BUILTIN_GAME_BG_YSCALESTART;
        if (msd_key_is(src, key, "yscaledelta")) return MSD_BUILTIN_GAME_BG_YSCALEDELTA;
        if (msd_key_is(src, key, "scalestart")) return MSD_BUILTIN_GAME_BG_SCALESTART;
        if (msd_key_is(src, key, "scaledelta")) return MSD_BUILTIN_GAME_BG_SCALEDELTA;
        if (msd_key_is(src, key, "maskwindow")) return MSD_BUILTIN_GAME_BG_MASKWINDOW;
        if (msd_key_is(src, key, "zoomdelta")) return MSD_BUILTIN_GAME_BG_ZOOMDELTA;
        if (msd_key_is(src, key, "sin.x")) return MSD_BUILTIN_GAME_BG_SINX;
        if (msd_key_is(src, key, "sin.y")) return MSD_BUILTIN_GAME_BG_SINY;
        if (msd_key_is(src, key, "trackchar")) return MSD_BUILTIN_GAME_BG_TRACKCHAR;
        break;
    case MSD_SECTION_BGCTRLDEF:
        if (msd_key_is(src, key, "looptime")) return MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME;
        if (msd_key_is(src, key, "ctrlid")) return MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID;
        break;
    case MSD_SECTION_BGCTRL:
        if (msd_key_is(src, key, "type")) return MSD_BUILTIN_GAME_BGCTRL_TYPE;
        if (msd_key_is(src, key, "time")) return MSD_BUILTIN_GAME_BGCTRL_TIME;
        if (msd_key_is(src, key, "ctrlid")) return MSD_BUILTIN_GAME_BGCTRL_CTRLID;
        if (msd_key_is(src, key, "x")) return MSD_BUILTIN_GAME_BGCTRL_X;
        if (msd_key_is(src, key, "y")) return MSD_BUILTIN_GAME_BGCTRL_Y;
        if (msd_key_is(src, key, "value")) return MSD_BUILTIN_GAME_BGCTRL_VALUE;
        if (msd_key_is(src, key, "attachedchar")) return MSD_BUILTIN_GAME_BGCTRL_ATTACHEDCHAR;
        if (msd_key_is(src, key, "attachedid")) return MSD_BUILTIN_GAME_BGCTRL_ATTACHEDID;
        if (msd_key_is(src, key, "sctrlid")) return MSD_BUILTIN_GAME_BGCTRL_SCTRLID;
        if (msd_key_is(src, key, "modifybgctrl")) return MSD_BUILTIN_GAME_BGCTRL_MODIFYBGCTRL;
        if (msd_key_is(src, key, "charoffset")) return MSD_BUILTIN_GAME_BGCTRL_CHAROFFSET;
        if (msd_key_is(src, key, "followchar")) return MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR;
        break;
    default:
        break;
    }
    return MSD_BUILTIN_CORE_RAW_ASSIGN;
}

MsdBuiltinId msd_mugen_resolve_row(MsdSectionKind kind)
{
    if (kind == MSD_SECTION_BEGIN_ACTION) {
        return MSD_BUILTIN_GAME_ACTION_FRAME;
    }
    return MSD_BUILTIN_CORE_RAW_ROW;
}
