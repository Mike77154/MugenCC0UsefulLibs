#include "msd_semantic.h"
#include "msd_syntax.h"
#include "msd_profile.h"

#define MSD_TYPE_IDENT   1
#define MSD_TYPE_STRING  2
#define MSD_TYPE_NUMBER  4

#define MSD_KEY_UNIQUE   1

typedef struct MsdKeySpec {
    MsdSectionKind section;
    const char *key;
    int min_count;
    int max_count;
    int type_mask;
    int flags;
} MsdKeySpec;

static const MsdKeySpec msd_specs[] = {
    { MSD_SECTION_INFO, "name", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_INFO, "displayname", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_INFO, "author", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_INFO, "versiondate", 1, 3, MSD_TYPE_IDENT | MSD_TYPE_STRING | MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_INFO, "mugenversion", 1, 3, MSD_TYPE_IDENT | MSD_TYPE_STRING | MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_CAMERA, "startx", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "starty", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "boundleft", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "boundright", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "boundhigh", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "boundlow", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "tension", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "tensionhigh", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "tensionlow", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "verticalfollow", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "floortension", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "overdrawhigh", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "overdrawlow", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "cuthigh", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "cutlow", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "startzoom", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "zoomout", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_CAMERA, "zoomin", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_PLAYERINFO, "p1startx", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "p1starty", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "p2startx", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "p2starty", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "p1facing", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "p2facing", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "leftbound", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_PLAYERINFO, "rightbound", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BOUND, "screenleft", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BOUND, "screenright", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_STAGEINFO, "zoffset", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "zoffsetlink", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "autoturn", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "resetbg", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "localcoord", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "xscale", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_STAGEINFO, "yscale", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_SHADOW, "intensity", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_SHADOW, "color", 3, 3, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_SHADOW, "yscale", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_SHADOW, "fade.range", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_SHADOW, "xshear", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_REFLECTION, "reflect", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_MUSIC, "bgmusic", 0, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING | MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_MUSIC, "bgvolume", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BGDEF, "spr", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGDEF, "debugbg", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BG, "type", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "spriteno", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "actionno", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "start", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "delta", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "mask", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "layerno", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "id", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "tile", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "tilespacing", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "window", 4, 4, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "windowdelta", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "trans", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "alpha", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "velocity", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "positionlink", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "width", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "xscale", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "scalestart", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "scaledelta", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "maskwindow", 4, 4, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "zoomdelta", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "sin.x", 2, 3, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "sin.y", 2, 3, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "yscalestart", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "yscaledelta", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BGCTRLDEF, "looptime", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRLDEF, "ctrlid", 1, MSD_MAX_CTRL_IDS, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BGCTRL, "type", 1, 1, MSD_TYPE_IDENT | MSD_TYPE_STRING, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "time", 1, 3, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "ctrlid", 1, MSD_MAX_CTRL_IDS, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "x", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "y", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "value", 1, 3, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },

    { MSD_SECTION_BGCTRL, "attachedchar", 1, 3, MSD_TYPE_IDENT | MSD_TYPE_STRING | MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "attachedid", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "sctrlid", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "modifybgctrl", 1, 4, MSD_TYPE_IDENT | MSD_TYPE_STRING | MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "charoffset", 2, 2, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BGCTRL, "followchar", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE },
    { MSD_SECTION_BG, "trackchar", 1, 1, MSD_TYPE_NUMBER, MSD_KEY_UNIQUE }
};

static const MsdKeySpec *msd_find_spec(MsdSectionKind section, const MsdSource *src, const MsdAtom *key)
{
    int i;
    for (i = 0; i < (int) (sizeof(msd_specs) / sizeof(msd_specs[0])); ++i) {
        if (msd_specs[i].section == section && msd_span_ieq(src->data, key->offset, key->length, msd_specs[i].key)) {
            return &msd_specs[i];
        }
    }
    return 0;
}

int msd_semantic_key_is_unique(MsdSectionKind section, const MsdSource *src, const MsdAtom *key)
{
    const MsdKeySpec *spec;
    spec = msd_find_spec(section, src, key);
    return spec && (spec->flags & MSD_KEY_UNIQUE);
}

static int msd_atom_type_mask(const MsdAtom *atom)
{
    if (!atom) {
        return 0;
    }
    switch (atom->type) {
    case MSD_ATOM_IDENT: return MSD_TYPE_IDENT;
    case MSD_ATOM_STRING: return MSD_TYPE_STRING;
    case MSD_ATOM_NUMBER: return MSD_TYPE_NUMBER;
    }
    return 0;
}

static int msd_atom_is_number(const MsdAtom *atom)
{
    return atom && atom->type == MSD_ATOM_NUMBER;
}

static int msd_atom_to_int_local(const MsdAtom *atom)
{
    if (!atom || atom->type != MSD_ATOM_NUMBER) {
        return 0;
    }
    return (int) msd_fixed_to_int(atom->number);
}

static int msd_fixed_in_range(msd_fixed_t value, msd_fixed_t lo, msd_fixed_t hi)
{
    return value >= lo && value <= hi;
}

static const MsdAstItem *msd_find_item_by_key(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec, const char *key)
{
    int i;
    const MsdAstItem *item;
    const MsdAtom *atom;
    if (!src || !arena || !sec || !key) {
        return 0;
    }
    for (i = 0; i < sec->item_count; ++i) {
        item = &arena->items[sec->first_item + i];
        if (item->kind != MSD_ITEM_ASSIGN || item->key_atom < 0) {
            continue;
        }
        atom = &arena->atoms[item->key_atom];
        if (msd_span_ieq(src->data, atom->offset, atom->length, key)) {
            return item;
        }
    }
    return 0;
}

static int msd_has_nonzero_tile(const MsdArena *arena, const MsdAstItem *item)
{
    int i;
    const MsdAtom *atom;
    if (!arena || !item) {
        return 0;
    }
    for (i = 0; i < item->value_count; ++i) {
        atom = &arena->atoms[item->value_start + i];
        if (atom->type == MSD_ATOM_NUMBER && atom->number != 0) {
            return 1;
        }
    }
    return 0;
}

static int msd_int_in_set(const int *values, int count, int value)
{
    int i;
    for (i = 0; i < count; ++i) {
        if (values[i] == value) {
            return 1;
        }
    }
    return 0;
}

static void msd_add_errorf(MsdArena *arena, int line, int col, const char *prefix, const char *name)
{
    char msg[MSD_MAX_TEXT];
    sprintf(msg, "%s%s", prefix, name ? name : "");
    msd_arena_add_error(arena, line, col, msg);
}

static void msd_validate_known_item(const MsdSource *src, MsdArena *arena, const MsdAstSection *sec, const MsdAstItem *item, const MsdKeySpec *spec)
{
    int i;
    int j;
    char keybuf[64];
    const MsdAtom *atom;
    const MsdAstItem *prev;

    if (!src || !arena || !sec || !item || !spec) {
        return;
    }

    if (item->value_count < spec->min_count || item->value_count > spec->max_count) {
        msd_atom_to_text(src, &arena->atoms[item->key_atom], keybuf, sizeof(keybuf));
        msd_add_errorf(arena, item->line, item->col, "invalid arity for key '", keybuf);
        if (arena->error_count > 0) {
            strcat(arena->errors[arena->error_count - 1].message, "'");
        }
    }

    for (i = 0; i < item->value_count; ++i) {
        atom = &arena->atoms[item->value_start + i];
        if ((msd_atom_type_mask(atom) & spec->type_mask) == 0) {
            msd_atom_to_text(src, &arena->atoms[item->key_atom], keybuf, sizeof(keybuf));
            {
                char msg[MSD_MAX_TEXT];
                sprintf(msg, "invalid value type for key '%s'", keybuf);
                msd_arena_add_error(arena, atom->line, atom->col, msg);
            }
            break;
        }
    }

    if ((spec->flags & MSD_KEY_UNIQUE) != 0) {
        for (j = 0; j < sec->item_count; ++j) {
            prev = &arena->items[sec->first_item + j];
            if (prev == item || prev->kind != MSD_ITEM_ASSIGN || prev->key_atom < 0) {
                if (prev == item) {
                    break;
                }
                continue;
            }
            if (msd_span_ieq(src->data, arena->atoms[prev->key_atom].offset, arena->atoms[prev->key_atom].length, spec->key)) {
                sprintf(keybuf, "duplicate key '%s'", spec->key);
                msd_arena_add_error(arena, item->line, item->col, keybuf);
                break;
            }
        }
    }
}

static void msd_validate_ranges(const MsdSource *src, MsdArena *arena, const MsdAstSection *sec, const MsdAstItem *item, const MsdKeySpec *spec)
{
    const MsdAtom *a0;
    const MsdAtom *a1;
    int v0;
    int v1;
    if (!src || !arena || !sec || !item || !spec || item->value_count <= 0) {
        return;
    }
    a0 = &arena->atoms[item->value_start];
    a1 = item->value_count > 1 ? &arena->atoms[item->value_start + 1] : 0;

    if (spec->section == MSD_SECTION_CAMERA && strcmp(spec->key, "boundleft") == 0 && a0->number >= 0) {
        msd_arena_add_error(arena, item->line, item->col, "Camera.boundleft must be negative");
    }
    if (spec->section == MSD_SECTION_CAMERA && strcmp(spec->key, "boundright") == 0 && a0->number <= 0) {
        msd_arena_add_error(arena, item->line, item->col, "Camera.boundright must be positive");
    }
    if (spec->section == MSD_SECTION_CAMERA && strcmp(spec->key, "boundhigh") == 0 && a0->number >= 0) {
        msd_arena_add_error(arena, item->line, item->col, "Camera.boundhigh must be negative");
    }
    if (spec->section == MSD_SECTION_CAMERA && strcmp(spec->key, "boundlow") == 0 && a0->number != 0) {
        msd_arena_add_error(arena, item->line, item->col, "Camera.boundlow must be 0");
    }
    if (spec->section == MSD_SECTION_CAMERA && strcmp(spec->key, "verticalfollow") == 0 && !msd_fixed_in_range(a0->number, 0, MSD_FIXED_ONE)) {
        msd_arena_add_error(arena, item->line, item->col, "Camera.verticalfollow must be in [0,1]");
    }

    if (spec->section == MSD_SECTION_PLAYERINFO && (strcmp(spec->key, "p1facing") == 0 || strcmp(spec->key, "p2facing") == 0)) {
        v0 = msd_atom_to_int_local(a0);
        if (!(v0 == -1 || v0 == 1)) {
            msd_arena_add_error(arena, item->line, item->col, "PlayerInfo facing must be -1 or 1");
        }
    }

    if (spec->section == MSD_SECTION_BOUND && (strcmp(spec->key, "screenleft") == 0 || strcmp(spec->key, "screenright") == 0) && a0->number <= 0) {
        msd_arena_add_error(arena, item->line, item->col, "Bound screen distances must be positive");
    }

    if (spec->section == MSD_SECTION_STAGEINFO && strcmp(spec->key, "localcoord") == 0 && a1) {
        v0 = msd_atom_to_int_local(a0);
        v1 = msd_atom_to_int_local(a1);
        if (v0 <= 0 || v1 <= 0) {
            msd_arena_add_error(arena, item->line, item->col, "StageInfo.localcoord values must be positive");
        }
    }
    if (spec->section == MSD_SECTION_STAGEINFO && (strcmp(spec->key, "autoturn") == 0 || strcmp(spec->key, "resetbg") == 0)) {
        v0 = msd_atom_to_int_local(a0);
        if (!(v0 == 0 || v0 == 1)) {
            msd_arena_add_error(arena, item->line, item->col, "StageInfo boolean keys must be 0 or 1");
        }
    }

    if (spec->section == MSD_SECTION_SHADOW && strcmp(spec->key, "intensity") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (v0 < 0 || v0 > 256) {
            msd_arena_add_error(arena, item->line, item->col, "Shadow.intensity must be in [0,256]");
        }
    }

    if (spec->section == MSD_SECTION_REFLECTION && strcmp(spec->key, "reflect") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (!(v0 == 0 || v0 == 1)) {
            msd_arena_add_error(arena, item->line, item->col, "Reflection.reflect must be 0 or 1");
        }
    }

    if (spec->section == MSD_SECTION_MUSIC && strcmp(spec->key, "bgvolume") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (v0 < -255 || v0 > 255) {
            msd_arena_add_error(arena, item->line, item->col, "Music.bgvolume must be in [-255,255]");
        }
    }

    if (spec->section == MSD_SECTION_BGDEF && strcmp(spec->key, "debugbg") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (!(v0 == 0 || v0 == 1)) {
            msd_arena_add_error(arena, item->line, item->col, "BGDef.debugbg must be 0 or 1");
        }
    }

    if (spec->section == MSD_SECTION_BG) {
        if ((strcmp(spec->key, "mask") == 0 || strcmp(spec->key, "positionlink") == 0) && !(msd_atom_to_int_local(a0) == 0 || msd_atom_to_int_local(a0) == 1)) {
            msd_arena_add_error(arena, item->line, item->col, "BG boolean keys must be 0 or 1");
        }
        if (strcmp(spec->key, "layerno") == 0) {
            v0 = msd_atom_to_int_local(a0);
            if (!(v0 == 0 || v0 == 1)) {
                msd_arena_add_error(arena, item->line, item->col, "BG.layerno must be 0 or 1");
            }
        }
        if (strcmp(spec->key, "tile") == 0) {
            if (a0->number < 0 || (a1 && a1->number < 0)) {
                msd_arena_add_error(arena, item->line, item->col, "BG.tile values must be >= 0");
            }
        }
        if (strcmp(spec->key, "alpha") == 0 && a1) {
            v0 = msd_atom_to_int_local(a0);
            v1 = msd_atom_to_int_local(a1);
            if (v0 < 0 || v0 > 256 || v1 < 0 || v1 > 256) {
                msd_arena_add_error(arena, item->line, item->col, "BG.alpha values must be in [0,256]");
            }
        }
        if ((strcmp(spec->key, "sin.x") == 0 || strcmp(spec->key, "sin.y") == 0) && a1 && a1->number <= 0) {
            msd_arena_add_error(arena, item->line, item->col, "BG sine period must be positive");
        }
    }

    if (spec->section == MSD_SECTION_BGCTRLDEF && strcmp(spec->key, "looptime") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (!(v0 == -1 || v0 > 0)) {
            msd_arena_add_error(arena, item->line, item->col, "BGCtrlDef.looptime must be -1 or > 0");
        }
    }

    if (spec->section == MSD_SECTION_BGCTRL && strcmp(spec->key, "time") == 0) {
        v0 = msd_atom_to_int_local(a0);
        if (v0 < 0) {
            msd_arena_add_error(arena, item->line, item->col, "BGCtrl.time start must be >= 0");
        }
        if (item->value_count > 1) {
            v1 = msd_atom_to_int_local(a1);
            if (v1 < v0) {
                msd_arena_add_error(arena, item->line, item->col, "BGCtrl.time end must be >= start");
            }
        }
        if (item->value_count > 2) {
            v1 = msd_atom_to_int_local(&arena->atoms[item->value_start + 2]);
            if (!(v1 == -1 || v1 > 0)) {
                msd_arena_add_error(arena, item->line, item->col, "BGCtrl.time loop must be -1 or > 0");
            }
        }
    }
}

static void msd_validate_rows(const MsdSource *src, MsdArena *arena, const MsdAstSection *sec, const MsdAstItem *item)
{
    int i;
    const MsdAtom *atom;
    if (sec->kind != MSD_SECTION_BEGIN_ACTION) {
        msd_arena_add_error(arena, item->line, item->col, "row syntax is only valid inside [Begin Action]");
        return;
    }
    if (item->value_count < 5 || item->value_count > 7) {
        msd_arena_add_error(arena, item->line, item->col, "action frame rows should have 5..7 values");
    }
    for (i = 0; i < item->value_count && i < 5; ++i) {
        atom = &arena->atoms[item->value_start + i];
        if (!msd_atom_is_number(atom)) {
            msd_arena_add_error(arena, atom->line, atom->col, "first 5 action frame fields must be numeric");
            break;
        }
    }
    (void) src;
}

static void msd_validate_section_shape(const MsdSource *src, MsdArena *arena, const MsdAstSection *sec, MsdProfile profile)
{
    const MsdAstItem *type_item;
    const MsdAstItem *spriteno_item;
    const MsdAstItem *actionno_item;
    const MsdAstItem *width_item;
    const MsdAstItem *xscale_item;
    const MsdAstItem *tile_item;
    const MsdAstItem *tilespacing_item;
    const MsdAstItem *time_item;
    const MsdAstItem *x_item;
    const MsdAstItem *y_item;
    const MsdAstItem *value_item;
    char typebuf[64];
    const MsdAtom *a;

    if (!src || !arena || !sec) {
        return;
    }

    if (sec->kind == MSD_SECTION_BG && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BG] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BGCTRLDEF && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BGCtrlDef] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BGCTRL && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BGCtrl] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BEGIN_ACTION) {
        if (sec->header_count < 3 || !msd_atom_is_number(&arena->atoms[sec->header_start + 2])) {
            msd_arena_add_error(arena, sec->line, sec->col, "[Begin Action N] requires a numeric action number");
        }
    }

    if (sec->kind == MSD_SECTION_BG) {
        type_item = msd_find_item_by_key(src, arena, sec, "type");
        spriteno_item = msd_find_item_by_key(src, arena, sec, "spriteno");
        actionno_item = msd_find_item_by_key(src, arena, sec, "actionno");
        width_item = msd_find_item_by_key(src, arena, sec, "width");
        xscale_item = msd_find_item_by_key(src, arena, sec, "xscale");
        tile_item = msd_find_item_by_key(src, arena, sec, "tile");
        tilespacing_item = msd_find_item_by_key(src, arena, sec, "tilespacing");
        if (!type_item) {
            msd_arena_add_error(arena, sec->line, sec->col, "BG section requires key 'type'");
            return;
        }
        msd_atom_to_text(src, &arena->atoms[type_item->value_start], typebuf, sizeof(typebuf));
        if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "normal")) {
            if (!spriteno_item) {
                msd_arena_add_error(arena, sec->line, sec->col, "normal BG requires spriteno");
            }
            if (actionno_item) {
                msd_arena_add_error(arena, actionno_item->line, actionno_item->col, "normal BG should not define actionno");
            }
        } else if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "anim")) {
            if (!actionno_item) {
                msd_arena_add_error(arena, sec->line, sec->col, "anim BG requires actionno");
            }
            if (spriteno_item) {
                msd_arena_add_error(arena, spriteno_item->line, spriteno_item->col, "anim BG should not define spriteno");
            }
            if (tile_item && msd_has_nonzero_tile(arena, tile_item) && !tilespacing_item) {
                msd_arena_add_error(arena, tile_item->line, tile_item->col, "anim BG using tile should define tilespacing");
            }
        } else if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "parallax")) {
            if (!spriteno_item && !actionno_item) {
                msd_arena_add_error(arena, sec->line, sec->col, "parallax BG requires spriteno or actionno");
            }
            if ((width_item && xscale_item) || (!width_item && !xscale_item)) {
                msd_arena_add_error(arena, sec->line, sec->col, "parallax BG requires exactly one of width or xscale");
            }
            if (actionno_item && xscale_item) {
                msd_arena_add_error(arena, xscale_item->line, xscale_item->col, "animated parallax BG cannot use xscale");
            }
        } else if (!msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "dummy")) {
            msd_arena_add_error(arena, type_item->line, type_item->col, "unknown BG type");
        }
    }

    if (sec->kind == MSD_SECTION_BGCTRL) {
        type_item = msd_find_item_by_key(src, arena, sec, "type");
        time_item = msd_find_item_by_key(src, arena, sec, "time");
        x_item = msd_find_item_by_key(src, arena, sec, "x");
        y_item = msd_find_item_by_key(src, arena, sec, "y");
        value_item = msd_find_item_by_key(src, arena, sec, "value");
        if (!type_item) {
            msd_arena_add_error(arena, sec->line, sec->col, "BGCtrl requires key 'type'");
            return;
        }
        if (!time_item) {
            msd_arena_add_error(arena, sec->line, sec->col, "BGCtrl requires key 'time'");
        }
        a = &arena->atoms[type_item->value_start];
        msd_atom_to_text(src, a, typebuf, sizeof(typebuf));
        if (!msd_profile_supports_bgctrl_type(profile, typebuf)) {
            msd_arena_add_error(arena, type_item->line, type_item->col, "BGCtrl type is not supported by the active profile");
            return;
        }
        if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "null")) {
        } else if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "visible") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "enabled") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "anim")) {
            if (!value_item || value_item->value_count != 1) {
                msd_arena_add_error(arena, sec->line, sec->col, "BGCtrl Visible/Enabled/Anim require value=<single number>");
            }
        } else if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "velset") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "veladd") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "posset") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "posadd")) {
            if (!x_item && !y_item) {
                msd_arena_add_error(arena, sec->line, sec->col, "BGCtrl motion controllers require x and/or y");
            }
        } else if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "sinx") || msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "siny")) {
            if (!value_item || value_item->value_count < 2 || value_item->value_count > 3) {
                msd_arena_add_error(arena, sec->line, sec->col, "BGCtrl SinX/SinY require value=amplitude,period[,phase]");
            }
        } else {
            msd_arena_add_error(arena, type_item->line, type_item->col, "unknown BGCtrl type");
        }
    }
}

static void msd_collect_bg_ids(const MsdSource *src, const MsdArena *arena, int *ids, int *count)
{
    int si;
    const MsdAstSection *sec;
    const MsdAstItem *item;
    ids[0] = 0;
    *count = 1;
    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind != MSD_SECTION_BG) {
            continue;
        }
        item = msd_find_item_by_key(src, arena, sec, "id");
        if (item && item->value_count > 0) {
            if (!msd_int_in_set(ids, *count, msd_atom_to_int_local(&arena->atoms[item->value_start])) && *count < MSD_MAX_BG + 1) {
                ids[*count] = msd_atom_to_int_local(&arena->atoms[item->value_start]);
                *count += 1;
            }
        }
    }
}

static void msd_collect_action_numbers(const MsdArena *arena, int *actions, int *count)
{
    int si;
    int number;
    const MsdAstSection *sec;
    *count = 0;
    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind != MSD_SECTION_BEGIN_ACTION) {
            continue;
        }
        if (sec->header_count > 2 && arena->atoms[sec->header_start + 2].type == MSD_ATOM_NUMBER) {
            number = msd_atom_to_int_local(&arena->atoms[sec->header_start + 2]);
            if (*count < MSD_MAX_ACTIONS) {
                actions[*count] = number;
                *count += 1;
            }
        }
    }
}

static void msd_validate_cross_refs(const MsdSource *src, MsdArena *arena, int strict, MsdProfile profile)
{
    int bg_ids[MSD_MAX_BG + 1];
    int bg_id_count;
    int actions[MSD_MAX_ACTIONS];
    int action_count;
    int section_counts[MSD_SECTION_BEGIN_ACTION + 1];
    int si;
    int i;
    int value;
    const MsdAstSection *sec;
    const MsdAstItem *item;

    (void) profile;
    memset(section_counts, 0, sizeof(section_counts));
    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind >= 0 && sec->kind <= MSD_SECTION_BEGIN_ACTION) {
            section_counts[sec->kind] += 1;
        }
    }

    if (section_counts[MSD_SECTION_BGDEF] != 1) {
        msd_arena_add_error(arena, 1, 1, "stage must contain exactly one [BGDef] section");
    }
    if (section_counts[MSD_SECTION_BG] < 1) {
        msd_arena_add_error(arena, 1, 1, "stage must contain at least one [BG ...] section");
    }
    if (strict) {
        if (section_counts[MSD_SECTION_INFO] < 1) msd_arena_add_error(arena, 1, 1, "strict mode expects an [Info] section");
        if (section_counts[MSD_SECTION_CAMERA] < 1) msd_arena_add_error(arena, 1, 1, "strict mode expects a [Camera] section");
        if (section_counts[MSD_SECTION_PLAYERINFO] < 1) msd_arena_add_error(arena, 1, 1, "strict mode expects a [PlayerInfo] section");
        if (section_counts[MSD_SECTION_BOUND] < 1) msd_arena_add_error(arena, 1, 1, "strict mode expects a [Bound] section");
        if (section_counts[MSD_SECTION_STAGEINFO] < 1) msd_arena_add_error(arena, 1, 1, "strict mode expects a [StageInfo] section");
    }

    msd_collect_bg_ids(src, arena, bg_ids, &bg_id_count);
    msd_collect_action_numbers(arena, actions, &action_count);

    for (i = 0; i < action_count; ++i) {
        if (msd_int_in_set(actions, i, actions[i])) {
            msd_arena_add_error(arena, 1, 1, "duplicate [Begin Action] number");
            break;
        }
    }

    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind == MSD_SECTION_STAGEINFO) {
            item = msd_find_item_by_key(src, arena, sec, "zoffsetlink");
            if (item && item->value_count > 0) {
                value = msd_atom_to_int_local(&arena->atoms[item->value_start]);
                if (!msd_int_in_set(bg_ids, bg_id_count, value)) {
                    msd_arena_add_error(arena, item->line, item->col, "StageInfo.zoffsetlink references an unknown BG id");
                }
            }
        }
        if (sec->kind == MSD_SECTION_BGCTRLDEF) {
            item = msd_find_item_by_key(src, arena, sec, "ctrlid");
            if (item) {
                for (i = 0; i < item->value_count; ++i) {
                    value = msd_atom_to_int_local(&arena->atoms[item->value_start + i]);
                    if (!msd_int_in_set(bg_ids, bg_id_count, value)) {
                        msd_arena_add_error(arena, item->line, item->col, "BGCtrlDef.ctrlID references an unknown BG id");
                        break;
                    }
                }
            }
        }
        if (sec->kind == MSD_SECTION_BGCTRL) {
            item = msd_find_item_by_key(src, arena, sec, "ctrlid");
            if (item) {
                for (i = 0; i < item->value_count; ++i) {
                    value = msd_atom_to_int_local(&arena->atoms[item->value_start + i]);
                    if (!msd_int_in_set(bg_ids, bg_id_count, value)) {
                        msd_arena_add_error(arena, item->line, item->col, "BGCtrl.ctrlID references an unknown BG id");
                        break;
                    }
                }
            }
            item = msd_find_item_by_key(src, arena, sec, "type");
            if (item && item->value_count > 0) {
                char typebuf[64];
                msd_atom_to_text(src, &arena->atoms[item->value_start], typebuf, sizeof(typebuf));
                if (msd_span_ieq(typebuf, 0, (int) strlen(typebuf), "anim")) {
                    const MsdAstItem *value_item;
                    value_item = msd_find_item_by_key(src, arena, sec, "value");
                    if (value_item && value_item->value_count > 0) {
                        value = msd_atom_to_int_local(&arena->atoms[value_item->value_start]);
                        if (!msd_int_in_set(actions, action_count, value)) {
                            msd_arena_add_error(arena, value_item->line, value_item->col, "BGCtrl Anim references an unknown action number");
                        }
                    }
                }
            }
        }
        if (sec->kind == MSD_SECTION_BG) {
            item = msd_find_item_by_key(src, arena, sec, "actionno");
            if (item && item->value_count > 0) {
                value = msd_atom_to_int_local(&arena->atoms[item->value_start]);
                if (!msd_int_in_set(actions, action_count, value)) {
                    msd_arena_add_error(arena, item->line, item->col, "BG actionno references an unknown [Begin Action]");
                }
            }
        }
    }
}

int msd_semantic_validate_profile(const MsdSource *src, MsdArena *arena, int strict, MsdProfile profile)
{
    int si;
    int ii;
    MsdProfile effective_profile;
    const MsdAstSection *sec;
    const MsdAstItem *item;
    const MsdKeySpec *spec;
    char keybuf[64];

    if (!src || !arena) {
        return 0;
    }
    effective_profile = msd_profile_resolve(src, arena, profile);

    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind == MSD_SECTION_UNKNOWN) {
            msd_arena_add_error(arena, sec->line, sec->col, "unknown section header");
            continue;
        }
        for (ii = 0; ii < sec->item_count; ++ii) {
            item = &arena->items[sec->first_item + ii];
            if (item->kind == MSD_ITEM_ASSIGN) {
                msd_atom_to_text(src, &arena->atoms[item->key_atom], keybuf, sizeof(keybuf));
                spec = msd_find_spec(sec->kind, src, &arena->atoms[item->key_atom]);
                if (spec) {
                    if (!msd_profile_supports_key(effective_profile, sec->kind, keybuf)) {
                        char msg[MSD_MAX_TEXT];
                        sprintf(msg, "key '%s' is not supported by profile %s", keybuf, msd_profile_name(effective_profile));
                        msd_arena_add_error(arena, item->line, item->col, msg);
                    } else {
                        msd_validate_known_item(src, arena, sec, item, spec);
                        msd_validate_ranges(src, arena, sec, item, spec);
                    }
                } else if (strict) {
                    {
                        char msg[MSD_MAX_TEXT];
                        sprintf(msg, "unknown key '%s' for section %s", keybuf, msd_section_kind_name(sec->kind));
                        msd_arena_add_error(arena, item->line, item->col, msg);
                    }
                }
            } else {
                msd_validate_rows(src, arena, sec, item);
            }
        }
        msd_validate_section_shape(src, arena, sec, effective_profile);
    }

    msd_validate_cross_refs(src, arena, strict, effective_profile);
    return arena->error_count == 0;
}


int msd_semantic_validate(const MsdSource *src, MsdArena *arena, int strict)
{
    return msd_semantic_validate_profile(src, arena, strict, MSD_PROFILE_AUTO);
}
