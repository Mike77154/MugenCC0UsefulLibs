#include "msd_bytecode.h"

static int msd_bc_add_atom(MsdBCAtom *storage, int *count, int cap, const MsdAtom *src_atom)
{
    if (*count >= cap) {
        return -1;
    }
    storage[*count].type = src_atom->type;
    storage[*count].offset = src_atom->offset;
    storage[*count].length = src_atom->length;
    storage[*count].number = src_atom->number;
    storage[*count].is_fixed = src_atom->is_fixed;
    storage[*count].line = src_atom->line;
    storage[*count].col = src_atom->col;
    return (*count)++;
}

int msd_compile_bytecode(const MsdSource *src, MsdArena *arena, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *atom_storage, int atom_cap)
{
    int i;
    int j;
    int bc_count;
    int atom_count;
    MsdBCInstr instr;
    const MsdIRInstr *ir;
    int index;

    (void) src;
    if (!arena || !arena->ir || !bc_storage || !atom_storage) {
        return 0;
    }

    bc_count = 0;
    atom_count = 0;
    for (i = 0; i < arena->ir_count; ++i) {
        ir = &arena->ir[i];
        memset(&instr, 0, sizeof(instr));
        instr.section_kind = ir->section_kind;
        instr.line = ir->line;
        instr.col = ir->col;
        instr.name_atom = -1;
        instr.const_start = -1;
        instr.const_count = 0;
        instr.profile_tag = ir->profile_tag;
        if (ir->op == MSD_IR_BEGIN_SECTION) {
            instr.op = MSD_BC_BEGIN_SECTION;
            instr.word_id = msd_mugen_resolve_begin(ir->section_kind);
            instr.const_start = atom_count;
            instr.const_count = 0;
            for (j = 0; j < ir->header_count; ++j) {
                index = msd_bc_add_atom(atom_storage, &atom_count, atom_cap, &arena->atoms[ir->header_start + j]);
                if (index < 0) return 0;
                ++instr.const_count;
            }
        } else if (ir->op == MSD_IR_SET) {
            instr.op = MSD_BC_CALL;
            instr.word_id = msd_mugen_resolve_key(ir->section_kind, src, &arena->atoms[ir->key_atom]);
            instr.name_atom = msd_bc_add_atom(atom_storage, &atom_count, atom_cap, &arena->atoms[ir->key_atom]);
            if (instr.name_atom < 0) return 0;
            instr.const_start = atom_count;
            instr.const_count = 0;
            for (j = 0; j < ir->value_count; ++j) {
                index = msd_bc_add_atom(atom_storage, &atom_count, atom_cap, &arena->atoms[ir->value_start + j]);
                if (index < 0) return 0;
                ++instr.const_count;
            }
        } else if (ir->op == MSD_IR_ROW) {
            instr.op = MSD_BC_CALL;
            instr.word_id = msd_mugen_resolve_row(ir->section_kind);
            instr.const_start = atom_count;
            instr.const_count = 0;
            for (j = 0; j < ir->value_count; ++j) {
                index = msd_bc_add_atom(atom_storage, &atom_count, atom_cap, &arena->atoms[ir->value_start + j]);
                if (index < 0) return 0;
                ++instr.const_count;
            }
        } else {
            instr.op = MSD_BC_END_SECTION;
            instr.word_id = MSD_BUILTIN_NONE;
        }
        if (bc_count >= bc_cap) {
            return 0;
        }
        bc_storage[bc_count++] = instr;
    }

    arena->bc = bc_storage;
    arena->bc_count = bc_count;
    arena->bc_atoms = atom_storage;
    arena->bc_atom_count = atom_count;
    return 1;
}

static void msd_bc_atom_to_text(const MsdSource *src, const MsdBCAtom *atom, char *buf, int cap)
{
    if (atom->type == MSD_ATOM_NUMBER) {
        if (atom->is_fixed) {
            msd_fixed_to_string(atom->number, buf, cap);
        } else {
            sprintf(buf, "%ld", msd_fixed_to_int(atom->number));
        }
    } else if (atom->type == MSD_ATOM_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, atom->offset, atom->length);
    } else {
        msd_copy_span(buf, cap, src->data, atom->offset, atom->length);
    }
}

void msd_bytecode_dump(const MsdSource *src, const MsdArena *arena, FILE *out)
{
    int i;
    int j;
    char buf[128];
    const MsdBCInstr *instr;

    if (!src || !arena || !arena->bc || !arena->bc_atoms || !out) {
        return;
    }
    for (i = 0; i < arena->bc_count; ++i) {
        instr = &arena->bc[i];
        fprintf(out, "%4d  ", i);
        if (instr->op == MSD_BC_BEGIN_SECTION) {
            fprintf(out, "BEGIN %-12s [%s] ", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
            for (j = 0; j < instr->const_count; ++j) {
                msd_bc_atom_to_text(src, &arena->bc_atoms[instr->const_start + j], buf, sizeof(buf));
                if (j > 0) fprintf(out, " ");
                fprintf(out, "%s", buf);
            }
        } else if (instr->op == MSD_BC_CALL) {
            fprintf(out, "CALL  %-24s [%s] ", msd_builtin_name(instr->word_id), msd_profile_name(instr->profile_tag));
            if (instr->name_atom >= 0) {
                msd_bc_atom_to_text(src, &arena->bc_atoms[instr->name_atom], buf, sizeof(buf));
                fprintf(out, "%s => ", buf);
            }
            for (j = 0; j < instr->const_count; ++j) {
                msd_bc_atom_to_text(src, &arena->bc_atoms[instr->const_start + j], buf, sizeof(buf));
                if (j > 0) fprintf(out, ", ");
                fprintf(out, "%s", buf);
            }
        } else {
            fprintf(out, "END   %-12s [%s]", msd_section_kind_name(instr->section_kind), msd_profile_name(instr->profile_tag));
        }
        fprintf(out, "\n");
    }
}
