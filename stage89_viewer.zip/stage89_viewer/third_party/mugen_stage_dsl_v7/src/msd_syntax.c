#include "msd_syntax.h"

static int msd_atom_ieq(const MsdSource *src, const MsdAtom *atom, const char *text)
{
    return atom && atom->type != MSD_ATOM_NUMBER && msd_span_ieq(src->data, atom->offset, atom->length, text);
}

MsdSectionKind msd_section_kind_from_header(const MsdSource *src, const MsdArena *arena, int header_start, int header_count)
{
    const MsdAtom *a0;
    const MsdAtom *a1;

    if (!src || !arena || header_count <= 0) {
        return MSD_SECTION_UNKNOWN;
    }

    a0 = &arena->atoms[header_start];
    a1 = header_count > 1 ? &arena->atoms[header_start + 1] : 0;

    if (header_count == 1 && msd_atom_ieq(src, a0, "Info")) return MSD_SECTION_INFO;
    if (header_count == 1 && msd_atom_ieq(src, a0, "Camera")) return MSD_SECTION_CAMERA;
    if (header_count == 1 && msd_atom_ieq(src, a0, "PlayerInfo")) return MSD_SECTION_PLAYERINFO;
    if (header_count == 1 && msd_atom_ieq(src, a0, "Bound")) return MSD_SECTION_BOUND;
    if (header_count == 1 && msd_atom_ieq(src, a0, "StageInfo")) return MSD_SECTION_STAGEINFO;
    if (header_count == 1 && msd_atom_ieq(src, a0, "Shadow")) return MSD_SECTION_SHADOW;
    if (header_count == 1 && msd_atom_ieq(src, a0, "Reflection")) return MSD_SECTION_REFLECTION;
    if (header_count == 1 && msd_atom_ieq(src, a0, "Music")) return MSD_SECTION_MUSIC;
    if (header_count >= 1 && msd_atom_ieq(src, a0, "BGDef")) return MSD_SECTION_BGDEF;
    if (header_count >= 1 && msd_atom_ieq(src, a0, "BGCtrlDef")) return MSD_SECTION_BGCTRLDEF;
    if (header_count >= 1 && msd_atom_ieq(src, a0, "BGCtrl")) return MSD_SECTION_BGCTRL;
    if (header_count >= 1 && msd_atom_ieq(src, a0, "BG")) return MSD_SECTION_BG;
    if (header_count >= 3 && msd_atom_ieq(src, a0, "Begin") && a1 && msd_atom_ieq(src, a1, "Action")) return MSD_SECTION_BEGIN_ACTION;
    return MSD_SECTION_UNKNOWN;
}

static int msd_atom_is_number(const MsdAtom *atom)
{
    return atom && atom->type == MSD_ATOM_NUMBER;
}

static void msd_validate_section_shape(MsdArena *arena, const MsdAstSection *sec)
{
    if (!arena || !sec) {
        return;
    }

    if (sec->kind == MSD_SECTION_BG && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BG] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BGCTRLDEF && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BGCtrlDef] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BGCTRL && sec->header_count < 2) {
        msd_arena_add_error(arena, sec->line, sec->col, "[BGCtrl] requires a symbolic name");
    }
    if (sec->kind == MSD_SECTION_BEGIN_ACTION) {
        if (sec->header_count < 3 || !msd_atom_is_number(&arena->atoms[sec->header_start + 2])) {
            msd_arena_add_error(arena, sec->line, sec->col, "[Begin Action N] requires a numeric action number");
        }
    }
}

static void msd_validate_row(MsdArena *arena, const MsdAstSection *sec, const MsdAstItem *item)
{
    int i;
    const MsdAtom *atom;

    if (!arena || !sec || !item) {
        return;
    }

    if (sec->kind != MSD_SECTION_BEGIN_ACTION) {
        msd_arena_add_error(arena, item->line, item->col, "row syntax is only valid inside [Begin Action]");
        return;
    }
    if (item->value_count < 5 || item->value_count > 7) {
        msd_arena_add_error(arena, item->line, item->col, "action frame rows should have 5..7 values");
    }
    for (i = 0; i < item->value_count && i < 5; ++i) {
        atom = &arena->atoms[item->value_start + i];
        if (!msd_atom_is_number(atom)) {
            msd_arena_add_error(arena, atom->line, atom->col, "first 5 action frame fields must be numeric");
            break;
        }
    }
}

int msd_syntax_validate(const MsdSource *src, MsdArena *arena, int strict)
{
    int si;
    int ii;
    const MsdAstSection *sec;
    const MsdAstItem *item;

    (void) src;
    (void) strict;

    if (!arena) {
        return 0;
    }

    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind == MSD_SECTION_UNKNOWN) {
            msd_arena_add_error(arena, sec->line, sec->col, "unknown section header");
            continue;
        }
        msd_validate_section_shape(arena, sec);
        for (ii = 0; ii < sec->item_count; ++ii) {
            item = &arena->items[sec->first_item + ii];
            if (item->kind == MSD_ITEM_ROW) {
                msd_validate_row(arena, sec, item);
            }
        }
    }

    return arena->error_count == 0;
}
