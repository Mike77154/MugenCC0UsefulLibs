#include "msd_profile.h"
#include "msd_arena.h"
#include "msd_common.h"
#include "msd_fixed.h"
#include "msd_words_mugen_dos2001.h"
#include "msd_words_mugen_win2002.h"
#include "msd_words_mugen_1_0.h"
#include "msd_words_mugen_1_1.h"
#include "msd_words_ikemengoplus.h"
#include "msd_words_ikemenplusultra.h"

static MsdProfile g_active_profile = MSD_PROFILE_MUGEN1_1;

static const MsdProfileCaps g_caps_dos2001 = {
    1, 0, 0, 0, 0, 0, 0, 0
};

static const MsdProfileCaps g_caps_win2002 = {
    1, 0, 0, 0, 0, 0, 0, 0
};

static const MsdProfileCaps g_caps_mugen_1_0 = {
    0, 1, 0, 0, 0, 0, 0, 0
};

static const MsdProfileCaps g_caps_mugen_1_1 = {
    0, 1, 1, 1, 1, 0, 0, 0
};

static const MsdProfileCaps g_caps_ikemengoplus = {
    0, 1, 1, 1, 1, 1, 0, 1
};

static const MsdProfileCaps g_caps_ikemenplusultra = {
    0, 1, 1, 1, 1, 1, 1, 1
};

static int msd_profile_ieq(const char *a, const char *b)
{
    int i;
    if (!a || !b) {
        return 0;
    }
    i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (msd_ascii_tolower((unsigned char) a[i]) != msd_ascii_tolower((unsigned char) b[i])) {
            return 0;
        }
        ++i;
    }
    return a[i] == '\0' && b[i] == '\0';
}

static const MsdAstItem *msd_profile_find_key(const MsdSource *src, const MsdArena *arena, MsdSectionKind kind, const char *key)
{
    int si;
    int ii;
    const MsdAstSection *sec;
    const MsdAstItem *item;
    const MsdAtom *atom;
    if (!src || !arena || !key) {
        return 0;
    }
    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        if (sec->kind != kind) {
            continue;
        }
        for (ii = 0; ii < sec->item_count; ++ii) {
            item = &arena->items[sec->first_item + ii];
            if (item->kind != MSD_ITEM_ASSIGN || item->key_atom < 0) {
                continue;
            }
            atom = &arena->atoms[item->key_atom];
            if (msd_span_ieq(src->data, atom->offset, atom->length, key)) {
                return item;
            }
        }
    }
    return 0;
}

static void msd_profile_value_text(const MsdSource *src, const MsdArena *arena, const MsdAstItem *item, char *buf, int cap)
{
    int i;
    int len;
    char part[64];
    const MsdAtom *atom;
    if (!buf || cap <= 0) {
        return;
    }
    buf[0] = '\0';
    if (!src || !arena || !item) {
        return;
    }
    len = 0;
    for (i = 0; i < item->value_count; ++i) {
        if (i > 0) {
            msd_append_char(buf, cap, &len, ',');
        }
        atom = &arena->atoms[item->value_start + i];
        msd_atom_to_text(src, atom, part, sizeof(part));
        msd_append_cstr(buf, cap, &len, part);
    }
}

const char *msd_profile_name(MsdProfile profile)
{
    switch (profile) {
    case MSD_PROFILE_AUTO: return "auto";
    case MSD_PROFILE_DOSMUGEN2001: return "dosmugen2001";
    case MSD_PROFILE_WINMUGEN2002: return "winmugen2002";
    case MSD_PROFILE_MUGEN1_0: return "mugen1.0";
    case MSD_PROFILE_MUGEN1_1: return "mugen1.1";
    case MSD_PROFILE_IKEMENGOPLUS: return "ikemengoplus";
    case MSD_PROFILE_IKEMENPLUSULTRA: return "ikemenplusultra";
    }
    return "unknown";
}

int msd_profile_parse(const char *text, MsdProfile *out)
{
    MsdProfile profile;
    if (!text || !out) {
        return 0;
    }
    profile = MSD_PROFILE_AUTO;
    if (msd_profile_ieq(text, "auto")) profile = MSD_PROFILE_AUTO;
    else if (msd_profile_ieq(text, "dosmugen2001") || msd_profile_ieq(text, "dos2001")) profile = MSD_PROFILE_DOSMUGEN2001;
    else if (msd_profile_ieq(text, "winmugen2002") || msd_profile_ieq(text, "win2002") || msd_profile_ieq(text, "2002")) profile = MSD_PROFILE_WINMUGEN2002;
    else if (msd_profile_ieq(text, "mugen1.0") || msd_profile_ieq(text, "1.0")) profile = MSD_PROFILE_MUGEN1_0;
    else if (msd_profile_ieq(text, "mugen1.1") || msd_profile_ieq(text, "1.1")) profile = MSD_PROFILE_MUGEN1_1;
    else if (msd_profile_ieq(text, "ikemengoplus") || msd_profile_ieq(text, "ikemen-go-plus")) profile = MSD_PROFILE_IKEMENGOPLUS;
    else if (msd_profile_ieq(text, "ikemenplusultra") || msd_profile_ieq(text, "ikemen-plus-ultra")) profile = MSD_PROFILE_IKEMENPLUSULTRA;
    else return 0;
    *out = profile;
    return 1;
}

MsdProfile msd_profile_detect(const MsdSource *src, const struct MsdArena *arena)
{
    const MsdAstItem *item;
    char value[64];
    if (!src || !arena) {
        return MSD_PROFILE_AUTO;
    }
    item = msd_profile_find_key(src, arena, MSD_SECTION_INFO, "mugenversion");
    if (!item || item->value_count <= 0) {
        return MSD_PROFILE_AUTO;
    }
    if (item->value_count >= 3) {
        msd_profile_value_text(src, arena, item, value, sizeof(value));
        if (msd_profile_ieq(value, "2002,2,14") || msd_profile_ieq(value, "2002,02,14")) {
            return MSD_PROFILE_WINMUGEN2002;
        }
    }
    msd_profile_value_text(src, arena, item, value, sizeof(value));
    if (msd_profile_ieq(value, "1.0") || msd_profile_ieq(value, "1,0") || msd_profile_ieq(value, "1")) {
        return MSD_PROFILE_MUGEN1_0;
    }
    if (msd_profile_ieq(value, "1.1") || msd_profile_ieq(value, "1,1")) {
        return MSD_PROFILE_MUGEN1_1;
    }
    return MSD_PROFILE_AUTO;
}

MsdProfile msd_profile_resolve(const MsdSource *src, const struct MsdArena *arena, MsdProfile requested)
{
    MsdProfile detected;
    if (requested != MSD_PROFILE_AUTO) {
        return requested;
    }
    detected = msd_profile_detect(src, arena);
    if (detected != MSD_PROFILE_AUTO) {
        return detected;
    }
    return MSD_PROFILE_WINMUGEN2002;
}

void msd_profile_set_active(MsdProfile profile)
{
    g_active_profile = profile;
}

MsdProfile msd_profile_get_active(void)
{
    return g_active_profile;
}

const MsdProfileLib *msd_profile_lib(MsdProfile profile)
{
    switch (profile) {
    case MSD_PROFILE_DOSMUGEN2001: return msd_words_mugen_dos2001_lib();
    case MSD_PROFILE_WINMUGEN2002: return msd_words_mugen_win2002_lib();
    case MSD_PROFILE_MUGEN1_0: return msd_words_mugen_1_0_lib();
    case MSD_PROFILE_MUGEN1_1: return msd_words_mugen_1_1_lib();
    case MSD_PROFILE_IKEMENGOPLUS: return msd_words_ikemengoplus_lib();
    case MSD_PROFILE_IKEMENPLUSULTRA: return msd_words_ikemenplusultra_lib();
    case MSD_PROFILE_AUTO: return msd_words_mugen_1_1_lib();
    }
    return msd_words_mugen_1_1_lib();
}

const MsdProfileCaps *msd_profile_caps(MsdProfile profile)
{
    switch (profile) {
    case MSD_PROFILE_DOSMUGEN2001: return &g_caps_dos2001;
    case MSD_PROFILE_WINMUGEN2002: return &g_caps_win2002;
    case MSD_PROFILE_MUGEN1_0: return &g_caps_mugen_1_0;
    case MSD_PROFILE_MUGEN1_1: return &g_caps_mugen_1_1;
    case MSD_PROFILE_IKEMENGOPLUS: return &g_caps_ikemengoplus;
    case MSD_PROFILE_IKEMENPLUSULTRA: return &g_caps_ikemenplusultra;
    case MSD_PROFILE_AUTO: return &g_caps_mugen_1_1;
    }
    return &g_caps_mugen_1_1;
}

static int msd_profile_key_in_list(const MsdProfileWord *keys, int key_count, MsdSectionKind section, const char *key)
{
    int i;
    if (!keys || key_count <= 0 || !key) {
        return 0;
    }
    for (i = 0; i < key_count; ++i) {
        if (keys[i].section == section && msd_profile_ieq(keys[i].key, key)) {
            return 1;
        }
    }
    return 0;
}

static int msd_profile_stub_in_list(const MsdProfileStubWord *stubs, int stub_count, MsdSectionKind section, const char *key)
{
    int i;
    if (!stubs || stub_count <= 0 || !key) {
        return 0;
    }
    for (i = 0; i < stub_count; ++i) {
        if (stubs[i].section == section && msd_profile_ieq(stubs[i].key, key)) {
            return 1;
        }
    }
    return 0;
}

int msd_profile_supports_key(MsdProfile profile, MsdSectionKind section, const char *key)
{
    const MsdProfileLib *lib;
    lib = msd_profile_lib(profile);
    if (!lib) {
        return 0;
    }
    if (msd_profile_key_in_list(lib->keys, lib->key_count, section, key)) {
        return 1;
    }
    return msd_profile_stub_in_list(lib->stubs, lib->stub_count, section, key);
}

int msd_profile_supports_bgctrl_type(MsdProfile profile, const char *type)
{
    const MsdProfileLib *lib;
    int i;
    lib = msd_profile_lib(profile);
    if (!lib || !type) {
        return 0;
    }
    for (i = 0; i < lib->bgctrl_count; ++i) {
        if (msd_profile_ieq(lib->bgctrl_types[i], type)) {
            return 1;
        }
    }
    return 0;
}

int msd_profile_is_stub_key(MsdProfile profile, MsdSectionKind section, const char *key)
{
    const MsdProfileLib *lib;
    lib = msd_profile_lib(profile);
    if (!lib) {
        return 0;
    }
    return msd_profile_stub_in_list(lib->stubs, lib->stub_count, section, key);
}

void msd_profile_print_summary(FILE *out, MsdProfile requested, MsdProfile detected, MsdProfile effective)
{
    const MsdProfileLib *lib;
    if (!out) {
        return;
    }
    lib = msd_profile_lib(effective);
    fprintf(out, "requested-profile : %s\n", msd_profile_name(requested));
    fprintf(out, "detected-profile  : %s\n", msd_profile_name(detected));
    fprintf(out, "effective-profile : %s\n", msd_profile_name(effective));
    if (lib) {
        fprintf(out, "lib.name          : %s\n", lib->name);
        fprintf(out, "lib.tagline       : %s\n", lib->tagline);
        fprintf(out, "lib.keys          : %d\n", lib->key_count);
        fprintf(out, "lib.bgctrl_types  : %d\n", lib->bgctrl_count);
        fprintf(out, "lib.stub_words    : %d\n", lib->stub_count);
    }
}

void msd_profile_print_words(FILE *out, MsdProfile profile)
{
    int i;
    const MsdProfileLib *lib;
    if (!out) {
        return;
    }
    lib = msd_profile_lib(profile);
    if (!lib) {
        return;
    }
    fprintf(out, "profile=%s\n", lib->name);
    fprintf(out, "tagline=%s\n", lib->tagline);
    fprintf(out, "\n== keys ==\n");
    for (i = 0; i < lib->key_count; ++i) {
        fprintf(out, "%s.%s\n", msd_section_kind_name(lib->keys[i].section), lib->keys[i].key);
    }
    fprintf(out, "\n== bgctrl-types ==\n");
    for (i = 0; i < lib->bgctrl_count; ++i) {
        fprintf(out, "%s\n", lib->bgctrl_types[i]);
    }
    fprintf(out, "\n== stubs ==\n");
    if (lib->stub_count <= 0) {
        fprintf(out, "(none)\n");
    } else {
        for (i = 0; i < lib->stub_count; ++i) {
            fprintf(out, "%s.%s  # %s\n", msd_section_kind_name(lib->stubs[i].section), lib->stubs[i].key, lib->stubs[i].description);
        }
    }
}
