#include "msd_lexer.h"

static int msd_is_ident_delim(int ch)
{
    return ch == '\0' || ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' || ch == '[' || ch == ']' || ch == '=' || ch == ',' || ch == ';';
}

static int msd_token_has_non_numeric_suffix(const char *src, int pos, int size)
{
    int i;
    int ch;

    i = pos;
    while (i < size && !msd_is_ident_delim((unsigned char) src[i])) {
        ch = (unsigned char) src[i];
        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || ch == '_' || ch == '/' || ch == '\\') {
            return 1;
        }
        ++i;
    }
    return 0;
}

static int msd_is_number_start(const char *src, int pos, int size)
{
    int ch;
    int next;
    if (pos >= size) {
        return 0;
    }
    if (msd_token_has_non_numeric_suffix(src, pos, size)) {
        return 0;
    }
    ch = (unsigned char) src[pos];
    next = pos + 1 < size ? (unsigned char) src[pos + 1] : '\0';
    if (ch >= '0' && ch <= '9') {
        return 1;
    }
    if ((ch == '+' || ch == '-') && ((next >= '0' && next <= '9') || next == '.')) {
        return 1;
    }
    if (ch == '.' && next >= '0' && next <= '9') {
        return 1;
    }
    return 0;
}

static int msd_scan_number(const MsdSource *src, int *pos, MsdToken *tok)
{
    int start;
    int i;
    int seen_dot;
    int seen_digit;
    int ok;
    int is_fixed;
    int ch;
    int next;

    start = *pos;
    i = *pos;
    seen_dot = 0;
    seen_digit = 0;

    if (src->data[i] == '+' || src->data[i] == '-') {
        ++i;
    }

    while (i < src->size) {
        ch = (unsigned char) src->data[i];
        next = i + 1 < src->size ? (unsigned char) src->data[i + 1] : '\0';
        if (ch >= '0' && ch <= '9') {
            seen_digit = 1;
            ++i;
        } else if (ch == '.' && !seen_dot && next >= '0' && next <= '9') {
            seen_dot = 1;
            ++i;
        } else {
            break;
        }
    }

    if (!seen_digit) {
        tok->type = MSD_TOK_ERROR;
        return 0;
    }

    tok->type = MSD_TOK_NUMBER;
    tok->offset = start;
    tok->length = i - start;
    tok->number = msd_fixed_from_span(src->data, tok->offset, tok->length, &ok, &is_fixed);
    tok->is_fixed = is_fixed;
    if (!ok) {
        tok->type = MSD_TOK_ERROR;
    }
    *pos = i;
    return tok->type != MSD_TOK_ERROR;
}

static void msd_emit_simple(MsdArena *arena, MsdTokenType type, int line, int col, int offset)
{
    MsdToken tok;
    tok.type = type;
    tok.line = line;
    tok.col = col;
    tok.offset = offset;
    tok.length = 1;
    tok.number = 0;
    tok.is_fixed = 0;
    msd_arena_add_token(arena, &tok);
}

int msd_lex_source(const MsdSource *src, MsdArena *arena)
{
    int pos;
    int line;
    int col;
    int start;
    int ch;
    MsdToken tok;

    if (!src || !arena) {
        return 0;
    }

    pos = 0;
    line = 1;
    col = 1;

    while (pos < src->size) {
        ch = (unsigned char) src->data[pos];

        if (ch == ' ' || ch == '\t' || ch == '\f') {
            ++pos;
            ++col;
            continue;
        }
        if (ch == '\r') {
            ++pos;
            continue;
        }
        if (ch == ';') {
            while (pos < src->size && src->data[pos] != '\n') {
                ++pos;
                ++col;
            }
            continue;
        }
        if (ch == '\n') {
            msd_emit_simple(arena, MSD_TOK_NEWLINE, line, col, pos);
            ++pos;
            ++line;
            col = 1;
            continue;
        }
        if (ch == '[') {
            msd_emit_simple(arena, MSD_TOK_LBRACKET, line, col, pos);
            ++pos;
            ++col;
            continue;
        }
        if (ch == ']') {
            msd_emit_simple(arena, MSD_TOK_RBRACKET, line, col, pos);
            ++pos;
            ++col;
            continue;
        }
        if (ch == '=') {
            msd_emit_simple(arena, MSD_TOK_EQUALS, line, col, pos);
            ++pos;
            ++col;
            continue;
        }
        if (ch == ',') {
            msd_emit_simple(arena, MSD_TOK_COMMA, line, col, pos);
            ++pos;
            ++col;
            continue;
        }
        if (ch == '"') {
            start = pos + 1;
            ++pos;
            ++col;
            while (pos < src->size) {
                ch = (unsigned char) src->data[pos];
                if (ch == '\\' && pos + 1 < src->size) {
                    pos += 2;
                    col += 2;
                    continue;
                }
                if (ch == '"') {
                    break;
                }
                if (ch == '\n') {
                    break;
                }
                ++pos;
                ++col;
            }
            tok.type = MSD_TOK_STRING;
            tok.line = line;
            tok.col = col;
            tok.offset = start;
            tok.length = pos - start;
            tok.number = 0;
            tok.is_fixed = 0;
            msd_arena_add_token(arena, &tok);
            if (pos < src->size && src->data[pos] == '"') {
                ++pos;
                ++col;
            }
            continue;
        }
        if (msd_is_number_start(src->data, pos, src->size)) {
            tok.line = line;
            tok.col = col;
            if (!msd_scan_number(src, &pos, &tok)) {
                msd_arena_add_error(arena, tok.line, tok.col, "invalid number token");
                return 0;
            }
            msd_arena_add_token(arena, &tok);
            col += tok.length;
            continue;
        }

        start = pos;
        while (pos < src->size && !msd_is_ident_delim((unsigned char) src->data[pos])) {
            ++pos;
        }
        tok.type = MSD_TOK_IDENT;
        tok.line = line;
        tok.col = col;
        tok.offset = start;
        tok.length = pos - start;
        tok.number = 0;
        tok.is_fixed = 0;
        msd_arena_add_token(arena, &tok);
        col += tok.length;
    }

    tok.type = MSD_TOK_EOF;
    tok.line = line;
    tok.col = col;
    tok.offset = src->size;
    tok.length = 0;
    tok.number = 0;
    tok.is_fixed = 0;
    msd_arena_add_token(arena, &tok);
    return 1;
}

void msd_lexer_dump(const MsdSource *src, const MsdArena *arena, FILE *out)
{
    int i;
    char buf[128];
    if (!src || !arena || !out) {
        return;
    }
    for (i = 0; i < arena->token_count; ++i) {
        msd_token_text(src, &arena->tokens[i], buf, sizeof(buf));
        fprintf(out, "%4d  %-10s  line=%d col=%d  text='%s'", i, msd_token_type_name(arena->tokens[i].type), arena->tokens[i].line, arena->tokens[i].col, buf);
        if (arena->tokens[i].type == MSD_TOK_NUMBER) {
            char nbuf[64];
            msd_fixed_to_string(arena->tokens[i].number, nbuf, sizeof(nbuf));
            fprintf(out, " value=%s", nbuf);
        }
        fprintf(out, "\n");
    }
}
