#include "msd_canon.h"
#include "msd_profile.h"

#define MSD_CANON_HASH_INIT 2166136261UL
#define MSD_CANON_HASH_MULT 16777619UL

typedef struct MsdSSAKeyState {
    MsdBuiltinId word_id;
    int key_atom;
    int version;
    int last_ssa_index;
    int is_unique;
    unsigned long last_value_hash;
    int last_value_id;
} MsdSSAKeyState;

typedef struct MsdCanonUniqueRef {
    int item_ordinal;
    MsdBuiltinId word_id;
    int key_atom;
} MsdCanonUniqueRef;

static unsigned long msd_hash_mix_byte(unsigned long hash, unsigned char byte)
{
    hash ^= (unsigned long) byte;
    hash *= MSD_CANON_HASH_MULT;
    return hash;
}

static unsigned long msd_hash_mix_int(unsigned long hash, int value)
{
    unsigned int u;
    int i;
    u = (unsigned int) value;
    for (i = 0; i < (int) sizeof(unsigned int); ++i) {
        hash = msd_hash_mix_byte(hash, (unsigned char) (u & 0xFFu));
        u >>= 8;
    }
    return hash;
}

static unsigned long msd_hash_mix_ulong(unsigned long hash, unsigned long value)
{
    int i;
    for (i = 0; i < (int) sizeof(unsigned long); ++i) {
        hash = msd_hash_mix_byte(hash, (unsigned char) (value & 0xFFul));
        value >>= 8;
    }
    return hash;
}

static unsigned long msd_hash_mix_text(unsigned long hash, const char *text, int lowercase)
{
    int i;
    unsigned char ch;
    if (!text) return hash;
    for (i = 0; text[i] != '\0'; ++i) {
        ch = (unsigned char) text[i];
        if (lowercase) {
            ch = (unsigned char) msd_ascii_tolower(ch);
        }
        hash = msd_hash_mix_byte(hash, ch);
    }
    return msd_hash_mix_byte(hash, 0u);
}

static void msd_atom_text_local(const MsdSource *src, const MsdAtom *atom, char *buf, int cap)
{
    msd_atom_to_text(src, atom, buf, cap);
}

static unsigned long msd_hash_mix_atom(unsigned long hash, const MsdSource *src, const MsdAtom *atom)
{
    char buf[MSD_MAX_TEXT];
    int i;
    if (!atom) {
        return msd_hash_mix_int(hash, -1);
    }
    hash = msd_hash_mix_int(hash, atom->type == MSD_ATOM_NUMBER ? (int) MSD_ATOM_NUMBER : (int) MSD_ATOM_IDENT);
    if (atom->type == MSD_ATOM_NUMBER) {
        hash = msd_hash_mix_ulong(hash, (unsigned long) atom->number);
        return hash;
    }
    msd_atom_text_local(src, atom, buf, sizeof(buf));
    for (i = 0; buf[i] != '\0'; ++i) {
        if (atom->type == MSD_ATOM_IDENT) {
            buf[i] = (char) msd_ascii_tolower((unsigned char) buf[i]);
        }
    }
    return msd_hash_mix_text(hash, buf, 0);
}

static unsigned long msd_hash_value_tuple(const MsdSource *src, const MsdArena *arena, int value_start, int value_count)
{
    unsigned long hash;
    int i;
    hash = MSD_CANON_HASH_INIT;
    hash = msd_hash_mix_int(hash, value_count);
    for (i = 0; i < value_count; ++i) {
        hash = msd_hash_mix_atom(hash, src, &arena->atoms[value_start + i]);
    }
    return hash;
}

static int msd_key_equal(const MsdSource *src, const MsdAtom *a, const MsdAtom *b)
{
    int i;
    if (!src || !a || !b) return 0;
    if (a->type == MSD_ATOM_NUMBER || b->type == MSD_ATOM_NUMBER) return 0;
    if (a->length != b->length) return 0;
    for (i = 0; i < a->length; ++i) {
        if (msd_ascii_tolower((unsigned char) src->data[a->offset + i]) != msd_ascii_tolower((unsigned char) src->data[b->offset + i])) {
            return 0;
        }
    }
    return 1;
}

static int msd_key_equal_atoms(const MsdSource *src, const MsdArena *arena, int atom_a, int atom_b)
{
    if (!arena || atom_a < 0 || atom_b < 0 || atom_a >= arena->atom_count || atom_b >= arena->atom_count) {
        return 0;
    }
    return msd_key_equal(src, &arena->atoms[atom_a], &arena->atoms[atom_b]);
}

static int msd_key_state_match(const MsdSource *src, const MsdArena *arena, const MsdSSAKeyState *state, MsdBuiltinId word_id, int key_atom)
{
    if (!state) return 0;
    if (state->word_id != word_id) return 0;
    if (word_id != MSD_BUILTIN_CORE_RAW_ASSIGN) return 1;
    return msd_key_equal_atoms(src, arena, state->key_atom, key_atom);
}

static int msd_find_key_state(const MsdSource *src, const MsdArena *arena, MsdSSAKeyState *states, int state_count, MsdBuiltinId word_id, int key_atom)
{
    int i;
    for (i = 0; i < state_count; ++i) {
        if (msd_key_state_match(src, arena, &states[i], word_id, key_atom)) {
            return i;
        }
    }
    return -1;
}

static int msd_unique_ref_cmp(const MsdSource *src, const MsdArena *arena, const MsdCanonUniqueRef *a, const MsdCanonUniqueRef *b)
{
    char ta[MSD_MAX_TEXT];
    char tb[MSD_MAX_TEXT];
    int i;
    if (a->word_id != b->word_id) {
        return (int) a->word_id - (int) b->word_id;
    }
    if (!arena) return 0;
    if (a->key_atom >= 0) {
        msd_atom_text_local(src, &arena->atoms[a->key_atom], ta, sizeof(ta));
    } else {
        ta[0] = '\0';
    }
    if (b->key_atom >= 0) {
        msd_atom_text_local(src, &arena->atoms[b->key_atom], tb, sizeof(tb));
    } else {
        tb[0] = '\0';
    }
    i = 0;
    while (ta[i] != '\0' && tb[i] != '\0') {
        int ca;
        int cb;
        ca = msd_ascii_tolower((unsigned char) ta[i]);
        cb = msd_ascii_tolower((unsigned char) tb[i]);
        if (ca != cb) return ca - cb;
        ++i;
    }
    return ((unsigned char) ta[i]) - ((unsigned char) tb[i]);
}

static unsigned long msd_hash_plan_section(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec, const MsdCanonPlanInstr *plans, int plan_start, int plan_count)
{
    unsigned long hash;
    int i;
    int pi;
    const MsdAstItem *item;
    hash = MSD_CANON_HASH_INIT;
    hash = msd_hash_mix_int(hash, (int) sec->kind);
    for (i = 0; i < sec->header_count; ++i) {
        hash = msd_hash_mix_atom(hash, src, &arena->atoms[sec->header_start + i]);
    }
    for (pi = 0; pi < plan_count; ++pi) {
        const MsdCanonPlanInstr *plan;
        plan = &plans[plan_start + pi];
        item = &arena->items[sec->first_item + plan->item_ordinal];
        hash = msd_hash_mix_int(hash, (int) plan->item_kind);
        hash = msd_hash_mix_int(hash, (int) plan->word_id);
        if (item->kind == MSD_ITEM_ASSIGN) {
            hash = msd_hash_mix_atom(hash, src, &arena->atoms[item->key_atom]);
        }
        for (i = 0; i < item->value_count; ++i) {
            hash = msd_hash_mix_atom(hash, src, &arena->atoms[item->value_start + i]);
        }
    }
    return hash;
}

void msd_canon_stats_init(MsdCanonStats *stats)
{
    if (!stats) return;
    memset(stats, 0, sizeof(*stats));
}

void msd_canon_section_header_text(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec, char *buf, int cap)
{
    int i;
    int len;
    char atom_buf[MSD_MAX_TEXT];
    if (!buf || cap <= 0) return;
    buf[0] = '\0';
    if (!src || !arena || !sec) return;
    len = 0;
    for (i = 0; i < sec->header_count; ++i) {
        msd_atom_text_local(src, &arena->atoms[sec->header_start + i], atom_buf, sizeof(atom_buf));
        if (i > 0) {
            if (!msd_append_char(buf, cap, &len, ' ')) break;
        }
        if (!msd_append_cstr(buf, cap, &len, atom_buf)) break;
    }
}

unsigned long msd_canon_section_plan_hash(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec)
{
    unsigned long hash;
    int ii;
    int vi;
    const MsdAstItem *item;
    hash = MSD_CANON_HASH_INIT;
    hash = msd_hash_mix_int(hash, (int) sec->kind);
    for (ii = 0; ii < sec->header_count; ++ii) {
        hash = msd_hash_mix_atom(hash, src, &arena->atoms[sec->header_start + ii]);
    }
    for (ii = 0; ii < sec->item_count; ++ii) {
        item = &arena->items[sec->first_item + ii];
        hash = msd_hash_mix_int(hash, (int) item->kind);
        if (item->kind == MSD_ITEM_ASSIGN) {
            hash = msd_hash_mix_atom(hash, src, &arena->atoms[item->key_atom]);
        }
        hash = msd_hash_mix_int(hash, item->value_count);
        for (vi = 0; vi < item->value_count; ++vi) {
            hash = msd_hash_mix_atom(hash, src, &arena->atoms[item->value_start + vi]);
        }
    }
    return hash;
}

int msd_build_ssa(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *raw_ir, int raw_ir_count, MsdSSAInstr *out_ssa, int out_cap, MsdCanonStats *stats)
{
    MsdSSAKeyState states[MSD_MAX_ITEMS];
    int state_count;
    int out_count;
    int i;
    int item_ordinal;
    int next_value_id;

    if (!src || !arena || !raw_ir || !out_ssa || out_cap <= 0) return 0;
    state_count = 0;
    out_count = 0;
    item_ordinal = -1;
    next_value_id = 1;
    if (stats) stats->raw_ir_in = raw_ir_count;

    for (i = 0; i < raw_ir_count; ++i) {
        MsdSSAInstr instr;
        const MsdIRInstr *ir;
        ir = &raw_ir[i];
        memset(&instr, 0, sizeof(instr));
        instr.op = ir->op;
        instr.section_kind = ir->section_kind;
        instr.key_atom = ir->key_atom;
        instr.value_start = ir->value_start;
        instr.value_count = ir->value_count;
        instr.line = ir->line;
        instr.col = ir->col;
        instr.word_id = MSD_BUILTIN_NONE;
        instr.item_ordinal = item_ordinal;
        instr.is_live = 1;
        instr.value_id = 0;
        instr.is_same_value = 0;
        instr.value_hash = 0UL;
        if (ir->op == MSD_IR_BEGIN_SECTION) {
            state_count = 0;
            item_ordinal = 0;
            next_value_id = 1;
            instr.word_id = msd_mugen_resolve_begin(ir->section_kind);
            instr.item_ordinal = -1;
        } else if (ir->op == MSD_IR_SET) {
            int key_idx;
            int unique;
            unsigned long value_hash;
            instr.word_id = msd_mugen_resolve_key(ir->section_kind, src, &arena->atoms[ir->key_atom]);
            unique = msd_semantic_key_is_unique(ir->section_kind, src, &arena->atoms[ir->key_atom]);
            value_hash = msd_hash_value_tuple(src, arena, ir->value_start, ir->value_count);
            key_idx = msd_find_key_state(src, arena, states, state_count, instr.word_id, ir->key_atom);
            if (key_idx < 0) {
                if (state_count >= MSD_MAX_ITEMS) return 0;
                key_idx = state_count++;
                states[key_idx].word_id = instr.word_id;
                states[key_idx].key_atom = ir->key_atom;
                states[key_idx].version = 0;
                states[key_idx].last_ssa_index = -1;
                states[key_idx].is_unique = unique;
                states[key_idx].last_value_hash = 0UL;
                states[key_idx].last_value_id = 0;
            }
            states[key_idx].version += 1;
            instr.version = states[key_idx].version;
            instr.item_ordinal = item_ordinal;
            instr.value_hash = value_hash;
            if (states[key_idx].last_value_id > 0 && states[key_idx].last_value_hash == value_hash) {
                instr.value_id = states[key_idx].last_value_id;
                instr.is_same_value = 1;
                if (stats) stats->ssa_same_value_redefs += 1;
            } else {
                instr.value_id = next_value_id++;
            }
            states[key_idx].last_value_hash = value_hash;
            states[key_idx].last_value_id = instr.value_id;
            if (unique && states[key_idx].last_ssa_index >= 0) {
                out_ssa[states[key_idx].last_ssa_index].is_live = 0;
            }
            states[key_idx].last_ssa_index = out_count;
            if (stats) stats->ssa_defs += 1;
            item_ordinal += 1;
        } else if (ir->op == MSD_IR_ROW) {
            instr.word_id = msd_mugen_resolve_row(ir->section_kind);
            instr.item_ordinal = item_ordinal;
            instr.value_hash = msd_hash_value_tuple(src, arena, ir->value_start, ir->value_count);
            instr.value_id = next_value_id++;
            item_ordinal += 1;
        } else {
            instr.item_ordinal = -1;
            item_ordinal = -1;
        }
        if (out_count >= out_cap) return 0;
        out_ssa[out_count++] = instr;
    }

    if (stats) {
        int live_defs;
        live_defs = 0;
        for (i = 0; i < out_count; ++i) {
            if (out_ssa[i].op == MSD_IR_SET && out_ssa[i].is_live) {
                live_defs += 1;
            }
        }
        stats->ssa_live_defs = live_defs;
        stats->ssa_value_classes = next_value_id - 1;
    }
    return out_count;
}

int msd_build_section_plan(const MsdSource *src, const MsdArena *arena, int section_index, MsdCanonSection *out_section, MsdCanonPlanInstr *plan_storage, int *plan_count, int plan_cap, MsdCanonStats *stats)
{
    const MsdAstSection *sec;
    char dead_unique[MSD_MAX_ITEMS];
    int seen_unique[MSD_MAX_ITEMS];
    MsdCanonUniqueRef uniques[MSD_MAX_ITEMS];
    int others[MSD_MAX_ITEMS];
    int seen_count;
    int unique_count;
    int other_count;
    int i;
    int j;

    if (!src || !arena || !out_section || !plan_storage || !plan_count) return 0;
    if (section_index < 0 || section_index >= arena->section_count) return 0;

    sec = &arena->sections[section_index];
    memset(dead_unique, 0, sizeof(dead_unique));
    seen_count = 0;
    unique_count = 0;
    other_count = 0;

    for (i = sec->item_count - 1; i >= 0; --i) {
        const MsdAstItem *item;
        item = &arena->items[sec->first_item + i];
        if (item->kind == MSD_ITEM_ASSIGN && item->key_atom >= 0 && msd_semantic_key_is_unique(sec->kind, src, &arena->atoms[item->key_atom])) {
            int found;
            found = 0;
            for (j = 0; j < seen_count; ++j) {
                const MsdAstItem *seen_item;
                seen_item = &arena->items[sec->first_item + seen_unique[j]];
                if (msd_key_equal_atoms(src, arena, item->key_atom, seen_item->key_atom)) {
                    found = 1;
                    break;
                }
            }
            if (found) {
                dead_unique[i] = 1;
                if (stats) stats->canon_duplicate_elided += 1;
            } else {
                if (seen_count >= MSD_MAX_ITEMS || unique_count >= MSD_MAX_ITEMS) return 0;
                seen_unique[seen_count++] = i;
                uniques[unique_count].item_ordinal = i;
                uniques[unique_count].word_id = msd_mugen_resolve_key(sec->kind, src, &arena->atoms[item->key_atom]);
                uniques[unique_count].key_atom = item->key_atom;
                unique_count += 1;
            }
        }
    }

    for (i = 1; i < unique_count; ++i) {
        MsdCanonUniqueRef key;
        key = uniques[i];
        j = i - 1;
        while (j >= 0 && msd_unique_ref_cmp(src, arena, &uniques[j], &key) > 0) {
            uniques[j + 1] = uniques[j];
            --j;
        }
        uniques[j + 1] = key;
    }

    for (i = 0; i < sec->item_count; ++i) {
        const MsdAstItem *item;
        item = &arena->items[sec->first_item + i];
        if (item->kind == MSD_ITEM_ASSIGN && item->key_atom >= 0 && msd_semantic_key_is_unique(sec->kind, src, &arena->atoms[item->key_atom])) {
            if (!dead_unique[i]) {
            }
        } else {
            if (other_count >= MSD_MAX_ITEMS) return 0;
            others[other_count++] = i;
        }
    }

    memset(out_section, 0, sizeof(*out_section));
    out_section->kind = sec->kind;
    out_section->src_section_index = section_index;
    out_section->plan_start = *plan_count;
    out_section->plan_count = 0;
    out_section->plan_hash = msd_canon_section_plan_hash(src, arena, sec);
    msd_canon_section_header_text(src, arena, sec, out_section->header_text, sizeof(out_section->header_text));

    for (i = 0; i < unique_count; ++i) {
        const MsdAstItem *item;
        MsdCanonPlanInstr plan;
        item = &arena->items[sec->first_item + uniques[i].item_ordinal];
        if (*plan_count >= plan_cap) return 0;
        plan.item_kind = item->kind;
        plan.item_ordinal = uniques[i].item_ordinal;
        plan.word_id = uniques[i].word_id;
        plan_storage[*plan_count] = plan;
        *plan_count += 1;
        out_section->plan_count += 1;
    }
    for (i = 0; i < other_count; ++i) {
        const MsdAstItem *item;
        MsdCanonPlanInstr plan;
        item = &arena->items[sec->first_item + others[i]];
        if (*plan_count >= plan_cap) return 0;
        plan.item_kind = item->kind;
        plan.item_ordinal = others[i];
        plan.word_id = item->kind == MSD_ITEM_ASSIGN ? msd_mugen_resolve_key(sec->kind, src, &arena->atoms[item->key_atom]) : msd_mugen_resolve_row(sec->kind);
        plan_storage[*plan_count] = plan;
        *plan_count += 1;
        out_section->plan_count += 1;
    }

    if (stats) {
        stats->canon_sections += 1;
        stats->canon_unique_sorted += unique_count;
    }
    return 1;
}

int msd_emit_ir_from_plans(const MsdSource *src, const MsdArena *arena, MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, MsdIRInstr *out_ir, int out_cap, int *out_count)
{
    int si;
    int count;
    (void) src;
    if (!arena || !sections || !plans || !out_ir || !out_count) return 0;
    count = 0;
    for (si = 0; si < section_count; ++si) {
        const MsdAstSection *sec;
        MsdIRInstr instr;
        int pi;
        sec = &arena->sections[sections[si].src_section_index];
        sections[si].ir_start = count;
        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_IR_BEGIN_SECTION;
        instr.profile_tag = msd_profile_get_active();
        instr.section_kind = sec->kind;
        instr.header_start = sec->header_start;
        instr.header_count = sec->header_count;
        instr.line = sec->line;
        instr.col = sec->col;
        if (count >= out_cap) return 0;
        out_ir[count++] = instr;
        for (pi = 0; pi < sections[si].plan_count; ++pi) {
            const MsdCanonPlanInstr *plan;
            const MsdAstItem *item;
            plan = &plans[sections[si].plan_start + pi];
            item = &arena->items[sec->first_item + plan->item_ordinal];
            memset(&instr, 0, sizeof(instr));
            instr.op = item->kind == MSD_ITEM_ASSIGN ? MSD_IR_SET : MSD_IR_ROW;
            instr.profile_tag = msd_profile_get_active();
            instr.section_kind = sec->kind;
            instr.key_atom = item->key_atom;
            instr.value_start = item->value_start;
            instr.value_count = item->value_count;
            instr.line = item->line;
            instr.col = item->col;
            if (count >= out_cap) return 0;
            out_ir[count++] = instr;
        }
        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_IR_END_SECTION;
        instr.profile_tag = msd_profile_get_active();
        instr.section_kind = sec->kind;
        instr.line = sec->line;
        instr.col = sec->col;
        if (count >= out_cap) return 0;
        out_ir[count++] = instr;
        sections[si].ir_count = count - sections[si].ir_start;
        sections[si].canon_hash = msd_hash_plan_section(src, arena, sec, plans, sections[si].plan_start, sections[si].plan_count);
    }
    *out_count = count;
    return 1;
}

static int msd_canon_bc_add_atom(MsdBCAtom *storage, int *count, int cap, const MsdAtom *src_atom)
{
    if (*count >= cap) return -1;
    storage[*count].type = src_atom->type;
    storage[*count].offset = src_atom->offset;
    storage[*count].length = src_atom->length;
    storage[*count].number = src_atom->number;
    storage[*count].is_fixed = src_atom->is_fixed;
    storage[*count].line = src_atom->line;
    storage[*count].col = src_atom->col;
    return (*count)++;
}

int msd_emit_bc_from_plans(const MsdSource *src, const MsdArena *arena, MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, MsdBCInstr *out_bc, int out_bc_cap, MsdBCAtom *out_atoms, int out_atom_cap, int *out_bc_count, int *out_atom_count)
{
    int si;
    int bc_count;
    int atom_count;
    (void) src;
    if (!arena || !sections || !plans || !out_bc || !out_atoms || !out_bc_count || !out_atom_count) return 0;
    bc_count = 0;
    atom_count = 0;
    for (si = 0; si < section_count; ++si) {
        const MsdAstSection *sec;
        MsdBCInstr instr;
        int pi;
        int j;
        sec = &arena->sections[sections[si].src_section_index];
        sections[si].bc_start = bc_count;
        sections[si].bc_atom_start = atom_count;

        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_BC_BEGIN_SECTION;
        instr.profile_tag = msd_profile_get_active();
        instr.section_kind = sec->kind;
        instr.word_id = msd_mugen_resolve_begin(sec->kind);
        instr.name_atom = -1;
        instr.const_start = atom_count;
        instr.const_count = 0;
        instr.line = sec->line;
        instr.col = sec->col;
        for (j = 0; j < sec->header_count; ++j) {
            if (msd_canon_bc_add_atom(out_atoms, &atom_count, out_atom_cap, &arena->atoms[sec->header_start + j]) < 0) return 0;
            instr.const_count += 1;
        }
        if (bc_count >= out_bc_cap) return 0;
        out_bc[bc_count++] = instr;

        for (pi = 0; pi < sections[si].plan_count; ++pi) {
            const MsdCanonPlanInstr *plan;
            const MsdAstItem *item;
            plan = &plans[sections[si].plan_start + pi];
            item = &arena->items[sec->first_item + plan->item_ordinal];
            memset(&instr, 0, sizeof(instr));
            instr.op = MSD_BC_CALL;
            instr.profile_tag = msd_profile_get_active();
            instr.section_kind = sec->kind;
            instr.word_id = plan->word_id;
            instr.name_atom = -1;
            instr.const_count = 0;
            instr.line = item->line;
            instr.col = item->col;
            if (item->kind == MSD_ITEM_ASSIGN) {
                instr.name_atom = msd_canon_bc_add_atom(out_atoms, &atom_count, out_atom_cap, &arena->atoms[item->key_atom]);
                if (instr.name_atom < 0) return 0;
            }
            instr.const_start = atom_count;
            for (j = 0; j < item->value_count; ++j) {
                if (msd_canon_bc_add_atom(out_atoms, &atom_count, out_atom_cap, &arena->atoms[item->value_start + j]) < 0) return 0;
                instr.const_count += 1;
            }
            if (bc_count >= out_bc_cap) return 0;
            out_bc[bc_count++] = instr;
        }

        memset(&instr, 0, sizeof(instr));
        instr.op = MSD_BC_END_SECTION;
        instr.profile_tag = msd_profile_get_active();
        instr.section_kind = sec->kind;
        instr.word_id = MSD_BUILTIN_NONE;
        instr.name_atom = -1;
        instr.const_start = -1;
        instr.const_count = 0;
        instr.line = sec->line;
        instr.col = sec->col;
        if (bc_count >= out_bc_cap) return 0;
        out_bc[bc_count++] = instr;

        sections[si].bc_count = bc_count - sections[si].bc_start;
        sections[si].bc_atom_count = atom_count - sections[si].bc_atom_start;
    }
    *out_bc_count = bc_count;
    *out_atom_count = atom_count;
    return 1;
}

int msd_canonicalize_ir(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *raw_ir, int raw_ir_count, MsdSSAInstr *ssa_storage, int ssa_cap, MsdCanonSection *sections, int sec_cap, MsdCanonPlanInstr *plans, int plan_cap, MsdIRInstr *out_ir, int out_ir_cap, int *out_ir_count, MsdCanonStats *stats)
{
    int sec_count;
    int plan_count;
    int si;
    int ssa_count;
    if (!src || !arena || !sections || !plans || !out_ir || !out_ir_count) return 0;
    if (sec_cap < arena->section_count) return 0;
    sec_count = 0;
    plan_count = 0;
    if (stats) msd_canon_stats_init(stats);
    if (ssa_storage && ssa_cap > 0 && raw_ir && raw_ir_count > 0) {
        ssa_count = msd_build_ssa(src, arena, raw_ir, raw_ir_count, ssa_storage, ssa_cap, stats);
        if (ssa_count <= 0) return 0;
    } else if (stats) {
        stats->raw_ir_in = raw_ir_count;
    }
    for (si = 0; si < arena->section_count; ++si) {
        if (sec_count >= sec_cap) return 0;
        if (!msd_build_section_plan(src, arena, si, &sections[sec_count], plans, &plan_count, plan_cap, stats)) {
            return 0;
        }
        sec_count += 1;
    }
    if (!msd_emit_ir_from_plans(src, arena, sections, sec_count, plans, out_ir, out_ir_cap, out_ir_count)) {
        return 0;
    }
    if (stats) stats->canon_ir_out = *out_ir_count;
    return sec_count;
}

void msd_ssa_dump(const MsdSource *src, const MsdArena *arena, const MsdSSAInstr *ssa, int ssa_count, FILE *out)
{
    int i;
    char buf[MSD_MAX_TEXT];
    if (!src || !arena || !ssa || !out) return;
    for (i = 0; i < ssa_count; ++i) {
        const MsdSSAInstr *instr;
        instr = &ssa[i];
        fprintf(out, "%4d  ", i);
        if (instr->op == MSD_IR_BEGIN_SECTION) {
            fprintf(out, "BEGIN %-12s\n", msd_section_kind_name(instr->section_kind));
        } else if (instr->op == MSD_IR_SET) {
            msd_atom_text_local(src, &arena->atoms[instr->key_atom], buf, sizeof(buf));
            fprintf(out, "SET   %-12s %s#%d %s\n", msd_section_kind_name(instr->section_kind), buf, instr->version, instr->is_live ? "[live]" : "[dead]");
        } else if (instr->op == MSD_IR_ROW) {
            fprintf(out, "ROW   %-12s row@%d\n", msd_section_kind_name(instr->section_kind), instr->item_ordinal);
        } else {
            fprintf(out, "END   %-12s\n", msd_section_kind_name(instr->section_kind));
        }
    }
}

void msd_canon_dump_sections(const MsdCanonSection *sections, int section_count, FILE *out)
{
    int i;
    if (!sections || !out) return;
    for (i = 0; i < section_count; ++i) {
        fprintf(out, "section[%d] kind=%s header=%s plan_hash=%lu canon_hash=%lu plans=%d ir=%d bc=%d\n",
            i,
            msd_section_kind_name(sections[i].kind),
            sections[i].header_text,
            sections[i].plan_hash,
            sections[i].canon_hash,
            sections[i].plan_count,
            sections[i].ir_count,
            sections[i].bc_count);
    }
}

void msd_canon_dump_summary(const MsdCanonStats *stats, FILE *out)
{
    if (!stats || !out) return;
    fprintf(out, "RAW IR: %d\n", stats->raw_ir_in);
    fprintf(out, "SSA defs: %d (live: %d)\n", stats->ssa_defs, stats->ssa_live_defs);
    fprintf(out, "Canonical sections: %d\n", stats->canon_sections);
    fprintf(out, "Canonical IR: %d\n", stats->canon_ir_out);
    fprintf(out, "Unique defs sorted: %d\n", stats->canon_unique_sorted);
    fprintf(out, "Duplicate unique defs elided: %d\n", stats->canon_duplicate_elided);
}
