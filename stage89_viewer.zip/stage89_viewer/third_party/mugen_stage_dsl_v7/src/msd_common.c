#include "msd_common.h"

int msd_source_load(MsdSource *src, const char *path)
{
    FILE *fp;
    long size;
    size_t nread;
    int i;

    if (!src || !path) {
        return 0;
    }

    fp = fopen(path, "rb");
    if (!fp) {
        return 0;
    }

    if (fseek(fp, 0L, SEEK_END) != 0) {
        fclose(fp);
        return 0;
    }

    size = ftell(fp);
    if (size < 0 || size > MSD_MAX_SOURCE_BYTES) {
        fclose(fp);
        return 0;
    }

    if (fseek(fp, 0L, SEEK_SET) != 0) {
        fclose(fp);
        return 0;
    }

    nread = fread(src->data, 1u, (size_t) size, fp);
    fclose(fp);
    if ((long) nread != size) {
        return 0;
    }

    src->size = (int) size;
    src->data[src->size] = '\0';

    for (i = 0; path[i] != '\0' && i < (int) sizeof(src->path) - 1; ++i) {
        src->path[i] = path[i];
    }
    src->path[i] = '\0';
    return 1;
}

int msd_ascii_tolower(int ch)
{
    if (ch >= 'A' && ch <= 'Z') {
        return ch - 'A' + 'a';
    }
    return ch;
}

int msd_span_ieq(const char *src, int offset, int length, const char *text)
{
    int i;
    if (!src || !text || length < 0) {
        return 0;
    }
    for (i = 0; i < length; ++i) {
        if (text[i] == '\0') {
            return 0;
        }
        if (msd_ascii_tolower((unsigned char) src[offset + i]) != msd_ascii_tolower((unsigned char) text[i])) {
            return 0;
        }
    }
    return text[length] == '\0';
}

int msd_span_eq(const char *src, int offset, int length, const char *text)
{
    int i;
    if (!src || !text || length < 0) {
        return 0;
    }
    for (i = 0; i < length; ++i) {
        if (text[i] == '\0') {
            return 0;
        }
        if (src[offset + i] != text[i]) {
            return 0;
        }
    }
    return text[length] == '\0';
}

int msd_copy_span(char *dst, int cap, const char *src, int offset, int length)
{
    int i;
    int n;
    if (!dst || cap <= 0) {
        return 0;
    }
    if (!src || length < 0) {
        dst[0] = '\0';
        return 0;
    }
    n = length;
    if (n > cap - 1) {
        n = cap - 1;
    }
    for (i = 0; i < n; ++i) {
        dst[i] = src[offset + i];
    }
    dst[n] = '\0';
    return n;
}

int msd_copy_quoted_span_unescaped(char *dst, int cap, const char *src, int offset, int length)
{
    int i;
    int d;
    int ch;
    if (!dst || cap <= 0) {
        return 0;
    }
    dst[0] = '\0';
    if (!src || length < 0) {
        return 0;
    }
    d = 0;
    i = 0;
    while (i < length && d < cap - 1) {
        ch = (unsigned char) src[offset + i];
        if (ch == '\\' && i + 1 < length) {
            ++i;
            ch = (unsigned char) src[offset + i];
            if (ch == 'n') ch = '\n';
            else if (ch == 'r') ch = '\r';
            else if (ch == 't') ch = '\t';
            else if (ch == '"') ch = '"';
            else if (ch == '\\') ch = '\\';
        }
        dst[d++] = (char) ch;
        ++i;
    }
    dst[d] = '\0';
    return d;
}

int msd_append_char(char *dst, int cap, int *len, char ch)
{
    if (!dst || !len || cap <= 0) {
        return 0;
    }
    if (*len >= cap - 1) {
        return 0;
    }
    dst[*len] = ch;
    *len += 1;
    dst[*len] = '\0';
    return 1;
}

int msd_append_cstr(char *dst, int cap, int *len, const char *text)
{
    int i;
    if (!text) {
        return 0;
    }
    for (i = 0; text[i] != '\0'; ++i) {
        if (!msd_append_char(dst, cap, len, text[i])) {
            return 0;
        }
    }
    return 1;
}

int msd_append_span(char *dst, int cap, int *len, const char *src, int offset, int length)
{
    int i;
    for (i = 0; i < length; ++i) {
        if (!msd_append_char(dst, cap, len, src[offset + i])) {
            return 0;
        }
    }
    return 1;
}

void msd_trim_trailing_zeros(char *buf)
{
    int len;
    if (!buf) {
        return;
    }
    len = (int) strlen(buf);
    while (len > 0 && buf[len - 1] == '0') {
        buf[len - 1] = '\0';
        --len;
    }
    if (len > 0 && buf[len - 1] == '.') {
        buf[len - 1] = '\0';
    }
}
