#include "msd_aot.h"
#include "msd_fixed.h"

#define MSD_AOT_VERSION 2

static const char msd_aot_magic[8] = { 'M','S','D','A','O','T','2','\n' };

typedef struct MsdAotHeader {
    char magic[8];
    int version;
    int flags;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int section_count;
    int item_count;
    int bc_count;
    int bc_atom_count;
    int dep_count;
    int verify_errors;
    int path_len;
} MsdAotHeader;

static int msd_aot_write_int(FILE *fp, int value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_aot_write_long(FILE *fp, long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_aot_write_ulong(FILE *fp, unsigned long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_aot_read_int(FILE *fp, int *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_aot_read_long(FILE *fp, long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_aot_read_ulong(FILE *fp, unsigned long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_aot_write_dep(FILE *fp, const MsdModuleDep *dep)
{
    int path_len;
    if (!dep) return 0;
    path_len = (int) strlen(dep->path);
    if (!msd_aot_write_int(fp, dep->size)) return 0;
    if (!msd_aot_write_ulong(fp, dep->hash)) return 0;
    if (!msd_aot_write_int(fp, path_len)) return 0;
    return path_len == 0 || fwrite(dep->path, 1u, (size_t) path_len, fp) == (size_t) path_len;
}

static int msd_aot_read_dep(FILE *fp, MsdAotDepInfo *dep)
{
    int path_len;
    if (!dep) return 0;
    memset(dep, 0, sizeof(*dep));
    if (!msd_aot_read_int(fp, &dep->size)) return 0;
    if (!msd_aot_read_ulong(fp, &dep->hash)) return 0;
    if (!msd_aot_read_int(fp, &path_len)) return 0;
    if (path_len < 0 || path_len >= (int) sizeof(dep->path)) return 0;
    if (path_len > 0 && fread(dep->path, 1u, (size_t) path_len, fp) != (size_t) path_len) return 0;
    dep->path[path_len] = '\0';
    return 1;
}

static int msd_aot_write_bc_atom(FILE *fp, const MsdBCAtom *atom)
{
    if (!msd_aot_write_int(fp, (int) atom->type)) return 0;
    if (!msd_aot_write_int(fp, atom->offset)) return 0;
    if (!msd_aot_write_int(fp, atom->length)) return 0;
    if (!msd_aot_write_long(fp, atom->number)) return 0;
    if (!msd_aot_write_int(fp, atom->is_fixed)) return 0;
    if (!msd_aot_write_int(fp, atom->line)) return 0;
    if (!msd_aot_write_int(fp, atom->col)) return 0;
    return 1;
}

static int msd_aot_read_bc_atom(FILE *fp, MsdBCAtom *atom)
{
    int type;
    long num;
    if (!msd_aot_read_int(fp, &type)) return 0;
    atom->type = (MsdAtomType) type;
    if (!msd_aot_read_int(fp, &atom->offset)) return 0;
    if (!msd_aot_read_int(fp, &atom->length)) return 0;
    if (!msd_aot_read_long(fp, &num)) return 0;
    atom->number = (msd_fixed_t) num;
    if (!msd_aot_read_int(fp, &atom->is_fixed)) return 0;
    if (!msd_aot_read_int(fp, &atom->line)) return 0;
    if (!msd_aot_read_int(fp, &atom->col)) return 0;
    return 1;
}

static int msd_aot_write_bc(FILE *fp, const MsdBCInstr *bc)
{
    if (!msd_aot_write_int(fp, (int) bc->op)) return 0;
    if (!msd_aot_write_int(fp, (int) bc->profile_tag)) return 0;
    if (!msd_aot_write_int(fp, (int) bc->section_kind)) return 0;
    if (!msd_aot_write_int(fp, (int) bc->word_id)) return 0;
    if (!msd_aot_write_int(fp, bc->name_atom)) return 0;
    if (!msd_aot_write_int(fp, bc->const_start)) return 0;
    if (!msd_aot_write_int(fp, bc->const_count)) return 0;
    if (!msd_aot_write_int(fp, bc->line)) return 0;
    if (!msd_aot_write_int(fp, bc->col)) return 0;
    return 1;
}

static int msd_aot_read_bc(FILE *fp, MsdBCInstr *bc)
{
    int op;
    int profile;
    int kind;
    int word;
    if (!msd_aot_read_int(fp, &op)) return 0;
    bc->op = (MsdBCOp) op;
    if (!msd_aot_read_int(fp, &profile)) return 0;
    bc->profile_tag = (MsdProfile) profile;
    if (!msd_aot_read_int(fp, &kind)) return 0;
    bc->section_kind = (MsdSectionKind) kind;
    if (!msd_aot_read_int(fp, &word)) return 0;
    bc->word_id = (MsdBuiltinId) word;
    if (!msd_aot_read_int(fp, &bc->name_atom)) return 0;
    if (!msd_aot_read_int(fp, &bc->const_start)) return 0;
    if (!msd_aot_read_int(fp, &bc->const_count)) return 0;
    if (!msd_aot_read_int(fp, &bc->line)) return 0;
    if (!msd_aot_read_int(fp, &bc->col)) return 0;
    return 1;
}

int msd_aot_default_path(const char *input_path, char *out, int cap)
{
    int len;
    if (!input_path || !out || cap <= 0) return 0;
    len = (int) strlen(input_path);
    if (len >= 4 && msd_ascii_tolower((unsigned char) input_path[len - 4]) == '.' &&
        msd_ascii_tolower((unsigned char) input_path[len - 3]) == 'd' &&
        msd_ascii_tolower((unsigned char) input_path[len - 2]) == 'e' &&
        msd_ascii_tolower((unsigned char) input_path[len - 1]) == 'f') {
        if (len + 5 >= cap) return 0;
        memcpy(out, input_path, (size_t) (len - 3));
        strcpy(out + (len - 3), "msdaot");
        return 1;
    }
    if (len + 8 >= cap) return 0;
    strcpy(out, input_path);
    strcat(out, ".msdaot");
    return 1;
}

int msd_aot_save(const char *path, const MsdSource *src, const MsdModuleInfo *mods, const MsdArena *arena, const MsdVerifyReport *verify)
{
    FILE *fp;
    MsdAotHeader hdr;
    int i;
    int path_len;
    if (!path || !src || !mods || !arena || !arena->bc || !arena->bc_atoms) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, msd_aot_magic, sizeof(hdr.magic));
    hdr.version = MSD_AOT_VERSION;
    hdr.flags = 1;
    hdr.int_size = (int) sizeof(int);
    hdr.long_size = (int) sizeof(long);
    hdr.fixed_frac_bits = MSD_FIXED_FRAC_BITS;
    hdr.source_size = src->size;
    hdr.source_hash = msd_module_hash_source(src);
    hdr.section_count = arena->section_count;
    hdr.item_count = arena->item_count;
    hdr.bc_count = arena->bc_count;
    hdr.bc_atom_count = arena->bc_atom_count;
    hdr.dep_count = mods->dep_count;
    hdr.verify_errors = verify ? verify->errors : 0;
    path_len = (int) strlen(src->path);
    hdr.path_len = path_len;
    if (fwrite(hdr.magic, sizeof(hdr.magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    if (!msd_aot_write_int(fp, hdr.version) ||
        !msd_aot_write_int(fp, hdr.flags) ||
        !msd_aot_write_int(fp, hdr.int_size) ||
        !msd_aot_write_int(fp, hdr.long_size) ||
        !msd_aot_write_int(fp, hdr.fixed_frac_bits) ||
        !msd_aot_write_int(fp, hdr.source_size) ||
        !msd_aot_write_ulong(fp, hdr.source_hash) ||
        !msd_aot_write_int(fp, hdr.section_count) ||
        !msd_aot_write_int(fp, hdr.item_count) ||
        !msd_aot_write_int(fp, hdr.bc_count) ||
        !msd_aot_write_int(fp, hdr.bc_atom_count) ||
        !msd_aot_write_int(fp, hdr.dep_count) ||
        !msd_aot_write_int(fp, hdr.verify_errors) ||
        !msd_aot_write_int(fp, hdr.path_len)) {
        fclose(fp);
        return 0;
    }
    if (path_len > 0 && fwrite(src->path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    for (i = 0; i < mods->dep_count; ++i) {
        if (!msd_aot_write_dep(fp, &mods->deps[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < arena->bc_count; ++i) {
        if (!msd_aot_write_bc(fp, &arena->bc[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < arena->bc_atom_count; ++i) {
        if (!msd_aot_write_bc_atom(fp, &arena->bc_atoms[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_aot_read_info(const char *path, MsdAotInfo *info)
{
    FILE *fp;
    char magic[8];
    int i;
    int path_len;
    if (!path || !info) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fread(magic, sizeof(magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    for (i = 0; i < 8; ++i) {
        if (magic[i] != msd_aot_magic[i]) { fclose(fp); return 0; }
    }
    memset(info, 0, sizeof(*info));
    if (!msd_aot_read_int(fp, &info->version) ||
        !msd_aot_read_int(fp, &info->flags) ||
        !msd_aot_read_int(fp, &info->int_size) ||
        !msd_aot_read_int(fp, &info->long_size) ||
        !msd_aot_read_int(fp, &info->fixed_frac_bits) ||
        !msd_aot_read_int(fp, &info->source_size) ||
        !msd_aot_read_ulong(fp, &info->source_hash) ||
        !msd_aot_read_int(fp, &info->section_count) ||
        !msd_aot_read_int(fp, &info->item_count) ||
        !msd_aot_read_int(fp, &info->bc_count) ||
        !msd_aot_read_int(fp, &info->bc_atom_count) ||
        !msd_aot_read_int(fp, &info->dep_count) ||
        !msd_aot_read_int(fp, &info->verify_errors) ||
        !msd_aot_read_int(fp, &path_len)) {
        fclose(fp);
        return 0;
    }
    if (path_len < 0 || path_len >= (int) sizeof(info->source_path)) { fclose(fp); return 0; }
    if (path_len > 0 && fread(info->source_path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    info->source_path[path_len] = '\0';
    if (info->dep_count < 0 || info->dep_count > MSD_MAX_DEPS) { fclose(fp); return 0; }
    for (i = 0; i < info->dep_count; ++i) {
        if (!msd_aot_read_dep(fp, &info->deps[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_aot_load(const char *path, MsdAotInfo *info, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *atom_storage, int atom_cap)
{
    FILE *fp;
    char magic[8];
    int i;
    int path_len;
    MsdAotInfo local;
    if (!path || !bc_storage || !atom_storage) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fread(magic, sizeof(magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    for (i = 0; i < 8; ++i) {
        if (magic[i] != msd_aot_magic[i]) { fclose(fp); return 0; }
    }
    memset(&local, 0, sizeof(local));
    if (!msd_aot_read_int(fp, &local.version) ||
        !msd_aot_read_int(fp, &local.flags) ||
        !msd_aot_read_int(fp, &local.int_size) ||
        !msd_aot_read_int(fp, &local.long_size) ||
        !msd_aot_read_int(fp, &local.fixed_frac_bits) ||
        !msd_aot_read_int(fp, &local.source_size) ||
        !msd_aot_read_ulong(fp, &local.source_hash) ||
        !msd_aot_read_int(fp, &local.section_count) ||
        !msd_aot_read_int(fp, &local.item_count) ||
        !msd_aot_read_int(fp, &local.bc_count) ||
        !msd_aot_read_int(fp, &local.bc_atom_count) ||
        !msd_aot_read_int(fp, &local.dep_count) ||
        !msd_aot_read_int(fp, &local.verify_errors) ||
        !msd_aot_read_int(fp, &path_len)) {
        fclose(fp);
        return 0;
    }
    if (local.bc_count < 0 || local.bc_count > bc_cap || local.bc_atom_count < 0 || local.bc_atom_count > atom_cap) { fclose(fp); return 0; }
    if (path_len < 0 || path_len >= (int) sizeof(local.source_path)) { fclose(fp); return 0; }
    if (path_len > 0 && fread(local.source_path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    local.source_path[path_len] = '\0';
    if (local.dep_count < 0 || local.dep_count > MSD_MAX_DEPS) { fclose(fp); return 0; }
    for (i = 0; i < local.dep_count; ++i) {
        if (!msd_aot_read_dep(fp, &local.deps[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < local.bc_count; ++i) {
        if (!msd_aot_read_bc(fp, &bc_storage[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < local.bc_atom_count; ++i) {
        if (!msd_aot_read_bc_atom(fp, &atom_storage[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    if (info) *info = local;
    return 1;
}

int msd_aot_matches(const MsdAotInfo *info, const MsdSource *src, const MsdModuleInfo *mods)
{
    int i;
    if (!info || !src || !mods) return 0;
    if (info->source_size != src->size || info->source_hash != msd_module_hash_source(src)) return 0;
    if (info->dep_count != mods->dep_count) return 0;
    for (i = 0; i < mods->dep_count; ++i) {
        if (info->deps[i].size != mods->deps[i].size) return 0;
        if (info->deps[i].hash != mods->deps[i].hash) return 0;
        if (strcmp(info->deps[i].path, mods->deps[i].path) != 0) return 0;
    }
    return 1;
}

void msd_aot_print_info(const MsdAotInfo *info, FILE *out)
{
    int i;
    if (!info || !out) return;
    fprintf(out, "msdaot version=%d source=%s\n", info->version, info->source_path);
    fprintf(out, "sizes: int=%d long=%d fixed_frac_bits=%d source_size=%d source_hash=%lu\n",
        info->int_size, info->long_size, info->fixed_frac_bits, info->source_size, info->source_hash);
    fprintf(out, "counts: sections=%d items=%d bc=%d atoms=%d deps=%d verify_errors=%d\n",
        info->section_count, info->item_count, info->bc_count, info->bc_atom_count, info->dep_count, info->verify_errors);
    for (i = 0; i < info->dep_count; ++i) {
        fprintf(out, "  [%d] size=%d hash=%lu path=%s\n", i, info->deps[i].size, info->deps[i].hash, info->deps[i].path);
    }
}
