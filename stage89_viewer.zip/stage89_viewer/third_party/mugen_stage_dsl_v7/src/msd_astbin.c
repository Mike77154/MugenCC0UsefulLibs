#include "msd_astbin.h"
#include "msd_fixed.h"
#include "msd_module.h"

#define MSD_ASTBIN_VERSION 1

static const char msd_astbin_magic[8] = { 'M','S','D','A','S','T','1','\n' };

typedef struct MsdAstBinHeader {
    char magic[8];
    int version;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int atom_count;
    int section_count;
    int item_count;
    int plan_count;
    int path_len;
} MsdAstBinHeader;

static int msd_astbin_write_int(FILE *fp, int value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_astbin_write_long(FILE *fp, long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_astbin_write_ulong(FILE *fp, unsigned long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_astbin_read_int(FILE *fp, int *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_astbin_read_ulong(FILE *fp, unsigned long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_astbin_write_atom(FILE *fp, const MsdAtom *atom)
{
    if (!msd_astbin_write_int(fp, (int) atom->type)) return 0;
    if (!msd_astbin_write_int(fp, atom->offset)) return 0;
    if (!msd_astbin_write_int(fp, atom->length)) return 0;
    if (!msd_astbin_write_long(fp, atom->number)) return 0;
    if (!msd_astbin_write_int(fp, atom->is_fixed)) return 0;
    if (!msd_astbin_write_int(fp, atom->line)) return 0;
    if (!msd_astbin_write_int(fp, atom->col)) return 0;
    return 1;
}

static int msd_astbin_write_section(FILE *fp, const MsdAstSection *sec)
{
    if (!msd_astbin_write_int(fp, (int) sec->kind)) return 0;
    if (!msd_astbin_write_int(fp, sec->header_start)) return 0;
    if (!msd_astbin_write_int(fp, sec->header_count)) return 0;
    if (!msd_astbin_write_int(fp, sec->first_item)) return 0;
    if (!msd_astbin_write_int(fp, sec->item_count)) return 0;
    if (!msd_astbin_write_int(fp, sec->line)) return 0;
    if (!msd_astbin_write_int(fp, sec->col)) return 0;
    return 1;
}

static int msd_astbin_write_item(FILE *fp, const MsdAstItem *item)
{
    if (!msd_astbin_write_int(fp, (int) item->kind)) return 0;
    if (!msd_astbin_write_int(fp, item->key_atom)) return 0;
    if (!msd_astbin_write_int(fp, item->value_start)) return 0;
    if (!msd_astbin_write_int(fp, item->value_count)) return 0;
    if (!msd_astbin_write_int(fp, item->line)) return 0;
    if (!msd_astbin_write_int(fp, item->col)) return 0;
    return 1;
}

static int msd_astbin_write_canon_section(FILE *fp, const MsdCanonSection *sec)
{
    if (!msd_astbin_write_int(fp, (int) sec->kind)) return 0;
    if (!msd_astbin_write_int(fp, sec->src_section_index)) return 0;
    if (!msd_astbin_write_int(fp, sec->plan_start)) return 0;
    if (!msd_astbin_write_int(fp, sec->plan_count)) return 0;
    if (!msd_astbin_write_ulong(fp, sec->plan_hash)) return 0;
    if (!msd_astbin_write_ulong(fp, sec->canon_hash)) return 0;
    if (!msd_astbin_write_int(fp, (int) strlen(sec->header_text))) return 0;
    return fwrite(sec->header_text, 1u, strlen(sec->header_text), fp) == strlen(sec->header_text);
}

static int msd_astbin_write_plan(FILE *fp, const MsdCanonPlanInstr *plan)
{
    if (!msd_astbin_write_int(fp, (int) plan->item_kind)) return 0;
    if (!msd_astbin_write_int(fp, plan->item_ordinal)) return 0;
    if (!msd_astbin_write_int(fp, (int) plan->word_id)) return 0;
    return 1;
}

int msd_astbin_default_path(const char *input_path, char *out, int cap)
{
    int len;
    if (!input_path || !out || cap <= 0) return 0;
    len = (int) strlen(input_path);
    if (len >= 4 && msd_ascii_tolower((unsigned char) input_path[len - 4]) == '.' &&
        msd_ascii_tolower((unsigned char) input_path[len - 3]) == 'd' &&
        msd_ascii_tolower((unsigned char) input_path[len - 2]) == 'e' &&
        msd_ascii_tolower((unsigned char) input_path[len - 1]) == 'f') {
        if (len + 3 >= cap) return 0;
        memcpy(out, input_path, (size_t) (len - 3));
        strcpy(out + (len - 3), "msda");
        return 1;
    }
    if (len + 6 >= cap) return 0;
    strcpy(out, input_path);
    strcat(out, ".msda");
    return 1;
}

int msd_astbin_save(const char *path, const MsdSource *src, const MsdArena *arena, const MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, int plan_count)
{
    FILE *fp;
    MsdAstBinHeader hdr;
    int i;
    int path_len;
    if (!path || !src || !arena || !sections || !plans) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, msd_astbin_magic, sizeof(hdr.magic));
    hdr.version = MSD_ASTBIN_VERSION;
    hdr.int_size = (int) sizeof(int);
    hdr.long_size = (int) sizeof(long);
    hdr.fixed_frac_bits = MSD_FIXED_FRAC_BITS;
    hdr.source_size = src->size;
    hdr.source_hash = msd_module_hash_source(src);
    hdr.atom_count = arena->atom_count;
    hdr.section_count = section_count;
    hdr.item_count = arena->item_count;
    hdr.plan_count = plan_count;
    path_len = (int) strlen(src->path);
    hdr.path_len = path_len;
    if (fwrite(hdr.magic, sizeof(hdr.magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    if (!msd_astbin_write_int(fp, hdr.version) ||
        !msd_astbin_write_int(fp, hdr.int_size) ||
        !msd_astbin_write_int(fp, hdr.long_size) ||
        !msd_astbin_write_int(fp, hdr.fixed_frac_bits) ||
        !msd_astbin_write_int(fp, hdr.source_size) ||
        !msd_astbin_write_ulong(fp, hdr.source_hash) ||
        !msd_astbin_write_int(fp, hdr.atom_count) ||
        !msd_astbin_write_int(fp, hdr.section_count) ||
        !msd_astbin_write_int(fp, hdr.item_count) ||
        !msd_astbin_write_int(fp, hdr.plan_count) ||
        !msd_astbin_write_int(fp, hdr.path_len)) {
        fclose(fp);
        return 0;
    }
    if (path_len > 0 && fwrite(src->path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    for (i = 0; i < arena->atom_count; ++i) {
        if (!msd_astbin_write_atom(fp, &arena->atoms[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < arena->section_count; ++i) {
        if (!msd_astbin_write_section(fp, &arena->sections[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < arena->item_count; ++i) {
        if (!msd_astbin_write_item(fp, &arena->items[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < section_count; ++i) {
        if (!msd_astbin_write_canon_section(fp, &sections[i])) { fclose(fp); return 0; }
    }
    for (i = 0; i < plan_count; ++i) {
        if (!msd_astbin_write_plan(fp, &plans[i])) { fclose(fp); return 0; }
    }
    fclose(fp);
    return 1;
}

int msd_astbin_read_info(const char *path, MsdAstBinInfo *info)
{
    FILE *fp;
    char magic[8];
    int i;
    int path_len;
    if (!path || !info) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fread(magic, sizeof(magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    for (i = 0; i < 8; ++i) {
        if (magic[i] != msd_astbin_magic[i]) { fclose(fp); return 0; }
    }
    memset(info, 0, sizeof(*info));
    if (!msd_astbin_read_int(fp, &info->version) ||
        !msd_astbin_read_int(fp, &info->int_size) ||
        !msd_astbin_read_int(fp, &info->long_size) ||
        !msd_astbin_read_int(fp, &info->fixed_frac_bits) ||
        !msd_astbin_read_int(fp, &info->source_size) ||
        !msd_astbin_read_ulong(fp, &info->source_hash) ||
        !msd_astbin_read_int(fp, &info->atom_count) ||
        !msd_astbin_read_int(fp, &info->section_count) ||
        !msd_astbin_read_int(fp, &info->item_count) ||
        !msd_astbin_read_int(fp, &info->plan_count) ||
        !msd_astbin_read_int(fp, &path_len)) {
        fclose(fp);
        return 0;
    }
    if (path_len < 0 || path_len >= (int) sizeof(info->source_path)) { fclose(fp); return 0; }
    if (path_len > 0 && fread(info->source_path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    info->source_path[path_len] = '\0';
    fclose(fp);
    return 1;
}

void msd_astbin_print_info(const MsdAstBinInfo *info, FILE *out)
{
    if (!info || !out) return;
    fprintf(out, "msda version=%d source=%s\n", info->version, info->source_path);
    fprintf(out, "sizes: int=%d long=%d fixed_frac_bits=%d source_size=%d\n",
        info->int_size, info->long_size, info->fixed_frac_bits, info->source_size);
    fprintf(out, "counts: atoms=%d sections=%d items=%d plans=%d hash=%lu\n",
        info->atom_count, info->section_count, info->item_count, info->plan_count, info->source_hash);
}
