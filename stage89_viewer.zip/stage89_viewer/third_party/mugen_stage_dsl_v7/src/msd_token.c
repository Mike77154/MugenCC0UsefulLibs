#include "msd_token.h"

const char *msd_token_type_name(MsdTokenType type)
{
    switch (type) {
    case MSD_TOK_EOF: return "EOF";
    case MSD_TOK_NEWLINE: return "NEWLINE";
    case MSD_TOK_LBRACKET: return "LBRACKET";
    case MSD_TOK_RBRACKET: return "RBRACKET";
    case MSD_TOK_EQUALS: return "EQUALS";
    case MSD_TOK_COMMA: return "COMMA";
    case MSD_TOK_IDENT: return "IDENT";
    case MSD_TOK_STRING: return "STRING";
    case MSD_TOK_NUMBER: return "NUMBER";
    case MSD_TOK_ERROR: return "ERROR";
    }
    return "?";
}

void msd_token_text(const MsdSource *src, const MsdToken *tok, char *buf, int cap)
{
    if (!src || !tok || !buf || cap <= 0) {
        return;
    }
    if (tok->type == MSD_TOK_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, tok->offset, tok->length);
    } else {
        msd_copy_span(buf, cap, src->data, tok->offset, tok->length);
    }
}
