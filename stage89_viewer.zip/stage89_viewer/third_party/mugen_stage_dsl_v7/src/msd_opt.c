#include "msd_opt.h"

static int msd_span_ieq_atom_atom(const MsdSource *src, const MsdAtom *a, const MsdAtom *b)
{
    int i;
    if (!src || !a || !b) return 0;
    if (a->type == MSD_ATOM_NUMBER || b->type == MSD_ATOM_NUMBER) return 0;
    if (a->length != b->length) return 0;
    for (i = 0; i < a->length; ++i) {
        if (msd_ascii_tolower((unsigned char) src->data[a->offset + i]) != msd_ascii_tolower((unsigned char) src->data[b->offset + i])) {
            return 0;
        }
    }
    return 1;
}

static int msd_builtin_is_overridable(MsdBuiltinId id)
{
    if (id >= MSD_BUILTIN_GAME_STAGE_NAME && id <= MSD_BUILTIN_GAME_BOUND_SCREENRIGHT) return 1;
    if (id >= MSD_BUILTIN_GAME_BG_TYPE && id <= MSD_BUILTIN_GAME_BG_TRACKCHAR) return 1;
    if (id >= MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME && id <= MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID) return 1;
    if (id >= MSD_BUILTIN_GAME_BGCTRL_TYPE && id <= MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR) return 1;
    return 0;
}

static int msd_bc_atom_equal(const MsdSource *src, const MsdBCAtom *a, const MsdBCAtom *b)
{
    int i;
    if (!a || !b) return 0;
    if (a->type != b->type) return 0;
    if (a->is_fixed != b->is_fixed) return 0;
    if (a->type == MSD_ATOM_NUMBER) {
        return a->number == b->number;
    }
    if (!src || a->length != b->length) return 0;
    for (i = 0; i < a->length; ++i) {
        if (src->data[a->offset + i] != src->data[b->offset + i]) {
            return 0;
        }
    }
    return 1;
}

static int msd_bc_intern_atom(const MsdSource *src, const MsdBCAtom *atom, MsdBCAtom *out_atoms, int *out_count, int out_cap, int *interned)
{
    int i;
    if (!atom || !out_atoms || !out_count) return -1;
    for (i = 0; i < *out_count; ++i) {
        if (msd_bc_atom_equal(src, atom, &out_atoms[i])) {
            if (interned) *interned += 1;
            return i;
        }
    }
    if (*out_count >= out_cap) return -1;
    out_atoms[*out_count] = *atom;
    return (*out_count)++;
}

static int msd_bc_append_atom(const MsdBCAtom *atom, MsdBCAtom *out_atoms, int *out_count, int out_cap)
{
    if (!atom || !out_atoms || !out_count) return -1;
    if (*out_count >= out_cap) return -1;
    out_atoms[*out_count] = *atom;
    return (*out_count)++;
}

void msd_opt_stats_init(MsdOptStats *stats)
{
    if (!stats) return;
    memset(stats, 0, sizeof(*stats));
}

int msd_optimize_ir(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *in_ir, int in_count, MsdIRInstr *out_ir, int out_cap, MsdOptStats *stats)
{
    char keep[MSD_MAX_IR];
    int seen[MSD_MAX_IR];
    int i;
    int j;
    int k;
    int out_count;
    int seen_count;

    if (!src || !arena || !in_ir || !out_ir || in_count < 0) return 0;
    memset(keep, 1, sizeof(keep));
    out_count = 0;

    if (stats) {
        stats->ir_in = in_count;
        stats->ir_out = 0;
    }

    i = 0;
    while (i < in_count) {
        if (in_ir[i].op != MSD_IR_BEGIN_SECTION) {
            if (out_count >= out_cap) return 0;
            out_ir[out_count++] = in_ir[i++];
            continue;
        }
        j = i + 1;
        while (j < in_count && in_ir[j].op != MSD_IR_END_SECTION) {
            ++j;
        }
        if (j >= in_count) {
            return 0;
        }
        seen_count = 0;
        for (k = j - 1; k > i; --k) {
            if (in_ir[k].op == MSD_IR_SET && in_ir[k].key_atom >= 0 &&
                msd_semantic_key_is_unique(in_ir[k].section_kind, src, &arena->atoms[in_ir[k].key_atom])) {
                int s;
                int found;
                found = 0;
                for (s = 0; s < seen_count; ++s) {
                    if (msd_span_ieq_atom_atom(src, &arena->atoms[in_ir[k].key_atom], &arena->atoms[in_ir[seen[s]].key_atom])) {
                        found = 1;
                        break;
                    }
                }
                if (found) {
                    keep[k] = 0;
                    if (stats) stats->ir_dead_sets += 1;
                } else {
                    seen[seen_count++] = k;
                }
            }
        }
        for (k = i; k <= j; ++k) {
            if (keep[k]) {
                if (out_count >= out_cap) return 0;
                out_ir[out_count++] = in_ir[k];
            }
        }
        i = j + 1;
    }

    if (stats) stats->ir_out = out_count;
    return out_count;
}

int msd_optimize_bytecode(const MsdSource *src, const MsdArena *arena, const MsdBCInstr *in_bc, int in_bc_count, const MsdBCAtom *in_atoms, int in_atom_count, MsdBCInstr *out_bc, int out_bc_cap, MsdBCAtom *out_atoms, int out_atom_cap, MsdOptStats *stats)
{
    char keep[MSD_MAX_BC];
    int seen[MSD_MAX_BC];
    int i;
    int j;
    int k;
    int s;
    int out_count;
    int out_atom_count;
    MsdBCInstr instr;
    int idx;

    (void) arena;
    if (!src || !in_bc || !in_atoms || !out_bc || !out_atoms) return 0;
    memset(keep, 1, sizeof(keep));
    out_count = 0;
    out_atom_count = 0;

    if (stats) {
        stats->bc_in = in_bc_count;
        stats->atom_in = in_atom_count;
        stats->bc_out = 0;
        stats->atom_out = 0;
    }

    i = 0;
    while (i < in_bc_count) {
        if (in_bc[i].op != MSD_BC_BEGIN_SECTION) {
            ++i;
            continue;
        }
        j = i + 1;
        while (j < in_bc_count && in_bc[j].op != MSD_BC_END_SECTION) {
            ++j;
        }
        if (j >= in_bc_count) return 0;
        s = 0;
        for (k = j - 1; k > i; --k) {
            if (in_bc[k].op == MSD_BC_CALL && msd_builtin_is_overridable(in_bc[k].word_id)) {
                int found;
                int n;
                found = 0;
                for (n = 0; n < s; ++n) {
                    if (in_bc[seen[n]].word_id == in_bc[k].word_id) {
                        found = 1;
                        break;
                    }
                }
                if (found) {
                    keep[k] = 0;
                    if (stats) stats->bc_dead_calls += 1;
                } else {
                    seen[s++] = k;
                }
            }
        }
        i = j + 1;
    }

    for (i = 0; i < in_bc_count; ++i) {
        if (!keep[i]) continue;
        instr = in_bc[i];
        if (instr.op == MSD_BC_BEGIN_SECTION) {
            instr.const_start = out_atom_count;
            instr.const_count = 0;
            for (k = 0; k < in_bc[i].const_count; ++k) {
                idx = msd_bc_append_atom(&in_atoms[in_bc[i].const_start + k], out_atoms, &out_atom_count, out_atom_cap);
                if (idx < 0) return 0;
                instr.const_count += 1;
            }
        } else if (instr.op == MSD_BC_CALL) {
            if (instr.name_atom >= 0) {
                idx = msd_bc_intern_atom(src, &in_atoms[instr.name_atom], out_atoms, &out_atom_count, out_atom_cap, stats ? &stats->atoms_interned : 0);
                if (idx < 0) return 0;
                instr.name_atom = idx;
            }
            instr.const_start = out_atom_count;
            instr.const_count = 0;
            for (k = 0; k < in_bc[i].const_count; ++k) {
                idx = msd_bc_append_atom(&in_atoms[in_bc[i].const_start + k], out_atoms, &out_atom_count, out_atom_cap);
                if (idx < 0) return 0;
                instr.const_count += 1;
            }
        }
        if (out_count >= out_bc_cap) return 0;
        out_bc[out_count++] = instr;
    }

    if (stats) {
        stats->bc_out = out_count;
        stats->atom_out = out_atom_count;
    }
    return out_count;
}

void msd_opt_dump_summary(const MsdOptStats *stats, FILE *out)
{
    if (!stats || !out) return;
    fprintf(out, "IR:   %d -> %d  (dead sets: %d)\n", stats->ir_in, stats->ir_out, stats->ir_dead_sets);
    fprintf(out, "BC:   %d -> %d  (dead calls: %d)\n", stats->bc_in, stats->bc_out, stats->bc_dead_calls);
    fprintf(out, "ATOM: %d -> %d  (interned reuses: %d)\n", stats->atom_in, stats->atom_out, stats->atoms_interned);
}
