#include "msd_vm.h"
#include "msd_profile.h"

int msd_vm_execute(MsdRuntime *rt, const MsdSource *src, const MsdArena *arena)
{
    int i;
    const MsdBCInstr *instr;
    if (!rt || !src || !arena || !arena->bc || !arena->bc_atoms) {
        return 0;
    }
    if (arena->bc_count > 0) {
        msd_runtime_set_profile(rt, arena->bc[0].profile_tag);
    } else {
        msd_runtime_set_profile(rt, msd_profile_get_active());
    }
    for (i = 0; i < arena->bc_count; ++i) {
        instr = &arena->bc[i];
        if (instr->op == MSD_BC_BEGIN_SECTION) {
            if (!msd_runtime_begin_section(rt, src, instr->section_kind, arena->bc_atoms, instr->const_start, instr->const_count)) {
                return 0;
            }
        } else if (instr->op == MSD_BC_CALL) {
            if (msd_builtin_is_core(instr->word_id)) {
                if (!msd_core_execute(rt, src, instr, arena->bc_atoms)) {
                    return 0;
                }
            } else {
                if (!msd_game_execute(rt, src, instr, arena->bc_atoms)) {
                    return 0;
                }
            }
        } else if (instr->op == MSD_BC_END_SECTION) {
            rt->ctx.section_kind = MSD_SECTION_UNKNOWN;
        }
    }
    msd_runtime_finalize_stage(rt);
    return 1;
}
