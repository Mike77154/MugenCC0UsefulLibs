#include "msd_verify.h"

static void msd_verify_add_error(MsdArena *arena, int line, int col, const char *message, MsdVerifyReport *report)
{
    if (!arena || !message) return;
    msd_arena_add_error(arena, line, col, message);
    if (report) report->errors += 1;
}

static int msd_verify_range_ok(int start, int count, int cap)
{
    if (count < 0) return 0;
    if (count == 0) return start >= 0 && start <= cap;
    if (start < 0) return 0;
    if (start > cap) return 0;
    if (count > cap - start) return 0;
    return 1;
}

static int msd_verify_word_is_row(MsdBuiltinId word_id)
{
    return word_id == MSD_BUILTIN_CORE_RAW_ROW || word_id == MSD_BUILTIN_GAME_ACTION_FRAME;
}

static int msd_verify_word_requires_name(MsdBuiltinId word_id)
{
    if (word_id == MSD_BUILTIN_CORE_RAW_ASSIGN) return 1;
    if (word_id >= MSD_BUILTIN_GAME_STAGE_NAME && word_id <= MSD_BUILTIN_GAME_BOUND_SCREENRIGHT) return 1;
    if (word_id >= MSD_BUILTIN_GAME_BG_TYPE && word_id <= MSD_BUILTIN_GAME_BG_TRACKCHAR) return 1;
    if (word_id >= MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME && word_id <= MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID) return 1;
    if (word_id >= MSD_BUILTIN_GAME_BGCTRL_TYPE && word_id <= MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR) return 1;
    return 0;
}

static int msd_verify_word_matches_section(MsdSectionKind kind, MsdBuiltinId word_id)
{
    if (word_id == MSD_BUILTIN_CORE_RAW_ASSIGN || word_id == MSD_BUILTIN_CORE_RAW_ROW) return 1;
    switch (kind) {
    case MSD_SECTION_INFO:
        return word_id >= MSD_BUILTIN_GAME_STAGE_NAME && word_id <= MSD_BUILTIN_GAME_STAGE_MUGENVERSION;
    case MSD_SECTION_STAGEINFO:
        return word_id >= MSD_BUILTIN_GAME_STAGE_ZOFFSET && word_id <= MSD_BUILTIN_GAME_STAGE_YSCALE;
    case MSD_SECTION_SHADOW:
        return word_id >= MSD_BUILTIN_GAME_SHADOW_INTENSITY && word_id <= MSD_BUILTIN_GAME_SHADOW_XSHEAR;
    case MSD_SECTION_REFLECTION:
        return word_id == MSD_BUILTIN_GAME_REFLECTION_REFLECT;
    case MSD_SECTION_MUSIC:
        return word_id == MSD_BUILTIN_GAME_STAGE_BGMUSIC || word_id == MSD_BUILTIN_GAME_STAGE_BGVOLUME;
    case MSD_SECTION_BGDEF:
        return word_id == MSD_BUILTIN_GAME_STAGE_SPR || word_id == MSD_BUILTIN_GAME_STAGE_DEBUGBG;
    case MSD_SECTION_CAMERA:
        return word_id >= MSD_BUILTIN_GAME_CAMERA_STARTX && word_id <= MSD_BUILTIN_GAME_CAMERA_ZOOMIN;
    case MSD_SECTION_PLAYERINFO:
        return word_id >= MSD_BUILTIN_GAME_PLAYER_P1STARTX && word_id <= MSD_BUILTIN_GAME_PLAYER_RIGHTBOUND;
    case MSD_SECTION_BOUND:
        return word_id >= MSD_BUILTIN_GAME_BOUND_SCREENLEFT && word_id <= MSD_BUILTIN_GAME_BOUND_SCREENRIGHT;
    case MSD_SECTION_BG:
        return word_id >= MSD_BUILTIN_GAME_BG_TYPE && word_id <= MSD_BUILTIN_GAME_BG_TRACKCHAR;
    case MSD_SECTION_BGCTRLDEF:
        return word_id >= MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME && word_id <= MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID;
    case MSD_SECTION_BGCTRL:
        return word_id >= MSD_BUILTIN_GAME_BGCTRL_TYPE && word_id <= MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR;
    case MSD_SECTION_BEGIN_ACTION:
        return word_id == MSD_BUILTIN_GAME_ACTION_FRAME || word_id == MSD_BUILTIN_CORE_RAW_ASSIGN || word_id == MSD_BUILTIN_CORE_RAW_ROW;
    default:
        return 1;
    }
}

void msd_verify_report_init(MsdVerifyReport *report)
{
    if (!report) return;
    memset(report, 0, sizeof(*report));
}

int msd_verify_bytecode(const MsdSource *src, MsdArena *arena, MsdVerifyReport *report)
{
    int i;
    int depth;
    MsdSectionKind current_kind;
    const MsdBCInstr *instr;
    (void) src;
    if (!arena || !arena->bc || !arena->bc_atoms) return 0;
    if (report) msd_verify_report_init(report);
    depth = 0;
    current_kind = MSD_SECTION_UNKNOWN;
    for (i = 0; i < arena->bc_count; ++i) {
        instr = &arena->bc[i];
        if (instr->op == MSD_BC_BEGIN_SECTION) {
            if (report) report->begins += 1;
            if (depth != 0) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: nested BEGIN not allowed", report);
            }
            if (instr->word_id != msd_mugen_resolve_begin(instr->section_kind)) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: BEGIN word does not match section", report);
            }
            if (!msd_verify_range_ok(instr->const_start, instr->const_count, arena->bc_atom_count)) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: BEGIN constant range out of bounds", report);
            }
            current_kind = instr->section_kind;
            depth = 1;
        } else if (instr->op == MSD_BC_CALL) {
            if (report) report->calls += 1;
            if (depth != 1) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: CALL outside section", report);
            }
            if (instr->section_kind != current_kind) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: CALL section does not match active section", report);
            }
            if (!msd_verify_word_matches_section(instr->section_kind, instr->word_id)) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: CALL word incompatible with section", report);
            }
            if (instr->name_atom < -1 || instr->name_atom >= arena->bc_atom_count) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: name atom out of bounds", report);
            }
            if (!msd_verify_range_ok(instr->const_start, instr->const_count, arena->bc_atom_count)) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: CALL constant range out of bounds", report);
            }
            if (msd_verify_word_requires_name(instr->word_id) && instr->name_atom < 0) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: CALL is missing required name atom", report);
            }
            if (msd_verify_word_is_row(instr->word_id) && instr->name_atom >= 0) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: row CALL must not carry a name atom", report);
            }
        } else if (instr->op == MSD_BC_END_SECTION) {
            if (report) report->ends += 1;
            if (depth != 1) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: END without active section", report);
            }
            if (instr->section_kind != current_kind) {
                msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: END section does not match active section", report);
            }
            depth = 0;
            current_kind = MSD_SECTION_UNKNOWN;
        } else {
            msd_verify_add_error(arena, instr->line, instr->col, "bytecode verifier: unknown opcode", report);
        }
    }
    if (depth != 0) {
        msd_verify_add_error(arena, 1, 1, "bytecode verifier: unclosed section at end of program", report);
    }
    return report ? report->errors == 0 : arena->error_count == 0;
}

void msd_verify_dump_report(const MsdVerifyReport *report, FILE *out)
{
    if (!report || !out) return;
    fprintf(out, "BEGIN=%d CALL=%d END=%d ERRORS=%d\n", report->begins, report->calls, report->ends, report->errors);
}
