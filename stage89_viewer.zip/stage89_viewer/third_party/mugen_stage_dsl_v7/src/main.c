#include "msd_cli.h"

int main(int argc, char **argv)
{
    return msd_cli_main(argc, argv);
}
