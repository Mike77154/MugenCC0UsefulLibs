#include "msd_cli.h"
#include "msd_lexer.h"
#include "msd_semantic.h"
#include "msd_opt.h"
#include "msd_cache.h"
#include "msd_canon.h"
#include "msd_cache_inc.h"
#include "msd_module.h"
#include "msd_verify.h"
#include "msd_astbin.h"
#include "msd_aot.h"
#include "msd_profile.h"

static MsdSource g_src;
static MsdArena g_arena;
static MsdModuleInfo g_mods;
static MsdIRInstr g_ir_raw[MSD_MAX_IR];
static MsdIRInstr g_ir_opt[MSD_MAX_IR];
static MsdIRInstr g_ir_canon[MSD_MAX_IR];
static MsdBCInstr g_bc_raw[MSD_MAX_BC];
static MsdBCInstr g_bc_opt[MSD_MAX_BC];
static MsdBCInstr g_bc_canon[MSD_MAX_BC];
static MsdBCAtom g_bc_atoms_raw[MSD_MAX_BC_CONSTS];
static MsdBCAtom g_bc_atoms_opt[MSD_MAX_BC_CONSTS];
static MsdBCAtom g_bc_atoms_canon[MSD_MAX_BC_CONSTS];
static MsdSSAInstr g_ssa[MSD_MAX_IR];
static MsdCanonSection g_canon_sections[MSD_MAX_SECTIONS];
static MsdCanonPlanInstr g_canon_plans[MSD_MAX_ITEMS];
static MsdCanonPlanInstr g_cached_plans[MSD_MAX_ITEMS];
static MsdOptStats g_opt_stats;
static MsdCanonStats g_canon_stats;
static MsdCacheInfo g_cache_info;
static MsdIncCacheInfo g_inc_info;
static MsdVerifyReport g_verify_report;
static MsdAstBinInfo g_astbin_info;
static MsdAotInfo g_aot_info;

static void msd_print_usage(FILE *out)
{
    fprintf(out, "usage: mugen-stage-dsl <mode> <file> [--strict] [--ticks N] [--out FILE] [--cache FILE] [--profile NAME]\n");
    fprintf(out, "modes: deps | link | lex | ast | syntax | sem | check | profile | words | ir | bc | opt | ssa | canon | verify | cast | cast-info | run | timeline | cache | cache-run | cache-info | cache-inc | cache-inc-run | cache-inc-info | aot | aot-run | aot-info | all\n");
}

static void msd_print_errors_from(const MsdSource *src, const MsdArena *arena, int start, FILE *out)
{
    int i;
    for (i = start; i < arena->error_count; ++i) {
        fprintf(out, "%s:%d:%d: %s\n", src->path, arena->errors[i].line, arena->errors[i].col, arena->errors[i].message);
    }
}

static int msd_emit_runtime(const MsdSource *src, const MsdArena *arena, int ticks, int timeline)
{
    int i;
    static MsdRuntime rt;
    msd_runtime_init(&rt, (MsdArena *) arena);
    if (!msd_vm_execute(&rt, src, arena)) {
        fprintf(stderr, "error: VM execution failed\n");
        return 1;
    }
    if (timeline) {
        if (ticks <= 0) ticks = 16;
        msd_runtime_dump_timeline(&rt, stdout, ticks);
        return 0;
    }
    msd_runtime_dump(&rt.stage, stdout);
    if (ticks < 0) ticks = 0;
    msd_runtime_reset_live(&rt);
    if (ticks == 0) {
        msd_runtime_apply_tick(&rt, 0);
    } else {
        for (i = 0; i < ticks; ++i) {
            msd_runtime_apply_tick(&rt, i);
            msd_runtime_advance(&rt);
        }
        msd_runtime_apply_tick(&rt, ticks);
    }
    fprintf(stdout, "\n");
    msd_runtime_dump_live(&rt.stage, stdout);
    return 0;
}

static int msd_build_phase3_pipeline(const MsdSource *src, MsdArena *arena, int *ir_raw_count, int *ir_opt_count, int *bc_opt_count, int *bc_opt_atom_count)
{
    int raw_bc_count;
    if (!msd_lower_to_ir(src, arena, g_ir_raw, MSD_MAX_IR)) {
        return 0;
    }
    *ir_raw_count = arena->ir_count;
    msd_opt_stats_init(&g_opt_stats);
    *ir_opt_count = msd_optimize_ir(src, arena, g_ir_raw, *ir_raw_count, g_ir_opt, MSD_MAX_IR, &g_opt_stats);
    if (*ir_opt_count <= 0) {
        return 0;
    }
    arena->ir = g_ir_opt;
    arena->ir_count = *ir_opt_count;
    if (!msd_compile_bytecode(src, arena, g_bc_raw, MSD_MAX_BC, g_bc_atoms_raw, MSD_MAX_BC_CONSTS)) {
        return 0;
    }
    raw_bc_count = arena->bc_count;
    *bc_opt_count = msd_optimize_bytecode(src, arena, g_bc_raw, raw_bc_count, g_bc_atoms_raw, arena->bc_atom_count, g_bc_opt, MSD_MAX_BC, g_bc_atoms_opt, MSD_MAX_BC_CONSTS, &g_opt_stats);
    if (*bc_opt_count <= 0) {
        return 0;
    }
    *bc_opt_atom_count = g_opt_stats.atom_out;
    arena->bc = g_bc_opt;
    arena->bc_count = *bc_opt_count;
    arena->bc_atoms = g_bc_atoms_opt;
    arena->bc_atom_count = *bc_opt_atom_count;
    return 1;
}

static int msd_build_phase4_pipeline(const MsdSource *src, MsdArena *arena, int raw_ir_count, int *canon_section_count, int *canon_ir_count, int *canon_bc_count, int *canon_bc_atom_count)
{
    msd_canon_stats_init(&g_canon_stats);
    *canon_section_count = msd_canonicalize_ir(src, arena, g_ir_raw, raw_ir_count, g_ssa, MSD_MAX_IR, g_canon_sections, MSD_MAX_SECTIONS, g_canon_plans, MSD_MAX_ITEMS, g_ir_canon, MSD_MAX_IR, canon_ir_count, &g_canon_stats);
    if (*canon_section_count <= 0) {
        return 0;
    }
    if (!msd_emit_bc_from_plans(src, arena, g_canon_sections, *canon_section_count, g_canon_plans, g_bc_canon, MSD_MAX_BC, g_bc_atoms_canon, MSD_MAX_BC_CONSTS, canon_bc_count, canon_bc_atom_count)) {
        return 0;
    }
    arena->ir = g_ir_canon;
    arena->ir_count = *canon_ir_count;
    arena->bc = g_bc_canon;
    arena->bc_count = *canon_bc_count;
    arena->bc_atoms = g_bc_atoms_canon;
    arena->bc_atom_count = *canon_bc_atom_count;
    return 1;
}

static int msd_build_incremental_pipeline(const MsdSource *src, MsdArena *arena, const char *cache_path, int *section_count, int *plan_count, int *canon_ir_count, int *canon_bc_count, int *canon_bc_atom_count, int *cache_hits, int *cache_misses)
{
    int si;
    int cache_loaded;
    char header_text[64];

    *section_count = 0;
    *plan_count = 0;
    *cache_hits = 0;
    *cache_misses = 0;
    cache_loaded = 0;
    msd_canon_stats_init(&g_canon_stats);

    if (cache_path && msd_cache_inc_load(cache_path, &g_inc_info, g_cached_plans, MSD_MAX_ITEMS)) {
        cache_loaded = 1;
    }

    for (si = 0; si < arena->section_count; ++si) {
        const MsdAstSection *sec;
        unsigned long plan_hash;
        int match;
        sec = &arena->sections[si];
        plan_hash = msd_canon_section_plan_hash(src, arena, sec);
        msd_canon_section_header_text(src, arena, sec, header_text, sizeof(header_text));
        match = -1;
        if (cache_loaded) {
            match = msd_cache_inc_find_match(&g_inc_info, sec->kind, plan_hash, header_text);
        }
        if (match >= 0) {
            int pi;
            MsdCanonSection *dst;
            if (*section_count >= MSD_MAX_SECTIONS) return 0;
            dst = &g_canon_sections[*section_count];
            memset(dst, 0, sizeof(*dst));
            dst->kind = sec->kind;
            dst->src_section_index = si;
            dst->plan_start = *plan_count;
            dst->plan_count = g_inc_info.sections[match].plan_count;
            dst->plan_hash = plan_hash;
            dst->canon_hash = g_inc_info.sections[match].canon_hash;
            strcpy(dst->header_text, header_text);
            if (*plan_count + dst->plan_count > MSD_MAX_ITEMS) return 0;
            for (pi = 0; pi < dst->plan_count; ++pi) {
                g_canon_plans[*plan_count + pi] = g_cached_plans[g_inc_info.sections[match].plan_start + pi];
            }
            *plan_count += dst->plan_count;
            *section_count += 1;
            *cache_hits += 1;
        } else {
            if (*section_count >= MSD_MAX_SECTIONS) return 0;
            if (!msd_build_section_plan(src, arena, si, &g_canon_sections[*section_count], g_canon_plans, plan_count, MSD_MAX_ITEMS, &g_canon_stats)) {
                return 0;
            }
            *section_count += 1;
            *cache_misses += 1;
        }
    }

    if (!msd_emit_ir_from_plans(src, arena, g_canon_sections, *section_count, g_canon_plans, g_ir_canon, MSD_MAX_IR, canon_ir_count)) {
        return 0;
    }
    if (!msd_emit_bc_from_plans(src, arena, g_canon_sections, *section_count, g_canon_plans, g_bc_canon, MSD_MAX_BC, g_bc_atoms_canon, MSD_MAX_BC_CONSTS, canon_bc_count, canon_bc_atom_count)) {
        return 0;
    }

    g_canon_stats.raw_ir_in = g_arena.ir_count;
    g_canon_stats.canon_sections = *section_count;
    g_canon_stats.canon_ir_out = *canon_ir_count;

    arena->ir = g_ir_canon;
    arena->ir_count = *canon_ir_count;
    arena->bc = g_bc_canon;
    arena->bc_count = *canon_bc_count;
    arena->bc_atoms = g_bc_atoms_canon;
    arena->bc_atom_count = *canon_bc_atom_count;
    return 1;
}

static int msd_verify_active_bc(const MsdSource *src, MsdArena *arena, int start_error, FILE *out)
{
    msd_verify_report_init(&g_verify_report);
    if (!msd_verify_bytecode(src, arena, &g_verify_report)) {
        msd_print_errors_from(src, arena, start_error, out);
        return 0;
    }
    return 1;
}

static int msd_load_frontend_only(const char *path)
{
    msd_arena_init(&g_arena);
    if (!msd_module_load(&g_src, &g_mods, path)) {
        return 0;
    }
    return 1;
}

int msd_cli_main(int argc, char **argv)
{
    const char *mode;
    const char *path;
    const char *out_path;
    const char *cache_path_arg;
    const char *cache_path_final;
    char cache_path[320];
    int strict;
    int ticks;
    int i;
    int syntax_errors;
    int semantic_errors;
    int ir_raw_count;
    int ir_opt_count;
    int bc_opt_count;
    int bc_opt_atom_count;
    int canon_section_count;
    int canon_ir_count;
    int canon_bc_count;
    int canon_bc_atom_count;
    int cache_hit;
    int cache_flags;
    int plan_count;
    int cache_hits;
    int cache_misses;
    int ssa_count;
    int verify_start;
    int aot_hit;
    MsdProfile requested_profile;
    MsdProfile detected_profile;
    MsdProfile effective_profile;

    if (argc < 3) {
        msd_print_usage(stderr);
        return 1;
    }

    mode = argv[1];
    path = argv[2];
    out_path = 0;
    cache_path_arg = 0;
    strict = 0;
    ticks = 0;
    requested_profile = MSD_PROFILE_AUTO;
    detected_profile = MSD_PROFILE_AUTO;
    effective_profile = MSD_PROFILE_AUTO;
    for (i = 3; i < argc; ++i) {
        if (strcmp(argv[i], "--strict") == 0) {
            strict = 1;
        } else if (strcmp(argv[i], "--ticks") == 0 && i + 1 < argc) {
            ticks = atoi(argv[i + 1]);
            ++i;
        } else if (strcmp(argv[i], "--out") == 0 && i + 1 < argc) {
            out_path = argv[i + 1];
            ++i;
        } else if (strcmp(argv[i], "--cache") == 0 && i + 1 < argc) {
            cache_path_arg = argv[i + 1];
            ++i;
        } else if (strcmp(argv[i], "--profile") == 0 && i + 1 < argc) {
            if (!msd_profile_parse(argv[i + 1], &requested_profile)) {
                fprintf(stderr, "error: unknown profile '%s'\n", argv[i + 1]);
                return 1;
            }
            ++i;
        }
    }

    if (strcmp(mode, "cache-info") == 0) {
        if (!msd_cache_read_info(path, &g_cache_info)) {
            fprintf(stderr, "error: could not read cache '%s'\n", path);
            return 1;
        }
        msd_cache_print_info(&g_cache_info, stdout);
        return 0;
    }
    if (strcmp(mode, "cache-inc-info") == 0) {
        if (!msd_cache_inc_read_info(path, &g_inc_info)) {
            fprintf(stderr, "error: could not read incremental cache '%s'\n", path);
            return 1;
        }
        msd_cache_inc_print_info(&g_inc_info, stdout);
        return 0;
    }
    if (strcmp(mode, "cast-info") == 0) {
        if (!msd_astbin_read_info(path, &g_astbin_info)) {
            fprintf(stderr, "error: could not read canonical AST snapshot '%s'\n", path);
            return 1;
        }
        msd_astbin_print_info(&g_astbin_info, stdout);
        return 0;
    }
    if (strcmp(mode, "aot-info") == 0) {
        if (!msd_aot_read_info(path, &g_aot_info)) {
            fprintf(stderr, "error: could not read AOT cache '%s'\n", path);
            return 1;
        }
        msd_aot_print_info(&g_aot_info, stdout);
        return 0;
    }

    if (!msd_load_frontend_only(path)) {
        fprintf(stderr, "error: could not load '%s'\n", path);
        return 1;
    }

    if (strcmp(mode, "deps") == 0) {
        msd_module_print_info(&g_mods, stdout);
        return 0;
    }
    if (strcmp(mode, "link") == 0) {
        const char *link_path;
        link_path = out_path;
        if (!link_path) {
            if (!msd_module_default_link_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive linked output path\n");
                return 1;
            }
            link_path = cache_path;
        }
        if (!msd_module_write_linked(&g_src, link_path)) {
            fprintf(stderr, "error: could not write linked source '%s'\n", link_path);
            return 1;
        }
        fprintf(stdout, "ok: linked source written to %s\n", link_path);
        return 0;
    }

    if (strcmp(mode, "aot-run") == 0) {
        cache_path_final = cache_path_arg;
        if (!cache_path_final) {
            if (!msd_aot_default_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive AOT cache path\n");
                return 1;
            }
            cache_path_final = cache_path;
        }
        aot_hit = 0;
        if (msd_aot_read_info(cache_path_final, &g_aot_info) && msd_aot_matches(&g_aot_info, &g_src, &g_mods)) {
            if (msd_aot_load(cache_path_final, &g_aot_info, g_bc_canon, MSD_MAX_BC, g_bc_atoms_canon, MSD_MAX_BC_CONSTS)) {
                g_arena.bc = g_bc_canon;
                g_arena.bc_count = g_aot_info.bc_count;
                g_arena.bc_atoms = g_bc_atoms_canon;
                g_arena.bc_atom_count = g_aot_info.bc_atom_count;
                aot_hit = 1;
            }
        }
        if (!aot_hit) {
            if (!msd_lex_source(&g_src, &g_arena)) {
                fprintf(stderr, "error: lexer failed\n");
                return 1;
            }
            if (!msd_parse_tokens(&g_src, &g_arena)) {
                fprintf(stderr, "error: parser failed\n");
                return 1;
            }
            msd_syntax_validate(&g_src, &g_arena, strict);
            syntax_errors = g_arena.error_count;
            if (syntax_errors != 0) {
                msd_print_errors_from(&g_src, &g_arena, 0, stdout);
                return 2;
            }
            detected_profile = msd_profile_detect(&g_src, &g_arena);
            effective_profile = msd_profile_resolve(&g_src, &g_arena, requested_profile);
            msd_profile_set_active(effective_profile);
            msd_semantic_validate_profile(&g_src, &g_arena, strict, requested_profile);
            if (g_arena.error_count != 0) {
                msd_print_errors_from(&g_src, &g_arena, 0, stdout);
                return 2;
            }
            if (!msd_lower_to_ir(&g_src, &g_arena, g_ir_raw, MSD_MAX_IR)) {
                fprintf(stderr, "error: IR lowering failed\n");
                return 1;
            }
            ir_raw_count = g_arena.ir_count;
            if (!msd_build_phase4_pipeline(&g_src, &g_arena, ir_raw_count, &canon_section_count, &canon_ir_count, &canon_bc_count, &canon_bc_atom_count)) {
                fprintf(stderr, "error: canonicalization failed\n");
                return 1;
            }
            verify_start = g_arena.error_count;
            if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
                return 2;
            }
            if (!msd_aot_save(cache_path_final, &g_src, &g_mods, &g_arena, &g_verify_report)) {
                fprintf(stderr, "error: could not write AOT cache '%s'\n", cache_path_final);
                return 1;
            }
        }
        fprintf(stdout, "aot-cache: %s\n", aot_hit ? "hit" : "rebuilt");
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        return msd_emit_runtime(&g_src, &g_arena, ticks, 0);
    }

    if (!msd_lex_source(&g_src, &g_arena)) {
        fprintf(stderr, "error: lexer failed\n");
        return 1;
    }
    if (strcmp(mode, "lex") == 0) {
        msd_lexer_dump(&g_src, &g_arena, stdout);
        return 0;
    }
    if (!msd_parse_tokens(&g_src, &g_arena)) {
        fprintf(stderr, "error: parser failed\n");
        return 1;
    }
    msd_syntax_validate(&g_src, &g_arena, strict);
    syntax_errors = g_arena.error_count;

    if (strcmp(mode, "ast") == 0) {
        msd_ast_dump(&g_src, &g_arena, stdout);
        return 0;
    }
    if (strcmp(mode, "syntax") == 0) {
        if (syntax_errors == 0) {
            fprintf(stdout, "ok: syntax accepted\n");
        } else {
            msd_print_errors_from(&g_src, &g_arena, 0, stdout);
        }
        return syntax_errors == 0 ? 0 : 2;
    }
    if (syntax_errors != 0) {
        msd_print_errors_from(&g_src, &g_arena, 0, stdout);
        return 2;
    }

    detected_profile = msd_profile_detect(&g_src, &g_arena);
    effective_profile = msd_profile_resolve(&g_src, &g_arena, requested_profile);
    msd_profile_set_active(effective_profile);

    if (strcmp(mode, "profile") == 0) {
        msd_profile_print_summary(stdout, requested_profile, detected_profile, effective_profile);
        return 0;
    }
    if (strcmp(mode, "words") == 0) {
        msd_profile_print_summary(stdout, requested_profile, detected_profile, effective_profile);
        fprintf(stdout, "\n");
        msd_profile_print_words(stdout, effective_profile);
        return 0;
    }

    msd_semantic_validate_profile(&g_src, &g_arena, strict, requested_profile);
    semantic_errors = g_arena.error_count - syntax_errors;

    if (strcmp(mode, "sem") == 0) {
        if (semantic_errors == 0) {
            fprintf(stdout, "ok: semantic pass accepted\n");
        } else {
            msd_print_errors_from(&g_src, &g_arena, syntax_errors, stdout);
        }
        return semantic_errors == 0 ? 0 : 2;
    }
    if (strcmp(mode, "check") == 0) {
        if (g_arena.error_count == 0) {
            fprintf(stdout, "ok: syntax and semantics accepted\n");
        } else {
            msd_print_errors_from(&g_src, &g_arena, 0, stdout);
        }
        return g_arena.error_count == 0 ? 0 : 2;
    }

    if (!msd_lower_to_ir(&g_src, &g_arena, g_ir_raw, MSD_MAX_IR)) {
        fprintf(stderr, "error: IR lowering failed\n");
        return 1;
    }
    ir_raw_count = g_arena.ir_count;

    if (strcmp(mode, "ir") == 0) {
        g_arena.ir = g_ir_raw;
        g_arena.ir_count = ir_raw_count;
        msd_ir_dump(&g_src, &g_arena, stdout);
        return 0;
    }

    if (strcmp(mode, "ssa") == 0) {
        msd_canon_stats_init(&g_canon_stats);
        ssa_count = msd_build_ssa(&g_src, &g_arena, g_ir_raw, ir_raw_count, g_ssa, MSD_MAX_IR, &g_canon_stats);
        if (ssa_count <= 0) {
            fprintf(stderr, "error: SSA build failed\n");
            return 1;
        }
        msd_canon_dump_summary(&g_canon_stats, stdout);
        fprintf(stdout, "\n== SSA ==\n");
        msd_ssa_dump(&g_src, &g_arena, g_ssa, ssa_count, stdout);
        return 0;
    }

    if (strcmp(mode, "canon") == 0 || strcmp(mode, "cast") == 0 || strcmp(mode, "aot") == 0) {
        if (!msd_build_phase4_pipeline(&g_src, &g_arena, ir_raw_count, &canon_section_count, &canon_ir_count, &canon_bc_count, &canon_bc_atom_count)) {
            fprintf(stderr, "error: canonicalization failed\n");
            return 1;
        }
        if (strcmp(mode, "canon") == 0) {
            fprintf(stdout, "== CANON SUMMARY ==\n");
            msd_canon_dump_summary(&g_canon_stats, stdout);
            fprintf(stdout, "\n== CANON SECTIONS ==\n");
            msd_canon_dump_sections(g_canon_sections, canon_section_count, stdout);
            fprintf(stdout, "\n== CANON IR ==\n");
            g_arena.ir = g_ir_canon;
            g_arena.ir_count = canon_ir_count;
            msd_ir_dump(&g_src, &g_arena, stdout);
            return 0;
        }
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        if (strcmp(mode, "cast") == 0) {
            const char *ast_path;
            ast_path = out_path;
            plan_count = 0;
            for (i = 0; i < canon_section_count; ++i) plan_count += g_canon_sections[i].plan_count;
            if (!ast_path) {
                if (!msd_astbin_default_path(path, cache_path, sizeof(cache_path))) {
                    fprintf(stderr, "error: could not derive canonical AST path\n");
                    return 1;
                }
                ast_path = cache_path;
            }
            if (!msd_astbin_save(ast_path, &g_src, &g_arena, g_canon_sections, canon_section_count, g_canon_plans, plan_count)) {
                fprintf(stderr, "error: could not write canonical AST snapshot '%s'\n", ast_path);
                return 1;
            }
            fprintf(stdout, "ok: canonical AST snapshot written to %s\n", ast_path);
            return 0;
        }
        if (strcmp(mode, "aot") == 0) {
            cache_path_final = out_path;
            if (!cache_path_final) {
                if (!msd_aot_default_path(path, cache_path, sizeof(cache_path))) {
                    fprintf(stderr, "error: could not derive AOT cache path\n");
                    return 1;
                }
                cache_path_final = cache_path;
            }
            if (!msd_aot_save(cache_path_final, &g_src, &g_mods, &g_arena, &g_verify_report)) {
                fprintf(stderr, "error: could not write AOT cache '%s'\n", cache_path_final);
                return 1;
            }
            fprintf(stdout, "ok: AOT cache written to %s\n", cache_path_final);
            return 0;
        }
    }

    if (!msd_build_phase3_pipeline(&g_src, &g_arena, &ir_raw_count, &ir_opt_count, &bc_opt_count, &bc_opt_atom_count)) {
        fprintf(stderr, "error: phase 3 compilation failed\n");
        return 1;
    }

    if (strcmp(mode, "bc") == 0) {
        msd_bytecode_dump(&g_src, &g_arena, stdout);
        return 0;
    }
    if (strcmp(mode, "verify") == 0) {
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        msd_verify_dump_report(&g_verify_report, stdout);
        return 0;
    }
    if (strcmp(mode, "opt") == 0) {
        fprintf(stdout, "== OPT SUMMARY ==\n");
        msd_opt_dump_summary(&g_opt_stats, stdout);
        fprintf(stdout, "\n== OPT IR ==\n");
        g_arena.ir = g_ir_opt;
        g_arena.ir_count = ir_opt_count;
        msd_ir_dump(&g_src, &g_arena, stdout);
        fprintf(stdout, "\n== OPT BYTECODE ==\n");
        g_arena.bc = g_bc_opt;
        g_arena.bc_count = bc_opt_count;
        g_arena.bc_atoms = g_bc_atoms_opt;
        g_arena.bc_atom_count = bc_opt_atom_count;
        msd_bytecode_dump(&g_src, &g_arena, stdout);
        return 0;
    }
    if (strcmp(mode, "cache") == 0) {
        cache_path_final = out_path;
        if (!cache_path_final) {
            if (!msd_cache_default_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive cache path\n");
                return 1;
            }
            cache_path_final = cache_path;
        }
        cache_flags = MSD_CACHE_FLAG_HAS_SOURCE | MSD_CACHE_FLAG_OPT_IR | MSD_CACHE_FLAG_OPT_BC;
        if (!msd_cache_save(cache_path_final, &g_src, &g_arena, cache_flags)) {
            fprintf(stderr, "error: could not write cache '%s'\n", cache_path_final);
            return 1;
        }
        fprintf(stdout, "ok: cache written to %s\n", cache_path_final);
        return 0;
    }
    if (strcmp(mode, "cache-inc") == 0) {
        cache_path_final = out_path;
        if (!cache_path_final) {
            if (!msd_cache_inc_default_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive incremental cache path\n");
                return 1;
            }
            cache_path_final = cache_path;
        }
        if (!msd_build_phase4_pipeline(&g_src, &g_arena, ir_raw_count, &canon_section_count, &canon_ir_count, &canon_bc_count, &canon_bc_atom_count)) {
            fprintf(stderr, "error: canonicalization failed\n");
            return 1;
        }
        plan_count = 0;
        for (i = 0; i < canon_section_count; ++i) plan_count += g_canon_sections[i].plan_count;
        if (!msd_cache_inc_save(cache_path_final, &g_src, g_canon_sections, canon_section_count, g_canon_plans, plan_count)) {
            fprintf(stderr, "error: could not write incremental cache '%s'\n", cache_path_final);
            return 1;
        }
        fprintf(stdout, "ok: incremental cache written to %s\n", cache_path_final);
        fprintf(stdout, "sections=%d plans=%d\n", canon_section_count, plan_count);
        return 0;
    }
    if (strcmp(mode, "cache-run") == 0) {
        cache_path_final = cache_path_arg;
        if (!cache_path_final) {
            if (!msd_cache_default_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive cache path\n");
                return 1;
            }
            cache_path_final = cache_path;
        }
        cache_hit = 0;
        if (msd_cache_read_info(cache_path_final, &g_cache_info) && msd_cache_matches_source(&g_cache_info, &g_src)) {
            if (msd_cache_load(cache_path_final, &g_src, &g_arena, g_ir_opt, MSD_MAX_IR, g_bc_opt, MSD_MAX_BC, g_bc_atoms_opt, MSD_MAX_BC_CONSTS, &g_cache_info)) {
                cache_hit = 1;
            }
        }
        if (!cache_hit) {
            if (!msd_build_phase3_pipeline(&g_src, &g_arena, &ir_raw_count, &ir_opt_count, &bc_opt_count, &bc_opt_atom_count)) {
                fprintf(stderr, "error: phase 3 compilation failed\n");
                return 1;
            }
            cache_flags = MSD_CACHE_FLAG_HAS_SOURCE | MSD_CACHE_FLAG_OPT_IR | MSD_CACHE_FLAG_OPT_BC;
            msd_cache_save(cache_path_final, &g_src, &g_arena, cache_flags);
        }
        fprintf(stdout, "cache: %s\n", cache_hit ? "hit" : "rebuilt");
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        return msd_emit_runtime(&g_src, &g_arena, ticks, 0);
    }
    if (strcmp(mode, "cache-inc-run") == 0) {
        cache_path_final = cache_path_arg;
        if (!cache_path_final) {
            if (!msd_cache_inc_default_path(path, cache_path, sizeof(cache_path))) {
                fprintf(stderr, "error: could not derive incremental cache path\n");
                return 1;
            }
            cache_path_final = cache_path;
        }
        if (!msd_build_incremental_pipeline(&g_src, &g_arena, cache_path_final, &canon_section_count, &plan_count, &canon_ir_count, &canon_bc_count, &canon_bc_atom_count, &cache_hits, &cache_misses)) {
            fprintf(stderr, "error: incremental compilation failed\n");
            return 1;
        }
        if (!msd_cache_inc_save(cache_path_final, &g_src, g_canon_sections, canon_section_count, g_canon_plans, plan_count)) {
            fprintf(stderr, "error: could not refresh incremental cache '%s'\n", cache_path_final);
            return 1;
        }
        fprintf(stdout, "inc-cache: hits=%d misses=%d\n", cache_hits, cache_misses);
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        return msd_emit_runtime(&g_src, &g_arena, ticks, 0);
    }
    if (strcmp(mode, "all") == 0) {
        fprintf(stdout, "== DEPS ==\n");
        msd_module_print_info(&g_mods, stdout);
        fprintf(stdout, "\n== TOKENS ==\n");
        msd_lexer_dump(&g_src, &g_arena, stdout);
        fprintf(stdout, "\n== AST ==\n");
        msd_ast_dump(&g_src, &g_arena, stdout);
        fprintf(stdout, "\n== OPT SUMMARY ==\n");
        msd_opt_dump_summary(&g_opt_stats, stdout);
        fprintf(stdout, "\n== RAW IR ==\n");
        g_arena.ir = g_ir_raw;
        g_arena.ir_count = ir_raw_count;
        msd_ir_dump(&g_src, &g_arena, stdout);
        fprintf(stdout, "\n== OPT BYTECODE ==\n");
        g_arena.ir = g_ir_opt;
        g_arena.ir_count = ir_opt_count;
        g_arena.bc = g_bc_opt;
        g_arena.bc_count = bc_opt_count;
        g_arena.bc_atoms = g_bc_atoms_opt;
        g_arena.bc_atom_count = bc_opt_atom_count;
        msd_bytecode_dump(&g_src, &g_arena, stdout);
        fprintf(stdout, "\n== VERIFY ==\n");
        verify_start = g_arena.error_count;
        if (msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            msd_verify_dump_report(&g_verify_report, stdout);
        }
        fprintf(stdout, "\n== ERRORS ==\n");
        if (g_arena.error_count == 0) {
            fprintf(stdout, "none\n");
        } else {
            msd_print_errors_from(&g_src, &g_arena, 0, stdout);
        }
        return 0;
    }
    if (strcmp(mode, "timeline") == 0) {
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        return msd_emit_runtime(&g_src, &g_arena, ticks, 1);
    }
    if (strcmp(mode, "run") == 0) {
        verify_start = g_arena.error_count;
        if (!msd_verify_active_bc(&g_src, &g_arena, verify_start, stdout)) {
            return 2;
        }
        return msd_emit_runtime(&g_src, &g_arena, ticks, 0);
    }

    msd_print_usage(stderr);
    return 1;
}
