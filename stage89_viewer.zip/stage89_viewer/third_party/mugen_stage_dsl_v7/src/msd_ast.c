#include "msd_arena.h"

const char *msd_atom_type_name(MsdAtomType type)
{
    switch (type) {
    case MSD_ATOM_IDENT: return "ident";
    case MSD_ATOM_STRING: return "string";
    case MSD_ATOM_NUMBER: return "number";
    }
    return "?";
}

const char *msd_section_kind_name(MsdSectionKind kind)
{
    switch (kind) {
    case MSD_SECTION_INFO: return "Info";
    case MSD_SECTION_CAMERA: return "Camera";
    case MSD_SECTION_PLAYERINFO: return "PlayerInfo";
    case MSD_SECTION_BOUND: return "Bound";
    case MSD_SECTION_STAGEINFO: return "StageInfo";
    case MSD_SECTION_SHADOW: return "Shadow";
    case MSD_SECTION_REFLECTION: return "Reflection";
    case MSD_SECTION_MUSIC: return "Music";
    case MSD_SECTION_BGDEF: return "BGDef";
    case MSD_SECTION_BG: return "BG";
    case MSD_SECTION_BGCTRLDEF: return "BGCtrlDef";
    case MSD_SECTION_BGCTRL: return "BGCtrl";
    case MSD_SECTION_BEGIN_ACTION: return "BeginAction";
    default: return "Unknown";
    }
}

void msd_atom_to_text(const MsdSource *src, const MsdAtom *atom, char *buf, int cap)
{
    if (!src || !atom || !buf || cap <= 0) {
        return;
    }
    if (atom->type == MSD_ATOM_NUMBER) {
        if (atom->is_fixed) {
            msd_fixed_to_string(atom->number, buf, cap);
        } else {
            sprintf(buf, "%ld", msd_fixed_to_int(atom->number));
        }
    } else if (atom->type == MSD_ATOM_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, atom->offset, atom->length);
    } else {
        msd_copy_span(buf, cap, src->data, atom->offset, atom->length);
    }
}

void msd_ast_dump(const MsdSource *src, const struct MsdArena *arena, FILE *out)
{
    int si;
    int ii;
    int vi;
    char buf[128];
    const MsdAstSection *sec;
    const MsdAstItem *item;

    if (!src || !arena || !out) {
        return;
    }

    for (si = 0; si < arena->section_count; ++si) {
        sec = &arena->sections[si];
        fprintf(out, "section[%d] kind=%s header=", si, msd_section_kind_name(sec->kind));
        for (vi = 0; vi < sec->header_count; ++vi) {
            msd_atom_to_text(src, &arena->atoms[sec->header_start + vi], buf, sizeof(buf));
            if (vi > 0) fprintf(out, " ");
            fprintf(out, "%s", buf);
        }
        fprintf(out, "\n");
        for (ii = 0; ii < sec->item_count; ++ii) {
            item = &arena->items[sec->first_item + ii];
            fprintf(out, "  item[%d] %s ", ii, item->kind == MSD_ITEM_ASSIGN ? "assign" : "row");
            if (item->kind == MSD_ITEM_ASSIGN) {
                msd_atom_to_text(src, &arena->atoms[item->key_atom], buf, sizeof(buf));
                fprintf(out, "%s = ", buf);
            }
            for (vi = 0; vi < item->value_count; ++vi) {
                msd_atom_to_text(src, &arena->atoms[item->value_start + vi], buf, sizeof(buf));
                if (vi > 0) fprintf(out, ", ");
                fprintf(out, "%s", buf);
            }
            fprintf(out, "\n");
        }
    }
}
