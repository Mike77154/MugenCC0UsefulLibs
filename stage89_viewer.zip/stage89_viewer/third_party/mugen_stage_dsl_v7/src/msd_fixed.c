#include "msd_fixed.h"

msd_fixed_t msd_fixed_from_int(long value)
{
    return (msd_fixed_t) (value << MSD_FIXED_FRAC_BITS);
}

msd_fixed_t msd_fixed_from_parts(long whole, long frac, long denom)
{
    msd_fixed_t base;
    long part;
    if (denom <= 0) {
        return msd_fixed_from_int(whole);
    }
    base = msd_fixed_from_int(whole);
    part = (long) ((frac * (long) MSD_FIXED_ONE) / denom);
    return base + (msd_fixed_t) part;
}

msd_fixed_t msd_fixed_from_span(const char *src, int offset, int length, int *ok, int *is_fixed)
{
    int i;
    int sign;
    long whole;
    long frac;
    long denom;
    int seen_dot;
    int frac_digits;
    int ch;
    msd_fixed_t value;

    if (ok) *ok = 0;
    if (is_fixed) *is_fixed = 0;
    if (!src || length <= 0) {
        return 0;
    }

    i = 0;
    sign = 1;
    if (src[offset + i] == '-') {
        sign = -1;
        ++i;
    } else if (src[offset + i] == '+') {
        ++i;
    }

    whole = 0;
    frac = 0;
    denom = 1;
    seen_dot = 0;
    frac_digits = 0;

    while (i < length) {
        ch = (unsigned char) src[offset + i];
        if (ch == '.') {
            if (seen_dot) {
                return 0;
            }
            seen_dot = 1;
            if (is_fixed) *is_fixed = 1;
        } else if (ch >= '0' && ch <= '9') {
            if (!seen_dot) {
                whole = whole * 10 + (ch - '0');
            } else if (frac_digits < 4) {
                frac = frac * 10 + (ch - '0');
                denom *= 10;
                ++frac_digits;
            }
        } else {
            return 0;
        }
        ++i;
    }

    value = msd_fixed_from_parts(whole, frac, denom);
    if (sign < 0) {
        value = -value;
    }
    if (ok) *ok = 1;
    return value;
}

long msd_fixed_to_int(msd_fixed_t value)
{
    return (long) (value >> MSD_FIXED_FRAC_BITS);
}

msd_fixed_t msd_fixed_abs(msd_fixed_t value)
{
    return value < 0 ? -value : value;
}

msd_fixed_t msd_fixed_mul(msd_fixed_t a, msd_fixed_t b)
{
    unsigned long ua;
    unsigned long ub;
    unsigned long ai;
    unsigned long af;
    unsigned long bi;
    unsigned long bf;
    unsigned long result;
    int neg;

    neg = 0;
    if (a < 0) {
        neg = !neg;
        ua = (unsigned long) (-a);
    } else {
        ua = (unsigned long) a;
    }
    if (b < 0) {
        neg = !neg;
        ub = (unsigned long) (-b);
    } else {
        ub = (unsigned long) b;
    }

    ai = ua >> MSD_FIXED_FRAC_BITS;
    af = ua & 0xFFFFUL;
    bi = ub >> MSD_FIXED_FRAC_BITS;
    bf = ub & 0xFFFFUL;

    result = ((ai * bi) << MSD_FIXED_FRAC_BITS) + (ai * bf) + (bi * af) + ((af * bf) >> MSD_FIXED_FRAC_BITS);

    if (neg) {
        return -(msd_fixed_t) result;
    }
    return (msd_fixed_t) result;
}

msd_fixed_t msd_fixed_div(msd_fixed_t a, msd_fixed_t b, int *ok)
{
    unsigned long ua;
    unsigned long ub;
    unsigned long q;
    unsigned long r;
    int i;
    int neg;

    if (ok) *ok = 0;
    if (b == 0) {
        return 0;
    }

    neg = 0;
    ua = (unsigned long) (a < 0 ? -a : a);
    ub = (unsigned long) (b < 0 ? -b : b);
    if ((a < 0) != (b < 0)) {
        neg = 1;
    }

    q = (ua / ub) << MSD_FIXED_FRAC_BITS;
    r = ua % ub;

    for (i = MSD_FIXED_FRAC_BITS - 1; i >= 0; --i) {
        r <<= 1;
        if (r >= ub) {
            r -= ub;
            q |= (1UL << i);
        }
    }

    if (ok) *ok = 1;
    if (neg) {
        return -(msd_fixed_t) q;
    }
    return (msd_fixed_t) q;
}

void msd_fixed_to_string(msd_fixed_t value, char *buf, int cap)
{
    char tmp[64];
    unsigned long frac;
    unsigned long dec;
    long whole;

    if (!buf || cap <= 0) {
        return;
    }
    whole = msd_fixed_to_int(value);
    frac = (unsigned long) (msd_fixed_abs(value) & 0xFFFFL);
    dec = (frac * 10000UL + 32768UL) / 65536UL;
    if (dec >= 10000UL) {
        if (value >= 0) {
            whole += 1;
        } else {
            whole -= 1;
        }
        dec = 0;
    }
    sprintf(tmp, "%ld.%04lu", whole, dec);
    msd_trim_trailing_zeros(tmp);
    msd_copy_span(buf, cap, tmp, 0, (int) strlen(tmp));
}
