#include "msd_cache.h"
#include "msd_fixed.h"

#define MSD_CACHE_VERSION 4

static const char msd_cache_magic[8] = { 'M','S','D','C','A','4','\r','\n' };

typedef struct MsdCacheHeader {
    char magic[8];
    int version;
    int flags;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int atom_count;
    int section_count;
    int item_count;
    int ir_count;
    int bc_count;
    int bc_atom_count;
    int path_len;
} MsdCacheHeader;

static int msd_write_int(FILE *fp, int value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_write_long(FILE *fp, long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_write_ulong(FILE *fp, unsigned long value)
{
    return fwrite(&value, sizeof(value), 1u, fp) == 1u;
}

static int msd_read_int(FILE *fp, int *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_read_long(FILE *fp, long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_read_ulong(FILE *fp, unsigned long *value)
{
    return fread(value, sizeof(*value), 1u, fp) == 1u;
}

static int msd_write_atom(FILE *fp, const MsdAtom *atom)
{
    if (!msd_write_int(fp, (int) atom->type)) return 0;
    if (!msd_write_int(fp, atom->offset)) return 0;
    if (!msd_write_int(fp, atom->length)) return 0;
    if (!msd_write_long(fp, atom->number)) return 0;
    if (!msd_write_int(fp, atom->is_fixed)) return 0;
    if (!msd_write_int(fp, atom->line)) return 0;
    if (!msd_write_int(fp, atom->col)) return 0;
    return 1;
}

static int msd_read_atom(FILE *fp, MsdAtom *atom)
{
    int type;
    long num;
    if (!msd_read_int(fp, &type)) return 0;
    atom->type = (MsdAtomType) type;
    if (!msd_read_int(fp, &atom->offset)) return 0;
    if (!msd_read_int(fp, &atom->length)) return 0;
    if (!msd_read_long(fp, &num)) return 0;
    atom->number = (msd_fixed_t) num;
    if (!msd_read_int(fp, &atom->is_fixed)) return 0;
    if (!msd_read_int(fp, &atom->line)) return 0;
    if (!msd_read_int(fp, &atom->col)) return 0;
    return 1;
}

static int msd_write_section(FILE *fp, const MsdAstSection *sec)
{
    if (!msd_write_int(fp, (int) sec->kind)) return 0;
    if (!msd_write_int(fp, sec->header_start)) return 0;
    if (!msd_write_int(fp, sec->header_count)) return 0;
    if (!msd_write_int(fp, sec->first_item)) return 0;
    if (!msd_write_int(fp, sec->item_count)) return 0;
    if (!msd_write_int(fp, sec->line)) return 0;
    if (!msd_write_int(fp, sec->col)) return 0;
    return 1;
}

static int msd_read_section(FILE *fp, MsdAstSection *sec)
{
    int kind;
    if (!msd_read_int(fp, &kind)) return 0;
    sec->kind = (MsdSectionKind) kind;
    if (!msd_read_int(fp, &sec->header_start)) return 0;
    if (!msd_read_int(fp, &sec->header_count)) return 0;
    if (!msd_read_int(fp, &sec->first_item)) return 0;
    if (!msd_read_int(fp, &sec->item_count)) return 0;
    if (!msd_read_int(fp, &sec->line)) return 0;
    if (!msd_read_int(fp, &sec->col)) return 0;
    return 1;
}

static int msd_write_item(FILE *fp, const MsdAstItem *item)
{
    if (!msd_write_int(fp, (int) item->kind)) return 0;
    if (!msd_write_int(fp, item->key_atom)) return 0;
    if (!msd_write_int(fp, item->value_start)) return 0;
    if (!msd_write_int(fp, item->value_count)) return 0;
    if (!msd_write_int(fp, item->line)) return 0;
    if (!msd_write_int(fp, item->col)) return 0;
    return 1;
}

static int msd_read_item(FILE *fp, MsdAstItem *item)
{
    int kind;
    if (!msd_read_int(fp, &kind)) return 0;
    item->kind = (MsdItemKind) kind;
    if (!msd_read_int(fp, &item->key_atom)) return 0;
    if (!msd_read_int(fp, &item->value_start)) return 0;
    if (!msd_read_int(fp, &item->value_count)) return 0;
    if (!msd_read_int(fp, &item->line)) return 0;
    if (!msd_read_int(fp, &item->col)) return 0;
    return 1;
}

static int msd_write_ir(FILE *fp, const MsdIRInstr *ir)
{
    if (!msd_write_int(fp, (int) ir->op)) return 0;
    if (!msd_write_int(fp, (int) ir->profile_tag)) return 0;
    if (!msd_write_int(fp, (int) ir->section_kind)) return 0;
    if (!msd_write_int(fp, ir->header_start)) return 0;
    if (!msd_write_int(fp, ir->header_count)) return 0;
    if (!msd_write_int(fp, ir->key_atom)) return 0;
    if (!msd_write_int(fp, ir->value_start)) return 0;
    if (!msd_write_int(fp, ir->value_count)) return 0;
    if (!msd_write_int(fp, ir->line)) return 0;
    if (!msd_write_int(fp, ir->col)) return 0;
    return 1;
}

static int msd_read_ir(FILE *fp, MsdIRInstr *ir)
{
    int op;
    int profile;
    int kind;
    if (!msd_read_int(fp, &op)) return 0;
    ir->op = (MsdIROp) op;
    if (!msd_read_int(fp, &profile)) return 0;
    ir->profile_tag = (MsdProfile) profile;
    if (!msd_read_int(fp, &kind)) return 0;
    ir->section_kind = (MsdSectionKind) kind;
    if (!msd_read_int(fp, &ir->header_start)) return 0;
    if (!msd_read_int(fp, &ir->header_count)) return 0;
    if (!msd_read_int(fp, &ir->key_atom)) return 0;
    if (!msd_read_int(fp, &ir->value_start)) return 0;
    if (!msd_read_int(fp, &ir->value_count)) return 0;
    if (!msd_read_int(fp, &ir->line)) return 0;
    if (!msd_read_int(fp, &ir->col)) return 0;
    return 1;
}

static int msd_write_bc_atom(FILE *fp, const MsdBCAtom *atom)
{
    if (!msd_write_int(fp, (int) atom->type)) return 0;
    if (!msd_write_int(fp, atom->offset)) return 0;
    if (!msd_write_int(fp, atom->length)) return 0;
    if (!msd_write_long(fp, atom->number)) return 0;
    if (!msd_write_int(fp, atom->is_fixed)) return 0;
    if (!msd_write_int(fp, atom->line)) return 0;
    if (!msd_write_int(fp, atom->col)) return 0;
    return 1;
}

static int msd_read_bc_atom(FILE *fp, MsdBCAtom *atom)
{
    int type;
    long num;
    if (!msd_read_int(fp, &type)) return 0;
    atom->type = (MsdAtomType) type;
    if (!msd_read_int(fp, &atom->offset)) return 0;
    if (!msd_read_int(fp, &atom->length)) return 0;
    if (!msd_read_long(fp, &num)) return 0;
    atom->number = (msd_fixed_t) num;
    if (!msd_read_int(fp, &atom->is_fixed)) return 0;
    if (!msd_read_int(fp, &atom->line)) return 0;
    if (!msd_read_int(fp, &atom->col)) return 0;
    return 1;
}

static int msd_write_bc(FILE *fp, const MsdBCInstr *bc)
{
    if (!msd_write_int(fp, (int) bc->op)) return 0;
    if (!msd_write_int(fp, (int) bc->profile_tag)) return 0;
    if (!msd_write_int(fp, (int) bc->section_kind)) return 0;
    if (!msd_write_int(fp, (int) bc->word_id)) return 0;
    if (!msd_write_int(fp, bc->name_atom)) return 0;
    if (!msd_write_int(fp, bc->const_start)) return 0;
    if (!msd_write_int(fp, bc->const_count)) return 0;
    if (!msd_write_int(fp, bc->line)) return 0;
    if (!msd_write_int(fp, bc->col)) return 0;
    return 1;
}

static int msd_read_bc(FILE *fp, MsdBCInstr *bc)
{
    int op;
    int profile;
    int kind;
    int word;
    if (!msd_read_int(fp, &op)) return 0;
    bc->op = (MsdBCOp) op;
    if (!msd_read_int(fp, &profile)) return 0;
    bc->profile_tag = (MsdProfile) profile;
    if (!msd_read_int(fp, &kind)) return 0;
    bc->section_kind = (MsdSectionKind) kind;
    if (!msd_read_int(fp, &word)) return 0;
    bc->word_id = (MsdBuiltinId) word;
    if (!msd_read_int(fp, &bc->name_atom)) return 0;
    if (!msd_read_int(fp, &bc->const_start)) return 0;
    if (!msd_read_int(fp, &bc->const_count)) return 0;
    if (!msd_read_int(fp, &bc->line)) return 0;
    if (!msd_read_int(fp, &bc->col)) return 0;
    return 1;
}

unsigned long msd_hash_buffer(const char *data, int size)
{
    unsigned long hash;
    int i;
    hash = 2166136261UL;
    for (i = 0; i < size; ++i) {
        hash ^= (unsigned char) data[i];
        hash *= 16777619UL;
    }
    return hash;
}

unsigned long msd_cache_hash_source(const MsdSource *src)
{
    if (!src) return 0UL;
    return msd_hash_buffer(src->data, src->size);
}

int msd_cache_default_path(const char *input_path, char *out, int cap)
{
    int len;
    if (!input_path || !out || cap <= 0) return 0;
    len = (int) strlen(input_path);
    if (len >= 4 && msd_ascii_tolower((unsigned char) input_path[len - 4]) == '.' &&
        msd_ascii_tolower((unsigned char) input_path[len - 3]) == 'd' &&
        msd_ascii_tolower((unsigned char) input_path[len - 2]) == 'e' &&
        msd_ascii_tolower((unsigned char) input_path[len - 1]) == 'f') {
        if (len + 2 >= cap) return 0;
        memcpy(out, input_path, (size_t) (len - 3));
        strcpy(out + (len - 3), "msdc");
        return 1;
    }
    if (len + 5 >= cap) return 0;
    strcpy(out, input_path);
    strcat(out, ".msdc");
    return 1;
}

int msd_cache_matches_source(const MsdCacheInfo *info, const MsdSource *src)
{
    if (!info || !src) return 0;
    return info->source_size == src->size && info->source_hash == msd_cache_hash_source(src);
}

static int msd_cache_read_header(FILE *fp, MsdCacheInfo *info, MsdCacheHeader *hdr)
{
    int i;
    if (fread(hdr->magic, sizeof(hdr->magic), 1u, fp) != 1u) return 0;
    for (i = 0; i < 8; ++i) {
        if (hdr->magic[i] != msd_cache_magic[i]) return 0;
    }
    if (!msd_read_int(fp, &hdr->version)) return 0;
    if (!msd_read_int(fp, &hdr->flags)) return 0;
    if (!msd_read_int(fp, &hdr->int_size)) return 0;
    if (!msd_read_int(fp, &hdr->long_size)) return 0;
    if (!msd_read_int(fp, &hdr->fixed_frac_bits)) return 0;
    if (!msd_read_int(fp, &hdr->source_size)) return 0;
    if (!msd_read_ulong(fp, &hdr->source_hash)) return 0;
    if (!msd_read_int(fp, &hdr->atom_count)) return 0;
    if (!msd_read_int(fp, &hdr->section_count)) return 0;
    if (!msd_read_int(fp, &hdr->item_count)) return 0;
    if (!msd_read_int(fp, &hdr->ir_count)) return 0;
    if (!msd_read_int(fp, &hdr->bc_count)) return 0;
    if (!msd_read_int(fp, &hdr->bc_atom_count)) return 0;
    if (!msd_read_int(fp, &hdr->path_len)) return 0;
    if (info) {
        memset(info, 0, sizeof(*info));
        info->version = hdr->version;
        info->flags = hdr->flags;
        info->int_size = hdr->int_size;
        info->long_size = hdr->long_size;
        info->fixed_frac_bits = hdr->fixed_frac_bits;
        info->source_size = hdr->source_size;
        info->source_hash = hdr->source_hash;
        info->atom_count = hdr->atom_count;
        info->section_count = hdr->section_count;
        info->item_count = hdr->item_count;
        info->ir_count = hdr->ir_count;
        info->bc_count = hdr->bc_count;
        info->bc_atom_count = hdr->bc_atom_count;
    }
    return 1;
}

int msd_cache_read_info(const char *path, MsdCacheInfo *info)
{
    FILE *fp;
    MsdCacheHeader hdr;
    int n;
    if (!path || !info) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (!msd_cache_read_header(fp, info, &hdr)) {
        fclose(fp);
        return 0;
    }
    if (hdr.path_len < 0 || hdr.path_len >= (int) sizeof(info->source_path)) {
        fclose(fp);
        return 0;
    }
    n = hdr.path_len;
    if (n > 0 && fread(info->source_path, 1u, (size_t) n, fp) != (size_t) n) {
        fclose(fp);
        return 0;
    }
    info->source_path[n] = '\0';
    fclose(fp);
    return 1;
}

int msd_cache_save(const char *path, const MsdSource *src, const MsdArena *arena, int flags)
{
    FILE *fp;
    MsdCacheHeader hdr;
    int i;
    int path_len;

    if (!path || !src || !arena || !arena->ir || !arena->bc || !arena->bc_atoms) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;

    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, msd_cache_magic, sizeof(hdr.magic));
    hdr.version = MSD_CACHE_VERSION;
    hdr.flags = flags;
    hdr.int_size = (int) sizeof(int);
    hdr.long_size = (int) sizeof(long);
    hdr.fixed_frac_bits = MSD_FIXED_FRAC_BITS;
    hdr.source_size = src->size;
    hdr.source_hash = msd_cache_hash_source(src);
    hdr.atom_count = arena->atom_count;
    hdr.section_count = arena->section_count;
    hdr.item_count = arena->item_count;
    hdr.ir_count = arena->ir_count;
    hdr.bc_count = arena->bc_count;
    hdr.bc_atom_count = arena->bc_atom_count;
    path_len = (int) strlen(src->path);
    if (path_len >= (int) sizeof(src->path)) path_len = (int) sizeof(src->path) - 1;
    hdr.path_len = path_len;

    if (fwrite(hdr.magic, sizeof(hdr.magic), 1u, fp) != 1u) { fclose(fp); return 0; }
    if (!msd_write_int(fp, hdr.version) || !msd_write_int(fp, hdr.flags) || !msd_write_int(fp, hdr.int_size) || !msd_write_int(fp, hdr.long_size) || !msd_write_int(fp, hdr.fixed_frac_bits) || !msd_write_int(fp, hdr.source_size) || !msd_write_ulong(fp, hdr.source_hash) || !msd_write_int(fp, hdr.atom_count) || !msd_write_int(fp, hdr.section_count) || !msd_write_int(fp, hdr.item_count) || !msd_write_int(fp, hdr.ir_count) || !msd_write_int(fp, hdr.bc_count) || !msd_write_int(fp, hdr.bc_atom_count) || !msd_write_int(fp, hdr.path_len)) { fclose(fp); return 0; }
    if (path_len > 0 && fwrite(src->path, 1u, (size_t) path_len, fp) != (size_t) path_len) { fclose(fp); return 0; }
    if ((flags & MSD_CACHE_FLAG_HAS_SOURCE) && src->size > 0 && fwrite(src->data, 1u, (size_t) src->size, fp) != (size_t) src->size) { fclose(fp); return 0; }

    for (i = 0; i < arena->atom_count; ++i) if (!msd_write_atom(fp, &arena->atoms[i])) { fclose(fp); return 0; }
    for (i = 0; i < arena->section_count; ++i) if (!msd_write_section(fp, &arena->sections[i])) { fclose(fp); return 0; }
    for (i = 0; i < arena->item_count; ++i) if (!msd_write_item(fp, &arena->items[i])) { fclose(fp); return 0; }
    for (i = 0; i < arena->ir_count; ++i) if (!msd_write_ir(fp, &arena->ir[i])) { fclose(fp); return 0; }
    for (i = 0; i < arena->bc_count; ++i) if (!msd_write_bc(fp, &arena->bc[i])) { fclose(fp); return 0; }
    for (i = 0; i < arena->bc_atom_count; ++i) if (!msd_write_bc_atom(fp, &arena->bc_atoms[i])) { fclose(fp); return 0; }

    fclose(fp);
    return 1;
}

int msd_cache_load(const char *path, MsdSource *src, MsdArena *arena, MsdIRInstr *ir_storage, int ir_cap, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *bc_atoms, int bc_atom_cap, MsdCacheInfo *info)
{
    FILE *fp;
    MsdCacheHeader hdr;
    int i;
    int n;

    if (!path || !src || !arena || !ir_storage || !bc_storage || !bc_atoms) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (!msd_cache_read_header(fp, info, &hdr)) { fclose(fp); return 0; }
    if (hdr.version != MSD_CACHE_VERSION || hdr.int_size != (int) sizeof(int) || hdr.long_size != (int) sizeof(long) || hdr.fixed_frac_bits != MSD_FIXED_FRAC_BITS) { fclose(fp); return 0; }
    if (hdr.atom_count > MSD_MAX_ATOMS || hdr.section_count > MSD_MAX_SECTIONS || hdr.item_count > MSD_MAX_ITEMS || hdr.ir_count > ir_cap || hdr.bc_count > bc_cap || hdr.bc_atom_count > bc_atom_cap || hdr.source_size > MSD_MAX_SOURCE_BYTES) { fclose(fp); return 0; }
    if (hdr.path_len < 0 || hdr.path_len >= (int) sizeof(src->path)) { fclose(fp); return 0; }

    memset(src, 0, sizeof(*src));
    n = hdr.path_len;
    if (n > 0 && fread(src->path, 1u, (size_t) n, fp) != (size_t) n) { fclose(fp); return 0; }
    src->path[n] = '\0';
    if (hdr.flags & MSD_CACHE_FLAG_HAS_SOURCE) {
        if (hdr.source_size > 0 && fread(src->data, 1u, (size_t) hdr.source_size, fp) != (size_t) hdr.source_size) { fclose(fp); return 0; }
        src->size = hdr.source_size;
        src->data[src->size] = '\0';
    }

    msd_arena_init(arena);
    arena->atom_count = hdr.atom_count;
    arena->section_count = hdr.section_count;
    arena->item_count = hdr.item_count;
    arena->ir = ir_storage;
    arena->ir_count = hdr.ir_count;
    arena->bc = bc_storage;
    arena->bc_count = hdr.bc_count;
    arena->bc_atoms = bc_atoms;
    arena->bc_atom_count = hdr.bc_atom_count;

    for (i = 0; i < hdr.atom_count; ++i) if (!msd_read_atom(fp, &arena->atoms[i])) { fclose(fp); return 0; }
    for (i = 0; i < hdr.section_count; ++i) if (!msd_read_section(fp, &arena->sections[i])) { fclose(fp); return 0; }
    for (i = 0; i < hdr.item_count; ++i) if (!msd_read_item(fp, &arena->items[i])) { fclose(fp); return 0; }
    for (i = 0; i < hdr.ir_count; ++i) if (!msd_read_ir(fp, &arena->ir[i])) { fclose(fp); return 0; }
    for (i = 0; i < hdr.bc_count; ++i) if (!msd_read_bc(fp, &arena->bc[i])) { fclose(fp); return 0; }
    for (i = 0; i < hdr.bc_atom_count; ++i) if (!msd_read_bc_atom(fp, &arena->bc_atoms[i])) { fclose(fp); return 0; }

    fclose(fp);
    return 1;
}

void msd_cache_print_info(const MsdCacheInfo *info, FILE *out)
{
    if (!info || !out) return;
    fprintf(out, "cache version: %d\n", info->version);
    fprintf(out, "flags: 0x%X\n", info->flags);
    fprintf(out, "abi: int=%d long=%d fixed=%d\n", info->int_size, info->long_size, info->fixed_frac_bits);
    fprintf(out, "source: %s\n", info->source_path);
    fprintf(out, "source_size: %d\n", info->source_size);
    fprintf(out, "source_hash: %lu\n", info->source_hash);
    fprintf(out, "atoms=%d sections=%d items=%d ir=%d bc=%d bc_atoms=%d\n", info->atom_count, info->section_count, info->item_count, info->ir_count, info->bc_count, info->bc_atom_count);
}
