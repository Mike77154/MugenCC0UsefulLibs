#include "msd_runtime.h"

static int msd_atom_to_int(const MsdBCAtom *atom)
{
    return atom && atom->type == MSD_ATOM_NUMBER ? (int) msd_fixed_to_int(atom->number) : 0;
}

static msd_fixed_t msd_atom_to_fixed(const MsdBCAtom *atom)
{
    return atom && atom->type == MSD_ATOM_NUMBER ? atom->number : 0;
}

static void msd_atom_to_text_local(const MsdSource *src, const MsdBCAtom *atom, char *buf, int cap)
{
    if (atom->type == MSD_ATOM_NUMBER) {
        if (atom->is_fixed) {
            msd_fixed_to_string(atom->number, buf, cap);
        } else {
            sprintf(buf, "%ld", msd_fixed_to_int(atom->number));
        }
    } else if (atom->type == MSD_ATOM_STRING) {
        msd_copy_quoted_span_unescaped(buf, cap, src->data, atom->offset, atom->length);
    } else {
        msd_copy_span(buf, cap, src->data, atom->offset, atom->length);
    }
}

static void msd_values_to_text(const MsdSource *src, const MsdBCAtom *atoms, int start, int count, char *buf, int cap)
{
    int i;
    int len;
    char tmp[64];
    buf[0] = '\0';
    len = 0;
    for (i = 0; i < count; ++i) {
        if (i > 0) msd_append_cstr(buf, cap, &len, ", ");
        msd_atom_to_text_local(src, &atoms[start + i], tmp, sizeof(tmp));
        msd_append_cstr(buf, cap, &len, tmp);
    }
}

static int msd_get_bg(MsdRuntime *rt, MsdBG **out)
{
    if (!rt || rt->ctx.current_bg < 0 || rt->ctx.current_bg >= rt->stage.background_count) return 0;
    *out = &rt->stage.backgrounds[rt->ctx.current_bg];
    return 1;
}

static int msd_get_ctrl_def(MsdRuntime *rt, MsdBGCtrlDef **out)
{
    if (!rt || rt->ctx.current_ctrl_def < 0 || rt->ctx.current_ctrl_def >= rt->stage.ctrl_def_count) return 0;
    *out = &rt->stage.ctrl_defs[rt->ctx.current_ctrl_def];
    return 1;
}

static int msd_get_ctrl(MsdRuntime *rt, MsdBGCtrl **out)
{
    if (!rt || rt->ctx.current_ctrl < 0 || rt->ctx.current_ctrl >= rt->stage.ctrl_count) return 0;
    *out = &rt->stage.ctrls[rt->ctx.current_ctrl];
    return 1;
}

static int msd_get_action(MsdRuntime *rt, MsdAction **out)
{
    if (!rt || rt->ctx.current_action < 0 || rt->ctx.current_action >= rt->stage.action_count) return 0;
    *out = &rt->stage.actions[rt->ctx.current_action];
    return 1;
}

static void msd_copy_fixed_values(MsdBGCtrl *ctrl, const MsdBCAtom *atoms, int start, int count)
{
    int i;
    ctrl->value_count = count > 3 ? 3 : count;
    for (i = 0; i < ctrl->value_count; ++i) {
        ctrl->value[i] = msd_atom_to_fixed(&atoms[start + i]);
    }
}

static void msd_copy_modify_values(MsdBGCtrl *ctrl, const MsdBCAtom *atoms, int start, int count)
{
    int i;
    ctrl->modify_value_count = count > 2 ? 2 : count;
    for (i = 0; i < ctrl->modify_value_count; ++i) {
        ctrl->modify_values[i] = msd_atom_to_fixed(&atoms[start + i]);
    }
}

int msd_game_execute(struct MsdRuntime *rt, const MsdSource *src, const struct MsdBCInstr *instr, const struct MsdBCAtom *atoms)
{
    MsdBG *bg;
    MsdBGCtrlDef *def;
    MsdBGCtrl *ctrl;
    MsdAction *action;
    MsdActionFrame *frame;
    char text[128];
    int i;

    if (!rt || !src || !instr || !atoms) {
        return 0;
    }

    switch (instr->word_id) {
    case MSD_BUILTIN_GAME_STAGE_NAME:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.name, sizeof(rt->stage.name)); return 1;
    case MSD_BUILTIN_GAME_STAGE_DISPLAYNAME:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.displayname, sizeof(rt->stage.displayname)); return 1;
    case MSD_BUILTIN_GAME_STAGE_AUTHOR:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.author, sizeof(rt->stage.author)); return 1;
    case MSD_BUILTIN_GAME_STAGE_VERSIONDATE:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.versiondate, sizeof(rt->stage.versiondate)); return 1;
    case MSD_BUILTIN_GAME_STAGE_MUGENVERSION:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.mugenversion, sizeof(rt->stage.mugenversion)); return 1;
    case MSD_BUILTIN_GAME_STAGE_ZOFFSET:
        rt->stage.zoffset = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_ZOFFSETLINK:
        rt->stage.zoffsetlink = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_AUTOTURN:
        rt->stage.autoturn = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_RESETBG:
        rt->stage.resetbg = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_LOCALCOORD:
        if (instr->const_count > 0) rt->stage.localcoord[0] = msd_atom_to_int(&atoms[instr->const_start]);
        if (instr->const_count > 1) rt->stage.localcoord[1] = msd_atom_to_int(&atoms[instr->const_start + 1]);
        return 1;
    case MSD_BUILTIN_GAME_STAGE_XSCALE:
        rt->stage.stage_xscale = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_YSCALE:
        rt->stage.stage_yscale = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_SPR:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.spr, sizeof(rt->stage.spr)); return 1;
    case MSD_BUILTIN_GAME_STAGE_DEBUGBG:
        rt->stage.debugbg = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_STAGE_BGMUSIC:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, rt->stage.bgmusic, sizeof(rt->stage.bgmusic)); return 1;
    case MSD_BUILTIN_GAME_STAGE_BGVOLUME:
        rt->stage.bgvolume = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_SHADOW_INTENSITY:
        rt->stage.shadow_intensity = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_SHADOW_COLOR:
        if (instr->const_count > 0) rt->stage.shadow_color[0] = msd_atom_to_int(&atoms[instr->const_start]);
        if (instr->const_count > 1) rt->stage.shadow_color[1] = msd_atom_to_int(&atoms[instr->const_start + 1]);
        if (instr->const_count > 2) rt->stage.shadow_color[2] = msd_atom_to_int(&atoms[instr->const_start + 2]);
        return 1;
    case MSD_BUILTIN_GAME_SHADOW_YSCALE:
        rt->stage.shadow_yscale = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_SHADOW_FADERANGE:
        if (instr->const_count > 0) rt->stage.shadow_fade_range[0] = msd_atom_to_fixed(&atoms[instr->const_start]);
        if (instr->const_count > 1) rt->stage.shadow_fade_range[1] = msd_atom_to_fixed(&atoms[instr->const_start + 1]);
        return 1;
    case MSD_BUILTIN_GAME_SHADOW_XSHEAR:
        rt->stage.shadow_xshear = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_REFLECTION_REFLECT:
        rt->stage.reflection_reflect = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_STARTX: rt->stage.camera_startx = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_STARTY: rt->stage.camera_starty = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_BOUNDLEFT: rt->stage.camera_boundleft = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_BOUNDRIGHT: rt->stage.camera_boundright = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_BOUNDHIGH: rt->stage.camera_boundhigh = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_BOUNDLOW: rt->stage.camera_boundlow = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_TENSION: rt->stage.camera_tension = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_OVERDRAWHIGH: rt->stage.camera_overdrawhigh = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_OVERDRAWLOW: rt->stage.camera_overdrawlow = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_CUTHIGH: rt->stage.camera_cuthigh = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_CUTLOW: rt->stage.camera_cutlow = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_TENSIONHIGH: rt->stage.camera_tensionhigh = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_TENSIONLOW: rt->stage.camera_tensionlow = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_VERTICALFOLLOW: rt->stage.camera_verticalfollow = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_FLOORTENSION: rt->stage.camera_floortension = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_STARTZOOM: rt->stage.camera_startzoom = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_ZOOMOUT: rt->stage.camera_zoomout = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_CAMERA_ZOOMIN: rt->stage.camera_zoomin = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P1STARTX: rt->stage.p1startx = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P1STARTY: rt->stage.p1starty = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P1FACING: rt->stage.p1facing = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P2STARTX: rt->stage.p2startx = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P2STARTY: rt->stage.p2starty = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_P2FACING: rt->stage.p2facing = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_LEFTBOUND: rt->stage.leftbound = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_PLAYER_RIGHTBOUND: rt->stage.rightbound = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BOUND_SCREENLEFT: rt->stage.screenleft = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BOUND_SCREENRIGHT: rt->stage.screenright = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_TYPE:
        if (!msd_get_bg(rt, &bg)) return 0; msd_values_to_text(src, atoms, instr->const_start, instr->const_count, bg->type, sizeof(bg->type)); return 1;
    case MSD_BUILTIN_GAME_BG_SPRITENO:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->spriteno[0] = msd_atom_to_int(&atoms[instr->const_start]); if (instr->const_count > 1) bg->spriteno[1] = msd_atom_to_int(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_ACTIONNO:
        if (!msd_get_bg(rt, &bg)) return 0; bg->actionno = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_START:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->start.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->start.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_DELTA:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->delta.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->delta.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_MASK:
        if (!msd_get_bg(rt, &bg)) return 0; bg->mask = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_LAYERNO:
        if (!msd_get_bg(rt, &bg)) return 0; bg->layerno = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_ID:
        if (!msd_get_bg(rt, &bg)) return 0; bg->id = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_TILE:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->tile[0] = msd_atom_to_int(&atoms[instr->const_start]); if (instr->const_count > 1) bg->tile[1] = msd_atom_to_int(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_TILESPACING:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->tilespacing[0] = msd_atom_to_int(&atoms[instr->const_start]); if (instr->const_count > 1) bg->tilespacing[1] = msd_atom_to_int(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_WINDOW:
        if (!msd_get_bg(rt, &bg)) return 0; for (i = 0; i < instr->const_count && i < 4; ++i) bg->window[i] = msd_atom_to_int(&atoms[instr->const_start + i]); return 1;
    case MSD_BUILTIN_GAME_BG_WINDOWDELTA:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->windowdelta.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->windowdelta.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_TRANS:
        if (!msd_get_bg(rt, &bg)) return 0; msd_values_to_text(src, atoms, instr->const_start, instr->const_count, bg->trans, sizeof(bg->trans)); return 1;
    case MSD_BUILTIN_GAME_BG_ALPHA:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->alpha[0] = msd_atom_to_int(&atoms[instr->const_start]); if (instr->const_count > 1) bg->alpha[1] = msd_atom_to_int(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_VELOCITY:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->velocity.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->velocity.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_POSITIONLINK:
        if (!msd_get_bg(rt, &bg)) return 0; bg->positionlink = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_WIDTH:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->width[0] = msd_atom_to_int(&atoms[instr->const_start]); if (instr->const_count > 1) bg->width[1] = msd_atom_to_int(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_XSCALE:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->xscale.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->xscale.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_YSCALESTART:
        if (!msd_get_bg(rt, &bg)) return 0; bg->yscalestart = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_YSCALEDELTA:
        if (!msd_get_bg(rt, &bg)) return 0; bg->yscaledelta = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_SCALESTART:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->scalestart.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->scalestart.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_SCALEDELTA:
        if (!msd_get_bg(rt, &bg)) return 0; if (instr->const_count > 0) bg->scaledelta.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->scaledelta.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BG_MASKWINDOW:
        if (!msd_get_bg(rt, &bg)) return 0; bg->has_maskwindow = 1; for (i = 0; i < instr->const_count && i < 4; ++i) bg->maskwindow[i] = msd_atom_to_int(&atoms[instr->const_start + i]); return 1;
    case MSD_BUILTIN_GAME_BG_ZOOMDELTA:
        if (!msd_get_bg(rt, &bg)) return 0; bg->zoomdelta = msd_atom_to_fixed(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BG_SINX:
        if (!msd_get_bg(rt, &bg)) return 0; bg->has_sinx = 1; if (instr->const_count > 0) bg->sinx.amplitude = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->sinx.period = msd_atom_to_fixed(&atoms[instr->const_start + 1]); if (instr->const_count > 2) bg->sinx.phase = msd_atom_to_fixed(&atoms[instr->const_start + 2]); return 1;
    case MSD_BUILTIN_GAME_BG_SINY:
        if (!msd_get_bg(rt, &bg)) return 0; bg->has_siny = 1; if (instr->const_count > 0) bg->siny.amplitude = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) bg->siny.period = msd_atom_to_fixed(&atoms[instr->const_start + 1]); if (instr->const_count > 2) bg->siny.phase = msd_atom_to_fixed(&atoms[instr->const_start + 2]); return 1;
    case MSD_BUILTIN_GAME_BG_TRACKCHAR:
        if (!msd_get_bg(rt, &bg)) return 0; bg->trackchar = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BGCTRLDEF_LOOPTIME:
        if (!msd_get_ctrl_def(rt, &def)) return 0; def->looptime = msd_atom_to_int(&atoms[instr->const_start]); return 1;
    case MSD_BUILTIN_GAME_BGCTRLDEF_CTRLID:
        if (!msd_get_ctrl_def(rt, &def)) return 0; def->ctrl_id_count = instr->const_count > MSD_MAX_CTRL_IDS ? MSD_MAX_CTRL_IDS : instr->const_count; for (i = 0; i < def->ctrl_id_count; ++i) def->ctrl_ids[i] = msd_atom_to_int(&atoms[instr->const_start + i]); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_TYPE:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; msd_values_to_text(src, atoms, instr->const_start, instr->const_count, ctrl->type, sizeof(ctrl->type)); ctrl->resolved_type = msd_bgctrl_type_from_cstr(ctrl->type); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_TIME:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->time_count = instr->const_count > 3 ? 3 : instr->const_count; for (i = 0; i < ctrl->time_count; ++i) ctrl->time[i] = msd_atom_to_int(&atoms[instr->const_start + i]); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_CTRLID:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->ctrl_id_count = instr->const_count > MSD_MAX_CTRL_IDS ? MSD_MAX_CTRL_IDS : instr->const_count; for (i = 0; i < ctrl->ctrl_id_count; ++i) ctrl->ctrl_ids[i] = msd_atom_to_int(&atoms[instr->const_start + i]); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_X:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->x = msd_atom_to_fixed(&atoms[instr->const_start]); ctrl->has_x = 1; return 1;
    case MSD_BUILTIN_GAME_BGCTRL_Y:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->y = msd_atom_to_fixed(&atoms[instr->const_start]); ctrl->has_y = 1; return 1;
    case MSD_BUILTIN_GAME_BGCTRL_VALUE:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; msd_copy_fixed_values(ctrl, atoms, instr->const_start, instr->const_count); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_ATTACHEDCHAR:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; msd_values_to_text(src, atoms, instr->const_start, instr->const_count, ctrl->attachedchar, sizeof(ctrl->attachedchar)); ctrl->attachedchar_count = instr->const_count; return 1;
    case MSD_BUILTIN_GAME_BGCTRL_ATTACHEDID:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->attachedid = msd_atom_to_int(&atoms[instr->const_start]); ctrl->has_attachedid = 1; return 1;
    case MSD_BUILTIN_GAME_BGCTRL_SCTRLID:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->sctrlid = msd_atom_to_int(&atoms[instr->const_start]); ctrl->has_sctrlid = 1; return 1;
    case MSD_BUILTIN_GAME_BGCTRL_MODIFYBGCTRL:
        if (!msd_get_ctrl(rt, &ctrl)) return 0;
        ctrl->has_modifybgctrl = 1;
        ctrl->modify_target[0] = '\0';
        ctrl->modify_field[0] = '\0';
        if (instr->const_count > 0) {
            msd_atom_to_text_local(src, &atoms[instr->const_start], ctrl->modify_target, sizeof(ctrl->modify_target));
        }
        if (instr->const_count > 1) {
            msd_atom_to_text_local(src, &atoms[instr->const_start + 1], ctrl->modify_field, sizeof(ctrl->modify_field));
        }
        if (instr->const_count > 2) {
            msd_copy_modify_values(ctrl, atoms, instr->const_start + 2, instr->const_count - 2);
        }
        return 1;
    case MSD_BUILTIN_GAME_BGCTRL_CHAROFFSET:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->has_charoffset = 1; if (instr->const_count > 0) ctrl->charoffset.x = msd_atom_to_fixed(&atoms[instr->const_start]); if (instr->const_count > 1) ctrl->charoffset.y = msd_atom_to_fixed(&atoms[instr->const_start + 1]); return 1;
    case MSD_BUILTIN_GAME_BGCTRL_FOLLOWCHAR:
        if (!msd_get_ctrl(rt, &ctrl)) return 0; ctrl->followchar = msd_atom_to_int(&atoms[instr->const_start]); ctrl->has_followchar = 1; return 1;
    case MSD_BUILTIN_GAME_ACTION_FRAME:
        if (!msd_get_action(rt, &action)) return 0;
        if (rt->stage.action_frame_count >= MSD_MAX_ACTION_FRAMES) return 0;
        frame = &rt->stage.action_frames[rt->stage.action_frame_count++];
        memset(frame, 0, sizeof(*frame));
        frame->value_count = instr->const_count > 7 ? 7 : instr->const_count;
        for (i = 0; i < frame->value_count; ++i) {
            if (atoms[instr->const_start + i].type == MSD_ATOM_NUMBER) {
                frame->values[i] = msd_atom_to_int(&atoms[instr->const_start + i]);
            }
        }
        frame->ticks = frame->value_count > 4 ? frame->values[4] : 1;
        action->frame_count += 1;
        return 1;
    default:
        msd_values_to_text(src, atoms, instr->const_start, instr->const_count, text, sizeof(text));
        return msd_runtime_store_raw_assign(rt, rt->ctx.section_name, rt->ctx.section_kind, msd_builtin_name(instr->word_id), text);
    }
}
