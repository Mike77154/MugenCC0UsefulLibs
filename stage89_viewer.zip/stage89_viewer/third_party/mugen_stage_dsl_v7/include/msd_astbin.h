#ifndef MSD_ASTBIN_H
#define MSD_ASTBIN_H

#include "msd_canon.h"

typedef struct MsdAstBinInfo {
    int version;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int atom_count;
    int section_count;
    int item_count;
    int plan_count;
    char source_path[260];
} MsdAstBinInfo;

int msd_astbin_default_path(const char *input_path, char *out, int cap);
int msd_astbin_save(const char *path, const MsdSource *src, const MsdArena *arena, const MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, int plan_count);
int msd_astbin_read_info(const char *path, MsdAstBinInfo *info);
void msd_astbin_print_info(const MsdAstBinInfo *info, FILE *out);

#endif
