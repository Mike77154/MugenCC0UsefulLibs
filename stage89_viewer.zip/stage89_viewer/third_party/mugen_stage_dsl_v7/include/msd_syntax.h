#ifndef MSD_SYNTAX_H
#define MSD_SYNTAX_H

#include "msd_arena.h"

MsdSectionKind msd_section_kind_from_header(const MsdSource *src, const MsdArena *arena, int header_start, int header_count);
int msd_syntax_validate(const MsdSource *src, MsdArena *arena, int strict);

#endif
