#ifndef MSD_LEXER_H
#define MSD_LEXER_H

#include "msd_arena.h"

int msd_lex_source(const MsdSource *src, MsdArena *arena);
void msd_lexer_dump(const MsdSource *src, const MsdArena *arena, FILE *out);

#endif
