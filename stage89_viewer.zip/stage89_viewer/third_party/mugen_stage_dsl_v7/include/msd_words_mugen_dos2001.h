#ifndef MSD_WORDS_MUGEN_DOS2001_H
#define MSD_WORDS_MUGEN_DOS2001_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_mugen_dos2001_lib(void);

#endif
