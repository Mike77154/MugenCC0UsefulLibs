#ifndef MSD_VM_H
#define MSD_VM_H

#include "msd_runtime.h"

int msd_vm_execute(MsdRuntime *rt, const MsdSource *src, const MsdArena *arena);

#endif
