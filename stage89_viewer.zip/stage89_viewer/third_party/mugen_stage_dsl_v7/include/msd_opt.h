#ifndef MSD_OPT_H
#define MSD_OPT_H

#include "msd_bytecode.h"
#include "msd_semantic.h"

typedef struct MsdOptStats {
    int ir_in;
    int ir_out;
    int bc_in;
    int bc_out;
    int atom_in;
    int atom_out;
    int ir_dead_sets;
    int bc_dead_calls;
    int atoms_interned;
} MsdOptStats;

void msd_opt_stats_init(MsdOptStats *stats);
int msd_optimize_ir(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *in_ir, int in_count, MsdIRInstr *out_ir, int out_cap, MsdOptStats *stats);
int msd_optimize_bytecode(const MsdSource *src, const MsdArena *arena, const MsdBCInstr *in_bc, int in_bc_count, const MsdBCAtom *in_atoms, int in_atom_count, MsdBCInstr *out_bc, int out_bc_cap, MsdBCAtom *out_atoms, int out_atom_cap, MsdOptStats *stats);
void msd_opt_dump_summary(const MsdOptStats *stats, FILE *out);

#endif
