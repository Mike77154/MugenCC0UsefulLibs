#ifndef MSD_RUNTIME_H
#define MSD_RUNTIME_H

#include "msd_bytecode.h"

typedef struct MsdVec2 {
    msd_fixed_t x;
    msd_fixed_t y;
} MsdVec2;

typedef struct MsdOsc {
    msd_fixed_t amplitude;
    msd_fixed_t period;
    msd_fixed_t phase;
} MsdOsc;

typedef struct MsdRect4 {
    msd_fixed_t a;
    msd_fixed_t b;
    msd_fixed_t c;
    msd_fixed_t d;
} MsdRect4;

typedef struct MsdRawEntry {
    int is_row;
    MsdSectionKind section_kind;
    char section_name[64];
    char key[64];
    char values[160];
} MsdRawEntry;

typedef enum MsdBGCtrlType {
    MSD_BGCTRL_KIND_UNKNOWN = 0,
    MSD_BGCTRL_KIND_NULL,
    MSD_BGCTRL_KIND_VISIBLE,
    MSD_BGCTRL_KIND_ENABLED,
    MSD_BGCTRL_KIND_VELSET,
    MSD_BGCTRL_KIND_VELADD,
    MSD_BGCTRL_KIND_POSSET,
    MSD_BGCTRL_KIND_POSADD,
    MSD_BGCTRL_KIND_ANIM,
    MSD_BGCTRL_KIND_SINX,
    MSD_BGCTRL_KIND_SINY
} MsdBGCtrlType;

typedef struct MsdBG {
    char name[64];
    char type[32];
    int spriteno[2];
    int actionno;
    MsdVec2 start;
    MsdVec2 delta;
    int mask;
    int layerno;
    int id;
    int tile[2];
    int tilespacing[2];
    int window[4];
    MsdVec2 windowdelta;
    char trans[32];
    int alpha[2];
    MsdVec2 velocity;
    int positionlink;
    int width[2];
    MsdVec2 xscale;
    msd_fixed_t yscalestart;
    msd_fixed_t yscaledelta;
    MsdVec2 scalestart;
    MsdVec2 scaledelta;
    int maskwindow[4];
    int has_maskwindow;
    msd_fixed_t zoomdelta;
    MsdOsc sinx;
    int has_sinx;
    MsdOsc siny;
    int has_siny;
    int trackchar;

    MsdVec2 current_start;
    MsdVec2 current_velocity;
    int visible;
    int enabled;
    int current_actionno;
    int anim_time;
    int current_frame_index;
    MsdOsc current_sinx;
    int current_has_sinx;
    MsdOsc current_siny;
    int current_has_siny;
    msd_fixed_t computed_x;
    msd_fixed_t computed_y;
    msd_fixed_t computed_scale_x;
    msd_fixed_t computed_scale_y;
    msd_fixed_t computed_zoomscale;
} MsdBG;

typedef struct MsdBGCtrlDef {
    char name[64];
    int looptime;
    int ctrl_ids[MSD_MAX_CTRL_IDS];
    int ctrl_id_count;
    int first_ctrl;
    int ctrl_count;
} MsdBGCtrlDef;

typedef struct MsdBGCtrl {
    char name[64];
    char type[32];
    MsdBGCtrlType resolved_type;
    int parent_def_index;
    int time[3];
    int time_count;
    int ctrl_ids[MSD_MAX_CTRL_IDS];
    int ctrl_id_count;
    msd_fixed_t x;
    int has_x;
    msd_fixed_t y;
    int has_y;
    msd_fixed_t value[3];
    int value_count;
    char attachedchar[32];
    int attachedchar_count;
    int attachedid;
    int has_attachedid;
    int sctrlid;
    int has_sctrlid;
    char modify_target[64];
    char modify_field[32];
    msd_fixed_t modify_values[2];
    int modify_value_count;
    int has_modifybgctrl;
    MsdVec2 charoffset;
    int has_charoffset;
    int followchar;
    int has_followchar;
} MsdBGCtrl;

typedef struct MsdActionFrame {
    int values[7];
    int value_count;
    int ticks;
} MsdActionFrame;

typedef struct MsdAction {
    int number;
    int first_frame;
    int frame_count;
} MsdAction;

typedef struct MsdStage {
    MsdProfile profile;
    MsdProfileCaps caps;
    char name[64];
    char displayname[64];
    char author[64];
    char versiondate[64];
    char mugenversion[64];
    msd_fixed_t zoffset;
    int zoffsetlink;
    msd_fixed_t dynamic_zoffset;
    int autoturn;
    int resetbg;
    int localcoord[2];
    msd_fixed_t stage_xscale;
    msd_fixed_t stage_yscale;
    char spr[128];
    int debugbg;
    char bgmusic[128];
    int bgvolume;

    msd_fixed_t camera_startx;
    msd_fixed_t camera_starty;
    msd_fixed_t camera_boundleft;
    msd_fixed_t camera_boundright;
    msd_fixed_t camera_boundhigh;
    msd_fixed_t camera_boundlow;
    msd_fixed_t camera_tension;
    msd_fixed_t camera_overdrawhigh;
    msd_fixed_t camera_overdrawlow;
    msd_fixed_t camera_cuthigh;
    msd_fixed_t camera_cutlow;
    msd_fixed_t camera_tensionhigh;
    msd_fixed_t camera_tensionlow;
    msd_fixed_t camera_verticalfollow;
    msd_fixed_t camera_floortension;
    msd_fixed_t camera_startzoom;
    msd_fixed_t camera_zoomout;
    msd_fixed_t camera_zoomin;
    msd_fixed_t live_camera_x;
    msd_fixed_t live_camera_y;
    msd_fixed_t live_camera_zoom;
    msd_fixed_t live_clip_top;
    msd_fixed_t live_clip_bottom;
    msd_fixed_t live_shadow_skew;

    msd_fixed_t p1startx;
    msd_fixed_t p1starty;
    int p1facing;
    msd_fixed_t p2startx;
    msd_fixed_t p2starty;
    int p2facing;
    msd_fixed_t leftbound;
    msd_fixed_t rightbound;

    msd_fixed_t screenleft;
    msd_fixed_t screenright;

    int shadow_intensity;
    int shadow_color[3];
    msd_fixed_t shadow_yscale;
    msd_fixed_t shadow_fade_range[2];
    msd_fixed_t shadow_xshear;
    int reflection_reflect;

    MsdBG backgrounds[MSD_MAX_BG];
    int background_count;

    MsdBGCtrlDef ctrl_defs[MSD_MAX_BGCTRLDEF];
    int ctrl_def_count;

    MsdBGCtrl ctrls[MSD_MAX_BGCTRL];
    int ctrl_count;

    MsdAction actions[MSD_MAX_ACTIONS];
    int action_count;

    MsdActionFrame action_frames[MSD_MAX_ACTION_FRAMES];
    int action_frame_count;

    MsdRawEntry raw[MSD_MAX_RAW];
    int raw_count;
} MsdStage;

typedef struct MsdExecContext {
    MsdSectionKind section_kind;
    char section_name[64];
    int current_bg;
    int current_ctrl_def;
    int current_ctrl;
    int current_action;
} MsdExecContext;


typedef struct MsdAttachment {
    int in_use;
    int id;
    char kind[32];
    MsdVec2 pos;
    MsdVec2 offset;
    int source_ctrl_index;
} MsdAttachment;

typedef struct MsdRuntime {
    MsdStage stage;
    MsdExecContext ctx;
    MsdArena *arena;
    int sim_tick;
    MsdAttachment attachments[MSD_MAX_ATTACHMENTS];
    int attachment_count;
} MsdRuntime;

void msd_runtime_init(MsdRuntime *rt, MsdArena *arena);
void msd_runtime_set_profile(MsdRuntime *rt, MsdProfile profile);
void msd_runtime_finalize_stage(MsdRuntime *rt);
void msd_runtime_reset_live(MsdRuntime *rt);
int msd_runtime_apply_tick(MsdRuntime *rt, int tick);
int msd_runtime_advance(MsdRuntime *rt);
void msd_runtime_dump(const MsdStage *stage, FILE *out);
void msd_runtime_dump_live(const MsdStage *stage, FILE *out);
void msd_runtime_dump_timeline(MsdRuntime *rt, FILE *out, int ticks);
int msd_runtime_store_raw_assign(MsdRuntime *rt, const char *section_name, MsdSectionKind kind, const char *key, const char *values);
int msd_runtime_store_raw_row(MsdRuntime *rt, const char *section_name, MsdSectionKind kind, const char *values);
int msd_runtime_begin_section(MsdRuntime *rt, const MsdSource *src, MsdSectionKind kind, const MsdBCAtom *atoms, int start, int count);
MsdBGCtrlType msd_bgctrl_type_from_cstr(const char *text);
const char *msd_bgctrl_type_name(MsdBGCtrlType type);

#endif
