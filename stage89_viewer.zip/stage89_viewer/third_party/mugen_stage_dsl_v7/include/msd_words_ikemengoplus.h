#ifndef MSD_WORDS_IKEMENGOPLUS_H
#define MSD_WORDS_IKEMENGOPLUS_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_ikemengoplus_lib(void);

#endif
