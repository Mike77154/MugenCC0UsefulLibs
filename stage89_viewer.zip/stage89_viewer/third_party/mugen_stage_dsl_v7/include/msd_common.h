#ifndef MSD_COMMON_H
#define MSD_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <ctype.h>

#include "msd_config.h"

typedef signed long msd_fixed_t;

typedef struct MsdSource {
    char path[260];
    char data[MSD_MAX_SOURCE_BYTES + 1];
    int size;
} MsdSource;

typedef struct MsdError {
    int line;
    int col;
    char message[MSD_MAX_TEXT];
} MsdError;

int msd_source_load(MsdSource *src, const char *path);
int msd_ascii_tolower(int ch);
int msd_span_ieq(const char *src, int offset, int length, const char *text);
int msd_span_eq(const char *src, int offset, int length, const char *text);
int msd_copy_span(char *dst, int cap, const char *src, int offset, int length);
int msd_copy_quoted_span_unescaped(char *dst, int cap, const char *src, int offset, int length);
int msd_append_char(char *dst, int cap, int *len, char ch);
int msd_append_cstr(char *dst, int cap, int *len, const char *text);
int msd_append_span(char *dst, int cap, int *len, const char *src, int offset, int length);
void msd_trim_trailing_zeros(char *buf);

#endif
