#ifndef MSD_CANON_H
#define MSD_CANON_H

#include "msd_semantic.h"
#include "msd_bytecode.h"

typedef struct MsdSSAInstr {
    MsdIROp op;
    MsdSectionKind section_kind;
    MsdBuiltinId word_id;
    int key_atom;
    int value_start;
    int value_count;
    int item_ordinal;
    int version;
    int is_live;
    int value_id;
    int is_same_value;
    unsigned long value_hash;
    int line;
    int col;
} MsdSSAInstr;

typedef struct MsdCanonPlanInstr {
    MsdItemKind item_kind;
    int item_ordinal;
    MsdBuiltinId word_id;
} MsdCanonPlanInstr;

typedef struct MsdCanonSection {
    MsdSectionKind kind;
    int src_section_index;
    int plan_start;
    int plan_count;
    int ir_start;
    int ir_count;
    int bc_start;
    int bc_count;
    int bc_atom_start;
    int bc_atom_count;
    unsigned long plan_hash;
    unsigned long canon_hash;
    char header_text[64];
} MsdCanonSection;

typedef struct MsdCanonStats {
    int raw_ir_in;
    int ssa_defs;
    int ssa_live_defs;
    int ssa_value_classes;
    int ssa_same_value_redefs;
    int canon_sections;
    int canon_ir_out;
    int canon_duplicate_elided;
    int canon_unique_sorted;
} MsdCanonStats;

void msd_canon_stats_init(MsdCanonStats *stats);
void msd_canon_section_header_text(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec, char *buf, int cap);
unsigned long msd_canon_section_plan_hash(const MsdSource *src, const MsdArena *arena, const MsdAstSection *sec);
int msd_build_ssa(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *raw_ir, int raw_ir_count, MsdSSAInstr *out_ssa, int out_cap, MsdCanonStats *stats);
int msd_build_section_plan(const MsdSource *src, const MsdArena *arena, int section_index, MsdCanonSection *out_section, MsdCanonPlanInstr *plan_storage, int *plan_count, int plan_cap, MsdCanonStats *stats);
int msd_emit_ir_from_plans(const MsdSource *src, const MsdArena *arena, MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, MsdIRInstr *out_ir, int out_cap, int *out_count);
int msd_emit_bc_from_plans(const MsdSource *src, const MsdArena *arena, MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, MsdBCInstr *out_bc, int out_bc_cap, MsdBCAtom *out_atoms, int out_atom_cap, int *out_bc_count, int *out_atom_count);
int msd_canonicalize_ir(const MsdSource *src, const MsdArena *arena, const MsdIRInstr *raw_ir, int raw_ir_count, MsdSSAInstr *ssa_storage, int ssa_cap, MsdCanonSection *sections, int sec_cap, MsdCanonPlanInstr *plans, int plan_cap, MsdIRInstr *out_ir, int out_ir_cap, int *out_ir_count, MsdCanonStats *stats);
void msd_ssa_dump(const MsdSource *src, const MsdArena *arena, const MsdSSAInstr *ssa, int ssa_count, FILE *out);
void msd_canon_dump_sections(const MsdCanonSection *sections, int section_count, FILE *out);
void msd_canon_dump_summary(const MsdCanonStats *stats, FILE *out);

#endif
