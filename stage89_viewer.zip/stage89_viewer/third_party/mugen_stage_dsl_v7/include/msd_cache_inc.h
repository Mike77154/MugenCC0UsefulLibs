#ifndef MSD_CACHE_INC_H
#define MSD_CACHE_INC_H

#include "msd_canon.h"

typedef struct MsdIncCacheSection {
    MsdSectionKind kind;
    unsigned long plan_hash;
    unsigned long canon_hash;
    int plan_start;
    int plan_count;
    char header_text[64];
} MsdIncCacheSection;

typedef struct MsdIncCacheInfo {
    int version;
    int flags;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    unsigned long source_hash;
    int section_count;
    int plan_count;
    char source_path[260];
    MsdIncCacheSection sections[MSD_MAX_SECTIONS];
} MsdIncCacheInfo;

int msd_cache_inc_default_path(const char *input_path, char *out, int cap);
int msd_cache_inc_save(const char *path, const MsdSource *src, const MsdCanonSection *sections, int section_count, const MsdCanonPlanInstr *plans, int plan_count);
int msd_cache_inc_read_info(const char *path, MsdIncCacheInfo *info);
int msd_cache_inc_load(const char *path, MsdIncCacheInfo *info, MsdCanonPlanInstr *plans, int plan_cap);
int msd_cache_inc_find_match(const MsdIncCacheInfo *info, MsdSectionKind kind, unsigned long plan_hash, const char *header_text);
void msd_cache_inc_print_info(const MsdIncCacheInfo *info, FILE *out);

#endif
