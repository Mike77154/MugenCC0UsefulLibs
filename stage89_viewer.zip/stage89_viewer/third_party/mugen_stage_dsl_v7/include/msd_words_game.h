#ifndef MSD_WORDS_GAME_H
#define MSD_WORDS_GAME_H

#include "msd_words_core.h"

struct MsdRuntime;
struct MsdBCInstr;
struct MsdBCAtom;

int msd_game_execute(struct MsdRuntime *rt, const MsdSource *src, const struct MsdBCInstr *instr, const struct MsdBCAtom *atoms);

#endif
