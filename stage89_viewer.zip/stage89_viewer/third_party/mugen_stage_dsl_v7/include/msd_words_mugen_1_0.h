#ifndef MSD_WORDS_MUGEN_1_0_H
#define MSD_WORDS_MUGEN_1_0_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_mugen_1_0_lib(void);

#endif
