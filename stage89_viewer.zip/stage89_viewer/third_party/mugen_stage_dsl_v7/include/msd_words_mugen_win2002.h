#ifndef MSD_WORDS_MUGEN_WIN2002_H
#define MSD_WORDS_MUGEN_WIN2002_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_mugen_win2002_lib(void);

#endif
