#ifndef MSD_MODULE_H
#define MSD_MODULE_H

#include "msd_common.h"

typedef struct MsdModuleDep {
    char path[260];
    int size;
    unsigned long hash;
    int parent_index;
    int depth;
} MsdModuleDep;

typedef struct MsdModuleInfo {
    int dep_count;
    int merged_size;
    unsigned long merged_hash;
    MsdModuleDep deps[MSD_MAX_DEPS];
} MsdModuleInfo;

unsigned long msd_module_hash_buffer(const char *data, int size);
unsigned long msd_module_hash_source(const MsdSource *src);
int msd_module_load(MsdSource *dst, MsdModuleInfo *info, const char *path);
int msd_module_default_link_path(const char *input_path, char *out, int cap);
int msd_module_write_linked(const MsdSource *src, const char *path);
void msd_module_print_info(const MsdModuleInfo *info, FILE *out);

#endif
