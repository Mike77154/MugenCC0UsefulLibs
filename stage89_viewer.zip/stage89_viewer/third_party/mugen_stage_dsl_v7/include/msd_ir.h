#ifndef MSD_IR_H
#define MSD_IR_H

#include "msd_parser.h"
#include "msd_profile.h"

typedef enum MsdIROp {
    MSD_IR_BEGIN_SECTION = 0,
    MSD_IR_SET,
    MSD_IR_ROW,
    MSD_IR_END_SECTION
} MsdIROp;

typedef struct MsdIRInstr {
    MsdIROp op;
    MsdSectionKind section_kind;
    int header_start;
    int header_count;
    int key_atom;
    int value_start;
    int value_count;
    int line;
    int col;
    MsdProfile profile_tag;
} MsdIRInstr;

int msd_lower_to_ir(const MsdSource *src, MsdArena *arena, MsdIRInstr *storage, int storage_cap);
void msd_ir_dump(const MsdSource *src, const MsdArena *arena, FILE *out);

#endif
