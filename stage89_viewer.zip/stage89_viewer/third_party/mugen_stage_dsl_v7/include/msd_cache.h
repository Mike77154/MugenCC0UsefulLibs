#ifndef MSD_CACHE_H
#define MSD_CACHE_H

#include "msd_opt.h"

#define MSD_CACHE_FLAG_HAS_SOURCE  1
#define MSD_CACHE_FLAG_OPT_IR      2
#define MSD_CACHE_FLAG_OPT_BC      4

typedef struct MsdCacheInfo {
    int version;
    int flags;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int atom_count;
    int section_count;
    int item_count;
    int ir_count;
    int bc_count;
    int bc_atom_count;
    char source_path[260];
} MsdCacheInfo;

unsigned long msd_hash_buffer(const char *data, int size);
unsigned long msd_cache_hash_source(const MsdSource *src);
int msd_cache_default_path(const char *input_path, char *out, int cap);
int msd_cache_matches_source(const MsdCacheInfo *info, const MsdSource *src);
int msd_cache_read_info(const char *path, MsdCacheInfo *info);
int msd_cache_save(const char *path, const MsdSource *src, const MsdArena *arena, int flags);
int msd_cache_load(const char *path, MsdSource *src, MsdArena *arena, MsdIRInstr *ir_storage, int ir_cap, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *bc_atoms, int bc_atom_cap, MsdCacheInfo *info);
void msd_cache_print_info(const MsdCacheInfo *info, FILE *out);

#endif
