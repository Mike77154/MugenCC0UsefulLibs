#ifndef MSD_BYTECODE_H
#define MSD_BYTECODE_H

#include "msd_words_mugen.h"

typedef enum MsdBCOp {
    MSD_BC_BEGIN_SECTION = 0,
    MSD_BC_CALL,
    MSD_BC_END_SECTION
} MsdBCOp;

typedef struct MsdBCAtom {
    MsdAtomType type;
    int offset;
    int length;
    msd_fixed_t number;
    int is_fixed;
    int line;
    int col;
} MsdBCAtom;

typedef struct MsdBCInstr {
    MsdBCOp op;
    MsdSectionKind section_kind;
    MsdBuiltinId word_id;
    int name_atom;
    int const_start;
    int const_count;
    int line;
    int col;
    MsdProfile profile_tag;
} MsdBCInstr;

int msd_compile_bytecode(const MsdSource *src, MsdArena *arena, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *atom_storage, int atom_cap);
void msd_bytecode_dump(const MsdSource *src, const MsdArena *arena, FILE *out);

#endif
