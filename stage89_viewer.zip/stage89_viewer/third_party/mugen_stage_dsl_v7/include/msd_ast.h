#ifndef MSD_AST_H
#define MSD_AST_H

#include "msd_token.h"

typedef enum MsdAtomType {
    MSD_ATOM_IDENT = 0,
    MSD_ATOM_STRING,
    MSD_ATOM_NUMBER
} MsdAtomType;

typedef struct MsdAtom {
    MsdAtomType type;
    int offset;
    int length;
    msd_fixed_t number;
    int is_fixed;
    int line;
    int col;
} MsdAtom;

typedef enum MsdSectionKind {
    MSD_SECTION_UNKNOWN = 0,
    MSD_SECTION_INFO,
    MSD_SECTION_CAMERA,
    MSD_SECTION_PLAYERINFO,
    MSD_SECTION_BOUND,
    MSD_SECTION_STAGEINFO,
    MSD_SECTION_SHADOW,
    MSD_SECTION_REFLECTION,
    MSD_SECTION_MUSIC,
    MSD_SECTION_BGDEF,
    MSD_SECTION_BG,
    MSD_SECTION_BGCTRLDEF,
    MSD_SECTION_BGCTRL,
    MSD_SECTION_BEGIN_ACTION
} MsdSectionKind;

typedef enum MsdItemKind {
    MSD_ITEM_ASSIGN = 0,
    MSD_ITEM_ROW
} MsdItemKind;

typedef struct MsdAstItem {
    MsdItemKind kind;
    int key_atom;
    int value_start;
    int value_count;
    int line;
    int col;
} MsdAstItem;

typedef struct MsdAstSection {
    MsdSectionKind kind;
    int header_start;
    int header_count;
    int first_item;
    int item_count;
    int line;
    int col;
} MsdAstSection;

struct MsdArena;

const char *msd_atom_type_name(MsdAtomType type);
const char *msd_section_kind_name(MsdSectionKind kind);
void msd_atom_to_text(const MsdSource *src, const MsdAtom *atom, char *buf, int cap);
void msd_ast_dump(const MsdSource *src, const struct MsdArena *arena, FILE *out);

#endif
