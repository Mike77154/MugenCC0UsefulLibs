#ifndef MSD_WORDS_IKEMENPLUSULTRA_H
#define MSD_WORDS_IKEMENPLUSULTRA_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_ikemenplusultra_lib(void);

#endif
