#ifndef MSD_VERIFY_H
#define MSD_VERIFY_H

#include "msd_bytecode.h"

typedef struct MsdVerifyReport {
    int begins;
    int calls;
    int ends;
    int errors;
} MsdVerifyReport;

void msd_verify_report_init(MsdVerifyReport *report);
int msd_verify_bytecode(const MsdSource *src, MsdArena *arena, MsdVerifyReport *report);
void msd_verify_dump_report(const MsdVerifyReport *report, FILE *out);

#endif
