#ifndef MSD_CONFIG_H
#define MSD_CONFIG_H

#define MSD_MAX_SOURCE_BYTES   262144
#define MSD_MAX_TOKENS         32768
#define MSD_MAX_SECTIONS       512
#define MSD_MAX_ITEMS          8192
#define MSD_MAX_ATOMS          32768
#define MSD_MAX_IR             16384
#define MSD_MAX_BC             16384
#define MSD_MAX_BC_CONSTS      32768
#define MSD_MAX_ERRORS         256
#define MSD_MAX_TEXT           256
#define MSD_MAX_RAW            512
#define MSD_MAX_BG             256
#define MSD_MAX_BGCTRLDEF      128
#define MSD_MAX_BGCTRL         512
#define MSD_MAX_ACTIONS        256
#define MSD_MAX_ACTION_FRAMES  4096
#define MSD_MAX_CTRL_IDS       10
#define MSD_MAX_ATTACHMENTS    32
#define MSD_MAX_DEPS           64
#define MSD_MAX_MODULE_DEPTH   16

#endif
