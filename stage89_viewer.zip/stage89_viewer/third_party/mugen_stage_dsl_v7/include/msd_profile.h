#ifndef MSD_PROFILE_H
#define MSD_PROFILE_H

#include "msd_ast.h"

/* Engine/version profiles and extension layers. */
typedef enum MsdProfile {
    MSD_PROFILE_AUTO = 0,
    MSD_PROFILE_DOSMUGEN2001,
    MSD_PROFILE_WINMUGEN2002,
    MSD_PROFILE_MUGEN1_0,
    MSD_PROFILE_MUGEN1_1,
    MSD_PROFILE_IKEMENGOPLUS,
    MSD_PROFILE_IKEMENPLUSULTRA
} MsdProfile;

typedef struct MsdProfileWord {
    MsdSectionKind section;
    const char *key;
} MsdProfileWord;

typedef struct MsdProfileStubWord {
    MsdSectionKind section;
    const char *key;
    const char *description;
} MsdProfileStubWord;

typedef struct MsdProfileCaps {
    int integer_camera;
    int overdraw_cut_runtime;
    int zoom_runtime;
    int modern_parallax_runtime;
    int shadow_xshear_runtime;
    int attachedchar_runtime;
    int followchar_runtime;
    int bgctrl_mutation_runtime;
} MsdProfileCaps;

typedef struct MsdProfileLib {
    const char *name;
    const char *tagline;
    const MsdProfileWord *keys;
    int key_count;
    const char *const *bgctrl_types;
    int bgctrl_count;
    const MsdProfileStubWord *stubs;
    int stub_count;
} MsdProfileLib;

const char *msd_profile_name(MsdProfile profile);
int msd_profile_parse(const char *text, MsdProfile *out);
MsdProfile msd_profile_detect(const MsdSource *src, const struct MsdArena *arena);
MsdProfile msd_profile_resolve(const MsdSource *src, const struct MsdArena *arena, MsdProfile requested);

void msd_profile_set_active(MsdProfile profile);
MsdProfile msd_profile_get_active(void);

const MsdProfileLib *msd_profile_lib(MsdProfile profile);
const MsdProfileCaps *msd_profile_caps(MsdProfile profile);
int msd_profile_supports_key(MsdProfile profile, MsdSectionKind section, const char *key);
int msd_profile_supports_bgctrl_type(MsdProfile profile, const char *type);
int msd_profile_is_stub_key(MsdProfile profile, MsdSectionKind section, const char *key);
void msd_profile_print_summary(FILE *out, MsdProfile requested, MsdProfile detected, MsdProfile effective);
void msd_profile_print_words(FILE *out, MsdProfile profile);

#endif
