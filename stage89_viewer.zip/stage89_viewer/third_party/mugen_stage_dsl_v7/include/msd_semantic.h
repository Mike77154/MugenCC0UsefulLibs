#ifndef MSD_SEMANTIC_H
#define MSD_SEMANTIC_H

#include "msd_syntax.h"
#include "msd_profile.h"

int msd_semantic_validate(const MsdSource *src, MsdArena *arena, int strict);
int msd_semantic_validate_profile(const MsdSource *src, MsdArena *arena, int strict, MsdProfile profile);
int msd_semantic_key_is_unique(MsdSectionKind section, const MsdSource *src, const MsdAtom *key);

#endif
