#ifndef MSD_FIXED_H
#define MSD_FIXED_H

#include "msd_common.h"

#define MSD_FIXED_FRAC_BITS 16
#define MSD_FIXED_ONE       ((msd_fixed_t)(1L << MSD_FIXED_FRAC_BITS))

msd_fixed_t msd_fixed_from_int(long value);
msd_fixed_t msd_fixed_from_parts(long whole, long frac, long denom);
msd_fixed_t msd_fixed_from_span(const char *src, int offset, int length, int *ok, int *is_fixed);
long msd_fixed_to_int(msd_fixed_t value);
msd_fixed_t msd_fixed_abs(msd_fixed_t value);
msd_fixed_t msd_fixed_mul(msd_fixed_t a, msd_fixed_t b);
msd_fixed_t msd_fixed_div(msd_fixed_t a, msd_fixed_t b, int *ok);
void msd_fixed_to_string(msd_fixed_t value, char *buf, int cap);

#endif
