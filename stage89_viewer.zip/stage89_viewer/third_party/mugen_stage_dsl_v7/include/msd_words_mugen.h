#ifndef MSD_WORDS_MUGEN_H
#define MSD_WORDS_MUGEN_H

#include "msd_words_game.h"

MsdBuiltinId msd_mugen_resolve_begin(MsdSectionKind kind);
MsdBuiltinId msd_mugen_resolve_key(MsdSectionKind kind, const MsdSource *src, const MsdAtom *key);
MsdBuiltinId msd_mugen_resolve_row(MsdSectionKind kind);

#endif
