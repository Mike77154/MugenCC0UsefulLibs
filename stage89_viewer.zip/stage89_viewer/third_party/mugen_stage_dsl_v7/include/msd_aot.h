#ifndef MSD_AOT_H
#define MSD_AOT_H

#include "msd_verify.h"
#include "msd_module.h"

typedef struct MsdAotDepInfo {
    char path[260];
    int size;
    unsigned long hash;
} MsdAotDepInfo;

typedef struct MsdAotInfo {
    int version;
    int flags;
    int int_size;
    int long_size;
    int fixed_frac_bits;
    int source_size;
    unsigned long source_hash;
    int section_count;
    int item_count;
    int bc_count;
    int bc_atom_count;
    int dep_count;
    int verify_errors;
    char source_path[260];
    MsdAotDepInfo deps[MSD_MAX_DEPS];
} MsdAotInfo;

int msd_aot_default_path(const char *input_path, char *out, int cap);
int msd_aot_save(const char *path, const MsdSource *src, const MsdModuleInfo *mods, const MsdArena *arena, const MsdVerifyReport *verify);
int msd_aot_read_info(const char *path, MsdAotInfo *info);
int msd_aot_load(const char *path, MsdAotInfo *info, MsdBCInstr *bc_storage, int bc_cap, MsdBCAtom *atom_storage, int atom_cap);
int msd_aot_matches(const MsdAotInfo *info, const MsdSource *src, const MsdModuleInfo *mods);
void msd_aot_print_info(const MsdAotInfo *info, FILE *out);

#endif
