#ifndef MSD_CLI_H
#define MSD_CLI_H

#include "msd_vm.h"

int msd_cli_main(int argc, char **argv);

#endif
