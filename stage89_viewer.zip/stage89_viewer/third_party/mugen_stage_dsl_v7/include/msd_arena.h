#ifndef MSD_ARENA_H
#define MSD_ARENA_H

#include "msd_ast.h"

struct MsdIRInstr;
struct MsdBCInstr;
struct MsdBCAtom;

typedef struct MsdArena {
    MsdToken tokens[MSD_MAX_TOKENS];
    int token_count;

    MsdAtom atoms[MSD_MAX_ATOMS];
    int atom_count;

    MsdAstSection sections[MSD_MAX_SECTIONS];
    int section_count;

    MsdAstItem items[MSD_MAX_ITEMS];
    int item_count;

    struct MsdIRInstr *ir;
    int ir_count;

    struct MsdBCInstr *bc;
    int bc_count;

    struct MsdBCAtom *bc_atoms;
    int bc_atom_count;

    MsdError errors[MSD_MAX_ERRORS];
    int error_count;
} MsdArena;

void msd_arena_init(MsdArena *arena);
int msd_arena_add_error(MsdArena *arena, int line, int col, const char *message);
int msd_arena_add_token(MsdArena *arena, const MsdToken *tok);
int msd_arena_add_atom(MsdArena *arena, const MsdAtom *atom);
int msd_arena_add_section(MsdArena *arena, const MsdAstSection *section);
int msd_arena_add_item(MsdArena *arena, const MsdAstItem *item);

#endif
