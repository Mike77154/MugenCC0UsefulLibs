#ifndef MSD_WORDS_MUGEN_1_1_H
#define MSD_WORDS_MUGEN_1_1_H

#include "msd_profile.h"

const MsdProfileLib *msd_words_mugen_1_1_lib(void);

#endif
