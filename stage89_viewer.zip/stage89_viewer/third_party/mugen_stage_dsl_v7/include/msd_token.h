#ifndef MSD_TOKEN_H
#define MSD_TOKEN_H

#include "msd_fixed.h"

typedef enum MsdTokenType {
    MSD_TOK_EOF = 0,
    MSD_TOK_NEWLINE,
    MSD_TOK_LBRACKET,
    MSD_TOK_RBRACKET,
    MSD_TOK_EQUALS,
    MSD_TOK_COMMA,
    MSD_TOK_IDENT,
    MSD_TOK_STRING,
    MSD_TOK_NUMBER,
    MSD_TOK_ERROR
} MsdTokenType;

typedef struct MsdToken {
    MsdTokenType type;
    int line;
    int col;
    int offset;
    int length;
    msd_fixed_t number;
    int is_fixed;
} MsdToken;

const char *msd_token_type_name(MsdTokenType type);
void msd_token_text(const MsdSource *src, const MsdToken *tok, char *buf, int cap);

#endif
