#ifndef MSD_PARSER_H
#define MSD_PARSER_H

#include "msd_syntax.h"

int msd_parse_tokens(const MsdSource *src, MsdArena *arena);

#endif
