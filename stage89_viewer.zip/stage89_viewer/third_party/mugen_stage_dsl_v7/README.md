# mugen_stage_dsl

A **C89**, **no-heap**, **fixed-point** parser / compiler / VM that treats a MUGEN stage DEF as a small DSL.

## Hard constraints

- no `malloc`
- no `realloc`
- no `free`
- no heap growth
- no `float` / `double`
- fixed-point math only (`Q16.16`)
- static / fixed-capacity storage only

## Pipeline

- module linker / include expander
- lexer
- token stream
- parser
- AST
- syntax pass
- semantic pass
- IR
- optimizer / peephole
- SSA-lite
- canonicalization passes
- bytecode
- bytecode verifier
- VM
- runtime model
- CLI
- whole-program cache
- incremental section cache
- AOT cache with dependency fingerprints
- canonical AST binary snapshot

## Library split

The word space remains separated in three layers:

- **core / general-use words** (`core.raw.*`, `core.time.*`)
- **generic game-engine operations** (`game.stage.*`, `game.bg.*`, `game.bgctrl.*`, `game.action.*`)
- **MUGEN words** (section/key resolver that maps MUGEN syntax into the generic word space)

## Phase 7 additions

### Profile tags now travel through the whole pipeline

Version profiles are no longer only a semantic gate.
They now survive and affect all of:

- IR
- optimized bytecode
- VM dispatch
- runtime execution
- whole-program cache (`.msdc`)
- AOT cache (`.msdaot`)
- canonical bytecode emitted from section plans

That means a cached / AOT-loaded program keeps the same effective profile semantics it was compiled with.

### Real runtime semantics per profile

The versioned sublibs now have concrete runtime weight instead of acting as a historical compatibility label only.

Implemented profile capabilities:

- `dosmugen2001`
  - integer-quantized camera / zoffset behavior
  - legacy parallax scaling path
- `winmugen2002`
  - integer-quantized camera / zoffset behavior
  - legacy parallax scaling path
- `mugen1.0`
  - `overdrawhigh` / `overdrawlow` / `cuthigh` / `cutlow` affect live clip bounds
- `mugen1.1`
  - zoom runtime from `startzoom` / `zoomout` / `zoomin`
  - modern parallax runtime from `width` / `scalestart` / `scaledelta` / `zoomdelta`
  - live `Shadow.xshear` state
- `ikemengoplus`
  - `attachedchar` / `attachedid` attachment channels
  - `sctrlid` storage
  - `modifybgctrl` runtime mutation of target BG controllers
- `ikemenplusultra`
  - everything from `ikemengoplus`
  - `charoffset`
  - `followchar`
  - `trackchar`

### VM/runtime behavior added for Ikemen extension words

The Ikemen profiles are no longer pure passthrough stubs at runtime.
They now execute meaningful fixed-point behavior in the VM/runtime model:

- attachment registration
- attachment offsets
- follower offsets for BG controllers
- controller mutation (`modifybgctrl`)
- background tracking (`trackchar`)

This is still a stage-runtime DSL model, not a claim of full Ikemen engine parity.

### Bytecode optimizer correctness fix

The peephole pass now preserves contiguous constant streams when rebuilding bytecode atom pools.
This matters because multi-value DSL calls like:

```text
modifybgctrl = WalkRight, x, 3
scalestart = 1.0, 1.0
```

must keep their argument tuples intact after optimization.

### Example runtime probes

```sh
./mugen-stage-dsl run examples/dosmugen2001_compat.def --profile dosmugen2001 --ticks 1
./mugen-stage-dsl run examples/mugen1_0_stage.def --ticks 1
./mugen-stage-dsl run examples/mugen1_1_stage.def --ticks 1
./mugen-stage-dsl timeline examples/ikemen_stub.def --profile ikemengoplus --ticks 3
./mugen-stage-dsl timeline examples/ikemen_ultra_stub.def --profile ikemenplusultra --ticks 3
```

Expected highlights:

- DOS / Win legacy profiles stay at integer-style camera behavior
- 1.0 exposes non-default clip bounds from overdraw/cut
- 1.1 shows live zoom/parallax/shadow skew state
- Ikemen examples now show real attachment / mutation effects in timeline output

## Phase 6 additions

### Versioned MUGEN sublibs

The MUGEN resolver is now split into profile-oriented sublibs:

- `dosmugen2001`
- `winmugen2002`
- `mugen1.0`
- `mugen1.1`

Each sublib exposes:

- a section/key manifest
- a BGCtrl type manifest
- profile-specific semantic gating
- profile summary / word-list CLI output

`dosmugen2001` is intentionally conservative and acts as a compatibility flavor for pre-1.0 legacy stage words.

### Ikemen stub libs

Two extra extension profiles are now present as **stubs**:

- `ikemengoplus`
- `ikemenplusultra`

These are not claimed as canonical engine implementations.
They reserve / validate extension words and, from phase 7 onward, several of them also execute concrete runtime semantics in the VM/runtime layer.

Current stub words include things like:

- `attachedchar`
- `attachedid`
- `sctrlid`
- `modifybgctrl`
- `charoffset` *(ultra stub)*
- `followchar` *(ultra stub)*
- `trackchar` *(ultra stub)*

### Profile-aware semantic pass

Semantic validation now resolves an **effective profile** from either:

- `--profile NAME`
- or `[Info] mugenversion`

The pass rejects keys that exist in the global DSL but are not valid for the active version profile.

Examples:

- 1.0 accepts `overdrawhigh` / `overdrawlow` / `cuthigh` / `cutlow`
- 1.1 accepts `startzoom` / `zoomout` / `zoomin`
- 1.1 accepts modern parallax keys like `width`, `scalestart`, `scaledelta`, `maskwindow`, `zoomdelta`
- pre-1.1 profiles reject those 1.1-only words
- Ikemen stub profiles accept their reserved extension keys in strict mode

### New builtin coverage

The runtime word layer now has direct generic/game builtins for previously raw-only stage words such as:

- `Shadow.color`
- `Shadow.fade.range`
- `Shadow.xshear`
- `Camera.overdrawhigh`
- `Camera.overdrawlow`
- `Camera.cuthigh`
- `Camera.cutlow`
- `Camera.startzoom`
- `Camera.zoomout`
- `Camera.zoomin`
- `BG.yscalestart`
- `BG.yscaledelta`

### New CLI profile tools

```sh
./mugen-stage-dsl profile examples/basic_stage.def
./mugen-stage-dsl profile examples/dosmugen2001_compat.def --profile dosmugen2001
./mugen-stage-dsl words examples/basic_stage.def --profile mugen1.1
./mugen-stage-dsl check examples/mugen1_0_stage.def --strict
./mugen-stage-dsl check examples/mugen1_1_stage.def --strict
./mugen-stage-dsl check examples/ikemen_stub.def --profile ikemengoplus --strict
./mugen-stage-dsl check examples/ikemen_ultra_stub.def --profile ikemenplusultra --strict
```

### New examples

- `examples/dosmugen2001_compat.def`
- `examples/winmugen2002_stage.def`
- `examples/mugen1_0_stage.def`
- `examples/mugen1_1_stage.def`
- `examples/ikemen_stub.def`
- `examples/ikemen_ultra_stub.def`

## Phase 5 additions

### 1) Module linker / include expander

The frontend now supports a DSL-level include system before lexing:

```text
@include "modules/music.definc"
#include "modules/bg_bundle.definc"
```

Notes:

- this is a **DSL extension**, not a claim about native MUGEN DEF include syntax
- include paths are resolved relative to the including file
- nesting is supported up to a fixed static depth
- no heap allocation is used
- dependency fingerprints are recorded in load order

New commands:

```sh
./mugen-stage-dsl deps examples/modular_stage.def
./mugen-stage-dsl link examples/modular_stage.def --out /tmp/modular.linked.def
```

### 2) Bytecode verifier

A dedicated verifier now checks compiled bytecode before execution or cache serialization.

It validates:

- `BEGIN` / `CALL` / `END` structure
- section nesting rules
- active-section matching for calls and ends
- constant/name atom bounds
- word/section compatibility
- row-vs-assignment call shape

New command:

```sh
./mugen-stage-dsl verify examples/basic_stage.def
```

### 3) Stronger SSA-lite metadata

SSA-lite now carries value fingerprints in addition to versioning:

- value tuple hash per assignment/row
- value class ids (`vN`)
- same-value redefinition detection for repeated unique-key writes
- summary counters for value classes and same-value redefs

This stays allocation-free and CFG-free.

### 4) Canonical AST binary snapshot

A new binary format stores a canonical AST-oriented compiler snapshot.

It serializes:

- source identity/hash
- atoms
- parsed sections/items
- canonical section metadata
- canonical compile plans

New commands:

```sh
./mugen-stage-dsl cast examples/modular_stage.def --out /tmp/mod.msda
./mugen-stage-dsl cast-info /tmp/mod.msda
```

### 5) AOT cache with dependency fingerprints

A new `.msdaot` cache stores:

- ABI/fixed-point compatibility info
- merged source hash/size
- dependency path/hash/size fingerprints
- verified canonical bytecode
- bytecode atom pool

Reuse requires all dependency fingerprints to match.

New commands:

```sh
./mugen-stage-dsl aot examples/modular_stage.def --out /tmp/mod.msdaot
./mugen-stage-dsl aot-info /tmp/mod.msdaot
./mugen-stage-dsl aot-run examples/modular_stage.def --cache /tmp/mod.msdaot --ticks 8
```

## Phase 4 features still present

### SSA-lite and canonicalization

- unique keys versioned as `name#1`, `name#2`, ...
- live/dead marking for last-wins semantics
- duplicate unique keys collapsed to last effective value
- stable canonical ordering for known unique keys
- raw/non-unique entries preserved in source order
- canonical IR and canonical bytecode generation

### Incremental section cache

- per-section plan hash
- per-section canonical plan reuse
- whitespace-tolerant section reuse
- partial rebuild when only some sections change

## Phase 3 features still present

### Separate syntax pass and semantic pass

- **syntax pass**
  - unknown section headers
  - required symbolic headers for `[BG ...]`, `[BGCtrlDef ...]`, `[BGCtrl ...]`
  - numeric `[Begin Action N]`
  - row-only-in-action constraints
- **semantic pass**
  - per-section key tables
  - arity validation
  - value-type validation
  - duplicate unique-key checks
  - range checks
  - section-shape rules
  - cross references:
    - `zoffsetlink -> BG id`
    - `ctrlID -> BG id`
    - `actionno` / `Anim -> Begin Action`

### Optimizer / peephole layer

- **IR dead-store elimination**
  - drops earlier overridden writes for unique per-section keys
- **bytecode peephole + atom interning**
  - removes redundant pure setter calls that survive lowering
  - interns bytecode atoms to shrink the constant pool

## Frontend coverage

Implemented section kinds:

- `Info`
- `Camera`
- `PlayerInfo`
- `Bound`
- `StageInfo`
- `Shadow`
- `Reflection`
- `Music`
- `BGDef`
- `BG`
- `BGCtrlDef`
- `BGCtrl`
- `Begin Action`

Tokenizer improvement already kept from v2:

- mixed atoms such as `3.da`

## Runtime / VM coverage

Implemented controller semantics:

- `null`
- `Visible`
- `Enabled`
- `VelSet`
- `VelAdd`
- `PosSet`
- `PosAdd`
- `Anim`
- `SinX`
- `SinY`

Supported timing behavior:

- parent `BGCtrlDef.looptime`
- per-controller `time = start[, end[, loop]]`
- inherited `ctrlID` fallback from `BGCtrlDef`
- default target = all backgrounds when no `ctrlID` exists

## CLI

```sh
make
```

### Frontend and linker

```sh
./mugen-stage-dsl deps examples/modular_stage.def
./mugen-stage-dsl link examples/modular_stage.def --out /tmp/modular.linked.def
./mugen-stage-dsl lex examples/basic_stage.def
./mugen-stage-dsl ast examples/basic_stage.def
./mugen-stage-dsl ir examples/basic_stage.def
./mugen-stage-dsl bc examples/basic_stage.def
```

### Validation and verification

```sh
./mugen-stage-dsl syntax examples/basic_stage.def
./mugen-stage-dsl sem examples/basic_stage.def --strict
./mugen-stage-dsl check examples/basic_stage.def --strict
./mugen-stage-dsl verify examples/basic_stage.def
```

### Optimization / canonicalization

```sh
./mugen-stage-dsl opt examples/optimizer_redundant.def
./mugen-stage-dsl ssa examples/optimizer_redundant.def
./mugen-stage-dsl canon examples/basic_stage.def
```

### Canonical AST snapshot

```sh
./mugen-stage-dsl cast examples/modular_stage.def --out /tmp/mod.msda
./mugen-stage-dsl cast-info /tmp/mod.msda
```

### Runtime execution

```sh
./mugen-stage-dsl run examples/basic_stage.def --ticks 8
./mugen-stage-dsl timeline examples/bgctrl_timeline.def --ticks 12
```

### Whole-program cache workflow

```sh
./mugen-stage-dsl cache examples/basic_stage.def --out /tmp/basic.msdc
./mugen-stage-dsl cache-info /tmp/basic.msdc
./mugen-stage-dsl cache-run examples/basic_stage.def --cache /tmp/basic.msdc --ticks 8
```

### Incremental section cache workflow

```sh
./mugen-stage-dsl cache-inc examples/basic_stage.def --out /tmp/basic.msdci
./mugen-stage-dsl cache-inc-info /tmp/basic.msdci
./mugen-stage-dsl cache-inc-run examples/basic_stage_whitespace.def --cache /tmp/basic.msdci --ticks 8
./mugen-stage-dsl cache-inc-run examples/basic_stage_music_patch.def --cache /tmp/basic.msdci --ticks 8
```

### AOT cache workflow

```sh
./mugen-stage-dsl aot examples/modular_stage.def --out /tmp/mod.msdaot
./mugen-stage-dsl aot-info /tmp/mod.msdaot
./mugen-stage-dsl aot-run examples/modular_stage.def --cache /tmp/mod.msdaot --ticks 8
./mugen-stage-dsl aot-run examples/modular_stage_music_patch.def --cache /tmp/mod.msdaot --ticks 8
```

## Example files

- `examples/basic_stage.def` — valid general sample
- `examples/basic_stage_whitespace.def` — same semantics, formatting changed
- `examples/basic_stage_music_patch.def` — one section changed for incremental miss demo
- `examples/bgctrl_timeline.def` — compact timeline demo for `BGCtrl`
- `examples/semantic_errors.def` — intentionally broken file for validator smoke tests
- `examples/optimizer_redundant.def` — repeated unique keys for optimizer / SSA / canonicalization demo
- `examples/modular_stage.def` — linked DSL stage with nested includes
- `examples/modular_stage_music_patch.def` — dependency-change demo for AOT rebuild
- `examples/modules/*.definc` — reusable stage modules

## Notes / limits

- the include system is a **compiler extension**, not native MUGEN syntax
- the parser still preserves unsupported but syntactically valid assignments as raw passthrough entries
- camera motion, draw ordering, sprite rendering and full AIR flag semantics are **not** implemented
- the VM is meant as a **semantic compiler/runtime core**, not yet a full renderer
- all storage is static / fixed-capacity as defined in `include/msd_config.h`

## Smoke test

```sh
make test
```
