#ifndef M2D_STAGE_MANAGER_H
#define M2D_STAGE_MANAGER_H

#include "m2d_common.h"
#include "m2d_compat.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct m2d_stage_asset
{
    char name[64];
    char displayname[64];
    char author[64];
    m2d_compat_profile compat;
    long boundleft;
    long boundright;
    long tension;
    long zoomout_q16;
    long zoomin_q16;
} m2d_stage_asset;

typedef struct m2d_stage_manager
{
    m2d_stage_asset stages[4];
    m2d_u16 stage_count;
    m2d_u16 selected_stage;
} m2d_stage_manager;

void m2d_stage_manager_init(m2d_stage_manager *mgr);
void m2d_stage_manager_seed_demo_stages(m2d_stage_manager *mgr);
int m2d_stage_manager_load_stage_into_slot(m2d_stage_manager *mgr, m2d_u16 index, const char *path);
const m2d_stage_asset *m2d_stage_manager_current(const m2d_stage_manager *mgr);

#ifdef __cplusplus
}
#endif

#endif
