#include "m2d_stage_manager.h"
#include "m2d_common.h"
#include "m2d_stage_dsl_probe.h"

static m2d_compat_profile m2d_stage_profile_from_text(const char *text)
{
    if (text == (const char*)0) {
        return M2D_COMPAT_MUGEN_1_1;
    }
    if (text[0] == 'm' && text[5] == '1' && text[7] == '1') {
        return M2D_COMPAT_MUGEN_1_1;
    }
    if (text[0] == 'm' && text[5] == '1' && text[7] == '0') {
        return M2D_COMPAT_MUGEN_1_0;
    }
    return M2D_COMPAT_WINMUGEN_2002;
}

void m2d_stage_manager_init(m2d_stage_manager *mgr)
{
    if (mgr == (m2d_stage_manager*)0) {
        return;
    }
    mgr->stage_count = 0u;
    mgr->selected_stage = 0u;
}

void m2d_stage_manager_seed_demo_stages(m2d_stage_manager *mgr)
{
    m2d_stage_asset *slot;

    if (mgr == (m2d_stage_manager*)0) {
        return;
    }

    mgr->stage_count = 2u;
    mgr->selected_stage = 0u;

    slot = &mgr->stages[0];
    m2d_copy_cstr(slot->name, sizeof(slot->name), "training_room");
    m2d_copy_cstr(slot->displayname, sizeof(slot->displayname), "Training Room");
    m2d_copy_cstr(slot->author, sizeof(slot->author), "Merequetege2D");
    slot->compat = M2D_COMPAT_MUGEN_1_1;
    slot->boundleft = -180l;
    slot->boundright = 180l;
    slot->tension = 50l;
    slot->zoomout_q16 = 52428l;
    slot->zoomin_q16 = 75366l;

    slot = &mgr->stages[1];
    m2d_copy_cstr(slot->name, sizeof(slot->name), "retro_dojo");
    m2d_copy_cstr(slot->displayname, sizeof(slot->displayname), "Retro Dojo");
    m2d_copy_cstr(slot->author, sizeof(slot->author), "Merequetege2D");
    slot->compat = M2D_COMPAT_WINMUGEN_2002;
    slot->boundleft = -160l;
    slot->boundright = 160l;
    slot->tension = 50l;
    slot->zoomout_q16 = 65536l;
    slot->zoomin_q16 = 65536l;
}

int m2d_stage_manager_load_stage_into_slot(m2d_stage_manager *mgr, m2d_u16 index, const char *path)
{
    m2d_stage_dsl_probe_result probe;
    m2d_stage_asset *slot;

    if (mgr == (m2d_stage_manager*)0 || index >= 4u) {
        return M2D_FALSE;
    }
    if (!m2d_stage_dsl_probe_file(path, &probe)) {
        return M2D_FALSE;
    }

    slot = &mgr->stages[index];
    m2d_copy_cstr(slot->name, sizeof(slot->name), probe.name);
    m2d_copy_cstr(slot->displayname, sizeof(slot->displayname), probe.displayname);
    m2d_copy_cstr(slot->author, sizeof(slot->author), probe.author);
    slot->compat = m2d_stage_profile_from_text(probe.profile);
    slot->boundleft = -220l;
    slot->boundright = 220l;
    slot->tension = 55l;
    slot->zoomout_q16 = probe.zoomout_q16;
    slot->zoomin_q16 = probe.zoomin_q16;

    if (mgr->stage_count <= index) {
        mgr->stage_count = (m2d_u16)(index + 1u);
    }
    return M2D_TRUE;
}

const m2d_stage_asset *m2d_stage_manager_current(const m2d_stage_manager *mgr)
{
    if (mgr == (const m2d_stage_manager*)0 || mgr->selected_stage >= mgr->stage_count) {
        return (const m2d_stage_asset*)0;
    }
    return &mgr->stages[mgr->selected_stage];
}
