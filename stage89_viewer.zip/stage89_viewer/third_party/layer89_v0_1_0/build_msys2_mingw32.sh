#!/usr/bin/env sh
set -eu
mkdir -p build
gcc -std=gnu89 -Wall -Wextra -Wpedantic -O2 \
  -Iinclude \
  src/layer89.c examples/layer89_demo_win32.c \
  -mwindows -lgdi32 -o build/layer89_demo.exe
printf '%s\n' 'BUILD OK: build/layer89_demo.exe'
