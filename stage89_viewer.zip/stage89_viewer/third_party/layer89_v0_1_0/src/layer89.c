#include "layer89.h"

#include <limits.h>
#include <stddef.h>

static unsigned short layer89_next_generation(unsigned short value)
{
    value = (unsigned short)(value + 1u);
    if (value == 0u) {
        value = 1u;
    }
    return value;
}

static int layer89_item_less(
    const layer89_item *left,
    const layer89_item *right
)
{
    if (left->z < right->z) {
        return 1;
    }
    if (left->z > right->z) {
        return 0;
    }
    return left->serial < right->serial;
}

static layer89_item *layer89_resolve(
    layer89_system *system,
    layer89_handle handle
)
{
    layer89_item *item;

    if (system == NULL) {
        return NULL;
    }
    if (handle.slot == LAYER89_INVALID_SLOT) {
        return NULL;
    }
    if ((unsigned int)handle.slot >= (unsigned int)LAYER89_MAX_ITEMS) {
        return NULL;
    }

    item = &system->items[handle.slot];
    if (!item->active) {
        return NULL;
    }
    if (item->generation != handle.generation) {
        return NULL;
    }
    return item;
}

static const layer89_item *layer89_resolve_const(
    const layer89_system *system,
    layer89_handle handle
)
{
    const layer89_item *item;

    if (system == NULL) {
        return NULL;
    }
    if (handle.slot == LAYER89_INVALID_SLOT) {
        return NULL;
    }
    if ((unsigned int)handle.slot >= (unsigned int)LAYER89_MAX_ITEMS) {
        return NULL;
    }

    item = &system->items[handle.slot];
    if (!item->active) {
        return NULL;
    }
    if (item->generation != handle.generation) {
        return NULL;
    }
    return item;
}

static void layer89_rebase(layer89_system *system)
{
    unsigned short count;
    unsigned short index;
    signed long base;

    count = layer89_build_render_order(system);
    base = 0L - ((signed long)count / 2L);

    for (index = 0u; index < count; ++index) {
        system->items[system->render_order[index]].z = base + (signed long)index;
        system->items[system->render_order[index]].serial = (unsigned long)index + 1ul;
    }

    system->next_serial = (unsigned long)count + 1ul;
}

static int layer89_swap_order_values(
    layer89_system *system,
    unsigned short left_slot,
    unsigned short right_slot
)
{
    signed long z_temp;
    unsigned long serial_temp;

    z_temp = system->items[left_slot].z;
    serial_temp = system->items[left_slot].serial;

    system->items[left_slot].z = system->items[right_slot].z;
    system->items[left_slot].serial = system->items[right_slot].serial;

    system->items[right_slot].z = z_temp;
    system->items[right_slot].serial = serial_temp;
    return 1;
}

void layer89_init(layer89_system *system)
{
    unsigned short index;

    if (system == NULL) {
        return;
    }

    system->active_count = 0u;
    system->free_hint = 0u;
    system->next_serial = 1ul;

    for (index = 0u; index < (unsigned short)LAYER89_MAX_ITEMS; ++index) {
        system->items[index].active = 0u;
        system->items[index].visible = 1u;
        system->items[index].enabled = 1u;
        system->items[index].reserved = 0u;
        system->items[index].generation = 1u;
        system->items[index].slot = index;
        system->items[index].z = 0L;
        system->items[index].serial = 0ul;
        system->items[index].draw = NULL;
        system->items[index].graphic = NULL;
        system->render_order[index] = index;
    }
}

void layer89_clear(layer89_system *system)
{
    unsigned short index;

    if (system == NULL) {
        return;
    }

    for (index = 0u; index < (unsigned short)LAYER89_MAX_ITEMS; ++index) {
        system->items[index].active = 0u;
        system->items[index].visible = 1u;
        system->items[index].enabled = 1u;
        system->items[index].generation = layer89_next_generation(
            system->items[index].generation
        );
        system->items[index].z = 0L;
        system->items[index].serial = 0ul;
        system->items[index].draw = NULL;
        system->items[index].graphic = NULL;
    }

    system->active_count = 0u;
    system->free_hint = 0u;
    system->next_serial = 1ul;
}

layer89_handle layer89_invalid_handle(void)
{
    layer89_handle handle;
    handle.slot = LAYER89_INVALID_SLOT;
    handle.generation = 0u;
    return handle;
}

int layer89_handle_is_valid(
    const layer89_system *system,
    layer89_handle handle
)
{
    return layer89_resolve_const(system, handle) != NULL;
}

layer89_handle layer89_add(
    layer89_system *system,
    signed long z,
    layer89_draw_fn draw,
    void *graphic
)
{
    unsigned short attempt;
    unsigned short slot;
    layer89_item *item;
    layer89_handle handle;

    handle = layer89_invalid_handle();
    if (system == NULL || draw == NULL) {
        return handle;
    }
    if (system->active_count >= (unsigned short)LAYER89_MAX_ITEMS) {
        return handle;
    }

    slot = system->free_hint;
    for (attempt = 0u; attempt < (unsigned short)LAYER89_MAX_ITEMS; ++attempt) {
        if (!system->items[slot].active) {
            break;
        }
        slot = (unsigned short)(slot + 1u);
        if (slot >= (unsigned short)LAYER89_MAX_ITEMS) {
            slot = 0u;
        }
    }

    if (attempt >= (unsigned short)LAYER89_MAX_ITEMS) {
        return handle;
    }

    if (system->next_serial == 0ul || system->next_serial == ULONG_MAX) {
        layer89_rebase(system);
    }

    item = &system->items[slot];
    item->active = 1u;
    item->visible = 1u;
    item->enabled = 1u;
    item->z = z;
    item->serial = system->next_serial;
    item->draw = draw;
    item->graphic = graphic;

    system->next_serial += 1ul;
    system->active_count = (unsigned short)(system->active_count + 1u);
    system->free_hint = (unsigned short)(slot + 1u);
    if (system->free_hint >= (unsigned short)LAYER89_MAX_ITEMS) {
        system->free_hint = 0u;
    }

    handle.slot = slot;
    handle.generation = item->generation;
    return handle;
}

int layer89_remove(layer89_system *system, layer89_handle handle)
{
    layer89_item *item;

    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }

    item->active = 0u;
    item->visible = 1u;
    item->enabled = 1u;
    item->generation = layer89_next_generation(item->generation);
    item->z = 0L;
    item->serial = 0ul;
    item->draw = NULL;
    item->graphic = NULL;

    if (system->active_count > 0u) {
        system->active_count = (unsigned short)(system->active_count - 1u);
    }
    if (handle.slot < system->free_hint) {
        system->free_hint = handle.slot;
    }
    return 1;
}

int layer89_set_visible(
    layer89_system *system,
    layer89_handle handle,
    int visible
)
{
    layer89_item *item;
    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }
    item->visible = visible ? 1u : 0u;
    return 1;
}

int layer89_set_enabled(
    layer89_system *system,
    layer89_handle handle,
    int enabled
)
{
    layer89_item *item;
    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }
    item->enabled = enabled ? 1u : 0u;
    return 1;
}

int layer89_set_z(
    layer89_system *system,
    layer89_handle handle,
    signed long z
)
{
    layer89_item *item;
    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }
    item->z = z;
    return 1;
}

int layer89_get_z(
    const layer89_system *system,
    layer89_handle handle,
    signed long *out_z
)
{
    const layer89_item *item;
    if (out_z == NULL) {
        return 0;
    }
    item = layer89_resolve_const(system, handle);
    if (item == NULL) {
        return 0;
    }
    *out_z = item->z;
    return 1;
}

int layer89_set_graphic(
    layer89_system *system,
    layer89_handle handle,
    layer89_draw_fn draw,
    void *graphic
)
{
    layer89_item *item;
    if (draw == NULL) {
        return 0;
    }
    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }
    item->draw = draw;
    item->graphic = graphic;
    return 1;
}

int layer89_bring_to_front(layer89_system *system, layer89_handle handle)
{
    unsigned short index;
    signed long highest;
    layer89_item *item;

    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }

    if (system->next_serial == 0ul || system->next_serial == ULONG_MAX) {
        layer89_rebase(system);
        item = layer89_resolve(system, handle);
    }

    highest = item->z;
    for (index = 0u; index < (unsigned short)LAYER89_MAX_ITEMS; ++index) {
        if (system->items[index].active && system->items[index].z > highest) {
            highest = system->items[index].z;
        }
    }

    if (highest == LONG_MAX) {
        layer89_rebase(system);
        item = layer89_resolve(system, handle);
        highest = system->items[system->render_order[system->active_count - 1u]].z;
    }

    item->z = highest + 1L;
    item->serial = system->next_serial++;
    return 1;
}

int layer89_send_to_back(layer89_system *system, layer89_handle handle)
{
    unsigned short index;
    signed long lowest;
    layer89_item *item;

    item = layer89_resolve(system, handle);
    if (item == NULL) {
        return 0;
    }

    lowest = item->z;
    for (index = 0u; index < (unsigned short)LAYER89_MAX_ITEMS; ++index) {
        if (system->items[index].active && system->items[index].z < lowest) {
            lowest = system->items[index].z;
        }
    }

    if (lowest == LONG_MIN) {
        layer89_rebase(system);
        item = layer89_resolve(system, handle);
        lowest = system->items[system->render_order[0u]].z;
    }

    item->z = lowest - 1L;
    item->serial = 0ul;
    return 1;
}

int layer89_bring_forward(layer89_system *system, layer89_handle handle)
{
    unsigned short count;
    unsigned short position;

    if (!layer89_handle_is_valid(system, handle)) {
        return 0;
    }

    count = layer89_build_render_order(system);
    for (position = 0u; position < count; ++position) {
        if (system->render_order[position] == handle.slot) {
            if ((unsigned short)(position + 1u) >= count) {
                return 1;
            }
            return layer89_swap_order_values(
                system,
                system->render_order[position],
                system->render_order[position + 1u]
            );
        }
    }
    return 0;
}

int layer89_send_backward(layer89_system *system, layer89_handle handle)
{
    unsigned short count;
    unsigned short position;

    if (!layer89_handle_is_valid(system, handle)) {
        return 0;
    }

    count = layer89_build_render_order(system);
    for (position = 0u; position < count; ++position) {
        if (system->render_order[position] == handle.slot) {
            if (position == 0u) {
                return 1;
            }
            return layer89_swap_order_values(
                system,
                system->render_order[position],
                system->render_order[position - 1u]
            );
        }
    }
    return 0;
}

static int layer89_move_relative(
    layer89_system *system,
    layer89_handle moving,
    layer89_handle reference,
    int place_after
)
{
    unsigned short count;
    unsigned short moving_pos;
    unsigned short reference_pos;
    unsigned short insert_pos;
    unsigned short cursor;
    unsigned short moving_slot;
    signed long target_z;
    unsigned long serial;

    if (!layer89_handle_is_valid(system, moving) ||
        !layer89_handle_is_valid(system, reference)) {
        return 0;
    }
    if (moving.slot == reference.slot) {
        return 1;
    }

    count = layer89_build_render_order(system);
    moving_pos = count;
    reference_pos = count;

    for (cursor = 0u; cursor < count; ++cursor) {
        if (system->render_order[cursor] == moving.slot) {
            moving_pos = cursor;
        }
        if (system->render_order[cursor] == reference.slot) {
            reference_pos = cursor;
        }
    }

    if (moving_pos == count || reference_pos == count) {
        return 0;
    }

    moving_slot = system->render_order[moving_pos];

    /* Remove moving from the temporary order. */
    for (cursor = moving_pos; (unsigned short)(cursor + 1u) < count; ++cursor) {
        system->render_order[cursor] = system->render_order[cursor + 1u];
    }
    count = (unsigned short)(count - 1u);

    /* Find reference again because removal may shift its position. */
    reference_pos = count;
    for (cursor = 0u; cursor < count; ++cursor) {
        if (system->render_order[cursor] == reference.slot) {
            reference_pos = cursor;
            break;
        }
    }
    if (reference_pos == count) {
        return 0;
    }

    insert_pos = place_after
        ? (unsigned short)(reference_pos + 1u)
        : reference_pos;

    for (cursor = count; cursor > insert_pos; --cursor) {
        system->render_order[cursor] = system->render_order[cursor - 1u];
    }
    system->render_order[insert_pos] = moving_slot;
    count = (unsigned short)(count + 1u);

    target_z = system->items[reference.slot].z;
    system->items[moving.slot].z = target_z;

    /* Re-serialise only the target z-band in the requested order. */
    serial = 1ul;
    for (cursor = 0u; cursor < count; ++cursor) {
        if (system->items[system->render_order[cursor]].z == target_z) {
            system->items[system->render_order[cursor]].serial = serial;
            serial += 1ul;
        }
    }

    if (system->next_serial <= serial) {
        system->next_serial = serial + 1ul;
    }
    return 1;
}

int layer89_move_before(
    layer89_system *system,
    layer89_handle moving,
    layer89_handle reference
)
{
    return layer89_move_relative(system, moving, reference, 0);
}

int layer89_move_after(
    layer89_system *system,
    layer89_handle moving,
    layer89_handle reference
)
{
    return layer89_move_relative(system, moving, reference, 1);
}

unsigned short layer89_count(const layer89_system *system)
{
    if (system == NULL) {
        return 0u;
    }
    return system->active_count;
}

unsigned short layer89_build_render_order(layer89_system *system)
{
    unsigned short slot;
    unsigned short count;
    unsigned short outer;
    unsigned short inner;
    unsigned short key_slot;

    if (system == NULL) {
        return 0u;
    }

    count = 0u;
    for (slot = 0u; slot < (unsigned short)LAYER89_MAX_ITEMS; ++slot) {
        if (system->items[slot].active) {
            system->render_order[count] = slot;
            count = (unsigned short)(count + 1u);
        }
    }

    /* Stable insertion sort: low z first, high z last. */
    for (outer = 1u; outer < count; ++outer) {
        key_slot = system->render_order[outer];
        inner = outer;

        while (inner > 0u && layer89_item_less(
            &system->items[key_slot],
            &system->items[system->render_order[inner - 1u]]
        )) {
            system->render_order[inner] = system->render_order[inner - 1u];
            inner = (unsigned short)(inner - 1u);
        }
        system->render_order[inner] = key_slot;
    }

    return count;
}

void layer89_render(
    layer89_system *system,
    const layer89_draw_context *context
)
{
    unsigned short count;
    unsigned short position;
    layer89_item *item;

    if (system == NULL || context == NULL) {
        return;
    }

    count = layer89_build_render_order(system);
    for (position = 0u; position < count; ++position) {
        item = &system->items[system->render_order[position]];
        if (item->active && item->visible && item->enabled && item->draw != NULL) {
            item->draw(item->graphic, context);
        }
    }
}
