#include <assert.h>
#include <stdio.h>

#include "layer89.h"

static int g_draw_order[16];
static int g_draw_count;

typedef struct test_graphic {
    int id;
} test_graphic;

static void test_draw(void *graphic, const layer89_draw_context *context)
{
    test_graphic *value;
    (void)context;
    value = (test_graphic *)graphic;
    g_draw_order[g_draw_count++] = value->id;
}

static void render_and_expect(
    layer89_system *system,
    const int *expected,
    int count
)
{
    layer89_draw_context context;
    int index;

    context.render_target = NULL;
    context.viewport_width = 0;
    context.viewport_height = 0;
    context.frame_index = 0ul;
    g_draw_count = 0;
    layer89_render(system, &context);
    assert(g_draw_count == count);
    for (index = 0; index < count; ++index) {
        assert(g_draw_order[index] == expected[index]);
    }
}

int main(void)
{
    layer89_system system;
    layer89_handle a;
    layer89_handle b;
    layer89_handle c;
    layer89_handle old_b;
    test_graphic ga;
    test_graphic gb;
    test_graphic gc;
    int expected[3];

    ga.id = 1;
    gb.id = 2;
    gc.id = 3;

    layer89_init(&system);
    a = layer89_add(&system, 0L, test_draw, &ga);
    b = layer89_add(&system, 0L, test_draw, &gb);
    c = layer89_add(&system, 0L, test_draw, &gc);
    assert(layer89_count(&system) == 3u);

    expected[0] = 1; expected[1] = 2; expected[2] = 3;
    render_and_expect(&system, expected, 3);

    assert(layer89_move_before(&system, c, a));
    expected[0] = 3; expected[1] = 1; expected[2] = 2;
    render_and_expect(&system, expected, 3);

    assert(layer89_move_after(&system, c, b));
    expected[0] = 1; expected[1] = 2; expected[2] = 3;
    render_and_expect(&system, expected, 3);

    assert(layer89_send_backward(&system, c));
    expected[0] = 1; expected[1] = 3; expected[2] = 2;
    render_and_expect(&system, expected, 3);

    assert(layer89_bring_forward(&system, a));
    expected[0] = 3; expected[1] = 1; expected[2] = 2;
    render_and_expect(&system, expected, 3);

    assert(layer89_bring_to_front(&system, c));
    expected[0] = 1; expected[1] = 2; expected[2] = 3;
    render_and_expect(&system, expected, 3);

    assert(layer89_send_to_back(&system, b));
    expected[0] = 2; expected[1] = 1; expected[2] = 3;
    render_and_expect(&system, expected, 3);

    assert(layer89_set_visible(&system, a, 0));
    expected[0] = 2; expected[1] = 3;
    render_and_expect(&system, expected, 2);
    assert(layer89_set_visible(&system, a, 1));

    old_b = b;
    assert(layer89_remove(&system, b));
    assert(!layer89_handle_is_valid(&system, old_b));
    b = layer89_add(&system, 5L, test_draw, &gb);
    assert(layer89_handle_is_valid(&system, b));
    assert(old_b.generation != b.generation || old_b.slot != b.slot);

    puts("layer89 tests: OK");
    return 0;
}
