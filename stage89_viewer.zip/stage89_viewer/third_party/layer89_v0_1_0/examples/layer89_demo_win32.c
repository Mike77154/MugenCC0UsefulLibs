#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include "layer89.h"

typedef struct demo_rect {
    int left;
    int top;
    int right;
    int bottom;
    COLORREF fill;
    const char *label;
} demo_rect;

typedef struct demo_state {
    layer89_system layers;
    layer89_handle handles[3];
    demo_rect rects[3];
    int selected;
    unsigned long frame_index;
} demo_state;

static demo_state g_demo;

static void demo_draw_rect(
    void *graphic,
    const layer89_draw_context *context
)
{
    demo_rect *rect;
    HDC dc;
    HBRUSH brush;
    RECT bounds;
    int old_mode;

    rect = (demo_rect *)graphic;
    dc = (HDC)context->render_target;
    bounds.left = rect->left;
    bounds.top = rect->top;
    bounds.right = rect->right;
    bounds.bottom = rect->bottom;

    brush = CreateSolidBrush(rect->fill);
    FillRect(dc, &bounds, brush);
    DeleteObject(brush);

    FrameRect(dc, &bounds, (HBRUSH)GetStockObject(BLACK_BRUSH));
    old_mode = SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, RGB(255, 255, 255));
    TextOutA(dc, rect->left + 10, rect->top + 10, rect->label,
             lstrlenA(rect->label));
    SetBkMode(dc, old_mode);
}

static void demo_init(void)
{
    layer89_init(&g_demo.layers);
    g_demo.selected = 0;
    g_demo.frame_index = 0ul;

    g_demo.rects[0].left = 80;
    g_demo.rects[0].top = 90;
    g_demo.rects[0].right = 300;
    g_demo.rects[0].bottom = 250;
    g_demo.rects[0].fill = RGB(190, 50, 70);
    g_demo.rects[0].label = "1 - ROJO";

    g_demo.rects[1].left = 180;
    g_demo.rects[1].top = 140;
    g_demo.rects[1].right = 400;
    g_demo.rects[1].bottom = 300;
    g_demo.rects[1].fill = RGB(50, 150, 90);
    g_demo.rects[1].label = "2 - VERDE";

    g_demo.rects[2].left = 280;
    g_demo.rects[2].top = 190;
    g_demo.rects[2].right = 500;
    g_demo.rects[2].bottom = 350;
    g_demo.rects[2].fill = RGB(50, 90, 190);
    g_demo.rects[2].label = "3 - AZUL";

    g_demo.handles[0] = layer89_add(
        &g_demo.layers, LAYER89_Z_WORLD, demo_draw_rect, &g_demo.rects[0]
    );
    g_demo.handles[1] = layer89_add(
        &g_demo.layers, LAYER89_Z_WORLD + 1L, demo_draw_rect, &g_demo.rects[1]
    );
    g_demo.handles[2] = layer89_add(
        &g_demo.layers, LAYER89_Z_WORLD + 2L, demo_draw_rect, &g_demo.rects[2]
    );
}

static void demo_draw(HWND window, HDC target_dc)
{
    RECT client;
    HDC memory_dc;
    HBITMAP bitmap;
    HBITMAP old_bitmap;
    layer89_draw_context context;
    char status[160];
    signed long z;

    GetClientRect(window, &client);
    memory_dc = CreateCompatibleDC(target_dc);
    bitmap = CreateCompatibleBitmap(
        target_dc,
        client.right - client.left,
        client.bottom - client.top
    );
    old_bitmap = (HBITMAP)SelectObject(memory_dc, bitmap);

    FillRect(memory_dc, &client, (HBRUSH)(COLOR_WINDOW + 1));

    context.render_target = (void *)memory_dc;
    context.viewport_width = client.right - client.left;
    context.viewport_height = client.bottom - client.top;
    context.frame_index = g_demo.frame_index;
    layer89_render(&g_demo.layers, &context);

    layer89_get_z(
        &g_demo.layers,
        g_demo.handles[g_demo.selected],
        &z
    );
    wsprintfA(
        status,
        "Seleccion: %d | z=%ld | HOME frente | END fondo | PGUP/PGDN paso | V visible",
        g_demo.selected + 1,
        z
    );
    SetBkMode(memory_dc, TRANSPARENT);
    SetTextColor(memory_dc, RGB(20, 20, 20));
    TextOutA(memory_dc, 12, 12, status, lstrlenA(status));

    BitBlt(
        target_dc,
        0,
        0,
        client.right - client.left,
        client.bottom - client.top,
        memory_dc,
        0,
        0,
        SRCCOPY
    );

    SelectObject(memory_dc, old_bitmap);
    DeleteObject(bitmap);
    DeleteDC(memory_dc);
}

static LRESULT CALLBACK demo_window_proc(
    HWND window,
    UINT message,
    WPARAM wparam,
    LPARAM lparam
)
{
    PAINTSTRUCT paint;
    HDC dc;
    int visible;

    (void)lparam;

    switch (message) {
        case WM_CREATE:
            demo_init();
            return 0;

        case WM_KEYDOWN:
            if (wparam >= '1' && wparam <= '3') {
                g_demo.selected = (int)(wparam - '1');
            } else if (wparam == VK_HOME) {
                layer89_bring_to_front(
                    &g_demo.layers,
                    g_demo.handles[g_demo.selected]
                );
            } else if (wparam == VK_END) {
                layer89_send_to_back(
                    &g_demo.layers,
                    g_demo.handles[g_demo.selected]
                );
            } else if (wparam == VK_PRIOR) {
                layer89_bring_forward(
                    &g_demo.layers,
                    g_demo.handles[g_demo.selected]
                );
            } else if (wparam == VK_NEXT) {
                layer89_send_backward(
                    &g_demo.layers,
                    g_demo.handles[g_demo.selected]
                );
            } else if (wparam == 'V') {
                visible = g_demo.layers.items[
                    g_demo.handles[g_demo.selected].slot
                ].visible ? 0 : 1;
                layer89_set_visible(
                    &g_demo.layers,
                    g_demo.handles[g_demo.selected],
                    visible
                );
            }
            InvalidateRect(window, NULL, FALSE);
            return 0;

        case WM_PAINT:
            dc = BeginPaint(window, &paint);
            demo_draw(window, dc);
            EndPaint(window, &paint);
            g_demo.frame_index += 1ul;
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProcA(window, message, wparam, lparam);
}

int WINAPI WinMain(
    HINSTANCE instance,
    HINSTANCE previous_instance,
    LPSTR command_line,
    int show_command
)
{
    WNDCLASSA window_class;
    HWND window;
    MSG message;

    (void)previous_instance;
    (void)command_line;

    ZeroMemory(&window_class, sizeof(window_class));
    window_class.style = CS_HREDRAW | CS_VREDRAW;
    window_class.lpfnWndProc = demo_window_proc;
    window_class.hInstance = instance;
    window_class.hCursor = LoadCursor(NULL, IDC_ARROW);
    window_class.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    window_class.lpszClassName = "layer89_demo_class";

    if (!RegisterClassA(&window_class)) {
        return 1;
    }

    window = CreateWindowExA(
        0,
        window_class.lpszClassName,
        "layer89 - demo Win32 GDI",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        640,
        480,
        NULL,
        NULL,
        instance,
        NULL
    );
    if (window == NULL) {
        return 1;
    }

    ShowWindow(window, show_command);
    UpdateWindow(window);

    while (GetMessageA(&message, NULL, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }

    return (int)message.wParam;
}
