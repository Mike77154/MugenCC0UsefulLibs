# API rápida

## Crear y destruir

- `layer89_init`
- `layer89_clear`
- `layer89_add`
- `layer89_remove`

## Visibilidad y contenido

- `layer89_set_visible`: no dibuja, pero conserva posición.
- `layer89_set_enabled`: desactiva el callback sin remover el nodo.
- `layer89_set_graphic`: cambia callback y puntero sin recrear el handle.

## Orden

- `layer89_set_z`: asigna una profundidad absoluta.
- `layer89_bring_to_front`: mayor profundidad global.
- `layer89_send_to_back`: menor profundidad global.
- `layer89_bring_forward`: intercambia con el siguiente elemento visible en orden.
- `layer89_send_backward`: intercambia con el anterior.
- `layer89_move_before`: coloca un elemento justo detrás de otro.
- `layer89_move_after`: coloca un elemento justo delante de otro.

## Render

`layer89_render` reconstruye el orden con insertion sort estable sobre un arreglo estático de índices. No mueve ni copia los gráficos del usuario.
