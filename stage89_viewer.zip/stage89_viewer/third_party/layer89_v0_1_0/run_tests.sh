#!/usr/bin/env sh
set -eu
mkdir -p build
gcc -std=c89 -Wall -Wextra -Wpedantic -Iinclude \
  src/layer89.c tests/test_layer89.c -o build/test_layer89
./build/test_layer89
