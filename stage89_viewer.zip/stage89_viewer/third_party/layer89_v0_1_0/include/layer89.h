#ifndef LAYER89_H
#define LAYER89_H

/*
 * layer89 - fixed-capacity render layer ordering for C89 engines.
 *
 * Design rules:
 *   - ISO C89 core.
 *   - No malloc/realloc/free.
 *   - No floating-point types.
 *   - User-owned graphics; layer89 only stores callback + pointer.
 *   - Stable back-to-front rendering.
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LAYER89_MAX_ITEMS
#define LAYER89_MAX_ITEMS 256
#endif

#ifndef LAYER89_INVALID_SLOT
#define LAYER89_INVALID_SLOT ((unsigned short)0xFFFFu)
#endif

/* Suggested broad render bands. Any signed long value is valid. */
#define LAYER89_Z_FAR_BACKGROUND (-30000L)
#define LAYER89_Z_BACKGROUND     (-20000L)
#define LAYER89_Z_WORLD_BACK     (-10000L)
#define LAYER89_Z_WORLD          (0L)
#define LAYER89_Z_WORLD_FRONT    (10000L)
#define LAYER89_Z_HUD            (20000L)
#define LAYER89_Z_OVERLAY        (30000L)
#define LAYER89_Z_DEBUG          (32000L)

typedef struct layer89_handle {
    unsigned short slot;
    unsigned short generation;
} layer89_handle;

typedef struct layer89_draw_context {
    void *render_target;
    int viewport_width;
    int viewport_height;
    unsigned long frame_index;
} layer89_draw_context;

typedef void (*layer89_draw_fn)(
    void *graphic,
    const layer89_draw_context *context
);

typedef struct layer89_item {
    unsigned char active;
    unsigned char visible;
    unsigned char enabled;
    unsigned char reserved;
    unsigned short generation;
    unsigned short slot;
    signed long z;
    unsigned long serial;
    layer89_draw_fn draw;
    void *graphic;
} layer89_item;

typedef struct layer89_system {
    layer89_item items[LAYER89_MAX_ITEMS];
    unsigned short render_order[LAYER89_MAX_ITEMS];
    unsigned short active_count;
    unsigned short free_hint;
    unsigned long next_serial;
} layer89_system;

/* Lifecycle */
void layer89_init(layer89_system *system);
void layer89_clear(layer89_system *system);

/* Handle helpers */
layer89_handle layer89_invalid_handle(void);
int layer89_handle_is_valid(
    const layer89_system *system,
    layer89_handle handle
);

/* Item management */
layer89_handle layer89_add(
    layer89_system *system,
    signed long z,
    layer89_draw_fn draw,
    void *graphic
);
int layer89_remove(layer89_system *system, layer89_handle handle);

/* Properties */
int layer89_set_visible(
    layer89_system *system,
    layer89_handle handle,
    int visible
);
int layer89_set_enabled(
    layer89_system *system,
    layer89_handle handle,
    int enabled
);
int layer89_set_z(
    layer89_system *system,
    layer89_handle handle,
    signed long z
);
int layer89_get_z(
    const layer89_system *system,
    layer89_handle handle,
    signed long *out_z
);
int layer89_set_graphic(
    layer89_system *system,
    layer89_handle handle,
    layer89_draw_fn draw,
    void *graphic
);

/* Ordering operations */
int layer89_bring_to_front(layer89_system *system, layer89_handle handle);
int layer89_send_to_back(layer89_system *system, layer89_handle handle);
int layer89_bring_forward(layer89_system *system, layer89_handle handle);
int layer89_send_backward(layer89_system *system, layer89_handle handle);
int layer89_move_before(
    layer89_system *system,
    layer89_handle moving,
    layer89_handle reference
);
int layer89_move_after(
    layer89_system *system,
    layer89_handle moving,
    layer89_handle reference
);

/* Queries and rendering */
unsigned short layer89_count(const layer89_system *system);
unsigned short layer89_build_render_order(layer89_system *system);
void layer89_render(
    layer89_system *system,
    const layer89_draw_context *context
);

#ifdef __cplusplus
}
#endif

#endif /* LAYER89_H */
