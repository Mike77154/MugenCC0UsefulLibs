@echo off
setlocal

if not exist build mkdir build

gcc -std=gnu89 -Wall -Wextra -Wpedantic -O2 ^
  -Iinclude ^
  src\layer89.c examples\layer89_demo_win32.c ^
  -mwindows -lgdi32 -o build\layer89_demo.exe

if errorlevel 1 (
  echo BUILD FAILED
  exit /b 1
)

echo BUILD OK: build\layer89_demo.exe
endlocal
