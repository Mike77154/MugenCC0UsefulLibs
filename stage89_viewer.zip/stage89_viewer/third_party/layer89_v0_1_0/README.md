# layer89 v0.1.0

Sistema de capas de render genérico, portable y vendorizable para motores C89.

## Restricciones cumplidas

- ISO C89 / `-std=gnu89`.
- Sin `malloc`, `realloc`, `free` ni heap propio.
- Sin `float` ni `double`.
- Pool estático de capacidad fija.
- Handles con generación para detectar referencias viejas.
- Orden estable: menor `z` se dibuja primero; mayor `z` queda adelante.
- El sistema no posee ni copia gráficos: almacena un callback y un puntero provisto por el motor.

## Integración mínima

```c
#include "layer89.h"

static void draw_sprite(void *graphic, const layer89_draw_context *ctx)
{
    MySprite *sprite = (MySprite *)graphic;
    MyRenderer *renderer = (MyRenderer *)ctx->render_target;
    my_renderer_draw_sprite(renderer, sprite);
}

static layer89_system layers;
static layer89_handle player_layer;

void game_init(void)
{
    layer89_init(&layers);
    player_layer = layer89_add(
        &layers,
        LAYER89_Z_WORLD,
        draw_sprite,
        &player_sprite
    );
}

void game_draw(MyRenderer *renderer, int width, int height, unsigned long frame)
{
    layer89_draw_context ctx;
    ctx.render_target = renderer;
    ctx.viewport_width = width;
    ctx.viewport_height = height;
    ctx.frame_index = frame;
    layer89_render(&layers, &ctx);
}
```

## Adelante y atrás

```c
layer89_bring_to_front(&layers, player_layer);
layer89_send_to_back(&layers, player_layer);
layer89_bring_forward(&layers, player_layer);
layer89_send_backward(&layers, player_layer);
layer89_move_before(&layers, shadow_layer, player_layer);
layer89_move_after(&layers, weapon_layer, player_layer);
```

## Capacidad

La capacidad predeterminada es 256 elementos. Puede cambiarse antes de incluir el header:

```c
#define LAYER89_MAX_ITEMS 512
#include "layer89.h"
```

Use el mismo valor al compilar `layer89.c` y el proyecto consumidor.

## Demo Win32

La demo usa GDI con doble buffer y tres rectángulos superpuestos.

- `1`, `2`, `3`: seleccionar gráfico.
- `Home`: mandar completamente al frente.
- `End`: mandar completamente al fondo.
- `Page Up`: avanzar una posición.
- `Page Down`: retroceder una posición.
- `V`: mostrar/ocultar.

### MSYS2 MinGW32

```sh
./build_msys2_mingw32.sh
./build/layer89_demo.exe
```

También se incluye `build_mingw32.bat`.

## Semántica de render

```text
z menor                                        z mayor
fondo -> escenario -> personaje -> partículas -> HUD -> overlay
[dibujado primero]                       [dibujado al final]
```

Dos elementos con el mismo `z` conservan orden estable por número serial.
