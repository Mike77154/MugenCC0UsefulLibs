# actionairstage_dsl v0.1.0

Minilib C89 de capacidad fija para leer y reproducir acciones AIR de MUGEN
incrustadas en archivos DEF de stages. No depende de Win32, GDI, SFF ni del
renderer de Stage89.

## Contrato

- ISO C89.
- Sin `malloc`, `realloc`, `free`, heap, `float` ni `double`.
- Todo el almacenamiento pertenece al llamador.
- Hasta `AAS_MAX_ACTIONS` acciones y `AAS_MAX_FRAMES` cuadros, configurables al compilar.
- Búsqueda de acciones duplicadas de atrás hacia adelante: la última definición gana.

## Sintaxis interpretada

- `[Begin Action n]`, sin distinguir mayúsculas/minúsculas.
- `LoopStart`.
- Cuadros `group,item,x,y,time`.
- Tiempo `-1` para conservar el cuadro indefinidamente.
- Cuadros vacíos `-1,-1`.
- Flip `H`, `V` y `HV`.
- Blends `A`, `A1`, `S` y `ASxxxDyyy`.
- Tolera etiquetas comunitarias como `:sign`.
- Tolera el error frecuente de poner `H` en el campo de tiempo: usa duración 1 y aplica flip.

Se omiten deliberadamente `Clsn*` e interpolaciones, porque un fondo de stage
sólo necesita seleccionar y presentar cuadros. BGCtrl tampoco forma parte de
esta minilib: controla entidades del stage, no el timeline interno de una acción.

## API mínima

```c
static AasLibrary g_air;
AasSample sample;
int action;

aas_parse_text(&g_air, def_text, def_size);
action = aas_find_action(&g_air, 42L);
aas_sample_action(&g_air, action, tick, &sample);
/* sample.frame contiene sprite, offset, tiempo, flip y blend. */
```

El reproductor no mantiene estado oculto. Recibe un `tick` absoluto y devuelve
el cuadro correspondiente; por eso pausar, avanzar cuadro a cuadro, rebobinar
o sincronizar varios fondos queda en manos del host.

## Prueba

```sh
./build_host_test.sh
```

Consulta `examples/action_player_demo.c` para un loop de reproducción completo.
