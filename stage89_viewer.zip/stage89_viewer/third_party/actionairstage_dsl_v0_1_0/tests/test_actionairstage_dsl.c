#include <stdio.h>
#include <string.h>
#include "actionairstage_dsl.h"

static AasLibrary g_library;

int main(void)
{
    static const char source[] =
        "[Begin Action 10]\n"
        "0,0,0,0,2\n"
        "LoopStart\n"
        "0,1,3,-2,3,H,AS224D32\n"
        "-1,-1,0,0,1\n";
    AasSample sample;
    int index;
    aas_init(&g_library);
    if (!aas_parse_text(&g_library, source, (unsigned long)sizeof(source))) return 1;
    index = aas_find_action(&g_library, 10L);
    if (index < 0) return 2;
    if (!aas_sample_action(&g_library, index, 2UL, &sample)) return 3;
    if (sample.frame->item != 1 || sample.frame->flip != AAS_FLIP_H ||
        sample.frame->blend != AAS_BLEND_ALPHA || sample.frame->alpha_src != 224 ||
        sample.frame->alpha_dst != 32) return 4;
    if (!aas_sample_action(&g_library, index, 7UL, &sample)) return 5;
    if (sample.frame->item != 1) return 6;
    puts("actionairstage_dsl: ok");
    return 0;
}
