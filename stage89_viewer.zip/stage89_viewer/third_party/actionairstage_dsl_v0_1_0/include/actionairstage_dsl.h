/* actionairstage_dsl.h - fixed-capacity MUGEN AIR action parser/player
   C89, caller-owned storage, no heap, no floating point. */
#ifndef ACTIONAIRSTAGE_DSL_H
#define ACTIONAIRSTAGE_DSL_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef AAS_MAX_ACTIONS
#define AAS_MAX_ACTIONS 512
#endif
#ifndef AAS_MAX_FRAMES
#define AAS_MAX_FRAMES 8192
#endif
#ifndef AAS_MAX_DIAGNOSTICS
#define AAS_MAX_DIAGNOSTICS 32
#endif
#ifndef AAS_DIAGNOSTIC_TEXT
#define AAS_DIAGNOSTIC_TEXT 128
#endif

#define AAS_FLIP_NONE 0
#define AAS_FLIP_H    1
#define AAS_FLIP_V    2

#define AAS_BLEND_INHERIT 0
#define AAS_BLEND_ADD     1
#define AAS_BLEND_ADD1    2
#define AAS_BLEND_SUB     3
#define AAS_BLEND_ALPHA   4

typedef struct AasFrame {
    int group;
    int item;
    int offset_x;
    int offset_y;
    int duration;          /* ticks; -1 holds indefinitely */
    int flip;              /* AAS_FLIP_* bit mask */
    int blend;             /* AAS_BLEND_* */
    int alpha_src;         /* 0..256 for AAS_BLEND_ALPHA */
    int alpha_dst;         /* 0..256 for AAS_BLEND_ALPHA */
} AasFrame;

typedef struct AasAction {
    long number;
    unsigned short first_frame;
    unsigned short frame_count;
    unsigned short loop_frame;      /* frame relative to first_frame */
    unsigned long total_ticks;      /* positive-duration portion */
    unsigned long loop_start_tick;
    int has_infinite_frame;
} AasAction;

typedef struct AasLibrary {
    AasAction actions[AAS_MAX_ACTIONS];
    AasFrame frames[AAS_MAX_FRAMES];
    int action_count;
    int frame_count;
    int warning_count;
    char diagnostics[AAS_MAX_DIAGNOSTICS][AAS_DIAGNOSTIC_TEXT];
} AasLibrary;

typedef struct AasSample {
    const AasAction *action;
    const AasFrame *frame;
    int action_index;
    int frame_index;       /* relative to action */
    unsigned long frame_tick;
} AasSample;

void aas_init(AasLibrary *library);
int aas_parse_text(AasLibrary *library, const char *text, unsigned long text_size);
int aas_find_action(const AasLibrary *library, long action_number);
int aas_sample_action(const AasLibrary *library, int action_index,
                      unsigned long tick, AasSample *out_sample);
const char *aas_blend_name(int blend);

#ifdef __cplusplus
}
#endif

#endif
