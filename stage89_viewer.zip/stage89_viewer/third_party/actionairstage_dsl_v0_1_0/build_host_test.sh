#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir -p "$ROOT/build"
cc -std=c89 -pedantic -Wall -Wextra -Werror \
  -I"$ROOT/include" "$ROOT/tests/test_actionairstage_dsl.c" \
  "$ROOT/src/actionairstage_dsl.c" -o "$ROOT/build/test_actionairstage_dsl"
"$ROOT/build/test_actionairstage_dsl"
