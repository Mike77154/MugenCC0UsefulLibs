#include <stdio.h>
#include "actionairstage_dsl.h"

static AasLibrary g_air;

int main(void)
{
    static const char source[] =
        "[Begin Action 7]\n"
        "10,0,0,0,3\n"
        "LoopStart\n"
        "10,1,2,-1,2,H\n"
        "10,2,0,0,2,,AS192D64\n";
    AasSample sample;
    int action;
    unsigned long tick;

    if (!aas_parse_text(&g_air, source, (unsigned long)sizeof(source))) return 1;
    action = aas_find_action(&g_air, 7L);
    if (action < 0) return 2;

    for (tick = 0UL; tick < 12UL; ++tick) {
        if (!aas_sample_action(&g_air, action, tick, &sample)) return 3;
        printf("tick=%lu sprite=%d,%d offset=%d,%d frame=%d local=%lu\n",
            tick, sample.frame->group, sample.frame->item,
            sample.frame->offset_x, sample.frame->offset_y,
            sample.frame_index, sample.frame_tick);
    }
    return 0;
}
