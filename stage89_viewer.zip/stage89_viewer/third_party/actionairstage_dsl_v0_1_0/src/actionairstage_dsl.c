#include "actionairstage_dsl.h"
#include <string.h>
#include <ctype.h>

#define AAS_LINE_CAP 512
#define AAS_TOKEN_CAP 64
#define AAS_MAX_TOKENS 10

static void aas_copy(char *dst, int cap, const char *src)
{
    int i;
    if (dst == (char*)0 || cap <= 0) return;
    if (src == (const char*)0) src = "";
    i = 0;
    while (i + 1 < cap && src[i] != '\0') { dst[i] = src[i]; ++i; }
    dst[i] = '\0';
}

static char *aas_trim(char *s)
{
    char *e;
    while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') ++s;
    e = s + strlen(s);
    while (e > s && (e[-1] == ' ' || e[-1] == '\t' || e[-1] == '\r' || e[-1] == '\n')) --e;
    *e = '\0';
    return s;
}

static int aas_eqi(const char *a, const char *b)
{
    unsigned char ca;
    unsigned char cb;
    while (*a != '\0' && *b != '\0') {
        ca = (unsigned char)tolower((unsigned char)*a);
        cb = (unsigned char)tolower((unsigned char)*b);
        if (ca != cb) return 0;
        ++a; ++b;
    }
    return *a == '\0' && *b == '\0';
}

static int aas_starts_i(const char *s, const char *prefix)
{
    unsigned char a;
    unsigned char b;
    while (*prefix != '\0') {
        if (*s == '\0') return 0;
        a = (unsigned char)tolower((unsigned char)*s);
        b = (unsigned char)tolower((unsigned char)*prefix);
        if (a != b) return 0;
        ++s; ++prefix;
    }
    return 1;
}

static long aas_parse_long(const char *s, int *ok)
{
    long sign;
    long value;
    int any;
    if (ok != (int*)0) *ok = 0;
    while (*s == ' ' || *s == '\t') ++s;
    sign = 1L;
    if (*s == '-') { sign = -1L; ++s; }
    else if (*s == '+') ++s;
    value = 0L;
    any = 0;
    while (*s >= '0' && *s <= '9') {
        value = value * 10L + (long)(*s - '0');
        any = 1;
        ++s;
    }
    while (*s == ' ' || *s == '\t') ++s;
    if (*s != '\0') any = 0;
    if (ok != (int*)0) *ok = any;
    return sign * value;
}

static void aas_diag(AasLibrary *library, const char *text)
{
    if (library->warning_count < AAS_MAX_DIAGNOSTICS) {
        aas_copy(library->diagnostics[library->warning_count], AAS_DIAGNOSTIC_TEXT, text);
    }
    ++library->warning_count;
}

static int aas_parse_flip(const char *token, int *out_flip)
{
    char clean[8];
    int i;
    int n;
    int flip;
    n = 0;
    for (i = 0; token[i] != '\0' && n + 1 < (int)sizeof(clean); ++i) {
        if (token[i] != ' ' && token[i] != '\t') clean[n++] = (char)toupper((unsigned char)token[i]);
    }
    clean[n] = '\0';
    if (clean[0] == '\0') return 0;
    flip = AAS_FLIP_NONE;
    for (i = 0; clean[i] != '\0'; ++i) {
        if (clean[i] == 'H') flip |= AAS_FLIP_H;
        else if (clean[i] == 'V') flip |= AAS_FLIP_V;
        else return 0;
    }
    if (out_flip != (int*)0) *out_flip = flip;
    return flip != AAS_FLIP_NONE;
}

static int aas_parse_blend(const char *token, int *out_blend, int *out_src, int *out_dst)
{
    char clean[32];
    int i;
    int n;
    const char *p;
    long src;
    long dst;
    int ok;
    n = 0;
    for (i = 0; token[i] != '\0' && n + 1 < (int)sizeof(clean); ++i) {
        if (token[i] != ' ' && token[i] != '\t') clean[n++] = (char)toupper((unsigned char)token[i]);
    }
    clean[n] = '\0';
    if (aas_eqi(clean, "A")) {
        *out_blend = AAS_BLEND_ADD; *out_src = 256; *out_dst = 256; return 1;
    }
    if (aas_eqi(clean, "A1")) {
        *out_blend = AAS_BLEND_ADD1; *out_src = 256; *out_dst = 128; return 1;
    }
    if (aas_eqi(clean, "S")) {
        *out_blend = AAS_BLEND_SUB; *out_src = 256; *out_dst = 256; return 1;
    }
    if (!aas_starts_i(clean, "AS")) return 0;
    p = clean + 2;
    src = 0L;
    if (*p < '0' || *p > '9') return 0;
    while (*p >= '0' && *p <= '9') { src = src * 10L + (long)(*p - '0'); ++p; }
    if (*p != 'D') return 0;
    ++p;
    dst = aas_parse_long(p, &ok);
    if (!ok) return 0;
    if (src < 0L) src = 0L;
    if (src > 256L) src = 256L;
    if (dst < 0L) dst = 0L;
    if (dst > 256L) dst = 256L;
    *out_blend = AAS_BLEND_ALPHA;
    *out_src = (int)src;
    *out_dst = (int)dst;
    return 1;
}

static int aas_tokenize(char *line, char tokens[AAS_MAX_TOKENS][AAS_TOKEN_CAP])
{
    char *p;
    char *start;
    int count;
    int len;
    p = line;
    count = 0;
    while (count < AAS_MAX_TOKENS) {
        start = p;
        while (*p != '\0' && *p != ',') ++p;
        len = (int)(p - start);
        if (len >= AAS_TOKEN_CAP) len = AAS_TOKEN_CAP - 1;
        if (len > 0) memcpy(tokens[count], start, (size_t)len);
        tokens[count][len] = '\0';
        aas_copy(tokens[count], AAS_TOKEN_CAP, aas_trim(tokens[count]));
        ++count;
        if (*p == '\0') break;
        ++p;
    }
    return count;
}

static int aas_parse_action_header(const char *line, long *out_number)
{
    char inner[96];
    const char *end;
    char *p;
    long value;
    int ok;
    int len;
    if (line[0] != '[') return 0;
    end = strchr(line + 1, ']');
    if (end == (const char*)0) return 0;
    len = (int)(end - (line + 1));
    if (len <= 0 || len >= (int)sizeof(inner)) return 0;
    memcpy(inner, line + 1, (size_t)len);
    inner[len] = '\0';
    p = aas_trim(inner);
    if (!aas_starts_i(p, "begin")) return 0;
    p += 5;
    while (*p == ' ' || *p == '\t') ++p;
    if (!aas_starts_i(p, "action")) return 0;
    p += 6;
    while (*p == ' ' || *p == '\t') ++p;
    value = aas_parse_long(p, &ok);
    if (!ok) return 0;
    *out_number = value;
    return 1;
}

static void aas_finalize_action(AasLibrary *library, int action_index)
{
    AasAction *action;
    unsigned long total;
    unsigned long loop_start;
    int i;
    int duration;
    if (action_index < 0 || action_index >= library->action_count) return;
    action = &library->actions[action_index];
    total = 0UL;
    loop_start = 0UL;
    action->has_infinite_frame = 0;
    if (action->loop_frame > action->frame_count) action->loop_frame = 0;
    for (i = 0; i < (int)action->frame_count; ++i) {
        if (i == (int)action->loop_frame) loop_start = total;
        duration = library->frames[(int)action->first_frame + i].duration;
        if (duration < 0) {
            action->has_infinite_frame = 1;
            break;
        }
        if (duration > 0) total += (unsigned long)duration;
    }
    action->total_ticks = total;
    action->loop_start_tick = loop_start;
}

void aas_init(AasLibrary *library)
{
    if (library == (AasLibrary*)0) return;
    memset(library, 0, sizeof(*library));
}

int aas_find_action(const AasLibrary *library, long action_number)
{
    int i;
    if (library == (const AasLibrary*)0) return -1;
    for (i = library->action_count - 1; i >= 0; --i) {
        if (library->actions[i].number == action_number) return i;
    }
    return -1;
}

int aas_parse_text(AasLibrary *library, const char *text, unsigned long text_size)
{
    unsigned long pos;
    unsigned long start;
    unsigned long len;
    char line_buf[AAS_LINE_CAP];
    char tokens[AAS_MAX_TOKENS][AAS_TOKEN_CAP];
    char *line;
    char *comment;
    long action_number;
    long value;
    int ok;
    int current_action;
    int pending_loop;
    int count;
    int i;
    int flip;
    int blend;
    int alpha_src;
    int alpha_dst;
    AasAction *action;
    AasFrame *frame;

    if (library == (AasLibrary*)0 || text == (const char*)0) return 0;
    aas_init(library);
    pos = 0UL;
    current_action = -1;
    pending_loop = 0;
    while (pos < text_size && text[pos] != '\0') {
        start = pos;
        while (pos < text_size && text[pos] != '\0' && text[pos] != '\n') ++pos;
        len = pos - start;
        if (pos < text_size && text[pos] == '\n') ++pos;
        if (len >= AAS_LINE_CAP) len = AAS_LINE_CAP - 1UL;
        if (len > 0UL) memcpy(line_buf, text + start, (size_t)len);
        line_buf[len] = '\0';
        comment = strchr(line_buf, ';');
        if (comment != (char*)0) *comment = '\0';
        line = aas_trim(line_buf);
        if (*line == '\0') continue;

        if (*line == '[') {
            if (current_action >= 0) aas_finalize_action(library, current_action);
            current_action = -1;
            pending_loop = 0;
            if (aas_parse_action_header(line, &action_number)) {
                if (library->action_count >= AAS_MAX_ACTIONS) {
                    aas_diag(library, "Action capacity reached; later actions ignored.");
                } else {
                    current_action = library->action_count++;
                    action = &library->actions[current_action];
                    memset(action, 0, sizeof(*action));
                    action->number = action_number;
                    action->first_frame = (unsigned short)library->frame_count;
                    action->loop_frame = 0;
                }
            }
            continue;
        }
        if (current_action < 0) continue;
        if (aas_starts_i(line, "loopstart")) {
            pending_loop = 1;
            continue;
        }
        if (aas_starts_i(line, "clsn") || aas_starts_i(line, "interpolate")) continue;
        if (*line == ':') continue; /* tolerated community labels */

        count = aas_tokenize(line, tokens);
        if (count < 5) continue;
        if (library->frame_count >= AAS_MAX_FRAMES) {
            aas_diag(library, "Frame capacity reached; later AIR frames ignored.");
            continue;
        }
        value = aas_parse_long(tokens[0], &ok); if (!ok) continue;
        frame = &library->frames[library->frame_count];
        memset(frame, 0, sizeof(*frame));
        frame->group = (int)value;
        value = aas_parse_long(tokens[1], &ok); if (!ok) continue;
        frame->item = (int)value;
        value = aas_parse_long(tokens[2], &ok); if (!ok) continue;
        frame->offset_x = (int)value;
        value = aas_parse_long(tokens[3], &ok); if (!ok) continue;
        frame->offset_y = (int)value;
        frame->duration = 1;
        frame->blend = AAS_BLEND_INHERIT;
        frame->alpha_src = 256;
        frame->alpha_dst = 0;

        value = aas_parse_long(tokens[4], &ok);
        if (ok) frame->duration = (int)value;
        else if (aas_parse_flip(tokens[4], &flip)) frame->flip = flip;

        for (i = 5; i < count; ++i) {
            if (tokens[i][0] == '\0') continue;
            if (aas_parse_flip(tokens[i], &flip)) frame->flip = flip;
            else {
                blend = frame->blend;
                alpha_src = frame->alpha_src;
                alpha_dst = frame->alpha_dst;
                if (aas_parse_blend(tokens[i], &blend, &alpha_src, &alpha_dst)) {
                    frame->blend = blend;
                    frame->alpha_src = alpha_src;
                    frame->alpha_dst = alpha_dst;
                }
            }
        }
        action = &library->actions[current_action];
        if (pending_loop) {
            action->loop_frame = action->frame_count;
            pending_loop = 0;
        }
        ++action->frame_count;
        ++library->frame_count;
    }
    if (current_action >= 0) aas_finalize_action(library, current_action);
    return library->action_count > 0;
}

int aas_sample_action(const AasLibrary *library, int action_index,
                      unsigned long tick, AasSample *out_sample)
{
    const AasAction *action;
    const AasFrame *frame;
    unsigned long local_tick;
    unsigned long loop_ticks;
    unsigned long elapsed;
    int i;
    int duration;
    int chosen;
    if (library == (const AasLibrary*)0 || out_sample == (AasSample*)0 ||
        action_index < 0 || action_index >= library->action_count) return 0;
    action = &library->actions[action_index];
    if (action->frame_count == 0) return 0;
    local_tick = tick;
    if (!action->has_infinite_frame && action->total_ticks > 0UL && local_tick >= action->total_ticks) {
        loop_ticks = action->total_ticks - action->loop_start_tick;
        if (loop_ticks > 0UL) {
            if (local_tick >= action->loop_start_tick) {
                local_tick = action->loop_start_tick +
                    ((local_tick - action->loop_start_tick) % loop_ticks);
            }
        } else {
            local_tick = action->total_ticks - 1UL;
        }
    }
    elapsed = 0UL;
    chosen = (int)action->frame_count - 1;
    for (i = 0; i < (int)action->frame_count; ++i) {
        frame = &library->frames[(int)action->first_frame + i];
        duration = frame->duration;
        if (duration < 0) { chosen = i; break; }
        if (duration == 0) continue;
        if (local_tick < elapsed + (unsigned long)duration) { chosen = i; break; }
        elapsed += (unsigned long)duration;
    }
    frame = &library->frames[(int)action->first_frame + chosen];
    out_sample->action = action;
    out_sample->frame = frame;
    out_sample->action_index = action_index;
    out_sample->frame_index = chosen;
    out_sample->frame_tick = local_tick >= elapsed ? local_tick - elapsed : 0UL;
    return 1;
}

const char *aas_blend_name(int blend)
{
    if (blend == AAS_BLEND_ADD) return "add";
    if (blend == AAS_BLEND_ADD1) return "add1";
    if (blend == AAS_BLEND_SUB) return "sub";
    if (blend == AAS_BLEND_ALPHA) return "alpha";
    return "inherit";
}
