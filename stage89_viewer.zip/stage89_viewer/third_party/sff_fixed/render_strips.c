#include "sff/sff_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned char* load_file(const char *path, unsigned long *out_size)
{
    FILE *f; long sz; unsigned char *buf; size_t got;
    *out_size = 0;
    f = fopen(path, "rb");
    if (!f) return 0;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return 0; }
    sz = ftell(f);
    if (sz < 0) { fclose(f); return 0; }
    if (fseek(f, 0, SEEK_SET) != 0) { fclose(f); return 0; }
    buf = (unsigned char*)malloc((size_t)sz);
    if (!buf) { fclose(f); return 0; }
    got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (got != (size_t)sz) { free(buf); return 0; }
    *out_size = (unsigned long)sz;
    return buf;
}

static void put_px(unsigned char *img, int W, int H, int x, int y, unsigned char r, unsigned char g, unsigned char b)
{
    unsigned long off;
    if (x < 0 || y < 0 || x >= W || y >= H) return;
    off = ((unsigned long)y * (unsigned long)W + (unsigned long)x) * 3ul;
    img[off+0] = r; img[off+1] = g; img[off+2] = b;
}

static void fill_checker(unsigned char *img, int W, int H)
{
    int x, y;
    for (y = 0; y < H; ++y) {
        for (x = 0; x < W; ++x) {
            int c = (((x/8) + (y/8)) & 1) ? 210 : 180;
            put_px(img, W, H, x, y, (unsigned char)c, (unsigned char)c, (unsigned char)c);
        }
    }
}

static void blit_rgba(unsigned char *dst, int DW, int DH, int dx, int dy,
                      const unsigned char *src, int SW, int SH)
{
    int x, y;
    for (y = 0; y < SH; ++y) {
        for (x = 0; x < SW; ++x) {
            unsigned long so = ((unsigned long)y * (unsigned long)SW + (unsigned long)x) * 4ul;
            unsigned char sr = src[so+0], sg = src[so+1], sb = src[so+2], sa = src[so+3];
            int tx = dx + x;
            int ty = dy + y;
            unsigned long doff;
            unsigned char dr, dg, db;
            if (tx < 0 || ty < 0 || tx >= DW || ty >= DH) continue;
            doff = ((unsigned long)ty * (unsigned long)DW + (unsigned long)tx) * 3ul;
            dr = dst[doff+0]; dg = dst[doff+1]; db = dst[doff+2];
            dst[doff+0] = (unsigned char)(((unsigned int)sr * sa + (unsigned int)dr * (255u - sa)) / 255u);
            dst[doff+1] = (unsigned char)(((unsigned int)sg * sa + (unsigned int)dg * (255u - sa)) / 255u);
            dst[doff+2] = (unsigned char)(((unsigned int)sb * sa + (unsigned int)db * (255u - sa)) / 255u);
        }
    }
}

static int save_ppm(const char *path, const unsigned char *img, int W, int H)
{
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    fprintf(f, "P6\n%d %d\n255\n", W, H);
    if (fwrite(img, 1, (size_t)W * (size_t)H * 3u, f) != (size_t)W * (size_t)H * 3u) {
        fclose(f); return 0;
    }
    fclose(f); return 1;
}

static int render_sheet(const char *input_path, const char *output_ppm, int max_sprites)
{
    unsigned long size;
    unsigned char *bytes = load_file(input_path, &size);
    SffFile s;
    SffOpenOptions opt;
    int rc;
    int count = 0;
    int cols = 8;
    int cell = 80;
    int margin = 8;
    int rows;
    int W, H;
    unsigned char *sheet;
    int i;

    if (!bytes) { fprintf(stderr, "load failed: %s\n", input_path); return 0; }
    opt.tolerant = 1;
    opt.codec = 0;
    rc = sff_open_memory(&s, bytes, (sff_u32)size, &opt);
    if (rc != SFF_OK) { fprintf(stderr, "open failed rc=%d: %s\n", rc, input_path); free(bytes); return 0; }
    if ((int)sff_sprite_count(&s) < max_sprites) max_sprites = (int)sff_sprite_count(&s);
    if (max_sprites < 1) { free(bytes); return 0; }
    rows = (max_sprites + cols - 1) / cols;
    W = cols * cell + (cols + 1) * margin;
    H = rows * cell + (rows + 1) * margin;
    sheet = (unsigned char*)malloc((size_t)W * (size_t)H * 3u);
    if (!sheet) { free(bytes); return 0; }
    fill_checker(sheet, W, H);

    for (i = 0; i < max_sprites; ++i) {
        SffSpriteInfo info;
        unsigned long rgba_bytes;
        unsigned long work_bytes;
        unsigned char *rgba;
        unsigned char *work;
        sff_u16 w, h;
        int col, row, ox, oy;
        rc = sff_get_sprite_info(&s, (sff_u32)i, &info);
        if (rc != SFF_OK || info.w == 0 || info.h == 0) continue;
        rgba_bytes = (unsigned long)info.w * (unsigned long)info.h * 4ul;
        work_bytes = (unsigned long)info.data_len + rgba_bytes + 8192ul;
        rgba = (unsigned char*)malloc((size_t)rgba_bytes);
        work = (unsigned char*)malloc((size_t)work_bytes);
        if (!rgba || !work) { if (rgba) free(rgba); if (work) free(work); continue; }
        rc = sff_decode_sprite_rgba_into(&s, (sff_u32)i, rgba, (sff_u32)rgba_bytes, &w, &h, work, (sff_u32)work_bytes);
        if (rc == SFF_OK) {
            col = count % cols;
            row = count / cols;
            ox = margin + col * (cell + margin) + (cell - (int)w) / 2;
            oy = margin + row * (cell + margin) + (cell - (int)h) / 2;
            blit_rgba(sheet, W, H, ox, oy, rgba, (int)w, (int)h);
            ++count;
        }
        free(rgba);
        free(work);
    }
    if (!save_ppm(output_ppm, sheet, W, H)) {
        fprintf(stderr, "save failed: %s\n", output_ppm);
    }
    free(sheet);
    free(bytes);
    return 1;
}

int main(int argc, char **argv)
{
    if (argc != 4) {
        fprintf(stderr, "usage: %s input.sff output.ppm count\n", argv[0]);
        return 2;
    }
    return render_sheet(argv[1], argv[2], atoi(argv[3])) ? 0 : 1;
}
