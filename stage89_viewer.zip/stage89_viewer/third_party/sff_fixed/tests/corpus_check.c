#include "sff_api.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned char* load_file(const char *path, unsigned long *out_size)
{
    FILE *f;
    long size;
    unsigned char *buf;
    size_t got;
    *out_size = 0;
    f = fopen(path, "rb");
    if (!f) return 0;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return 0; }
    size = ftell(f);
    if (size < 0) { fclose(f); return 0; }
    if (fseek(f, 0, SEEK_SET) != 0) { fclose(f); return 0; }
    buf = (unsigned char*)malloc((size_t)size);
    if (!buf) { fclose(f); return 0; }
    got = fread(buf, 1, (size_t)size, f);
    fclose(f);
    if (got != (size_t)size) { free(buf); return 0; }
    *out_size = (unsigned long)size;
    return buf;
}

static const char *kind_name(SffKind k)
{
    switch (k) {
        case SFF_KIND_V1: return "v1";
        case SFF_KIND_V2: return "v2";
        default: return "unknown";
    }
}

static void report_file(const char *path)
{
    unsigned long size;
    unsigned char *bytes;
    SffFile s;
    SffOpenOptions opt;
    int rc;
    sff_u32 i;
    unsigned long comp_none = 0, comp_rle8 = 0, comp_rle5 = 0, comp_lz5 = 0, comp_png = 0, comp_pcx = 0, comp_other = 0;
    unsigned long decoded_indexed = 0, decoded_rgba = 0, need_codec = 0, decode_fail = 0, not_indexed = 0;
    unsigned long biggest_rgba = 0;
    unsigned long total_pixels = 0;

    bytes = load_file(path, &size);
    if (!bytes) {
        printf("FILE %s\n  load: failed\n", path);
        return;
    }

    opt.tolerant = 1;
    opt.codec = 0;
    rc = sff_open_memory(&s, bytes, (sff_u32)size, &opt);
    if (rc != SFF_OK) {
        printf("FILE %s\n  open: failed rc=%d\n", path, rc);
        free(bytes);
        return;
    }

    printf("FILE %s\n", path);
    printf("  kind=%s sprites=%lu\n", kind_name(sff_kind(&s)), (unsigned long)sff_sprite_count(&s));

    for (i = 0u; i < sff_sprite_count(&s); ++i) {
        SffSpriteInfo info;
        unsigned long pix_bytes;
        unsigned long rgba_bytes;
        unsigned char *pix;
        unsigned char *rgba;
        unsigned char *work;
        unsigned char pal[768];
        sff_u16 w, h;
        int has_pal;

        rc = sff_get_sprite_info(&s, i, &info);
        if (rc != SFF_OK) {
            ++decode_fail;
            continue;
        }

        switch (info.compression) {
            case SFF_COMP_NONE: ++comp_none; break;
            case SFF_COMP_RLE8_SFF: ++comp_rle8; break;
            case SFF_COMP_RLE5: ++comp_rle5; break;
            case SFF_COMP_LZ5: ++comp_lz5; break;
            case SFF_COMP_PNG8:
            case SFF_COMP_PNG24:
            case SFF_COMP_PNG32: ++comp_png; break;
            case SFF_COMP_V1_PCX: ++comp_pcx; break;
            default: ++comp_other; break;
        }

        pix_bytes = (unsigned long)info.w * (unsigned long)info.h;
        rgba_bytes = pix_bytes * 4ul;
        total_pixels += pix_bytes;
        if (rgba_bytes > biggest_rgba) biggest_rgba = rgba_bytes;

        pix = 0;
        rgba = 0;
        work = 0;
        if (pix_bytes != 0ul) pix = (unsigned char*)malloc((size_t)pix_bytes);
        if (rgba_bytes != 0ul) rgba = (unsigned char*)malloc((size_t)rgba_bytes);
        {
            unsigned long work_bytes = (unsigned long)info.data_len + rgba_bytes + 8192ul;
            if (work_bytes != 0ul) work = (unsigned char*)malloc((size_t)work_bytes);
        }

        if (pix && pix_bytes != 0ul) {
            rc = sff_decode_sprite_indexed_into(&s, i, pix, (sff_u32)pix_bytes, &w, &h, pal, &has_pal, work, work ? (sff_u32)((unsigned long)info.data_len + rgba_bytes + 8192ul) : 0u);
            if (rc == SFF_OK) ++decoded_indexed;
            else if (rc == SFF_ERR_CODEC_REQUIRED) ++need_codec;
            else if (rc == SFF_ERR_NOT_INDEXED) ++not_indexed;
            else ++decode_fail;
        }

        if (rgba && rgba_bytes != 0ul) {
            rc = sff_decode_sprite_rgba_into(&s, i, rgba, (sff_u32)rgba_bytes, &w, &h, work, work ? (sff_u32)((unsigned long)info.data_len + rgba_bytes + 8192ul) : 0u);
            if (rc == SFF_OK) ++decoded_rgba;
            else if (rc == SFF_ERR_CODEC_REQUIRED) ++need_codec;
            else ++decode_fail;
        }

        if (pix) free(pix);
        if (rgba) free(rgba);
        if (work) free(work);
    }

    printf("  compression: none=%lu rle8=%lu rle5=%lu lz5=%lu png=%lu pcx=%lu other=%lu\n",
           comp_none, comp_rle8, comp_rle5, comp_lz5, comp_png, comp_pcx, comp_other);
    printf("  decode: indexed_ok=%lu rgba_ok=%lu need_codec=%lu not_indexed=%lu fail=%lu\n",
           decoded_indexed, decoded_rgba, need_codec, not_indexed, decode_fail);
    printf("  aggregate: total_pixels=%lu biggest_rgba=%lu\n", total_pixels, biggest_rgba);

    if (sff_sprite_count(&s) > 0u) {
        sff_u32 idx;
        if (sff_find_sprite(&s, 0u, 0u, &idx) == SFF_OK) {
            SffSpriteInfo info;
            if (sff_get_sprite_info(&s, idx, &info) == SFF_OK) {
                printf("  sprite(0,0): idx=%lu size=%ux%u axis=(%d,%d) comp=0x%02X depth=%u\n",
                       (unsigned long)idx,
                       (unsigned)info.w, (unsigned)info.h,
                       (int)info.axis_x, (int)info.axis_y,
                       (unsigned)info.compression, (unsigned)info.depth);
            }
        }
    }

    free(bytes);
}

int main(int argc, char **argv)
{
    int i;
    if (argc < 2) {
        fprintf(stderr, "usage: %s file.sff [more.sff...]\n", argv[0]);
        return 2;
    }
    for (i = 1; i < argc; ++i) {
        report_file(argv[i]);
    }
    return 0;
}
