#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
if command -v i686-w64-mingw32-gcc >/dev/null 2>&1; then
  CC=i686-w64-mingw32-gcc
else
  CC=${CC:-gcc}
fi
TARGET=$($CC -dumpmachine)
case "$TARGET" in
  i?86*w64*mingw32*) ;;
  *)
    echo "ERROR: usa la shell MSYS2 MinGW32 o i686-w64-mingw32-gcc; target actual: $TARGET" >&2
    exit 2
    ;;
esac
printf 'Compilando con %s para %s...\n' "$CC" "$TARGET"
"$CC" -std=gnu89 -O2 -Wall -Wextra -Wno-unused-parameter -mwindows -static-libgcc -Wl,--large-address-aware \
 -Iinclude \
 -Ithird_party/sff_fixed/sff \
 -Ithird_party/sff_fixed/sublibs/pcx89 \
 -Ithird_party/sff_fixed/sublibs/png89 \
 -Ithird_party/sff_fixed/sublibs/zlib89 \
 -Ithird_party/layer89_v0_1_0/include \
 -Ithird_party/actionairstage_dsl_v0_1_0/include \
 -Ithird_party/bgctrlstage_dsl_v0_1_0/include \
 src/stage89_fixed.c src/stage89_stage.c src/stage89_render.c src/stage89_win32.c \
 third_party/layer89_v0_1_0/src/layer89.c \
 third_party/actionairstage_dsl_v0_1_0/src/actionairstage_dsl.c \
 third_party/bgctrlstage_dsl_v0_1_0/src/bgctrlstage_dsl.c \
 third_party/sff_fixed/sff/sff_api.c \
 third_party/sff_fixed/sff/sff_decomp.c \
 third_party/sff_fixed/sff/sff_endian.c \
 third_party/sff_fixed/sff/sff_map.c \
 third_party/sff_fixed/sff/sff_pcx.c \
 third_party/sff_fixed/sff/sff_png.c \
 third_party/sff_fixed/sff/sff_png_builtin.c \
 third_party/sff_fixed/sff/sff_v1.c \
 third_party/sff_fixed/sff/sff_v2.c \
 third_party/sff_fixed/sublibs/pcx89/pcx89.c \
 third_party/sff_fixed/sublibs/png89/png89.c \
 third_party/sff_fixed/sublibs/png89/png89_zlib89.c \
 third_party/sff_fixed/sublibs/zlib89/zlib89.c \
 -o build/stage89_viewer.exe -lcomdlg32 -lshell32 -lgdi32 -luser32
rm -rf build/corpus
cp -R corpus build/corpus
printf 'OK: build/stage89_viewer.exe\n'
