# stage89_viewer v0.4.0 — BGCtrl Flow Corpus

Visor Win32 de stages MUGEN usado como banco de pruebas para un engine 2D propio.
Esta revisión conserva SFF v1/v2, parallax, Action AIR y el backbuffer GDI, y
agrega ejecución determinista de controladores de fondo mediante la minilib
vendorizada `bgctrlstage_dsl`.

## Reglas del runtime

- C89 / `gnu89` para MinGW32 de 32 bits.
- Sin `malloc`, `realloc`, `free` ni crecimiento de heap en el código enlazado.
- Sin `float` ni `double`; posiciones, velocidades, seno, cámara, zoom y
  parallax usan Q16.16.
- Buffers estáticos y capacidades fijadas al compilar.
- Raster por software a framebuffer BGRA estático.
- Backbuffer GDI persistente con `CreateDIBSection` + memory DC.
- Un solo `BitBlt` visible por cuadro; `WM_ERASEBKGND` queda suprimido.

Windows y GDI administran internamente sus ventanas, controles y objetos del
sistema; el engine no solicita memoria dinámica de aplicación.

## Compilar en MSYS2 Portable

Abre la shell **MinGW32** y ejecuta:

```bat
build_msys2_mingw32.bat
```

O:

```sh
./build_msys2_mingw32.sh
```

Se exige target `i686-w64-mingw32` y se genera:

```text
build/stage89_viewer.exe
build/corpus/*
```

El ejecutable intenta abrir `corpus/stages/kfm.def`. También acepta un `.def`
como argumento, diálogo nativo, doble clic en la lista lateral y arrastrar/soltar.

## Controles

- Flechas o `WASD`: mover cámara.
- Botón izquierdo y arrastre: desplazar cámara.
- Rueda, `+` y `-`: zoom.
- `Espacio`: pausar/reanudar todo el timeline del stage.
- `,` y `.` con pausa activa: retroceder/avanzar un tick determinista.
- `R`: reiniciar vista y timeline.
- `G`: rejilla y `zoffset`/`zoffsetlink`.
- `P`: muñecos P1/P2 de referencia.
- `F`: foregrounds (`layerno = 1`).

## BGCtrl Flow

`bgctrlstage_dsl` interpreta y ejecuta:

- `[BGCtrlDef nombre]`, `looptime` y `ctrlID` heredado.
- `[BGCtrl nombre]`, `time = inicio,fin,loop` y `ctrlID` propio.
- `null`, `Visible`, `Enabled` y el alias comunitario `Enable`.
- `VelSet`, `VelAdd`, `PosSet`, `PosAdd`.
- `Anim`, enlazado con `actionairstage_dsl`.
- `SinX` y `SinY` con amplitud, periodo y fase Q16.16.
- `positionlink`, fondos `dummy` y `zoffsetlink`.

Cada BG conserva estado local: posición, velocidad, visibilidad, enabled,
acción AIR, tick de acción, osciladores y tick local. `Visible = 0` oculta sin
pausar el reloj; `Enabled = 0` oculta y congela posición, seno y AIR. Las
búsquedas hacia atrás reutilizan snapshots fijos cada 256 ticks.

La minilib es independiente de Win32, GDI, SFF y AIR:

```text
third_party/bgctrlstage_dsl_v0_1_0/
├── include/bgctrlstage_dsl.h
├── src/bgctrlstage_dsl.c
├── tests/test_bgctrlstage_dsl.c
├── examples/bgctrl_player_demo.c
└── docs/API.md
```

## Action AIR

`actionairstage_dsl` conserva `[Begin Action n]`, `LoopStart`, duración `-1`,
offsets, flips y transparencias. BGCtrl `Anim` puede cambiar el `actionno` de un
elemento y reiniciar su timeline local sin tocar otros fondos.

## Recuperación tolerante de SFF

Si un DEF declara `spr = stages\\archivo.sff` pero el SFF viene junto al DEF,
el visor intenta la ruta declarada y luego el basename hermano. No reescribe el
stage ni confunde un error de ruta con un error de códec.

## Parallax y presentación GDI

Se conservan las rutas `xscale = top,bottom` y `width = top,bottom`, la fórmula
inversa `yscalestart/yscaledelta`, tiling continuo y compatibilidad `hires = 1`.
La ventana se presenta desde un DIBSection persistente mediante un solo
`BitBlt`.

## Capacidades fijas

| Recurso | Capacidad |
|---|---:|
| Texto DEF | 2 MiB |
| Arena de sprites | 64 MiB |
| Work buffer codecs | 16 MiB |
| Framebuffer máximo | 1600 × 900 × 32 bpp |
| BG por stage | 96 |
| BGCtrlDef | 64 |
| BGCtrl | 256 |
| IDs por controlador | 10 |
| Acciones AIR | 512 |
| Cuadros AIR | 8192 |
| Sprites distintos en caché | 512 |

## Corpus BGCtrl

En los 12 stages DEF/SFF del corpus AIR, nueve usan BGCtrl. Los máximos
observados son 207 controladores en Daily Bugle, 190 en Doctor Doom y 147 en
Iron Man, todos dentro de las tablas fijas. El lote cubre `Visible`, `Enabled`,
`VelSet`, `PosSet`, `PosAdd`, `Anim`, `SinX` y `SinY`.

Consulta:

```text
docs/BGCTRL_FLOW_REPORT.md
validation/bgctrl_corpus_inspection.txt
validation/daily_bugle_bgctrl_probe.txt
```

## Validación

```sh
./third_party/actionairstage_dsl_v0_1_0/build_host_test.sh
./third_party/bgctrlstage_dsl_v0_1_0/build_host_test.sh
./tests/run_host_tests.sh
./tests/run_action_air_corpus.sh
./tests/run_win32_syntax_stub.sh
```

El núcleo portable se compila con `-std=c89 -pedantic -Wall -Wextra -Werror`.
