# SFF path recovery

## Orden de resolución

1. Construir la ruta declarada en `[BGDef] spr = ...` respecto al directorio del DEF.
2. Normalizar separadores Windows y POSIX.
3. Probar apertura.
4. Si falla, extraer el basename del valor `spr` y probarlo como archivo hermano del DEF.

El fallback sólo resuelve ubicación. `sff_open_io` sigue siendo quien valida la cabecera y decodifica SFF v1/v2; un archivo realmente inválido continúa reportando error.

## Corpus

- 12 DEF/SFF utilizables.
- 12 SFF v1 abiertos.
- 9 necesitaron fallback de archivo hermano.
- 3 respetaron directamente la ruta declarada.
- 0 errores de decodificación SFF.
