# Arquitectura

```text
┌──────────────────────────── Win32 viewer ────────────────────────────┐
│ controles + lista DEF + drag/drop + timer + teclado/ratón          │
└───────────────────────────────┬──────────────────────────────────────┘
                                │
                 ┌──────────────▼──────────────┐
                 │ stage89_stage              │
                 │ parser DEF, paths, Q16.16   │
                 └──────────────┬──────────────┘
                                │ Stage89Stage[96 BG]
       ┌────────────────────────▼────────────────────────┐
       │ stage89_runtime                                 │
       │ SffIo Win32 → sff_fixed → arena estática 64 MiB │
       │ deduplicación group,item + paletas              │
       └────────────────────────┬────────────────────────┘
                                │
                 ┌──────────────▼──────────────┐
                 │ layer89                    │
                 │ BG0 → players → BG1 → grid │
                 └──────────────┬──────────────┘
                                │
                 ┌──────────────▼──────────────┐
                 │ raster software Q16.16      │
                 │ tile, delta, width/xscale   │
                 │ yscale inverso, blend       │
                 └──────────────┬──────────────┘
                                │ framebuffer estático
                 ┌──────────────▼──────────────┐
                 │ DIBSection persistente      │
                 │ StretchDIBits al backbuffer │
                 │ BitBlt único a la ventana   │
                 └─────────────────────────────┘
```

## Separación

`stage89_stage.c` no conoce Win32 ni SFF. Convierte el DEF mutable a estructuras fijas y resuelve `localcoord`/`hires`.

`stage89_render.c` no conoce archivos ni GDI. Decodifica a buffers del llamador y rasteriza a una superficie de `unsigned long`.

`stage89_win32.c` aporta I/O, explorador, input y un backbuffer GDI persistente. La ventana visible sólo recibe el cuadro terminado.

Los tests portables usan el mismo parser y renderer con adaptador SFF basado en `FILE*`.
