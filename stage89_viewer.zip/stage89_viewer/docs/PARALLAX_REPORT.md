# Informe de parallax v0.2.0

## Fallos corregidos

### 1. `xscale` no es el ancho de la scanline

La versión anterior interpolaba `xscale` y lo usaba para redimensionar horizontalmente cada fila. Ahora `xscale` multiplica el desplazamiento de cámara de la arista superior e inferior; la fila conserva el ancho del sprite preprocesado.

```text
row_motion = lerp(xscale_top, xscale_bottom, scanline_t)
row_x = anchor_x - camera_x * delta_x * row_motion
```

### 2. Ruta `width = top,bottom`

`width` dejó de reinterpretarse como dos escalas gigantes. Ahora se conserva en Q16.16 y se genera un trapecio real por scanline:

```text
row_width  = lerp(width_top, width_bottom, scanline_t)
row_axis_x = row_width / 2
row_motion = row_width / width_top
```

El eje X del SFF no participa en esta ruta.

### 3. Escala vertical heredada

Se aplica la fórmula inversa completa:

```text
vertical_scale = 1 / (yscalestart/100 + yscaledelta/100 * camera_y)
```

Todo se evalúa en Q16.16, con límites de seguridad para impedir singularidades en DEF corruptos.

### 4. Tiling del piso

Las copias de un parallax se repiten después de calcular el ancho de la fila. En `width` quedan unidas borde con borde, evitando las franjas negras que aparecían al tratar `tilespacing` como un hueco de BG normal.

### 5. Corpus WinMUGEN hi-res

`redtechbay`, `redtechfactoryzero` y `redtechtower` declaran `hires = 1`. Cuando no existe `localcoord`, ahora se usa 640×480. Esto coloca correctamente los ejes Y negativos y vuelve visible el piso.

## Doble buffer GDI

```text
framebuffer estático
        │
        ▼
StretchDIBits
        │
        ▼
CreateDIBSection seleccionada en CreateCompatibleDC
        │ cuadro + texto terminados
        ▼
BitBlt único durante WM_PAINT
```

- El DIB se conserva mientras no cambie el tamaño del área de render.
- `InvalidateRect(..., FALSE)` evita pedir borrado de fondo.
- `WM_ERASEBKGND` devuelve 1.
- El backbuffer se destruye al redimensionar o cerrar.

La ruta Win32 pasó revisión sintáctica GNU89; la comprobación visual final del parpadeo debe hacerse en Windows con el ejecutable compilado.

## Corpus de parallax

| Stage | Espacio | Parallax | Ruta |
|---|---:|---:|---|
| `bugle.def` | 320×240 | 7 | `xscale` |
| `concrete-cave.def` | 320×240 | 0 | — |
| `hulk_stage.def` | 320×240 | 2 | `xscale` |
| `kfm.def` | 320×240 explícito | 2 | `xscale` + escala Y |
| `mall.def` | 320×240 | 0 | — |
| `redtechbay.def` | 640×480 por `hires` | 1 | `width` + tile X |
| `redtechfactoryzero.def` | 640×480 por `hires` | 1 | `width` + tile X |
| `redtechtower.def` | 640×480 por `hires` | 1 | `xscale` |
| `scream.def` | 320×240 | 1 | `xscale` |
