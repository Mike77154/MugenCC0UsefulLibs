# Action AIR / SFF corpus report

## Qué fallaba

El fallo dominante no estaba en el decodificador SFF. Nueve DEF declaraban una ruta como `stages\archivo.sff`, pero el ZIP colocaba el SFF junto al DEF. La resolución tolerante conserva la ruta declarada como primer intento y usa el basename hermano sólo si esa apertura falla.

Los 12 SFF utilizables del lote son SFF v1 y se abrieron correctamente. La carpeta `The Incredible Hulk` sólo contiene una imagen JPG y no trae DEF/SFF.

## Integración AIR

```text
DEF completo
   ├── parser de secciones del stage
   └── actionairstage_dsl
          ├── [Begin Action n]
          ├── LoopStart / duración / blank frame
          └── offset / flip / blend
                    ↓
BG type=anim + actionno
                    ↓
aas_sample_action(tick)
                    ↓
sprite cache → software raster → DIBSection → BitBlt
```

El reproductor AIR es funcional y sin estado oculto: el host entrega un tick absoluto y recibe el frame que corresponde. Esto hace que pausa, frame-step y sincronización sean deterministas.

## Resultado por stage

| Stage | BG | BG anim | Acciones | Frames | SFF fallback | Referencias ausentes únicas |
|---|---:|---:|---:|---:|---:|---|
| Mephisto's Realm | 21 | 12 | 12 | 241 | sí | — |
| Fallen Liberty | 11 | 8 | 8 | 46 | no | 999,0 |
| Doom submarine | 73 | 41 | 41 | 344 | sí | 82,5; 85,1; 85,2; 85,3 |
| Stark Industries | 78 | 51 | 23 | 176 | sí | — |
| Construction Rumble | 33 | 5 | 4 | 481 | sí | — |
| Asteroid M | 71 | 33 | 32 | 914 | sí | 80,43; 80,44; 2290,1 |
| Uptown Express | 92 | 38 | 38 | 206 | sí | — |
| MSH:SHUMA-GORATH Loop Stage | 11 | 8 | 8 | 300 | sí | — |
| Chaos Dimension | 22 | 11 | 11 | 187 | no | — |
| Across the Daily Bugle | 91 | 50 | 41 | 285 | sí | — |
| Infiniti Requiem | 12 | 7 | 7 | 140 | no | — |
| Rocky Mountains, Canada | 46 | 42 | 26 | 433 | sí | 0,0 |

Las referencias ausentes son entradas pedidas por el DEF que no existen en el SFF. No produjeron errores de decodificación ni impidieron abrir el stage. El runtime omite esas entradas y continúa.

## Validación temporal

- Todos los stages produjeron hashes diferentes al avanzar el timeline AIR.
- Daily Bugle parece estático en pruebas cortas porque varias acciones mantienen el primer cuadro durante 3064 ticks; cambia en 3064, 3128 y 3150.
- Los 12 stages terminaron con `decode_errors=0`.
- El máximo observado en este lote fue 914 frames AIR en Asteroid M y 10.3 MiB aproximados de arena usada en Chaos Dimension, por debajo de las capacidades fijas.

## Compatibilidad de sintaxis observada

- `type = anim` y el alias comunitario `type = ani`.
- Acciones repetidas: la última definición reemplaza la anterior al resolver `actionno`.
- Etiquetas no estándar con `:`.
- Una tupla comunitaria con `H` en el campo de duración; se tolera como duración 1 + flip horizontal.
- Blends AIR y frames vacíos.

## Pendiente separado

BGCtrl es una máquina de control de entidades diferente al timeline AIR. Daily Bugle, por ejemplo, usa `enable`, `posset`, `posadd`, `velset`, `sinx` y `siny` para coreografías largas. v0.3 reproduce las acciones AIR y las velocidades declaradas directamente en BG; una futura minilib de BGCtrl puede conectarse encima sin modificar `actionairstage_dsl`.
