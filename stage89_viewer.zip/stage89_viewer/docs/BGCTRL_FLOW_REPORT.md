# BGCtrl Flow — corpus report

## Alcance

La revisión v0.4 separa BGCtrl en `bgctrlstage_dsl`, una máquina de estado
portable que no conoce Win32, GDI, SFF ni el formato interno del renderer.
`Stage89Runtime` adapta cada `[BG ...]` a un target de la máquina y consulta el
estado resultante antes de dibujar.

## Flujo

```text
DEF
 ├─ [BG ...] --------------------┐
 ├─ [Begin Action n] -> AIR -----┤
 └─ [BGCtrlDef]/[BGCtrl] -> DSL -┤
                                 v
                    estado local por fondo
       pos + vel + sin + visible + enabled + action
                                 v
               renderer normal / anim / parallax
                                 v
                 framebuffer -> DIBSection -> BitBlt
```

## Semántica implementada

- Timer global por tick, timer de `BGCtrlDef` y loop opcional por controlador.
- `ctrlID` del controlador reemplaza al heredado; sin IDs se afectan todos.
- `Visible` no congela tiempo.
- `Enabled` oculta y congela posición, osciladores y AIR.
- `Anim` cambia acción y reinicia el tick local de animación.
- Velocidad integra una vez por tick; `VelSet/VelAdd/PosSet/PosAdd` modifican el
  estado persistente.
- `SinX/SinY` reemplazan amplitud, periodo y fase del target.
- `positionlink` suma la posición del elemento precedente y toma el delta de
  cámara de la raíz de la cadena.
- `dummy` participa en movimiento y control sin solicitar sprite.
- `zoffsetlink` usa la coordenada Y calculada del primer BG con el ID indicado.

## Corpus observado

| Stage | BGCtrlDef | BGCtrl |
|---|---:|---:|
| Daily Bugle | 19 | 207 |
| Doctor Doom | 48 | 190 |
| Iron Man | 17 | 147 |
| Uptown Express | 24 | 104 |
| Wolverine | 16 | 81 |
| Asteroid M | 17 | 53 |
| Juggernaut | 9 | 52 |
| BlackHeart | 8 | 36 |
| Shuma loop | 6 | 29 |

Los restantes tres DEF del lote no declaran BGCtrl. No hubo truncación de tablas
ni errores de decodificación SFF. Los sprites ausentes reportados por cuatro
stages ya estaban referenciados como inexistentes dentro de sus DEF/AIR y se
omiten sin abortar.

## Daily Bugle

La prueba visual usa ticks 0, 370, 674, 1300, 3150 y 8478. El stage cambia
velocidades, senos, posiciones, visibilidad, acciones y grupos habilitados hasta
pasar de la fachada diurna a la vista nocturna. El probe textual conserva los
estados modificados en `validation/daily_bugle_bgctrl_probe.txt`.

## Límites actuales

- Capacidades fijas: 64 BGCtrlDef, 256 BGCtrl, 96 targets del visor y 10 IDs por
  controlador.
- No se implementan extensiones no documentadas fuera del conjunto encontrado
  en el corpus.
- El seno usa aproximación entera determinista; evita tabla dinámica, `libm`,
  float y double.
