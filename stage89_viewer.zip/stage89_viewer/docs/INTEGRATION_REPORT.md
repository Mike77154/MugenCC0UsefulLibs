# Informe de integración

## Componentes recibidos

### `sff_fixed`

Se enlaza directamente. El visor usa `SffIo.read_at` con un `HANDLE` Win32, busca sprites por `group,item` y decodifica a una arena proporcionada por el llamador. No se carga el SFF completo a RAM.

### `layer89_v0_1_0`

Se enlaza directamente. Cada sección `[BG ...]` se registra con orden estable:

```text
layerno 0: z = -10000 + orden DEF
jugadores de referencia: z = 0
layerno 1: z = 10000 + orden DEF
rejilla de depuración: z = 30000
```

### `stage_manager`

El original dependía de headers `m2d_*` no presentes en su ZIP y sólo disponía de cuatro slots. Se conserva sin modificar en `third_party/stage_manager_original`. Su responsabilidad fue absorbida por `Stage89Stage` y por la lista lateral Win32, sin el límite de cuatro stages.

### `mugen_stage_dsl_v7`

Se conserva completo como sublibrería vendorizada para la siguiente fase. Su núcleo Q16.16 sirvió de referencia para la multiplicación y división sin enteros de 64 bits.

No se enlaza al loop gráfico de v0.2.0 por dos motivos:

1. El propio README lo define como núcleo semántico y no como renderer.
2. Su modo estricto actual rechaza claves presentes en el corpus oficial, entre ellas `Reflection.intensity`, `Music.bgmvolume` y los puntos P3/P4 de `stage0-720.def`.

El visor utiliza por ello un adaptador DEF acotado, tolerante y orientado al render. El DSL queda disponible para integrar BGCtrl, acciones, perfiles y AOT sin obligar al frame loop a ejecutar el compilador completo.

## Memoria

```text
2 MiB   texto DEF
64 MiB  arena de pixeles de sprites
16 MiB  work buffer de SFF/PNG/RLE
~6 MiB  framebuffer máximo
fijo     tablas SFF, BG, cachés y layer89
```

No hay rutas de asignación o liberación dinámica en `src/`, `include/` ni en las fuentes de terceros que forman el enlace.

## Integración v0.3.0: `actionairstage_dsl`

La reproducción AIR se separó del adaptador DEF y del renderer. La minilib lee
`[Begin Action n]`, conserva cuadros en tablas fijas y resuelve un frame a partir
de un tick absoluto. `Stage89Stage` mantiene la biblioteca AIR; cada BG animado
guarda `actionno/action_index`; `Stage89Runtime` decodifica los sprites únicos
de las acciones realmente referenciadas.

Esto evita ejecutar un compilador general dentro del frame loop y permite usar
la misma minilib con otro proveedor de dibujo. BGCtrl continúa fuera de esta
pieza porque controla posición, velocidad, seno y enable de entidades, no la
selección interna de cuadros AIR.

## Integración v0.4.0: `bgctrlstage_dsl`

BGCtrl se separó en una segunda minilib portable. El parser conserva grupos,
tiempos, loops, IDs y parámetros en tablas fijas; el runtime mantiene un estado
por fondo y puede avanzar o retroceder determinísticamente mediante snapshots.

`Stage89Runtime` convierte los BG a `BgcTargetInit`, ejecuta el scheduler antes
del render y alimenta posición, visibilidad, enabled y acción AIR a la ruta de
dibujo. Los controladores `Anim` reutilizan `actionairstage_dsl`; no duplican el
parser AIR ni conocen el SFF. `dummy`, `positionlink` y `zoffsetlink` completan
la conexión de entidades móviles con el piso del stage.
