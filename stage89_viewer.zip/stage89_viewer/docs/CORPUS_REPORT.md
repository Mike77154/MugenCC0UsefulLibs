# Reporte del corpus MUGEN — v0.2.0

Compilación portable:

```text
-std=c89 -pedantic -Wall -Wextra -Werror
```

| Stage | BG | sprites únicos | caché | missing | decode |
|---|---:|---:|---:|---:|---:|
| `bugle.def` — Across the Daily Bugle | 91 | 19 | 824315 | 0 | 0 |
| `concrete-cave.def` — CONCRETE CAVE | 13 | 2 | 166125 | 0 | 0 |
| `hulk_stage.def` — Desolate Carnival | 38 | 20 | 1369533 | 0 | 0 |
| `kfm.def` — Mountainside Temple | 7 | 7 | 198272 | 0 | 0 |
| `mall.def` — Mall mayhem | 7 | 5 | 791814 | 0 | 0 |
| `redtechbay.def` — Red Tech Battle Bay | 16 | 12 | 2356296 | 0 | 0 |
| `redtechfactoryzero.def` — Red Tech Factory Zero | 8 | 6 | 1843062 | 2 | 0 |
| `redtechtower.def` — Redtech Battle Tower | 9 | 7 | 1997695 | 0 | 0 |
| `scream.def` — Green scream | 13 | 8 | 453114 | 0 | 0 |

`redtechfactoryzero` conserva dos referencias estáticas ausentes, pero su sprite de piso `7,1` sí fue localizado y decodificado: 180×121, eje `109,-273`, modo `width`, tile X infinito.

## Pruebas específicas

- `xscale`: KFM, Bugle, Hulk, Red Tech Tower y Scream.
- `width`: Red Tech Battle Bay y Red Tech Factory Zero.
- `yscalestart` + `yscaledelta`: piso y techo de KFM.
- `hires = 1`: tres Red Tech tratados como 640×480.
- Cámara horizontal: probes en -100, 0 y +100.
- Tiling deformado: continuidad de las scanlines del piso Red Tech.
- SFF v1/v2 y ejes negativos.

Las previsualizaciones están en `docs/previews/parallax/`.
