#ifndef STAGE89_RENDER_H
#define STAGE89_RENDER_H

#include "stage89_stage.h"
#include "sff_api.h"
#include "layer89.h"

#define STAGE89_MAX_SPRITE_CACHE 512
#define STAGE89_CACHE_INDEXED 1
#define STAGE89_CACHE_RGBA 2

typedef struct Stage89SpriteCache {
    int active;
    int format;
    int group;
    int item;
    unsigned short width;
    unsigned short height;
    short axis_x;
    short axis_y;
    unsigned long arena_offset;
    unsigned long arena_size;
    unsigned char palette[768];
} Stage89SpriteCache;

typedef struct Stage89Surface {
    unsigned long *pixels;
    int width;
    int height;
    int stride;
} Stage89Surface;

typedef struct Stage89View {
    stage89_q16 camera_x;
    stage89_q16 camera_y;
    stage89_q16 zoom;
    unsigned long tick;
    int paused;
    int show_players;
    int show_grid;
    int show_foreground;
} Stage89View;

struct Stage89Runtime;

typedef struct Stage89LayerNode {
    struct Stage89Runtime *runtime;
    int kind;
    int bg_index;
} Stage89LayerNode;

typedef struct Stage89Runtime {
    Stage89Stage *stage;
    unsigned char *pixel_arena;
    unsigned long pixel_capacity;
    unsigned long pixel_used;
    unsigned char *decode_work;
    unsigned long decode_work_capacity;
    Stage89SpriteCache cache[STAGE89_MAX_SPRITE_CACHE];
    int cache_count;
    int missing_sprites;
    int decode_errors;
    int last_sff_error;
    int animated_bg_count;
    int decoded_action_frames;
    BgcRuntime bgctrl_runtime;
    int bgctrl_ready;
    layer89_system layers;
    Stage89LayerNode nodes[STAGE89_MAX_BG + 2];
} Stage89Runtime;

void stage89_view_reset(Stage89View *view, const Stage89Stage *stage);
void stage89_view_tick(Stage89View *view);
void stage89_runtime_init(Stage89Runtime *runtime, Stage89Stage *stage,
                          unsigned char *pixel_arena, unsigned long pixel_capacity,
                          unsigned char *decode_work, unsigned long decode_work_capacity);
int stage89_runtime_decode(Stage89Runtime *runtime, const SffFile *sff);
void stage89_render(Stage89Runtime *runtime, Stage89View *view, Stage89Surface *surface);

#endif
