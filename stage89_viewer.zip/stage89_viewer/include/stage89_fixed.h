#ifndef STAGE89_FIXED_H
#define STAGE89_FIXED_H

/* Q16.16 fixed point. ISO C89 implementation, no 64-bit dependency. */
#include <limits.h>

#if UINT_MAX == 0xFFFFFFFFu
typedef signed int stage89_q16;
typedef unsigned int stage89_u32;
#elif ULONG_MAX == 0xFFFFFFFFul
typedef signed long stage89_q16;
typedef unsigned long stage89_u32;
#else
#error "stage89 requires a 32-bit unsigned integer type"
#endif

#define STAGE89_Q16_ONE ((stage89_q16)65536L)
#define STAGE89_Q16_HALF ((stage89_q16)32768L)

stage89_q16 stage89_q16_from_int(long value);
stage89_q16 stage89_q16_from_text(const char *text, int *ok);
stage89_q16 stage89_q16_mul(stage89_q16 a, stage89_q16 b);
stage89_q16 stage89_q16_div(stage89_q16 a, stage89_q16 b, int *ok);
long stage89_q16_to_int(stage89_q16 value);
long stage89_q16_round(stage89_q16 value);
stage89_q16 stage89_q16_clamp(stage89_q16 value, stage89_q16 lo, stage89_q16 hi);
void stage89_q16_to_text(stage89_q16 value, char *out, int out_cap);

#endif
