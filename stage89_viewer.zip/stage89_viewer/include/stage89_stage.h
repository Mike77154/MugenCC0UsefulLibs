#ifndef STAGE89_STAGE_H
#define STAGE89_STAGE_H

#include "stage89_fixed.h"
#include "actionairstage_dsl.h"
#include "bgctrlstage_dsl.h"

#define STAGE89_MAX_BG 96
#define STAGE89_MAX_NAME 96
#define STAGE89_MAX_PATH 1024
#define STAGE89_MAX_DIAGNOSTICS 32
#define STAGE89_DIAG_TEXT 160

#define STAGE89_BG_NORMAL 0
#define STAGE89_BG_PARALLAX 1
#define STAGE89_BG_ANIM 2
#define STAGE89_BG_DUMMY 3

#define STAGE89_PARALLAX_XSCALE 1
#define STAGE89_PARALLAX_WIDTH 2

#define STAGE89_TRANS_NONE 0
#define STAGE89_TRANS_ADD 1
#define STAGE89_TRANS_ADD1 2
#define STAGE89_TRANS_ADDALPHA 3
#define STAGE89_TRANS_SUB 4

typedef struct Stage89Bg {
    char name[STAGE89_MAX_NAME];
    int type;
    int group;
    int item;
    long action_no;
    int action_index;
    int layerno;
    int mask;
    int visible;
    int position_link;
    BgcOsc sin_x;
    BgcOsc sin_y;
    int has_sin_x;
    int has_sin_y;
    int tile_x;
    int tile_y;
    int tile_spacing_x;
    int tile_spacing_y;
    int trans;
    int alpha_src;
    int alpha_dst;
    stage89_q16 start_x;
    stage89_q16 start_y;
    stage89_q16 delta_x;
    stage89_q16 delta_y;
    stage89_q16 velocity_x;
    stage89_q16 velocity_y;
    int parallax_mode;
    stage89_q16 xscale_top;
    stage89_q16 xscale_bottom;
    stage89_q16 width_top;
    stage89_q16 width_bottom;
    stage89_q16 yscale_start;
    stage89_q16 yscale_delta;
    long id;
    int cache_index;
} Stage89Bg;

typedef struct Stage89Stage {
    char name[STAGE89_MAX_NAME];
    char display_name[STAGE89_MAX_NAME];
    char author[STAGE89_MAX_NAME];
    char mugen_version[32];
    char def_path[STAGE89_MAX_PATH];
    char base_dir[STAGE89_MAX_PATH];
    char sff_name[STAGE89_MAX_PATH];
    char sff_path[STAGE89_MAX_PATH];
    char sff_fallback_path[STAGE89_MAX_PATH];
    int sff_used_fallback;
    int localcoord_x;
    int localcoord_y;
    int localcoord_explicit;
    int hires;
    int zoffset;
    long zoffset_link;
    int p1_start_x;
    int p1_start_y;
    int p1_facing;
    int p2_start_x;
    int p2_start_y;
    int p2_facing;
    stage89_q16 camera_start_x;
    stage89_q16 camera_start_y;
    stage89_q16 bound_left;
    stage89_q16 bound_right;
    stage89_q16 bound_high;
    stage89_q16 bound_low;
    stage89_q16 tension;
    stage89_q16 vertical_follow;
    stage89_q16 start_zoom;
    stage89_q16 zoom_out;
    stage89_q16 zoom_in;
    int debug_bg;
    AasLibrary actions;
    BgcProgram bgctrls;
    Stage89Bg bg[STAGE89_MAX_BG];
    int bg_count;
    int warning_count;
    char diagnostics[STAGE89_MAX_DIAGNOSTICS][STAGE89_DIAG_TEXT];
} Stage89Stage;

void stage89_stage_init(Stage89Stage *stage);
int stage89_stage_parse(Stage89Stage *stage, const char *def_path, char *text, unsigned long text_size);
void stage89_path_dirname(const char *path, char *out, int out_cap);
void stage89_path_join(const char *base, const char *child, char *out, int out_cap);
int stage89_path_is_absolute(const char *path);

#endif
