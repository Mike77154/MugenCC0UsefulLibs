# Third-party notices

El código original de este proyecto (`src/`, `include/`, tests y
`third_party/actionairstage_dsl_v0_1_0` y
`third_party/bgctrlstage_dsl_v0_1_0`) se entrega bajo CC0-1.0.

Las demás carpetas bajo `third_party/` conservan sus archivos originales y sus
propios términos:

- `layer89_v0_1_0` incluye su archivo `LICENSE` CC0.
- `sff_fixed`, `mugen_stage_dsl_v7` y `stage_manager_original` proceden de los
  archivos proporcionados para esta integración; consulta sus README y avisos.

El contenido de prueba en `corpus/stages` pertenece al sample content de
Elecbyte M.U.G.E.N 1.0. El README de Elecbyte declara ese sample content bajo
Creative Commons BY-NC 3.0, con atribución opcional. Se incluye el README
original completo como `corpus/ELECBYTE_MUGEN_README.txt`.

`corpus/user_stages` y `corpus/action_air_stages` contienen stages aportados por
el usuario exclusivamente como corpus técnico. Sus gráficos, nombres y demás
contenido siguen perteneciendo a sus respectivos autores; incluirlos en este
paquete de prueba no cambia sus licencias.
