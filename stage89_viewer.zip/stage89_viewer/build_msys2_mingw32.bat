@echo off
setlocal
cd /d "%~dp0"
if not exist build mkdir build

set CC=i686-w64-mingw32-gcc
where %CC% >nul 2>nul
if errorlevel 1 set CC=gcc
for /f "delims=" %%T in ('%CC% -dumpmachine') do set TARGET=%%T
echo %TARGET% | findstr /i /b "i686" >nul
if errorlevel 1 (
  echo ERROR: este build necesita el compilador de la shell MSYS2 MinGW32 ^(i686-w64-mingw32^).
  echo Abre mingw32.exe o instala mingw-w64-i686-gcc.
  exit /b 2
)

echo Compilando con %CC% para %TARGET%...
%CC% -std=gnu89 -O2 -Wall -Wextra -Wno-unused-parameter -mwindows -static-libgcc -Wl,--large-address-aware ^
 -Iinclude ^
 -Ithird_party\sff_fixed\sff ^
 -Ithird_party\sff_fixed\sublibs\pcx89 ^
 -Ithird_party\sff_fixed\sublibs\png89 ^
 -Ithird_party\sff_fixed\sublibs\zlib89 ^
 -Ithird_party\layer89_v0_1_0\include ^
  -Ithird_party\actionairstage_dsl_v0_1_0\include ^
 -Ithird_party\bgctrlstage_dsl_v0_1_0\include ^
 src\stage89_fixed.c src\stage89_stage.c src\stage89_render.c src\stage89_win32.c ^
 third_party\layer89_v0_1_0\src\layer89.c ^
  third_party\actionairstage_dsl_v0_1_0\src\actionairstage_dsl.c ^
 third_party\bgctrlstage_dsl_v0_1_0\src\bgctrlstage_dsl.c ^
 third_party\sff_fixed\sff\sff_api.c ^
 third_party\sff_fixed\sff\sff_decomp.c ^
 third_party\sff_fixed\sff\sff_endian.c ^
 third_party\sff_fixed\sff\sff_map.c ^
 third_party\sff_fixed\sff\sff_pcx.c ^
 third_party\sff_fixed\sff\sff_png.c ^
 third_party\sff_fixed\sff\sff_png_builtin.c ^
 third_party\sff_fixed\sff\sff_v1.c ^
 third_party\sff_fixed\sff\sff_v2.c ^
 third_party\sff_fixed\sublibs\pcx89\pcx89.c ^
 third_party\sff_fixed\sublibs\png89\png89.c ^
 third_party\sff_fixed\sublibs\png89\png89_zlib89.c ^
 third_party\sff_fixed\sublibs\zlib89\zlib89.c ^
 -o build\stage89_viewer.exe -lcomdlg32 -lshell32 -lgdi32 -luser32
if errorlevel 1 exit /b 1

if exist build\corpus rmdir /s /q build\corpus
xcopy /e /i /y corpus build\corpus >nul
echo.
echo OK: build\stage89_viewer.exe
endlocal
