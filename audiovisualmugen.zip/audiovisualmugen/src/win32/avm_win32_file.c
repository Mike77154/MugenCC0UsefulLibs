#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "avm_win32_file.h"

static avm_file_ref avm_w32_open_read(void *user, const char *path)
{
    HANDLE file;
    (void)user;
    file = CreateFileA(path,
                       GENERIC_READ,
                       FILE_SHARE_READ,
                       0,
                       OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL | FILE_FLAG_RANDOM_ACCESS,
                       0);
    if (file == INVALID_HANDLE_VALUE) {
        return 0;
    }
    return (avm_file_ref)file;
}

static void avm_w32_close(void *user, avm_file_ref file)
{
    (void)user;
    if (file != 0) {
        CloseHandle((HANDLE)file);
    }
}

static int avm_w32_read_at(void *user,
                           avm_file_ref file,
                           avm_u32 offset,
                           void *dst,
                           avm_u32 size,
                           avm_u32 *out_read)
{
    DWORD moved;
    DWORD got;
    DWORD error;
    (void)user;
    if (file == 0 || dst == 0 || out_read == 0) {
        return 0;
    }
    SetLastError(NO_ERROR);
    moved = SetFilePointer((HANDLE)file, (LONG)offset, 0, FILE_BEGIN);
    if (moved == INVALID_SET_FILE_POINTER) {
        error = GetLastError();
        if (error != NO_ERROR) {
            return 0;
        }
    }
    got = 0u;
    if (!ReadFile((HANDLE)file, dst, (DWORD)size, &got, 0)) {
        *out_read = 0u;
        return 0;
    }
    *out_read = (avm_u32)got;
    return 1;
}

static int avm_w32_get_size(void *user, avm_file_ref file, avm_u32 *out_size)
{
    DWORD high;
    DWORD low;
    (void)user;
    if (file == 0 || out_size == 0) {
        return 0;
    }
    high = 0u;
    SetLastError(NO_ERROR);
    low = GetFileSize((HANDLE)file, &high);
    if (low == INVALID_FILE_SIZE && GetLastError() != NO_ERROR) {
        return 0;
    }
    if (high != 0u) {
        return 0;
    }
    *out_size = (avm_u32)low;
    return 1;
}

void avm_win32_file_api_init(avm_file_api *api)
{
    if (api == 0) {
        return;
    }
    api->open_read = avm_w32_open_read;
    api->close = avm_w32_close;
    api->read_at = avm_w32_read_at;
    api->get_size = avm_w32_get_size;
    api->user = 0;
}
