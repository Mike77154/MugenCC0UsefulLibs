#ifndef AVM_WIN32_FILE_H
#define AVM_WIN32_FILE_H

#include "audiovisualmugen/audiovisualmugen.h"

#ifdef __cplusplus
extern "C" {
#endif

void avm_win32_file_api_init(avm_file_api *api);

#ifdef __cplusplus
}
#endif

#endif
