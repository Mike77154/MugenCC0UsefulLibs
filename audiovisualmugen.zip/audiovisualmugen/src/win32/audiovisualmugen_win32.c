#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0501
#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <shellapi.h>
#include <mmsystem.h>
#include <string.h>
#include "audiovisualmugen/audiovisualmugen.h"
#include "avm_win32_file.h"

#define AVM_APP_TITLE "audiovisualmugen 0.1.4"

#define AVM_DEF_TEXT_BYTES       65535u
#define AVM_AIR_TEXT_BYTES       (2u * 1024u * 1024u)
#define AVM_AIR_ASSET_BYTES      (12u * 1024u * 1024u)
#define AVM_AIR_SCRATCH_BYTES    (64u * 1024u * 1024u)
#define AVM_SND_ENTRY_COUNT      4096u
#define AVM_SPRITE_MAX_W         2048u
#define AVM_SPRITE_MAX_H         2048u
#define AVM_SPRITE_RGBA_BYTES    (AVM_SPRITE_MAX_W * AVM_SPRITE_MAX_H * 4u)
#define AVM_SPRITE_WORK_BYTES    (16u * 1024u * 1024u)
#define AVM_SOUND_PAYLOAD_BYTES  (8u * 1024u * 1024u)
#define AVM_SOUND_SAMPLE_COUNT   (8u * 1024u * 1024u)

#define AVM_TIMER_ANIMATION 1u
#define AVM_TIMER_MS 16u

#define IDM_FILE_OPEN       1001
#define IDM_FILE_RELOAD     1002
#define IDM_FILE_EXIT       1003
#define IDM_VIEW_SPRITES    1101
#define IDM_VIEW_ANIMS      1102
#define IDM_VIEW_SOUNDS     1103
#define IDM_VIEW_CLSN1      1104
#define IDM_VIEW_CLSN2      1105
#define IDM_PLAY_TOGGLE     1201
#define IDM_PLAY_PREV       1202
#define IDM_PLAY_NEXT       1203
#define IDM_PLAY_STOP       1204
#define IDM_ZOOM_IN         1301
#define IDM_ZOOM_OUT        1302
#define IDM_HELP_KEYS       1401
#define IDM_HELP_ABOUT      1402

typedef enum avm_view_mode_tag {
    AVM_VIEW_SPRITES = 0,
    AVM_VIEW_ANIMATIONS = 1,
    AVM_VIEW_SOUNDS = 2
} avm_view_mode;

typedef struct avm_layout_tag {
    RECT header;
    RECT sidebar;
    RECT preview;
    RECT status;
    RECT tab_sprites;
    RECT tab_anims;
    RECT tab_sounds;
    RECT prev_item;
    RECT next_item;
    RECT prev_frame;
    RECT play;
    RECT next_frame;
    RECT zoom_out;
    RECT zoom_in;
} avm_layout;

typedef struct avm_app_tag {
    HWND hwnd;
    HINSTANCE instance;
    HFONT font_ui;
    HFONT font_title;
    avm_file_api file_api;
    avm_character character;
    avm_memory memory;
    avm_report report;
    avm_view_mode mode;
    char loaded_def_path[AVM_PATH_CAPACITY];
    char status_text[AVM_REPORT_CAPACITY];

    avm_u32 sprite_index;
    avm_u32 action_index;
    avm_u32 sound_index;
    int zoom;
    int show_clsn1;
    int show_clsn2;
    int animation_playing;
    DWORD animation_last_ms;
    avm_u32 animation_tick_accum;
    int manual_frame;
    avm_u32 manual_element;
    air_pose_sample manual_sample;

    int decoded_valid;
    avm_u32 decoded_index;
    avm_u16 decoded_w;
    avm_u16 decoded_h;
    SffSpriteInfo decoded_info;

    int sound_decoded;
    wavc89_info sound_info;
    avm_u32 sound_payload_size;
    avm_u32 sound_sample_count;
    avm_u32 sound_duration_ms;
    HWAVEOUT wave_out;
    WAVEHDR wave_header;
    int wave_prepared;

    HDC back_dc;
    HBITMAP back_bitmap;
    HBITMAP back_old_bitmap;
    int back_width;
    int back_height;
} avm_app;

static avm_app g_app;
static char g_def_text[AVM_DEF_TEXT_BYTES];
static char g_air_text[AVM_AIR_TEXT_BYTES];
static avm_u8 g_air_asset[AVM_AIR_ASSET_BYTES];
static avm_u8 g_air_scratch[AVM_AIR_SCRATCH_BYTES];
static sndmug_entry g_snd_entries[AVM_SND_ENTRY_COUNT];
static avm_u8 g_sprite_rgba[AVM_SPRITE_RGBA_BYTES];
static avm_u8 g_sprite_work[AVM_SPRITE_WORK_BYTES];
static avm_u8 g_sound_payload[AVM_SOUND_PAYLOAD_BYTES];
static wavc89_s16 g_sound_samples[AVM_SOUND_SAMPLE_COUNT];
static air_rect_fx g_clsn1_boxes[AIR_MAX_BOXES_PER_ELEM];
static air_rect_fx g_clsn2_boxes[AIR_MAX_BOXES_PER_ELEM];

static const COLORREF AVM_COLOR_BG = RGB(21, 23, 33);
static const COLORREF AVM_COLOR_PANEL = RGB(31, 34, 48);
static const COLORREF AVM_COLOR_PANEL_2 = RGB(42, 46, 63);
static const COLORREF AVM_COLOR_TEXT = RGB(237, 239, 246);
static const COLORREF AVM_COLOR_MUTED = RGB(162, 168, 190);
static const COLORREF AVM_COLOR_ACCENT = RGB(231, 93, 133);
static const COLORREF AVM_COLOR_ACCENT_2 = RGB(255, 168, 190);
static const COLORREF AVM_COLOR_BLUE = RGB(46, 148, 255);
static const COLORREF AVM_COLOR_RED = RGB(255, 62, 90);
static const COLORREF AVM_COLOR_GRID_A = RGB(78, 82, 98);
static const COLORREF AVM_COLOR_GRID_B = RGB(57, 61, 77);

static void app_copy_text(char *dst, avm_u32 cap, const char *src)
{
    avm_u32 i;
    if (dst == 0 || cap == 0u) {
        return;
    }
    if (src == 0) {
        dst[0] = '\0';
        return;
    }
    i = 0u;
    while (src[i] != '\0' && i + 1u < cap) {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = '\0';
}

static int app_point_in_rect(const RECT *rc, int x, int y)
{
    return rc != 0 && x >= rc->left && x < rc->right &&
           y >= rc->top && y < rc->bottom;
}

static void app_fill_rect(HDC dc, const RECT *rc, COLORREF color)
{
    HBRUSH brush;
    brush = CreateSolidBrush(color);
    FillRect(dc, rc, brush);
    DeleteObject(brush);
}

static void app_frame_rect(HDC dc, const RECT *rc, COLORREF color)
{
    HBRUSH brush;
    brush = CreateSolidBrush(color);
    FrameRect(dc, rc, brush);
    DeleteObject(brush);
}

static void app_backbuffer_destroy(avm_app *app)
{
    if (app == 0) {
        return;
    }
    if (app->back_dc != 0 && app->back_old_bitmap != 0) {
        SelectObject(app->back_dc, app->back_old_bitmap);
    }
    if (app->back_bitmap != 0) {
        DeleteObject(app->back_bitmap);
    }
    if (app->back_dc != 0) {
        DeleteDC(app->back_dc);
    }
    app->back_dc = 0;
    app->back_bitmap = 0;
    app->back_old_bitmap = 0;
    app->back_width = 0;
    app->back_height = 0;
}

static int app_backbuffer_ensure(avm_app *app, HDC reference_dc, int width, int height)
{
    HBITMAP bitmap;
    HGDIOBJ old_object;

    if (app == 0 || reference_dc == 0 || width <= 0 || height <= 0) {
        return 0;
    }
    if (app->back_dc != 0 && app->back_bitmap != 0 &&
        app->back_width == width && app->back_height == height) {
        return 1;
    }
    if (app->back_dc == 0) {
        app->back_dc = CreateCompatibleDC(reference_dc);
        if (app->back_dc == 0) {
            return 0;
        }
    }
    bitmap = CreateCompatibleBitmap(reference_dc, width, height);
    if (bitmap == 0) {
        return 0;
    }
    old_object = SelectObject(app->back_dc, bitmap);
    if (old_object == 0 || old_object == HGDI_ERROR) {
        DeleteObject(bitmap);
        return 0;
    }
    if (app->back_bitmap != 0) {
        SelectObject(app->back_dc, app->back_old_bitmap);
        DeleteObject(app->back_bitmap);
        old_object = SelectObject(app->back_dc, bitmap);
        if (old_object == 0 || old_object == HGDI_ERROR) {
            DeleteObject(bitmap);
            app->back_bitmap = 0;
            app->back_old_bitmap = 0;
            app->back_width = 0;
            app->back_height = 0;
            return 0;
        }
    }
    app->back_bitmap = bitmap;
    app->back_old_bitmap = (HBITMAP)old_object;
    app->back_width = width;
    app->back_height = height;
    return 1;
}

static void app_draw_line(HDC dc, int x1, int y1, int x2, int y2, COLORREF color, int width)
{
    HPEN pen;
    HGDIOBJ old_pen;
    pen = CreatePen(PS_SOLID, width, color);
    old_pen = SelectObject(dc, pen);
    MoveToEx(dc, x1, y1, 0);
    LineTo(dc, x2, y2);
    SelectObject(dc, old_pen);
    DeleteObject(pen);
}

static void app_draw_text(HDC dc,
                          HFONT font,
                          const RECT *rc,
                          COLORREF color,
                          UINT flags,
                          const char *text)
{
    HGDIOBJ old_font;
    RECT copy;
    if (text == 0 || rc == 0) {
        return;
    }
    old_font = SelectObject(dc, font);
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    copy = *rc;
    DrawTextA(dc, text, -1, &copy, flags);
    SelectObject(dc, old_font);
}

static void app_draw_button(HDC dc,
                            HFONT font,
                            const RECT *rc,
                            const char *label,
                            int active)
{
    COLORREF fill;
    COLORREF border;
    fill = active ? AVM_COLOR_ACCENT : AVM_COLOR_PANEL_2;
    border = active ? AVM_COLOR_ACCENT_2 : RGB(73, 78, 101);
    app_fill_rect(dc, rc, fill);
    app_frame_rect(dc, rc, border);
    app_draw_text(dc, font, rc, AVM_COLOR_TEXT,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE, label);
}

static void app_set_status(avm_app *app, const char *text)
{
    if (app == 0) {
        return;
    }
    app_copy_text(app->status_text, AVM_REPORT_CAPACITY, text);
    if (app->hwnd != 0) {
        InvalidateRect(app->hwnd, 0, FALSE);
    }
}

static void app_set_status_index(avm_app *app,
                                 const char *prefix,
                                 avm_u32 index,
                                 avm_u32 count)
{
    char buf[AVM_REPORT_CAPACITY];
    wsprintfA(buf, "%s %lu / %lu", prefix,
              (unsigned long)(count == 0u ? 0u : index + 1u),
              (unsigned long)count);
    app_set_status(app, buf);
}

static void app_compute_layout(HWND hwnd, avm_layout *layout)
{
    RECT client;
    int width;
    int height;
    int sidebar_width;
    int button_y;
    GetClientRect(hwnd, &client);
    width = client.right - client.left;
    height = client.bottom - client.top;
    sidebar_width = width / 3;
    if (sidebar_width < 300) sidebar_width = 300;
    if (sidebar_width > 390) sidebar_width = 390;
    if (sidebar_width > width - 180) sidebar_width = width - 180;

    layout->header.left = 0;
    layout->header.top = 0;
    layout->header.right = width;
    layout->header.bottom = 58;

    layout->status.left = 0;
    layout->status.top = height - 26;
    layout->status.right = width;
    layout->status.bottom = height;

    layout->sidebar.left = 0;
    layout->sidebar.top = layout->header.bottom;
    layout->sidebar.right = sidebar_width;
    layout->sidebar.bottom = layout->status.top;

    layout->preview.left = sidebar_width;
    layout->preview.top = layout->header.bottom;
    layout->preview.right = width;
    layout->preview.bottom = layout->status.top;

    layout->tab_sprites.left = 14;
    layout->tab_sprites.top = 12;
    layout->tab_sprites.right = 118;
    layout->tab_sprites.bottom = 46;
    layout->tab_anims.left = 126;
    layout->tab_anims.top = 12;
    layout->tab_anims.right = 250;
    layout->tab_anims.bottom = 46;
    layout->tab_sounds.left = 258;
    layout->tab_sounds.top = 12;
    layout->tab_sounds.right = 368;
    layout->tab_sounds.bottom = 46;

    button_y = layout->sidebar.bottom - 116;
    layout->prev_item.left = 14;
    layout->prev_item.top = button_y;
    layout->prev_item.right = sidebar_width / 2 - 4;
    layout->prev_item.bottom = button_y + 32;
    layout->next_item.left = sidebar_width / 2 + 4;
    layout->next_item.top = button_y;
    layout->next_item.right = sidebar_width - 14;
    layout->next_item.bottom = button_y + 32;

    layout->prev_frame.left = 14;
    layout->prev_frame.top = button_y + 40;
    layout->prev_frame.right = sidebar_width / 3 - 2;
    layout->prev_frame.bottom = button_y + 72;
    layout->play.left = sidebar_width / 3 + 4;
    layout->play.top = button_y + 40;
    layout->play.right = (sidebar_width * 2) / 3 - 4;
    layout->play.bottom = button_y + 72;
    layout->next_frame.left = (sidebar_width * 2) / 3 + 2;
    layout->next_frame.top = button_y + 40;
    layout->next_frame.right = sidebar_width - 14;
    layout->next_frame.bottom = button_y + 72;

    layout->zoom_out.left = 14;
    layout->zoom_out.top = button_y + 80;
    layout->zoom_out.right = sidebar_width / 2 - 4;
    layout->zoom_out.bottom = button_y + 108;
    layout->zoom_in.left = sidebar_width / 2 + 4;
    layout->zoom_in.top = button_y + 80;
    layout->zoom_in.right = sidebar_width - 14;
    layout->zoom_in.bottom = button_y + 108;
}

static void app_audio_stop(avm_app *app)
{
    if (app == 0) {
        return;
    }
    if (app->wave_out != 0) {
        waveOutReset(app->wave_out);
        if (app->wave_prepared) {
            waveOutUnprepareHeader(app->wave_out,
                                   &app->wave_header,
                                   sizeof(app->wave_header));
        }
        waveOutClose(app->wave_out);
    }
    memset(&app->wave_header, 0, sizeof(app->wave_header));
    app->wave_out = 0;
    app->wave_prepared = 0;
}

static int app_decode_sound(avm_app *app)
{
    avm_status status;
    wavc89_io io;
    wavc89_mem_reader mem;
    wavc89_reader reader;
    wavc89_u32 sample_count;
    wavc89_u32 frames;
    wavc89_u32 seconds;
    wavc89_u32 remainder;
    int rc;

    if (app == 0 || !app->character.has_snd ||
        app->sound_index >= app->character.snd.entry_count) {
        return 0;
    }
    app_audio_stop(app);
    app->sound_decoded = 0;
    app->sound_payload_size = 0u;
    app->sound_sample_count = 0u;
    app->sound_duration_ms = 0u;

    status = avm_character_read_sound_payload(&app->character,
                                              app->sound_index,
                                              g_sound_payload,
                                              AVM_SOUND_PAYLOAD_BYTES,
                                              &app->sound_payload_size);
    if (status != AVM_STATUS_OK) {
        app_set_status(app, status == AVM_STATUS_CAPACITY ?
                       "Sound payload exceeds the static 8 MiB buffer." :
                       "Could not read this SND entry.");
        return 0;
    }

    rc = wavc89_io_mem_reader_init(&io, &mem,
                                   g_sound_payload,
                                   app->sound_payload_size);
    if (rc != WAVC89_OK) {
        app_set_status(app, "Could not create WAV memory reader.");
        return 0;
    }
    rc = wavc89_reader_open(&reader, &io, 0u, app->sound_payload_size);
    if (rc != WAVC89_OK) {
        app_set_status(app, "SND payload is not a supported RIFF/WAVE file.");
        return 0;
    }
    app->sound_info = reader.info;
    if (reader.info.data_offset > app->sound_payload_size ||
        reader.info.data_size > app->sound_payload_size - reader.info.data_offset) {
        app_set_status(app, "WAV data range is corrupt.");
        return 0;
    }

    sample_count = 0u;
    rc = wavc89_decode_to_s16(&reader.info,
                              g_sound_payload + reader.info.data_offset,
                              reader.info.data_size,
                              g_sound_samples,
                              AVM_SOUND_SAMPLE_COUNT,
                              &sample_count);
    if (rc != WAVC89_OK) {
        app_set_status(app, rc == WAVC89_E_LIMIT ?
                       "Decoded sound exceeds the static PCM buffer." :
                       "Unsupported or corrupt WAV compression.");
        return 0;
    }
    app->sound_sample_count = sample_count;
    if (reader.info.channels != 0u && reader.info.sample_rate != 0u) {
        frames = sample_count / reader.info.channels;
        seconds = frames / reader.info.sample_rate;
        remainder = frames % reader.info.sample_rate;
        app->sound_duration_ms = seconds * 1000u +
            (remainder * 1000u) / reader.info.sample_rate;
    }
    app->sound_decoded = 1;
    return 1;
}

static void app_audio_play(avm_app *app)
{
    WAVEFORMATEX fmt;
    MMRESULT mm;
    if (app == 0) {
        return;
    }
    if (!app->sound_decoded && !app_decode_sound(app)) {
        return;
    }
    app_audio_stop(app);
    memset(&fmt, 0, sizeof(fmt));
    fmt.wFormatTag = WAVE_FORMAT_PCM;
    fmt.nChannels = app->sound_info.channels;
    fmt.nSamplesPerSec = app->sound_info.sample_rate;
    fmt.wBitsPerSample = 16u;
    fmt.nBlockAlign = (WORD)(fmt.nChannels * 2u);
    fmt.nAvgBytesPerSec = fmt.nSamplesPerSec * fmt.nBlockAlign;
    fmt.cbSize = 0u;

    mm = waveOutOpen(&app->wave_out,
                     WAVE_MAPPER,
                     &fmt,
                     (DWORD_PTR)app->hwnd,
                     0,
                     CALLBACK_WINDOW);
    if (mm != MMSYSERR_NOERROR) {
        app->wave_out = 0;
        app_set_status(app, "Windows waveOut could not open this PCM format.");
        return;
    }
    memset(&app->wave_header, 0, sizeof(app->wave_header));
    app->wave_header.lpData = (LPSTR)g_sound_samples;
    app->wave_header.dwBufferLength = app->sound_sample_count * 2u;
    mm = waveOutPrepareHeader(app->wave_out,
                              &app->wave_header,
                              sizeof(app->wave_header));
    if (mm != MMSYSERR_NOERROR) {
        waveOutClose(app->wave_out);
        app->wave_out = 0;
        app_set_status(app, "waveOutPrepareHeader failed.");
        return;
    }
    app->wave_prepared = 1;
    mm = waveOutWrite(app->wave_out,
                      &app->wave_header,
                      sizeof(app->wave_header));
    if (mm != MMSYSERR_NOERROR) {
        app_audio_stop(app);
        app_set_status(app, "waveOutWrite failed.");
        return;
    }
    app_set_status(app, "Playing selected character sound.");
}

static const air_pose_sample *app_current_pose(avm_app *app)
{
    if (app == 0 || !app->character.has_air) {
        return 0;
    }
    if (app->manual_frame) {
        return &app->manual_sample;
    }
    return air_runtime_get_pose(&app->character.air_runtime_data);
}

static void app_invalidate_decode(avm_app *app)
{
    if (app != 0) {
        app->decoded_valid = 0;
    }
}

static void app_select_action(avm_app *app, avm_u32 index)
{
    const air_action *action;
    air_status rc;
    if (app == 0 || !app->character.has_air ||
        app->character.air_program_data.action_count == 0u) {
        return;
    }
    index %= app->character.air_program_data.action_count;
    app->action_index = index;
    action = avm_character_action_at(&app->character, index);
    air_diag_list_reset(&app->character.air_diags);
    rc = air_runtime_set_action(&app->character.air_runtime_data,
                                action->action_no,
                                &app->character.air_diags);
    app->animation_playing = 0;
    KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
    app->manual_frame = 0;
    app->manual_element = 0u;
    app_invalidate_decode(app);
    if (rc != AIR_STATUS_OK) {
        app_set_status(app, "Could not bind this AIR action.");
    } else {
        app_set_status_index(app, "AIR action", index,
                             app->character.air_program_data.action_count);
    }
}

static int app_sample_element(avm_app *app, avm_u32 element)
{
    const air_action *action;
    air_vm_state vm;
    air_status rc;
    avm_u32 i;
    if (app == 0 || !app->character.has_air) {
        return 0;
    }
    action = avm_character_action_at(&app->character, app->action_index);
    if (action == 0 || action->elem_count == 0u) {
        return 0;
    }
    element %= action->elem_count;
    air_vm_init(&vm, &app->character.air_program_data);
    air_diag_list_reset(&app->character.air_diags);
    rc = air_vm_bind_action(&vm, action->action_no, &app->character.air_diags);
    if (rc != AIR_STATUS_OK) {
        return 0;
    }
    for (i = 0u; i <= element; ++i) {
        rc = air_vm_step_elem(&vm, &app->manual_sample,
                              &app->character.air_diags);
        if (rc != AIR_STATUS_OK) {
            return 0;
        }
    }
    app->manual_frame = 1;
    app->manual_element = element;
    app->animation_playing = 0;
    KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
    app_invalidate_decode(app);
    return 1;
}

static void app_step_frame(avm_app *app, int direction)
{
    const air_action *action;
    avm_u32 current;
    avm_u32 target;
    const air_pose_sample *pose;
    if (app == 0 || !app->character.has_air) {
        return;
    }
    action = avm_character_action_at(&app->character, app->action_index);
    if (action == 0 || action->elem_count == 0u) {
        return;
    }
    pose = app_current_pose(app);
    current = app->manual_frame ? app->manual_element :
        (pose != 0 ? pose->elem_index : 0u);
    if (direction < 0) {
        target = current == 0u ? action->elem_count - 1u : current - 1u;
    } else {
        target = current + 1u;
        if (target >= action->elem_count) target = 0u;
    }
    if (app_sample_element(app, target)) {
        app_set_status_index(app, "Animation frame", target, action->elem_count);
        InvalidateRect(app->hwnd, 0, FALSE);
    }
}

static void app_toggle_animation(avm_app *app)
{
    const air_action *action;
    if (app == 0 || !app->character.has_air) {
        return;
    }
    if (app->animation_playing) {
        app->animation_playing = 0;
        KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
        app_set_status(app, "Animation paused.");
        return;
    }
    action = avm_character_action_at(&app->character, app->action_index);
    if (action == 0) {
        return;
    }
    air_diag_list_reset(&app->character.air_diags);
    if (air_runtime_set_action(&app->character.air_runtime_data,
                               action->action_no,
                               &app->character.air_diags) != AIR_STATUS_OK) {
        app_set_status(app, "Could not start this AIR action.");
        return;
    }
    app->manual_frame = 0;
    app->animation_playing = 1;
    app->animation_last_ms = GetTickCount();
    app->animation_tick_accum = 0u;
    if (SetTimer(app->hwnd, AVM_TIMER_ANIMATION, AVM_TIMER_MS, 0) == 0u) {
        app->animation_playing = 0;
        app_set_status(app, "Windows could not create the animation timer.");
        return;
    }
    app_set_status(app, "Animation playing at M.U.G.E.N's 60-tick timeline.");
}

static void app_change_item(avm_app *app, int direction)
{
    avm_u32 count;
    if (app == 0 || !app->character.loaded) {
        return;
    }
    if (app->mode == AVM_VIEW_SPRITES) {
        count = avm_character_sprite_count(&app->character);
        if (count == 0u) return;
        if (direction < 0) app->sprite_index = app->sprite_index == 0u ? count - 1u : app->sprite_index - 1u;
        else app->sprite_index = (app->sprite_index + 1u) % count;
        app_invalidate_decode(app);
        app_set_status_index(app, "Sprite", app->sprite_index, count);
    } else if (app->mode == AVM_VIEW_ANIMATIONS) {
        count = avm_character_action_count(&app->character);
        if (count == 0u) return;
        if (direction < 0) app_select_action(app, app->action_index == 0u ? count - 1u : app->action_index - 1u);
        else app_select_action(app, (app->action_index + 1u) % count);
    } else {
        count = avm_character_sound_count(&app->character);
        if (count == 0u) return;
        app_audio_stop(app);
        if (direction < 0) app->sound_index = app->sound_index == 0u ? count - 1u : app->sound_index - 1u;
        else app->sound_index = (app->sound_index + 1u) % count;
        app->sound_decoded = 0;
        (void)app_decode_sound(app);
        app_set_status_index(app, "Sound", app->sound_index, count);
    }
    InvalidateRect(app->hwnd, 0, FALSE);
}

static void app_set_mode(avm_app *app, avm_view_mode mode)
{
    if (app == 0) {
        return;
    }
    app->mode = mode;
    app->animation_playing = 0;
    KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
    app_audio_stop(app);
    if (mode == AVM_VIEW_SPRITES) {
        app_set_status_index(app, "Sprite", app->sprite_index,
                             avm_character_sprite_count(&app->character));
    } else if (mode == AVM_VIEW_ANIMATIONS) {
        if (app->character.has_air && app->character.air_program_data.action_count != 0u) {
            app_select_action(app, app->action_index);
        } else {
            app_set_status(app, "No AIR actions loaded.");
        }
    } else {
        if (app->character.has_snd && app->character.snd.entry_count != 0u) {
            (void)app_decode_sound(app);
            app_set_status_index(app, "Sound", app->sound_index,
                                 avm_character_sound_count(&app->character));
        } else {
            app_set_status(app, "This character has no readable SND archive.");
        }
    }
    app_invalidate_decode(app);
    InvalidateRect(app->hwnd, 0, FALSE);
}

static int app_decode_preview_sprite(avm_app *app)
{
    avm_u32 index;
    avm_status status;
    const air_pose_sample *pose;
    avm_u32 pixel_count;
    avm_u32 i;
    avm_u8 r;
    avm_u8 g;
    avm_u8 b;
    avm_u8 a;
    avm_u8 bg;
    avm_u32 x;
    avm_u32 y;

    if (app == 0 || !app->character.has_sff) {
        return 0;
    }
    if (app->mode == AVM_VIEW_SPRITES) {
        index = app->sprite_index;
    } else if (app->mode == AVM_VIEW_ANIMATIONS) {
        pose = app_current_pose(app);
        if (pose == 0 || pose->pose.group_no < 0 || pose->pose.group_no > 65535 ||
            pose->pose.image_no < 0 || pose->pose.image_no > 65535) {
            return 0;
        }
        status = avm_character_find_sprite(&app->character,
                                           (avm_u16)pose->pose.group_no,
                                           (avm_u16)pose->pose.image_no,
                                           &index);
        if (status != AVM_STATUS_OK) {
            app_set_status(app, "AIR frame references a sprite missing from the SFF.");
            return 0;
        }
    } else {
        return 0;
    }

    if (app->decoded_valid && app->decoded_index == index) {
        return 1;
    }
    if (avm_character_sprite_info(&app->character,
                                  index,
                                  &app->decoded_info) != AVM_STATUS_OK) {
        return 0;
    }
    if (app->decoded_info.w > AVM_SPRITE_MAX_W ||
        app->decoded_info.h > AVM_SPRITE_MAX_H) {
        app_set_status(app, "Sprite exceeds the static 2048x2048 preview limit.");
        return 0;
    }
    status = avm_character_decode_sprite_rgba(&app->character,
                                              index,
                                              g_sprite_rgba,
                                              AVM_SPRITE_RGBA_BYTES,
                                              &app->decoded_w,
                                              &app->decoded_h,
                                              g_sprite_work,
                                              AVM_SPRITE_WORK_BYTES);
    if (status != AVM_STATUS_OK) {
        app_set_status(app, status == AVM_STATUS_CAPACITY ?
                       "Sprite decoder needs a larger static work buffer." :
                       "Could not decode this SFF sprite.");
        return 0;
    }

    pixel_count = (avm_u32)app->decoded_w * (avm_u32)app->decoded_h;
    for (i = 0u; i < pixel_count; ++i) {
        r = g_sprite_rgba[i * 4u + 0u];
        g = g_sprite_rgba[i * 4u + 1u];
        b = g_sprite_rgba[i * 4u + 2u];
        a = g_sprite_rgba[i * 4u + 3u];
        x = i % app->decoded_w;
        y = i / app->decoded_w;
        bg = (avm_u8)((((x >> 3) + (y >> 3)) & 1u) != 0u ? 112u : 82u);
        g_sprite_rgba[i * 4u + 0u] = (avm_u8)(((avm_u32)b * a + (avm_u32)bg * (255u - a)) / 255u);
        g_sprite_rgba[i * 4u + 1u] = (avm_u8)(((avm_u32)g * a + (avm_u32)bg * (255u - a)) / 255u);
        g_sprite_rgba[i * 4u + 2u] = (avm_u8)(((avm_u32)r * a + (avm_u32)bg * (255u - a)) / 255u);
        g_sprite_rgba[i * 4u + 3u] = 0u;
    }
    app->decoded_valid = 1;
    app->decoded_index = index;
    return 1;
}

static void app_draw_checker(HDC dc, const RECT *rc)
{
    RECT cell;
    HBRUSH brush_a;
    HBRUSH brush_b;
    HBRUSH brush;
    int x;
    int y;
    int size;

    brush_a = CreateSolidBrush(AVM_COLOR_GRID_A);
    brush_b = CreateSolidBrush(AVM_COLOR_GRID_B);
    if (brush_a == 0 || brush_b == 0) {
        if (brush_a != 0) DeleteObject(brush_a);
        if (brush_b != 0) DeleteObject(brush_b);
        app_fill_rect(dc, rc, AVM_COLOR_GRID_B);
        return;
    }
    size = 24;
    for (y = rc->top; y < rc->bottom; y += size) {
        for (x = rc->left; x < rc->right; x += size) {
            cell.left = x;
            cell.top = y;
            cell.right = x + size;
            cell.bottom = y + size;
            if (cell.right > rc->right) cell.right = rc->right;
            if (cell.bottom > rc->bottom) cell.bottom = rc->bottom;
            brush = ((((x - rc->left) / size) +
                      ((y - rc->top) / size)) & 1) != 0 ? brush_a : brush_b;
            FillRect(dc, &cell, brush);
        }
    }
    DeleteObject(brush_a);
    DeleteObject(brush_b);
}

static int app_abs_i32(int value)
{
    return value < 0 ? -value : value;
}

static void app_draw_sprite_preview(avm_app *app, HDC dc, const RECT *preview)
{
    BITMAPINFO bmi;
    const air_pose_sample *pose;
    int origin_x;
    int origin_y;
    int air_x;
    int air_y;
    int scale_x;
    int scale_y;
    int draw_w;
    int draw_h;
    int draw_x;
    int draw_y;
    int flip_h;
    int flip_v;
    int zoom;
    int dx;
    int dy;
    air_box_transform xf;
    air_boxset boxset;
    air_status box_rc;
    air_u16 i;
    RECT box;
    HGDIOBJ old_brush;
    HPEN pen;
    HGDIOBJ old_pen;

    app_draw_checker(dc, preview);
    origin_x = (preview->left + preview->right) / 2;
    origin_y = preview->top + ((preview->bottom - preview->top) * 2) / 3;
    app_draw_line(dc, preview->left, origin_y, preview->right, origin_y,
                  RGB(126, 130, 147), 1);
    app_draw_line(dc, origin_x, preview->top, origin_x, preview->bottom,
                  RGB(126, 130, 147), 1);

    if (!app_decode_preview_sprite(app)) {
        RECT msg;
        msg = *preview;
        app_draw_text(dc, app->font_title, &msg, AVM_COLOR_MUTED,
                      DT_CENTER | DT_VCENTER | DT_SINGLELINE,
                      app->character.loaded ? "No decodable sprite" :
                      "Open a M.U.G.E.N character .def");
        return;
    }

    zoom = app->zoom;
    air_x = 0;
    air_y = 0;
    scale_x = AIR_FIXED_ONE;
    scale_y = AIR_FIXED_ONE;
    flip_h = 0;
    flip_v = 0;
    pose = 0;
    if (app->mode == AVM_VIEW_ANIMATIONS) {
        pose = app_current_pose(app);
        if (pose != 0) {
            air_x = air_fx_to_int_floor(pose->pose.x);
            air_y = air_fx_to_int_floor(pose->pose.y);
            scale_x = pose->pose.scale_x;
            scale_y = pose->pose.scale_y;
            if (scale_x == 0) scale_x = AIR_FIXED_ONE;
            if (scale_y == 0) scale_y = AIR_FIXED_ONE;
            flip_h = (pose->pose.flip & AIR_FLIP_H) != 0;
            flip_v = (pose->pose.flip & AIR_FLIP_V) != 0;
        }
    }
    scale_x = app_abs_i32(scale_x);
    scale_y = app_abs_i32(scale_y);
    if (scale_x > AIR_FIXED_ONE * 16) scale_x = AIR_FIXED_ONE * 16;
    if (scale_y > AIR_FIXED_ONE * 16) scale_y = AIR_FIXED_ONE * 16;
    draw_w = ((int)app->decoded_w * scale_x) >> AIR_FIXED_SHIFT;
    draw_h = ((int)app->decoded_h * scale_y) >> AIR_FIXED_SHIFT;
    if (draw_w < 1) draw_w = 1;
    if (draw_h < 1) draw_h = 1;
    draw_w *= zoom;
    draw_h *= zoom;
    dx = ((int)app->decoded_info.axis_x * scale_x) >> AIR_FIXED_SHIFT;
    dy = ((int)app->decoded_info.axis_y * scale_y) >> AIR_FIXED_SHIFT;
    dx *= zoom;
    dy *= zoom;
    if (flip_h) {
        draw_x = origin_x + air_x * zoom - draw_w + dx;
    } else {
        draw_x = origin_x + air_x * zoom - dx;
    }
    if (flip_v) {
        draw_y = origin_y + air_y * zoom - draw_h + dy;
    } else {
        draw_y = origin_y + air_y * zoom - dy;
    }

    memset(&bmi, 0, sizeof(bmi));
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = app->decoded_w;
    bmi.bmiHeader.biHeight = -(LONG)app->decoded_h;
    bmi.bmiHeader.biPlanes = 1u;
    bmi.bmiHeader.biBitCount = 32u;
    bmi.bmiHeader.biCompression = BI_RGB;

    SetStretchBltMode(dc, COLORONCOLOR);
    StretchDIBits(dc,
                  flip_h ? draw_x + draw_w : draw_x,
                  flip_v ? draw_y + draw_h : draw_y,
                  flip_h ? -draw_w : draw_w,
                  flip_v ? -draw_h : draw_h,
                  0, 0,
                  app->decoded_w,
                  app->decoded_h,
                  g_sprite_rgba,
                  &bmi,
                  DIB_RGB_COLORS,
                  SRCCOPY);

    app_draw_line(dc, origin_x - 8, origin_y, origin_x + 9, origin_y,
                  AVM_COLOR_ACCENT_2, 2);
    app_draw_line(dc, origin_x, origin_y - 8, origin_x, origin_y + 9,
                  AVM_COLOR_ACCENT_2, 2);

    if (app->mode == AVM_VIEW_ANIMATIONS && pose != 0) {
        air_box_transform_default(&xf);
        xf.origin_x = pose->pose.x;
        xf.origin_y = pose->pose.y;
        xf.facing_right = flip_h ? AIR_FALSE : AIR_TRUE;
        xf.scale_x = (air_fx)scale_x;
        xf.scale_y = (air_fx)scale_y;
        xf.policy = AIR_BOX_POLICY_VISUAL_MATCH | AIR_BOX_POLICY_IGNORE_ANGLE;
        air_diag_list_reset(&app->character.air_diags);
        box_rc = air_boxes_build_from_pose(&app->character.air_program_data,
                                           pose,
                                           &xf,
                                           &boxset,
                                           g_clsn1_boxes,
                                           AIR_MAX_BOXES_PER_ELEM,
                                           g_clsn2_boxes,
                                           AIR_MAX_BOXES_PER_ELEM,
                                           &app->character.air_diags);
        if (box_rc == AIR_STATUS_OK) {
            old_brush = SelectObject(dc, GetStockObject(HOLLOW_BRUSH));
            if (app->show_clsn2) {
                pen = CreatePen(PS_SOLID, 2, AVM_COLOR_BLUE);
                old_pen = SelectObject(dc, pen);
                for (i = 0u; i < boxset.clsn2_count; ++i) {
                    box.left = origin_x + air_fx_to_int_floor(boxset.clsn2[i].x1) * zoom;
                    box.top = origin_y + air_fx_to_int_floor(boxset.clsn2[i].y1) * zoom;
                    box.right = origin_x + air_fx_to_int_floor(boxset.clsn2[i].x2) * zoom;
                    box.bottom = origin_y + air_fx_to_int_floor(boxset.clsn2[i].y2) * zoom;
                    Rectangle(dc, box.left, box.top, box.right, box.bottom);
                }
                SelectObject(dc, old_pen);
                DeleteObject(pen);
            }
            if (app->show_clsn1) {
                pen = CreatePen(PS_SOLID, 2, AVM_COLOR_RED);
                old_pen = SelectObject(dc, pen);
                for (i = 0u; i < boxset.clsn1_count; ++i) {
                    box.left = origin_x + air_fx_to_int_floor(boxset.clsn1[i].x1) * zoom;
                    box.top = origin_y + air_fx_to_int_floor(boxset.clsn1[i].y1) * zoom;
                    box.right = origin_x + air_fx_to_int_floor(boxset.clsn1[i].x2) * zoom;
                    box.bottom = origin_y + air_fx_to_int_floor(boxset.clsn1[i].y2) * zoom;
                    Rectangle(dc, box.left, box.top, box.right, box.bottom);
                }
                SelectObject(dc, old_pen);
                DeleteObject(pen);
            }
            SelectObject(dc, old_brush);
        }
    }
}

static void app_draw_waveform(avm_app *app, HDC dc, const RECT *preview)
{
    RECT inner;
    int mid;
    int width;
    int height;
    int x;
    avm_u32 start;
    avm_u32 end;
    avm_u32 i;
    int peak;
    int value;
    char buf[256];
    RECT text_rc;

    app_fill_rect(dc, preview, RGB(22, 25, 37));
    inner = *preview;
    inner.left += 28;
    inner.right -= 28;
    inner.top += 54;
    inner.bottom -= 72;
    app_frame_rect(dc, &inner, RGB(76, 82, 105));
    mid = (inner.top + inner.bottom) / 2;
    app_draw_line(dc, inner.left, mid, inner.right, mid, RGB(80, 86, 108), 1);

    if (!app->sound_decoded && !app_decode_sound(app)) {
        text_rc = *preview;
        app_draw_text(dc, app->font_title, &text_rc, AVM_COLOR_MUTED,
                      DT_CENTER | DT_VCENTER | DT_SINGLELINE,
                      "No decodable sound");
        return;
    }
    width = inner.right - inner.left;
    height = inner.bottom - inner.top;
    if (width <= 0 || app->sound_sample_count == 0u) {
        return;
    }
    for (x = 0; x < width; ++x) {
        start = ((avm_u32)x * app->sound_sample_count) / (avm_u32)width;
        end = ((avm_u32)(x + 1) * app->sound_sample_count) / (avm_u32)width;
        if (end <= start) end = start + 1u;
        if (end > app->sound_sample_count) end = app->sound_sample_count;
        peak = 0;
        for (i = start; i < end; ++i) {
            value = g_sound_samples[i];
            if (value < 0) value = -value;
            if (value > peak) peak = value;
        }
        peak = (peak * (height / 2 - 2)) / 32768;
        app_draw_line(dc, inner.left + x, mid - peak,
                      inner.left + x, mid + peak,
                      AVM_COLOR_ACCENT, 1);
    }

    wsprintfA(buf, "%lu Hz   %u ch   source %u-bit   %lu ms   PCM preview: %lu samples",
              (unsigned long)app->sound_info.sample_rate,
              (unsigned int)app->sound_info.channels,
              (unsigned int)app->sound_info.bits_per_sample,
              (unsigned long)app->sound_duration_ms,
              (unsigned long)app->sound_sample_count);
    text_rc = *preview;
    text_rc.left += 30;
    text_rc.top += 18;
    text_rc.right -= 30;
    text_rc.bottom = text_rc.top + 28;
    app_draw_text(dc, app->font_ui, &text_rc, AVM_COLOR_TEXT,
                  DT_LEFT | DT_VCENTER | DT_SINGLELINE, buf);
}

static void app_draw_sidebar_list(avm_app *app, HDC dc, const avm_layout *layout)
{
    RECT rc;
    RECT row;
    char buf[256];
    avm_u32 count;
    avm_u32 current;
    int offset;
    int y;
    avm_u32 index;
    const air_action *action;
    const sndmug_entry *sound;
    SffSpriteInfo info;
    const air_pose_sample *pose;

    rc = layout->sidebar;
    rc.left += 16;
    rc.right -= 16;
    rc.top += 16;
    rc.bottom = rc.top + 82;
    if (!app->character.loaded) {
        app_draw_text(dc, app->font_title, &rc, AVM_COLOR_TEXT,
                      DT_LEFT | DT_TOP | DT_WORDBREAK,
                      "Open a character .def to inspect its audiovisual assets.");
        return;
    }

    app_draw_text(dc, app->font_title, &rc, AVM_COLOR_TEXT,
                  DT_LEFT | DT_TOP | DT_SINGLELINE,
                  app->character.display_name[0] != '\0' ?
                  app->character.display_name : "Unnamed character");
    rc.top += 30;
    wsprintfA(buf, "Author: %s", app->character.author[0] != '\0' ?
              app->character.author : "unknown");
    app_draw_text(dc, app->font_ui, &rc, AVM_COLOR_MUTED,
                  DT_LEFT | DT_TOP | DT_SINGLELINE, buf);
    rc.top += 22;
    wsprintfA(buf, "%lu sprites  |  %lu actions  |  %lu sounds",
              (unsigned long)avm_character_sprite_count(&app->character),
              (unsigned long)avm_character_action_count(&app->character),
              (unsigned long)avm_character_sound_count(&app->character));
    app_draw_text(dc, app->font_ui, &rc, AVM_COLOR_MUTED,
                  DT_LEFT | DT_TOP | DT_SINGLELINE, buf);

    rc = layout->sidebar;
    rc.left += 14;
    rc.right -= 14;
    rc.top += 112;
    rc.bottom = rc.top + 58;
    app_fill_rect(dc, &rc, AVM_COLOR_PANEL_2);
    app_frame_rect(dc, &rc, RGB(72, 78, 100));

    if (app->mode == AVM_VIEW_SPRITES) {
        if (avm_character_sprite_info(&app->character,
                                      app->sprite_index,
                                      &info) == AVM_STATUS_OK) {
            wsprintfA(buf, "Sprite %u,%u    index %lu\n%ux%u  axis %d,%d  depth %u",
                      (unsigned int)info.group,
                      (unsigned int)info.item,
                      (unsigned long)app->sprite_index,
                      (unsigned int)info.w,
                      (unsigned int)info.h,
                      (int)info.axis_x,
                      (int)info.axis_y,
                      (unsigned int)info.depth);
        } else {
            app_copy_text(buf, sizeof(buf), "Invalid sprite entry");
        }
    } else if (app->mode == AVM_VIEW_ANIMATIONS) {
        action = avm_character_action_at(&app->character, app->action_index);
        pose = app_current_pose(app);
        if (action != 0 && pose != 0) {
            wsprintfA(buf, "Action %ld    frame %lu/%lu\nSprite %ld,%ld  time %ld  C1:%u C2:%u",
                      (long)action->action_no,
                      (unsigned long)(pose->elem_index + 1u),
                      (unsigned long)action->elem_count,
                      (long)pose->pose.group_no,
                      (long)pose->pose.image_no,
                      (long)pose->pose.time,
                      (unsigned int)pose->clsn1.count,
                      (unsigned int)pose->clsn2.count);
        } else {
            app_copy_text(buf, sizeof(buf), "Invalid AIR action");
        }
    } else {
        sound = avm_character_sound_at(&app->character, app->sound_index);
        if (sound != 0) {
            wsprintfA(buf, "Sound %lu,%lu    index %lu\n%lu bytes  %lu ms  %lu Hz",
                      (unsigned long)sound->group_no,
                      (unsigned long)sound->sound_no,
                      (unsigned long)app->sound_index,
                      (unsigned long)sound->data_length,
                      (unsigned long)app->sound_duration_ms,
                      (unsigned long)(app->sound_decoded ? app->sound_info.sample_rate : 0u));
        } else {
            app_copy_text(buf, sizeof(buf), "No readable sound entry");
        }
    }
    rc.left += 10;
    rc.top += 7;
    app_draw_text(dc, app->font_ui, &rc, AVM_COLOR_TEXT,
                  DT_LEFT | DT_TOP | DT_WORDBREAK, buf);

    rc = layout->sidebar;
    rc.left += 14;
    rc.right -= 14;
    rc.top += 184;
    rc.bottom = layout->prev_item.top - 12;
    app_fill_rect(dc, &rc, RGB(27, 30, 43));
    app_frame_rect(dc, &rc, RGB(64, 69, 89));

    if (app->mode == AVM_VIEW_SPRITES) {
        count = avm_character_sprite_count(&app->character);
        current = app->sprite_index;
    } else if (app->mode == AVM_VIEW_ANIMATIONS) {
        count = avm_character_action_count(&app->character);
        current = app->action_index;
    } else {
        count = avm_character_sound_count(&app->character);
        current = app->sound_index;
    }

    y = rc.top + 8;
    for (offset = -4; offset <= 4; ++offset) {
        if (count == 0u) break;
        {
            long signed_index;
            signed_index = (long)current + (long)offset;
            while (signed_index < 0L) signed_index += (long)count;
            while (signed_index >= (long)count) signed_index -= (long)count;
            index = (avm_u32)signed_index;
        }
        row.left = rc.left + 6;
        row.right = rc.right - 6;
        row.top = y;
        row.bottom = y + 25;
        if (index == current) {
            app_fill_rect(dc, &row, AVM_COLOR_ACCENT);
        }
        if (app->mode == AVM_VIEW_SPRITES) {
            if (avm_character_sprite_info(&app->character, index, &info) == AVM_STATUS_OK) {
                wsprintfA(buf, "%c %5lu   %u,%u   %ux%u",
                          index == current ? '>' : ' ',
                          (unsigned long)index,
                          (unsigned int)info.group,
                          (unsigned int)info.item,
                          (unsigned int)info.w,
                          (unsigned int)info.h);
            } else {
                wsprintfA(buf, "%c %5lu   invalid", index == current ? '>' : ' ',
                          (unsigned long)index);
            }
        } else if (app->mode == AVM_VIEW_ANIMATIONS) {
            action = avm_character_action_at(&app->character, index);
            wsprintfA(buf, "%c action %-6ld   %lu frames",
                      index == current ? '>' : ' ',
                      action != 0 ? (long)action->action_no : -1L,
                      action != 0 ? (unsigned long)action->elem_count : 0ul);
        } else {
            sound = avm_character_sound_at(&app->character, index);
            wsprintfA(buf, "%c %5lu   %lu,%lu",
                      index == current ? '>' : ' ',
                      (unsigned long)index,
                      sound != 0 ? (unsigned long)sound->group_no : 0ul,
                      sound != 0 ? (unsigned long)sound->sound_no : 0ul);
        }
        app_draw_text(dc, app->font_ui, &row,
                      index == current ? AVM_COLOR_TEXT : AVM_COLOR_MUTED,
                      DT_LEFT | DT_VCENTER | DT_SINGLELINE, buf);
        y += 27;
        if (y + 25 > rc.bottom) break;
    }
}

static void app_draw_ui(avm_app *app, HDC dc)
{
    avm_layout layout;
    RECT client;
    char buf[128];
    app_compute_layout(app->hwnd, &layout);
    GetClientRect(app->hwnd, &client);
    app_fill_rect(dc, &client, AVM_COLOR_BG);
    app_fill_rect(dc, &layout.header, AVM_COLOR_PANEL);
    app_fill_rect(dc, &layout.sidebar, AVM_COLOR_PANEL);
    app_fill_rect(dc, &layout.status, RGB(17, 19, 28));

    app_draw_button(dc, app->font_ui, &layout.tab_sprites, "SPRITES",
                    app->mode == AVM_VIEW_SPRITES);
    app_draw_button(dc, app->font_ui, &layout.tab_anims, "ANIMATIONS",
                    app->mode == AVM_VIEW_ANIMATIONS);
    app_draw_button(dc, app->font_ui, &layout.tab_sounds, "SOUNDS",
                    app->mode == AVM_VIEW_SOUNDS);

    app_draw_sidebar_list(app, dc, &layout);

    app_draw_button(dc, app->font_ui, &layout.prev_item, "< PREVIOUS", 0);
    app_draw_button(dc, app->font_ui, &layout.next_item, "NEXT >", 0);
    if (app->mode == AVM_VIEW_ANIMATIONS) {
        app_draw_button(dc, app->font_ui, &layout.prev_frame, "[ FRAME", 0);
        app_draw_button(dc, app->font_ui, &layout.play,
                        app->animation_playing ? "PAUSE" : "PLAY", 0);
        app_draw_button(dc, app->font_ui, &layout.next_frame, "FRAME ]", 0);
    } else if (app->mode == AVM_VIEW_SOUNDS) {
        app_draw_button(dc, app->font_ui, &layout.prev_frame, "RELOAD", 0);
        app_draw_button(dc, app->font_ui, &layout.play, "PLAY", 0);
        app_draw_button(dc, app->font_ui, &layout.next_frame, "STOP", 0);
    } else {
        app_draw_button(dc, app->font_ui, &layout.prev_frame, "CLSN1 N/A", 0);
        app_draw_button(dc, app->font_ui, &layout.play, "FRAME N/A", 0);
        app_draw_button(dc, app->font_ui, &layout.next_frame, "CLSN2 N/A", 0);
    }
    wsprintfA(buf, "- ZOOM (%dx)", app->zoom);
    app_draw_button(dc, app->font_ui, &layout.zoom_out, buf, 0);
    wsprintfA(buf, "+ ZOOM (%dx)", app->zoom);
    app_draw_button(dc, app->font_ui, &layout.zoom_in, buf, 0);

    if (app->mode == AVM_VIEW_SOUNDS) {
        app_draw_waveform(app, dc, &layout.preview);
    } else {
        app_draw_sprite_preview(app, dc, &layout.preview);
    }
    app_draw_text(dc, app->font_ui, &layout.status, AVM_COLOR_MUTED,
                  DT_LEFT | DT_VCENTER | DT_SINGLELINE,
                  app->status_text[0] != '\0' ? app->status_text :
                  "Ctrl+O opens a character. Arrow keys browse. Space plays.");
}

static void app_zoom(avm_app *app, int delta)
{
    if (app == 0) return;
    app->zoom += delta;
    if (app->zoom < 1) app->zoom = 1;
    if (app->zoom > 8) app->zoom = 8;
    InvalidateRect(app->hwnd, 0, FALSE);
}

static void app_reset_selection(avm_app *app)
{
    app->sprite_index = 0u;
    app->action_index = 0u;
    app->sound_index = 0u;
    app->manual_frame = 0;
    app->manual_element = 0u;
    app->decoded_valid = 0;
    app->sound_decoded = 0;
    app->animation_playing = 0;
}

static int app_open_character_path(avm_app *app, const char *path)
{
    avm_status status;
    char title[512];
    const char *warning_text;
    if (app == 0 || path == 0) {
        return 0;
    }
    app_audio_stop(app);
    KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
    app_reset_selection(app);
    status = avm_character_open(&app->character,
                                path,
                                &app->file_api,
                                &app->memory,
                                &app->report);
    if (status != AVM_STATUS_OK) {
        wsprintfA(title, "Import failed: %s (native %d)",
                  app->report.message[0] != '\0' ? app->report.message :
                  avm_status_string(status),
                  app->report.native_status);
        MessageBoxA(app->hwnd, title, AVM_APP_TITLE,
                    MB_OK | MB_ICONERROR);
        app_set_status(app, title);
        return 0;
    }
    app_copy_text(app->loaded_def_path, AVM_PATH_CAPACITY, path);
    wsprintfA(title, "%s - %s", AVM_APP_TITLE,
              app->character.display_name[0] != '\0' ?
              app->character.display_name : path);
    SetWindowTextA(app->hwnd, title);
    if (app->character.has_air &&
        app->character.air_program_data.action_count != 0u) {
        app_select_action(app, 0u);
    }
    if (app->character.has_snd && app->character.snd.entry_count != 0u) {
        (void)app_decode_sound(app);
    }
    warning_text = "No import warnings.";
    if (app->report.warning_flags != 0u) {
        if (app->report.warning_flags == AVM_WARNING_AIR_RECOVERED) {
            warning_text = "AIR compatibility corrections were applied.";
        } else {
            warning_text = "Warnings were reported.";
        }
    }
    wsprintfA(title, "Imported %lu sprites, %lu AIR actions and %lu sounds. %s",
              (unsigned long)avm_character_sprite_count(&app->character),
              (unsigned long)avm_character_action_count(&app->character),
              (unsigned long)avm_character_sound_count(&app->character),
              warning_text);
    app_set_status(app, title);
    InvalidateRect(app->hwnd, 0, TRUE);
    return 1;
}

static void app_open_dialog(avm_app *app)
{
    OPENFILENAMEA ofn;
    char path[AVM_PATH_CAPACITY];
    memset(&ofn, 0, sizeof(ofn));
    memset(path, 0, sizeof(path));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = app->hwnd;
    ofn.hInstance = app->instance;
    ofn.lpstrFilter = "M.U.G.E.N character DEF (*.def)\0*.def\0All files (*.*)\0*.*\0\0";
    ofn.lpstrFile = path;
    ofn.nMaxFile = sizeof(path);
    ofn.lpstrTitle = "Open M.U.G.E.N character definition";
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST |
                OFN_HIDEREADONLY | OFN_EXPLORER;
    if (GetOpenFileNameA(&ofn)) {
        (void)app_open_character_path(app, path);
    }
}

static HMENU app_create_menu(void)
{
    HMENU bar;
    HMENU file;
    HMENU view;
    HMENU playback;
    HMENU help;
    bar = CreateMenu();
    file = CreatePopupMenu();
    view = CreatePopupMenu();
    playback = CreatePopupMenu();
    help = CreatePopupMenu();
    AppendMenuA(file, MF_STRING, IDM_FILE_OPEN, "&Open character...\tCtrl+O");
    AppendMenuA(file, MF_STRING, IDM_FILE_RELOAD, "&Reload\tF5");
    AppendMenuA(file, MF_SEPARATOR, 0, 0);
    AppendMenuA(file, MF_STRING, IDM_FILE_EXIT, "E&xit");
    AppendMenuA(view, MF_STRING, IDM_VIEW_SPRITES, "&Sprites\t1");
    AppendMenuA(view, MF_STRING, IDM_VIEW_ANIMS, "&Animations\t2");
    AppendMenuA(view, MF_STRING, IDM_VIEW_SOUNDS, "S&ounds\t3");
    AppendMenuA(view, MF_SEPARATOR, 0, 0);
    AppendMenuA(view, MF_STRING | MF_CHECKED, IDM_VIEW_CLSN1, "Show Clsn1 attack boxes\tC");
    AppendMenuA(view, MF_STRING | MF_CHECKED, IDM_VIEW_CLSN2, "Show Clsn2 hurt boxes\tV");
    AppendMenuA(playback, MF_STRING, IDM_PLAY_PREV, "Previous item/frame\tLeft / [");
    AppendMenuA(playback, MF_STRING, IDM_PLAY_TOGGLE, "Play or pause\tSpace");
    AppendMenuA(playback, MF_STRING, IDM_PLAY_NEXT, "Next item/frame\tRight / ]");
    AppendMenuA(playback, MF_STRING, IDM_PLAY_STOP, "Stop\tEsc");
    AppendMenuA(playback, MF_SEPARATOR, 0, 0);
    AppendMenuA(playback, MF_STRING, IDM_ZOOM_IN, "Zoom in\t+");
    AppendMenuA(playback, MF_STRING, IDM_ZOOM_OUT, "Zoom out\t-");
    AppendMenuA(help, MF_STRING, IDM_HELP_KEYS, "Keyboard controls");
    AppendMenuA(help, MF_STRING, IDM_HELP_ABOUT, "About audiovisualmugen");
    AppendMenuA(bar, MF_POPUP, (UINT_PTR)file, "&File");
    AppendMenuA(bar, MF_POPUP, (UINT_PTR)view, "&View");
    AppendMenuA(bar, MF_POPUP, (UINT_PTR)playback, "&Playback");
    AppendMenuA(bar, MF_POPUP, (UINT_PTR)help, "&Help");
    return bar;
}

static void app_handle_command(avm_app *app, int command)
{
    HMENU menu;
    UINT flags;
    if (app == 0) return;
    switch (command) {
    case IDM_FILE_OPEN:
        app_open_dialog(app);
        break;
    case IDM_FILE_RELOAD:
        if (app->loaded_def_path[0] != '\0') {
            (void)app_open_character_path(app, app->loaded_def_path);
        }
        break;
    case IDM_FILE_EXIT:
        DestroyWindow(app->hwnd);
        break;
    case IDM_VIEW_SPRITES:
        app_set_mode(app, AVM_VIEW_SPRITES);
        break;
    case IDM_VIEW_ANIMS:
        app_set_mode(app, AVM_VIEW_ANIMATIONS);
        break;
    case IDM_VIEW_SOUNDS:
        app_set_mode(app, AVM_VIEW_SOUNDS);
        break;
    case IDM_VIEW_CLSN1:
        app->show_clsn1 = !app->show_clsn1;
        menu = GetMenu(app->hwnd);
        flags = MF_BYCOMMAND | (app->show_clsn1 ? MF_CHECKED : MF_UNCHECKED);
        CheckMenuItem(menu, IDM_VIEW_CLSN1, flags);
        InvalidateRect(app->hwnd, 0, FALSE);
        break;
    case IDM_VIEW_CLSN2:
        app->show_clsn2 = !app->show_clsn2;
        menu = GetMenu(app->hwnd);
        flags = MF_BYCOMMAND | (app->show_clsn2 ? MF_CHECKED : MF_UNCHECKED);
        CheckMenuItem(menu, IDM_VIEW_CLSN2, flags);
        InvalidateRect(app->hwnd, 0, FALSE);
        break;
    case IDM_PLAY_PREV:
        if (app->mode == AVM_VIEW_ANIMATIONS) app_step_frame(app, -1);
        else app_change_item(app, -1);
        break;
    case IDM_PLAY_NEXT:
        if (app->mode == AVM_VIEW_ANIMATIONS) app_step_frame(app, 1);
        else app_change_item(app, 1);
        break;
    case IDM_PLAY_TOGGLE:
        if (app->mode == AVM_VIEW_ANIMATIONS) app_toggle_animation(app);
        else if (app->mode == AVM_VIEW_SOUNDS) app_audio_play(app);
        break;
    case IDM_PLAY_STOP:
        if (app->mode == AVM_VIEW_ANIMATIONS) {
            app->animation_playing = 0;
            KillTimer(app->hwnd, AVM_TIMER_ANIMATION);
        }
        app_audio_stop(app);
        break;
    case IDM_ZOOM_IN:
        app_zoom(app, 1);
        break;
    case IDM_ZOOM_OUT:
        app_zoom(app, -1);
        break;
    case IDM_HELP_KEYS:
        MessageBoxA(app->hwnd,
                    "Ctrl+O: open character\n"
                    "1/2/3: sprites, animations, sounds\n"
                    "Left/Right: previous/next item\n"
                    "[ and ]: previous/next animation frame\n"
                    "Space: play/pause animation or play sound\n"
                    "C/V: toggle Clsn1/Clsn2\n"
                    "+/-: zoom\nF5: reload\nEsc: stop",
                    "audiovisualmugen controls",
                    MB_OK | MB_ICONINFORMATION);
        break;
    case IDM_HELP_ABOUT:
        MessageBoxA(app->hwnd,
                    "audiovisualmugen 0.1.4\n\n"
                    "Reusable no-heap M.U.G.E.N character importer plus a Win32 audiovisual inspector.\n"
                    "C89, static buffers, integer/fixed-point only.",
                    AVM_APP_TITLE,
                    MB_OK | MB_ICONINFORMATION);
        break;
    default:
        break;
    }
}

static void app_handle_click(avm_app *app, int x, int y)
{
    avm_layout layout;
    app_compute_layout(app->hwnd, &layout);
    if (app_point_in_rect(&layout.tab_sprites, x, y)) app_set_mode(app, AVM_VIEW_SPRITES);
    else if (app_point_in_rect(&layout.tab_anims, x, y)) app_set_mode(app, AVM_VIEW_ANIMATIONS);
    else if (app_point_in_rect(&layout.tab_sounds, x, y)) app_set_mode(app, AVM_VIEW_SOUNDS);
    else if (app_point_in_rect(&layout.prev_item, x, y)) app_change_item(app, -1);
    else if (app_point_in_rect(&layout.next_item, x, y)) app_change_item(app, 1);
    else if (app_point_in_rect(&layout.prev_frame, x, y)) {
        if (app->mode == AVM_VIEW_ANIMATIONS) app_step_frame(app, -1);
        else if (app->mode == AVM_VIEW_SOUNDS) (void)app_decode_sound(app);
    }
    else if (app_point_in_rect(&layout.play, x, y)) {
        if (app->mode == AVM_VIEW_ANIMATIONS) app_toggle_animation(app);
        else if (app->mode == AVM_VIEW_SOUNDS) app_audio_play(app);
    }
    else if (app_point_in_rect(&layout.next_frame, x, y)) {
        if (app->mode == AVM_VIEW_ANIMATIONS) app_step_frame(app, 1);
        else if (app->mode == AVM_VIEW_SOUNDS) app_audio_stop(app);
    }
    else if (app_point_in_rect(&layout.zoom_out, x, y)) app_zoom(app, -1);
    else if (app_point_in_rect(&layout.zoom_in, x, y)) app_zoom(app, 1);
}

static LRESULT CALLBACK app_window_proc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
    PAINTSTRUCT ps;
    HDC dc;
    HDROP drop;
    char path[AVM_PATH_CAPACITY];
    int key;
    switch (message) {
    case WM_CREATE:
        g_app.hwnd = hwnd;
        DragAcceptFiles(hwnd, TRUE);
        return 0;
    case WM_COMMAND:
        app_handle_command(&g_app, LOWORD(wparam));
        return 0;
    case WM_LBUTTONDOWN:
        app_handle_click(&g_app, GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam));
        return 0;
    case WM_KEYDOWN:
        key = (int)wparam;
        if ((GetKeyState(VK_CONTROL) & 0x8000) != 0 && key == 'O') {
            app_open_dialog(&g_app);
        } else if (key == '1') {
            app_set_mode(&g_app, AVM_VIEW_SPRITES);
        } else if (key == '2') {
            app_set_mode(&g_app, AVM_VIEW_ANIMATIONS);
        } else if (key == '3') {
            app_set_mode(&g_app, AVM_VIEW_SOUNDS);
        } else if (key == VK_LEFT) {
            app_change_item(&g_app, -1);
        } else if (key == VK_RIGHT) {
            app_change_item(&g_app, 1);
        } else if (key == VK_OEM_4) {
            app_step_frame(&g_app, -1);
        } else if (key == VK_OEM_6) {
            app_step_frame(&g_app, 1);
        } else if (key == VK_SPACE) {
            if (g_app.mode == AVM_VIEW_ANIMATIONS) app_toggle_animation(&g_app);
            else if (g_app.mode == AVM_VIEW_SOUNDS) app_audio_play(&g_app);
        } else if (key == 'C') {
            app_handle_command(&g_app, IDM_VIEW_CLSN1);
        } else if (key == 'V') {
            app_handle_command(&g_app, IDM_VIEW_CLSN2);
        } else if (key == VK_ADD || key == VK_OEM_PLUS) {
            app_zoom(&g_app, 1);
        } else if (key == VK_SUBTRACT || key == VK_OEM_MINUS) {
            app_zoom(&g_app, -1);
        } else if (key == VK_F5) {
            app_handle_command(&g_app, IDM_FILE_RELOAD);
        } else if (key == VK_ESCAPE) {
            app_handle_command(&g_app, IDM_PLAY_STOP);
        }
        return 0;
    case WM_TIMER:
        if (wparam == AVM_TIMER_ANIMATION && g_app.animation_playing) {
            DWORD now_ms;
            DWORD elapsed_ms;
            avm_u32 ticks;

            now_ms = GetTickCount();
            elapsed_ms = now_ms - g_app.animation_last_ms;
            g_app.animation_last_ms = now_ms;
            if (elapsed_ms > 250u) {
                elapsed_ms = 250u;
            }
            g_app.animation_tick_accum += (avm_u32)elapsed_ms * 60u;
            ticks = g_app.animation_tick_accum / 1000u;
            g_app.animation_tick_accum %= 1000u;
            if (ticks == 0u) {
                return 0;
            }

            air_diag_list_reset(&g_app.character.air_diags);
            if (air_runtime_step_ticks(&g_app.character.air_runtime_data,
                                       (air_tick_t)ticks,
                                       &g_app.character.air_diags) == AIR_STATUS_OK) {
                /* The decoder cache is keyed by SFF index.  Do not invalidate
                   it for every AIR tick: most elements hold the same sprite
                   for several ticks.  The next paint decodes only when the
                   resolved group/image maps to a different SFF entry. */
                InvalidateRect(hwnd, 0, FALSE);
            } else {
                g_app.animation_playing = 0;
                KillTimer(hwnd, AVM_TIMER_ANIMATION);
                app_set_status(&g_app, "Animation runtime stopped on an AIR error.");
            }
        }
        return 0;
    case WM_DROPFILES:
        drop = (HDROP)wparam;
        path[0] = '\0';
        if (DragQueryFileA(drop, 0u, path, AVM_PATH_CAPACITY) != 0u) {
            (void)app_open_character_path(&g_app, path);
        }
        DragFinish(drop);
        return 0;
    case MM_WOM_DONE:
        app_audio_stop(&g_app);
        app_set_status(&g_app, "Sound playback finished.");
        return 0;
    case WM_PAINT:
        {
            RECT client;
            int width;
            int height;
            dc = BeginPaint(hwnd, &ps);
            GetClientRect(hwnd, &client);
            width = client.right - client.left;
            height = client.bottom - client.top;
            if (app_backbuffer_ensure(&g_app, dc, width, height)) {
                app_draw_ui(&g_app, g_app.back_dc);
                BitBlt(dc, 0, 0, width, height,
                       g_app.back_dc, 0, 0, SRCCOPY);
            } else {
                /* Low-resource fallback: keep the program usable even when
                   Windows cannot allocate a compatible backbuffer. */
                app_draw_ui(&g_app, dc);
            }
            EndPaint(hwnd, &ps);
        }
        return 0;
    case WM_ERASEBKGND:
        return 1;
    case WM_SIZE:
        InvalidateRect(hwnd, 0, FALSE);
        return 0;
    case WM_DESTROY:
        app_audio_stop(&g_app);
        KillTimer(hwnd, AVM_TIMER_ANIMATION);
        avm_character_close(&g_app.character);
        app_backbuffer_destroy(&g_app);
        if (g_app.font_ui != 0) DeleteObject(g_app.font_ui);
        if (g_app.font_title != 0) DeleteObject(g_app.font_title);
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcA(hwnd, message, wparam, lparam);
    }
}

int WINAPI WinMain(HINSTANCE instance,
                   HINSTANCE previous,
                   LPSTR command_line,
                   int show_command)
{
    WNDCLASSEXA wc;
    HWND hwnd;
    MSG message;
    char initial_path[AVM_PATH_CAPACITY];
    (void)previous;

    memset(&g_app, 0, sizeof(g_app));
    g_app.instance = instance;
    g_app.mode = AVM_VIEW_SPRITES;
    g_app.zoom = 2;
    g_app.show_clsn1 = 1;
    g_app.show_clsn2 = 1;
    avm_win32_file_api_init(&g_app.file_api);
    avm_character_init(&g_app.character);
    avm_memory_init(&g_app.memory);
    g_app.memory.def_text = g_def_text;
    g_app.memory.def_text_capacity = AVM_DEF_TEXT_BYTES;
    g_app.memory.air_text = g_air_text;
    g_app.memory.air_text_capacity = AVM_AIR_TEXT_BYTES;
    g_app.memory.air_asset_memory = g_air_asset;
    g_app.memory.air_asset_capacity = AVM_AIR_ASSET_BYTES;
    g_app.memory.air_scratch_memory = g_air_scratch;
    g_app.memory.air_scratch_capacity = AVM_AIR_SCRATCH_BYTES;
    g_app.memory.snd_entries = g_snd_entries;
    g_app.memory.snd_entry_capacity = AVM_SND_ENTRY_COUNT;
    app_copy_text(g_app.status_text, AVM_REPORT_CAPACITY,
                  "Ctrl+O opens a M.U.G.E.N character .def. Drag-and-drop also works.");

    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(wc);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = app_window_proc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorA(0, IDC_ARROW);
    wc.hIcon = LoadIconA(0, IDI_APPLICATION);
    wc.hIconSm = LoadIconA(0, IDI_APPLICATION);
    wc.hbrBackground = 0;
    wc.lpszClassName = "audiovisualmugen_window";
    if (!RegisterClassExA(&wc)) {
        return 1;
    }

    hwnd = CreateWindowExA(0,
                           wc.lpszClassName,
                           AVM_APP_TITLE,
                           WS_OVERLAPPEDWINDOW,
                           CW_USEDEFAULT,
                           CW_USEDEFAULT,
                           1180,
                           760,
                           0,
                           app_create_menu(),
                           instance,
                           0);
    if (hwnd == 0) {
        return 2;
    }
    g_app.hwnd = hwnd;
    g_app.font_ui = CreateFontA(-16, 0, 0, 0, FW_NORMAL,
                                FALSE, FALSE, FALSE, ANSI_CHARSET,
                                OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                DEFAULT_QUALITY, FF_DONTCARE,
                                "Segoe UI");
    g_app.font_title = CreateFontA(-23, 0, 0, 0, FW_BOLD,
                                   FALSE, FALSE, FALSE, ANSI_CHARSET,
                                   OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                   DEFAULT_QUALITY, FF_DONTCARE,
                                   "Segoe UI");
    ShowWindow(hwnd, show_command);
    UpdateWindow(hwnd);

    initial_path[0] = '\0';
    if (command_line != 0 && command_line[0] != '\0') {
        app_copy_text(initial_path, AVM_PATH_CAPACITY, command_line);
        if (initial_path[0] == '"') {
            avm_u32 len;
            avm_u32 i;
            len = (avm_u32)strlen(initial_path);
            if (len > 1u && initial_path[len - 1u] == '"') {
                for (i = 1u; i + 1u < len; ++i) {
                    initial_path[i - 1u] = initial_path[i];
                }
                initial_path[len - 2u] = '\0';
            }
        }
        (void)app_open_character_path(&g_app, initial_path);
    }

    while (GetMessageA(&message, 0, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageA(&message);
    }
    return (int)message.wParam;
}
