#include <limits.h>
#include <string.h>
#include "audiovisualmugen/audiovisualmugen.h"

static void avm_copy_text(char *dst, avm_u32 cap, const char *src)
{
    avm_u32 i;
    if (dst == 0 || cap == 0u) {
        return;
    }
    if (src == 0) {
        dst[0] = '\0';
        return;
    }
    i = 0u;
    while (src[i] != '\0' && i + 1u < cap) {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = '\0';
}

static void avm_report_set(avm_report *report,
                           avm_status status,
                           int native_status,
                           const char *message)
{
    if (report == 0) {
        return;
    }
    report->status = status;
    report->native_status = native_status;
    avm_copy_text(report->message, AVM_REPORT_CAPACITY, message);
}

void avm_memory_init(avm_memory *memory)
{
    if (memory != 0) {
        memset(memory, 0, sizeof(*memory));
    }
}

void avm_report_clear(avm_report *report)
{
    if (report != 0) {
        memset(report, 0, sizeof(*report));
        report->status = AVM_STATUS_OK;
    }
}

const char *avm_status_string(avm_status status)
{
    switch (status) {
    case AVM_STATUS_OK: return "ok";
    case AVM_STATUS_BAD_ARGUMENT: return "bad argument";
    case AVM_STATUS_OPEN_DEF_FAILED: return "could not open character DEF";
    case AVM_STATUS_DEF_TOO_LARGE: return "character DEF exceeds caller buffer";
    case AVM_STATUS_DEF_READ_FAILED: return "could not read character DEF";
    case AVM_STATUS_DEF_PARSE_FAILED: return "character DEF parse failed";
    case AVM_STATUS_DEF_MISSING_SPRITE: return "character DEF has no sprite file";
    case AVM_STATUS_DEF_MISSING_ANIM: return "character DEF has no animation file";
    case AVM_STATUS_OPEN_SFF_FAILED: return "could not open SFF";
    case AVM_STATUS_SFF_PARSE_FAILED: return "SFF parse failed";
    case AVM_STATUS_OPEN_AIR_FAILED: return "could not open AIR";
    case AVM_STATUS_AIR_TOO_LARGE: return "AIR exceeds caller buffer";
    case AVM_STATUS_AIR_READ_FAILED: return "could not read AIR";
    case AVM_STATUS_AIR_COMPILE_FAILED: return "AIR compile failed";
    case AVM_STATUS_OPEN_SND_FAILED: return "could not open SND";
    case AVM_STATUS_SND_PARSE_FAILED: return "SND parse failed";
    case AVM_STATUS_CAPACITY: return "caller capacity exhausted";
    case AVM_STATUS_NOT_LOADED: return "character is not loaded";
    case AVM_STATUS_NOT_FOUND: return "asset not found";
    case AVM_STATUS_DECODE_FAILED: return "asset decode failed";
    default: return "unknown audiovisualmugen status";
    }
}

static void avm_file_state_clear(avm_file_state *file)
{
    if (file != 0) {
        memset(file, 0, sizeof(*file));
    }
}

static int avm_file_state_open(avm_file_state *file,
                               const avm_file_api *api,
                               const char *path)
{
    avm_u32 size;
    avm_file_ref ref;
    if (file == 0 || api == 0 || api->open_read == 0 || api->close == 0 ||
        api->read_at == 0 || api->get_size == 0 || path == 0) {
        return 0;
    }
    avm_file_state_clear(file);
    ref = api->open_read(api->user, path);
    if (ref == 0) {
        return 0;
    }
    if (!api->get_size(api->user, ref, &size)) {
        api->close(api->user, ref);
        return 0;
    }
    file->api = api;
    file->ref = ref;
    file->size = size;
    file->pos = 0u;
    return 1;
}

static void avm_file_state_close(avm_file_state *file)
{
    if (file != 0 && file->ref != 0 && file->api != 0 && file->api->close != 0) {
        file->api->close(file->api->user, file->ref);
    }
    avm_file_state_clear(file);
}

static int avm_file_read_exact(const avm_file_state *file,
                               avm_u32 offset,
                               void *dst,
                               avm_u32 size)
{
    avm_u32 got;
    if (file == 0 || file->api == 0 || file->ref == 0 || dst == 0) {
        return 0;
    }
    got = 0u;
    if (!file->api->read_at(file->api->user, file->ref, offset, dst, size, &got)) {
        return 0;
    }
    return got == size;
}

static int avm_read_text_file(const avm_file_api *api,
                              const char *path,
                              char *buffer,
                              avm_u32 capacity,
                              avm_u32 *out_size,
                              int *out_too_large)
{
    avm_file_state file;
    avm_u32 size;
    int ok;
    if (out_size != 0) {
        *out_size = 0u;
    }
    if (out_too_large != 0) {
        *out_too_large = 0;
    }
    if (api == 0 || path == 0 || buffer == 0 || capacity == 0u) {
        return 0;
    }
    if (!avm_file_state_open(&file, api, path)) {
        return 0;
    }
    size = file.size;
    if (size + 1u < size || size + 1u > capacity) {
        if (out_too_large != 0) {
            *out_too_large = 1;
        }
        avm_file_state_close(&file);
        return 0;
    }
    ok = avm_file_read_exact(&file, 0u, buffer, size);
    avm_file_state_close(&file);
    if (!ok) {
        return 0;
    }
    buffer[size] = '\0';
    if (out_size != 0) {
        *out_size = size;
    }
    return 1;
}

static int avm_sff_read_at(void *user,
                           sff_u32 offset,
                           void *dst,
                           sff_u32 len)
{
    avm_file_state *file;
    file = (avm_file_state *)user;
    return avm_file_read_exact(file, (avm_u32)offset, dst, (avm_u32)len) ? 1 : 0;
}

static int avm_snd_read(void *user,
                        void *dst,
                        sndmug_u32 size,
                        sndmug_u32 *out_read)
{
    avm_file_state *file;
    avm_u32 got;
    file = (avm_file_state *)user;
    if (file == 0 || file->api == 0 || dst == 0 || out_read == 0) {
        return SNDMUG_E_INVALID_ARG;
    }
    got = 0u;
    if (!file->api->read_at(file->api->user, file->ref, file->pos,
                            dst, (avm_u32)size, &got)) {
        *out_read = 0u;
        return SNDMUG_E_IO;
    }
    file->pos += got;
    *out_read = (sndmug_u32)got;
    return got == (avm_u32)size ? SNDMUG_OK : SNDMUG_E_SHORT_READ;
}

static int avm_snd_seek(void *user, sndmug_u32 absolute_offset)
{
    avm_file_state *file;
    file = (avm_file_state *)user;
    if (file == 0 || (avm_u32)absolute_offset > file->size) {
        return SNDMUG_E_SEEK;
    }
    file->pos = (avm_u32)absolute_offset;
    return SNDMUG_OK;
}

static int avm_snd_tell(void *user, sndmug_u32 *out_offset)
{
    avm_file_state *file;
    file = (avm_file_state *)user;
    if (file == 0 || out_offset == 0) {
        return SNDMUG_E_INVALID_ARG;
    }
    *out_offset = (sndmug_u32)file->pos;
    return SNDMUG_OK;
}

static int avm_snd_size(void *user, sndmug_u32 *out_size)
{
    avm_file_state *file;
    file = (avm_file_state *)user;
    if (file == 0 || out_size == 0) {
        return SNDMUG_E_INVALID_ARG;
    }
    *out_size = (sndmug_u32)file->size;
    return SNDMUG_OK;
}

static void avm_setup_snd_io(avm_character *character)
{
    character->snd_io.read = avm_snd_read;
    character->snd_io.write = 0;
    character->snd_io.seek = avm_snd_seek;
    character->snd_io.tell = avm_snd_tell;
    character->snd_io.size = avm_snd_size;
    character->snd_io.user = &character->snd_file;
}

static void avm_copy_optional_view(const cfg_document *doc,
                                   mugen_value_view view,
                                   char *dst,
                                   avm_u32 cap)
{
    int rc;
    if (dst == 0 || cap == 0u) {
        return;
    }
    dst[0] = '\0';
    if (view.present) {
        rc = mugen_char_copy_view(doc, view, dst, (size_t)cap);
        if (rc != CFG_STATUS_OK) {
            dst[0] = '\0';
        }
    }
}

void avm_character_init(avm_character *character)
{
    if (character == 0) {
        return;
    }
    memset(character, 0, sizeof(*character));
    sff_init(&character->sff);
    air_program_zero(&character->air_program_data);
    air_diag_list_init(&character->air_diags,
                       character->air_diag_storage,
                       (air_u16)AIR_MAX_DIAGS);
    avm_file_state_clear(&character->sff_file);
    avm_file_state_clear(&character->snd_file);
}

void avm_character_close(avm_character *character)
{
    if (character == 0) {
        return;
    }
    avm_file_state_close(&character->snd_file);
    avm_file_state_close(&character->sff_file);
    sff_close(&character->sff);
    character->has_sff = 0;
    character->has_air = 0;
    character->has_snd = 0;
    character->loaded = 0;
    character->def_text_size = 0u;
    character->air_text_size = 0u;
    character->name[0] = '\0';
    character->display_name[0] = '\0';
    character->author[0] = '\0';
    character->def_path[0] = '\0';
    character->sprite_path[0] = '\0';
    character->anim_path[0] = '\0';
    character->sound_path[0] = '\0';
    air_program_zero(&character->air_program_data);
    air_diag_list_reset(&character->air_diags);
}

static avm_status avm_fail(avm_character *character,
                           avm_report *report,
                           avm_status status,
                           int native_status,
                           const char *message)
{
    avm_character_close(character);
    avm_report_set(report, status, native_status, message);
    return status;
}

avm_status avm_character_open(avm_character *character,
                              const char *def_path,
                              const avm_file_api *file_api,
                              const avm_memory *memory,
                              avm_report *report)
{
    cfg_parse_options cfg_opts;
    air_build_options air_opts;
    SffOpenOptions sff_opts;
    air_status air_rc;
    int cfg_rc;
    int sff_rc;
    int snd_rc;
    int too_large;
    const air_diag *last_diag;
    char air_diag_text[AVM_REPORT_CAPACITY];

    if (character == 0 || def_path == 0 || file_api == 0 || memory == 0 ||
        memory->def_text == 0 || memory->def_text_capacity == 0u ||
        memory->air_text == 0 || memory->air_text_capacity == 0u ||
        memory->air_asset_memory == 0 || memory->air_asset_capacity == 0u ||
        memory->air_scratch_memory == 0 || memory->air_scratch_capacity == 0u ||
        memory->snd_entries == 0 || memory->snd_entry_capacity == 0u) {
        avm_report_set(report, AVM_STATUS_BAD_ARGUMENT, 0, "invalid importer arguments");
        return AVM_STATUS_BAD_ARGUMENT;
    }

    avm_character_close(character);
    character->file_api = file_api;
    character->memory = *memory;
    avm_copy_text(character->def_path, AVM_PATH_CAPACITY, def_path);
    avm_report_clear(report);

    too_large = 0;
    if (!avm_read_text_file(file_api, def_path,
                            memory->def_text, memory->def_text_capacity,
                            &character->def_text_size, &too_large)) {
        if (too_large) {
            return avm_fail(character, report, AVM_STATUS_DEF_TOO_LARGE, 0,
                            "character DEF is larger than AVM def_text buffer");
        }
        return avm_fail(character, report, AVM_STATUS_OPEN_DEF_FAILED, 0,
                        "could not open or read character DEF");
    }

    cfg_parse_options_mugen(&cfg_opts);
    cfg_rc = cfg_parse_buffer(&character->def_document,
                              def_path,
                              memory->def_text,
                              (size_t)character->def_text_size,
                              &cfg_opts);
    if (cfg_rc != CFG_STATUS_OK) {
        return avm_fail(character, report, AVM_STATUS_DEF_PARSE_FAILED, cfg_rc,
                        cfg_status_string(cfg_rc));
    }
    cfg_rc = mugen_char_load(&character->def_document, &character->def_character);
    if (cfg_rc != CFG_STATUS_OK) {
        return avm_fail(character, report, AVM_STATUS_DEF_PARSE_FAILED, cfg_rc,
                        "could not map character DEF fields");
    }

    avm_copy_optional_view(&character->def_document, character->def_character.info.name,
                           character->name, AVM_NAME_CAPACITY);
    avm_copy_optional_view(&character->def_document, character->def_character.info.displayname,
                           character->display_name, AVM_NAME_CAPACITY);
    avm_copy_optional_view(&character->def_document, character->def_character.info.author,
                           character->author, AVM_NAME_CAPACITY);
    if (character->display_name[0] == '\0') {
        avm_copy_text(character->display_name, AVM_NAME_CAPACITY, character->name);
    }

    if (!character->def_character.files.sprite.present) {
        return avm_fail(character, report, AVM_STATUS_DEF_MISSING_SPRITE, 0,
                        "[Files] sprite is missing");
    }
    if (!character->def_character.files.anim.present) {
        return avm_fail(character, report, AVM_STATUS_DEF_MISSING_ANIM, 0,
                        "[Files] anim is missing");
    }

    cfg_rc = mugen_char_resolve_view_path(def_path,
                                          &character->def_document,
                                          character->def_character.files.sprite,
                                          character->sprite_path,
                                          AVM_PATH_CAPACITY);
    if (cfg_rc != CFG_STATUS_OK) {
        return avm_fail(character, report, AVM_STATUS_DEF_MISSING_SPRITE, cfg_rc,
                        "could not resolve sprite path");
    }
    cfg_rc = mugen_char_resolve_view_path(def_path,
                                          &character->def_document,
                                          character->def_character.files.anim,
                                          character->anim_path,
                                          AVM_PATH_CAPACITY);
    if (cfg_rc != CFG_STATUS_OK) {
        return avm_fail(character, report, AVM_STATUS_DEF_MISSING_ANIM, cfg_rc,
                        "could not resolve AIR path");
    }
    character->sound_path[0] = '\0';
    if (character->def_character.files.sound.present) {
        (void)mugen_char_resolve_view_path(def_path,
                                           &character->def_document,
                                           character->def_character.files.sound,
                                           character->sound_path,
                                           AVM_PATH_CAPACITY);
    }

    if (!avm_file_state_open(&character->sff_file, file_api, character->sprite_path)) {
        return avm_fail(character, report, AVM_STATUS_OPEN_SFF_FAILED, 0,
                        "could not open character SFF");
    }
    character->sff_io.read_at = avm_sff_read_at;
    character->sff_io.user = &character->sff_file;
    character->sff_io.size = character->sff_file.size;
    sff_opts.tolerant = 1;
    sff_opts.codec = 0;
    sff_rc = sff_open_io(&character->sff, &character->sff_io, &sff_opts);
    if (sff_rc != SFF_OK) {
        return avm_fail(character, report, AVM_STATUS_SFF_PARSE_FAILED, sff_rc,
                        "could not parse character SFF");
    }
    character->has_sff = 1;

    too_large = 0;
    if (!avm_read_text_file(file_api, character->anim_path,
                            memory->air_text, memory->air_text_capacity,
                            &character->air_text_size, &too_large)) {
        if (too_large) {
            return avm_fail(character, report, AVM_STATUS_AIR_TOO_LARGE, 0,
                            "AIR is larger than AVM air_text buffer");
        }
        return avm_fail(character, report, AVM_STATUS_OPEN_AIR_FAILED, 0,
                        "could not open or read character AIR");
    }

    air_arena_init(&character->air_asset_arena,
                   memory->air_asset_memory,
                   memory->air_asset_capacity);
    air_arena_init(&character->air_scratch_arena,
                   memory->air_scratch_memory,
                   memory->air_scratch_capacity);
    air_program_zero(&character->air_program_data);
    air_diag_list_reset(&character->air_diags);
    air_build_options_default(&air_opts);
    air_opts.parse.permissive = AIR_TRUE;
    air_opts.validate_after_compile = AIR_TRUE;
    air_rc = air_program_build_from_text(&character->air_program_data,
                                         &character->air_asset_arena,
                                         &character->air_scratch_arena,
                                         memory->air_text,
                                         character->air_text_size,
                                         &air_opts,
                                         &character->air_diags);
    if (air_rc != AIR_STATUS_OK) {
        last_diag = air_diag_last(&character->air_diags);
        air_diag_text[0] = '\0';
        if (last_diag != 0) {
            air_diag_format(last_diag,
                            air_diag_text,
                            (air_u32)sizeof(air_diag_text));
        }
        return avm_fail(character, report, AVM_STATUS_AIR_COMPILE_FAILED, (int)air_rc,
                        air_diag_text[0] != '\0' ? air_diag_text : "could not compile AIR");
    }
    air_runtime_init(&character->air_runtime_data,
                     &character->air_program_data,
                     0);
    character->has_air = 1;

    if (character->sound_path[0] != '\0') {
        if (avm_file_state_open(&character->snd_file, file_api, character->sound_path)) {
            avm_setup_snd_io(character);
            snd_rc = sndmug_reader_open(&character->snd,
                                        &character->snd_io,
                                        memory->snd_entries,
                                        memory->snd_entry_capacity);
            if (snd_rc == SNDMUG_OK) {
                character->has_snd = 1;
            } else {
                avm_file_state_close(&character->snd_file);
                memset(&character->snd, 0, sizeof(character->snd));
                if (report != 0) {
                    report->warning_flags |= AVM_WARNING_SND_PARSE_FAILED;
                }
            }
        } else if (report != 0) {
            report->warning_flags |= AVM_WARNING_SND_OPEN_FAILED;
        }
    }

    character->loaded = 1;
    if (report != 0) {
        if (character->air_diags.warning_count != 0u) {
            report->warning_flags |= AVM_WARNING_AIR_RECOVERED;
        }
        report->warning_flags |= character->def_character.warnings << AVM_WARNING_DEF_SHIFT;
        avm_report_set(report, AVM_STATUS_OK, 0,
                       character->has_snd ? "character imported" :
                       "character imported; sound archive unavailable");
    }
    return AVM_STATUS_OK;
}

avm_u32 avm_character_sprite_count(const avm_character *character)
{
    return character != 0 && character->has_sff ?
        (avm_u32)sff_sprite_count(&character->sff) : 0u;
}

avm_u32 avm_character_action_count(const avm_character *character)
{
    return character != 0 && character->has_air ?
        (avm_u32)character->air_program_data.action_count : 0u;
}

avm_u32 avm_character_sound_count(const avm_character *character)
{
    return character != 0 && character->has_snd ?
        (avm_u32)character->snd.entry_count : 0u;
}

avm_status avm_character_decode_sprite_rgba(const avm_character *character,
                                            avm_u32 sprite_index,
                                            avm_u8 *rgba,
                                            avm_u32 rgba_capacity,
                                            avm_u16 *out_w,
                                            avm_u16 *out_h,
                                            avm_u8 *work,
                                            avm_u32 work_capacity)
{
    int rc;
    if (character == 0 || !character->has_sff) {
        return AVM_STATUS_NOT_LOADED;
    }
    rc = sff_decode_sprite_rgba_into(&character->sff,
                                     (sff_u32)sprite_index,
                                     (sff_u8 *)rgba,
                                     (sff_u32)rgba_capacity,
                                     (sff_u16 *)out_w,
                                     (sff_u16 *)out_h,
                                     (sff_u8 *)work,
                                     (sff_u32)work_capacity);
    if (rc == SFF_OK) {
        return AVM_STATUS_OK;
    }
    if (rc == SFF_ERR_BUFFER_TOO_SMALL || rc == SFF_ERR_CAPACITY) {
        return AVM_STATUS_CAPACITY;
    }
    return AVM_STATUS_DECODE_FAILED;
}


avm_status avm_character_sprite_info(const avm_character *character,
                                     avm_u32 sprite_index,
                                     SffSpriteInfo *out_info)
{
    int rc;
    if (character == 0 || out_info == 0 || !character->has_sff) {
        return AVM_STATUS_NOT_LOADED;
    }
    rc = sff_get_sprite_info(&character->sff,
                             (sff_u32)sprite_index,
                             out_info);
    return rc == SFF_OK ? AVM_STATUS_OK : AVM_STATUS_NOT_FOUND;
}

avm_status avm_character_find_sprite(const avm_character *character,
                                     avm_u16 group_no,
                                     avm_u16 image_no,
                                     avm_u32 *out_index)
{
    sff_u32 index;
    int rc;
    if (character == 0 || out_index == 0 || !character->has_sff) {
        return AVM_STATUS_NOT_LOADED;
    }
    rc = sff_find_sprite(&character->sff,
                         (sff_u16)group_no,
                         (sff_u16)image_no,
                         &index);
    if (rc != SFF_OK) {
        return AVM_STATUS_NOT_FOUND;
    }
    *out_index = (avm_u32)index;
    return AVM_STATUS_OK;
}


avm_status avm_character_find_action(const avm_character *character,
                                     avm_s32 action_no,
                                     avm_u32 *out_index)
{
    avm_u32 i;
    if (character == 0 || out_index == 0 || !character->has_air) {
        return AVM_STATUS_NOT_LOADED;
    }
    for (i = 0u; i < character->air_program_data.action_count; ++i) {
        if (character->air_program_data.actions[i].action_no == (air_i32)action_no) {
            *out_index = i;
            return AVM_STATUS_OK;
        }
    }
    return AVM_STATUS_NOT_FOUND;
}

avm_status avm_character_find_sound(const avm_character *character,
                                    avm_u32 group_no,
                                    avm_u32 sound_no,
                                    avm_u32 *out_index)
{
    int rc;
    sndmug_u32 index;
    if (character == 0 || out_index == 0 || !character->has_snd) {
        return AVM_STATUS_NOT_LOADED;
    }
    rc = sndmug_reader_find(&character->snd,
                            (sndmug_u32)group_no,
                            (sndmug_u32)sound_no,
                            &index);
    if (rc != SNDMUG_OK) {
        return AVM_STATUS_NOT_FOUND;
    }
    *out_index = (avm_u32)index;
    return AVM_STATUS_OK;
}

const air_action *avm_character_action_at(const avm_character *character,
                                          avm_u32 action_index)
{
    if (character == 0 || !character->has_air ||
        action_index >= character->air_program_data.action_count) {
        return 0;
    }
    return &character->air_program_data.actions[action_index];
}

const sndmug_entry *avm_character_sound_at(const avm_character *character,
                                           avm_u32 sound_index)
{
    if (character == 0 || !character->has_snd ||
        sound_index >= character->snd.entry_count) {
        return 0;
    }
    return &character->snd.entries[sound_index];
}

avm_status avm_character_read_sound_payload(const avm_character *character,
                                            avm_u32 sound_index,
                                            void *dst,
                                            avm_u32 capacity,
                                            avm_u32 *out_size)
{
    int rc;
    if (character == 0 || !character->has_snd) {
        return AVM_STATUS_NOT_LOADED;
    }
    rc = sndmug_reader_read_payload(&character->snd,
                                    (sndmug_u32)sound_index,
                                    dst,
                                    (sndmug_u32)capacity,
                                    (sndmug_u32 *)out_size);
    if (rc == SNDMUG_OK) {
        return AVM_STATUS_OK;
    }
    if (rc == SNDMUG_E_LIMIT) {
        return AVM_STATUS_CAPACITY;
    }
    return AVM_STATUS_DECODE_FAILED;
}
