@echo off
setlocal
cd /d "%~dp0"
where bash >nul 2>nul
if errorlevel 1 (
  echo error: bash was not found. Run this from an MSYS2 MINGW32 shell.
  exit /b 1
)
bash ./build_msys2_mingw32.sh
exit /b %errorlevel%
