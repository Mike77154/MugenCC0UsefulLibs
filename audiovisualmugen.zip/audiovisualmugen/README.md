# audiovisualmugen

Visor audiovisual Win32 para personajes de M.U.G.E.N, construido sobre una **capa de importación reutilizable**. El ejecutable es sólo un consumidor del importador: el mismo núcleo puede integrarse después en un engine, editor o validador.

## Qué inspecciona

- Abre el `.def` principal de un personaje y resuelve sus rutas relativas.
- **Sprites:** recorre el SFF sprite por sprite, muestra `group,image`, tamaño, eje y profundidad.
- **Animaciones:** recorre todas las acciones AIR, reproduce su timeline a 60 ticks por segundo y permite avanzar elemento por elemento.
- **Vínculo AIR → SFF:** cada elemento busca y muestra el sprite que referencia por `group,image`.
- **Hitboxes:** dibuja `Clsn1` en rojo y `Clsn2` en azul, incluyendo offset, escala y flip horizontal.
- **Sonidos:** recorre el SND, decodifica WAV PCM, Microsoft ADPCM e IMA ADPCM a PCM16, dibuja la forma de onda y reproduce con `waveOut`.
- Abre desde diálogo, argumento de línea de comandos o arrastrando un `.def` a la ventana.
- El front-end GDI pinta toda la interfaz en un backbuffer persistente y presenta el frame terminado con un único `BitBlt`.
- Durante playback conserva el sprite decodificado mientras el `group,image` no cambie; el timeline puede avanzar a 60 ticks sin volver a decodificar el mismo SFF en cada tick.

## Compatibilidad Elecbyte comprobada

La versión 0.1.4 se probó exhaustivamente contra **KFM**, **KFM720**,
**Hokuto**, **ShadowGeist** y **Chonshu**. El corpus adicional expuso rutas que
no aparecían en los personajes mínimos: SFF v1 con miles de sprites,
paletas compartidas por streaming, PCX sin paleta cuyo RLE contiene un falso
marcador `0x0C`, AIR de más de 50 000 líneas y el valor numérico `0` en el
campo de flip.

El importador contempla peculiaridades reales de esos archivos:

- BOM UTF-8 al inicio de `kfm.air`.
- Declaraciones `Clsn1` seguidas por rectángulos etiquetados `Clsn2`; en modo
  compatible manda la declaración y el orden de los N rectángulos, igual que
  al cargar los personajes de referencia.
- El último subarchivo de `kfm.snd` usa un `next_offset` igual al fin del
  archivo en vez de cero.
- Algunos WAV internos terminan con un chunk `data` impar sin byte de relleno.
- PCX v1 sin paleta que contienen por coincidencia `0x0C` exactamente 769 bytes
  antes del final; el decoder valida el final real del RLE antes de considerar
  presente una paleta VGA.
- Paletas compartidas de SFF v1 abiertas por callbacks `read_at`: el propietario
  se resuelve por `same_palette` y la paleta se lee desde la cola del PCX, sin
  cargar el SFF completo.
- SFF de hasta 8192 sprites por defecto; Hokuto contiene 4787.
- AIR grandes: hasta 65535 líneas, 1048576 tokens y 131072 instrucciones
  compiladas por defecto.
- El valor `0` en el campo flip AIR se interpreta como ausencia de flip.

Las recuperaciones AIR válidas no bloquean la carga: se registran como
advertencias mediante `AVM_WARNING_AIR_RECOVERED`.

La división `.def` / `.air` / `.sff` / `.snd`, el vínculo de elementos AIR con sprites y la semántica de `Clsn1`/`Clsn2` siguen la documentación de Elecbyte:

- https://www.elecbyte.com/mugendocs/mugen.html
- https://www.elecbyte.com/mugendocs/air.html
- https://www.elecbyte.com/mugendocs-11b1/air.html

## Restricciones del runtime

El código que se compila en la biblioteca y el visor cumple:

- C89 / `gnu89` estricto.
- Sin `malloc`, `calloc`, `realloc` ni `free`.
- Sin `float` ni `double`.
- Almacenamiento variable entregado por el host o reservado estáticamente.
- Matemática visual y de AIR en enteros / fixed-point Q16.16.
- I/O del importador mediante callbacks; el núcleo no depende de `FILE*` ni de Win32.

Ejecuta la auditoría incluida:

```sh
./scripts/audit_constraints.sh
```

## Arquitectura

```text
┌──────────────────────────────────────────────────────────┐
│ audiovisualmugen.exe                                     │
│ Win32 + GDI doble buffer + waveOut                       │
│ pestañas / navegación / preview / waveform               │
└──────────────────────────┬───────────────────────────────┘
                           │ API pública C89
┌──────────────────────────▼───────────────────────────────┐
│ libaudiovisualmugen.a                                    │
│ avm_character_open / decode_sprite / action_at / sound   │
│ buffers e I/O pertenecen al host                         │
└───────┬──────────────────┬──────────────────┬────────────┘
        │                  │                  │
  defroute89          airdsl_irvm         sff_fixed       sndmuglib
  DEF + rutas         AIR IR/VM + boxes   SFF v1/v2      SND + WAV
```

Consulta `docs/ARCHITECTURE.md` y `docs/IMPORTER_API.md` para la separación completa.

## Compilar Win32 de 32 bits en MSYS2

Abre una terminal **MINGW32**, entra a la carpeta y ejecuta:

```sh
./build_msys2_mingw32.sh
```

También puedes lanzar:

```bat
build_mingw32.bat
```

El script verifica que el target sea `i686-w64-mingw32`, prioriza las
herramientas `gcc` y `ar` del propio shell **MINGW32 portable**, y enlaza el
visor directamente desde los objetos antes de intentar crear la biblioteca.
Siempre genera:

```text
build/win32/audiovisualmugen.exe
build/win32/sample.def
build/win32/sample.air
build/win32/sample.sff
build/win32/sample.snd
```

Cuando `ar` está disponible también genera:

```text
build/win32/libaudiovisualmugen.a
```

Prueba rápida:

```sh
./build/win32/audiovisualmugen.exe ./build/win32/sample.def
```

## Prueba del importador

En Linux o cualquier host POSIX con un compilador C:

```sh
./scripts/build_core_smoke.sh
```

La prueba abre el personaje mínimo incluido y comprueba DEF, SFF, AIR, cajas y
SND. También ejecuta regresiones autocontenidas para BOM, colisiones tolerantes,
flip AIR numérico `0`, terminación SND en EOF, WAV impar sin padding, falsos
marcadores de paleta PCX y paletas SFF compartidas a través de I/O por
callbacks.

Para repetir la prueba exhaustiva con una instalación de M.U.G.E.N:

```sh
./scripts/test_reference_mugen.sh \
  /ruta/mugen/chars/kfm/kfm.def \
  /ruta/mugen/chars/kfm720/kfm720.def \
  /ruta/personajes/Hokuto/Hokuto.def \
  /ruta/personajes/ShadowGeist/ShadowGeist.def \
  /ruta/personajes/Chonshu/Chonshu.def
```

Esa prueba decodifica todos los sprites, recorre todos los elementos de todas
las acciones y abre/decodifica todos los sonidos de cada personaje.

## Controles

| Entrada | Acción |
|---|---|
| `Ctrl+O` | Abrir personaje `.def` |
| `1`, `2`, `3` | Sprites / animaciones / sonidos |
| `←`, `→` | Elemento anterior / siguiente de la lista |
| `[`, `]` | Frame AIR anterior / siguiente |
| `Espacio` | Play/pausa de AIR o reproducir sonido |
| `C`, `V` | Mostrar/ocultar `Clsn1` / `Clsn2` |
| `+`, `-` | Zoom |
| `F5` | Recargar personaje |
| `Esc` | Detener reproducción |

## Memoria estática del visor

Los límites están al principio de `src/win32/audiovisualmugen_win32.c`:

```c
#define AVM_DEF_TEXT_BYTES       65535u
#define AVM_AIR_TEXT_BYTES       (2u * 1024u * 1024u)
#define AVM_AIR_ASSET_BYTES      (12u * 1024u * 1024u)
#define AVM_AIR_SCRATCH_BYTES    (64u * 1024u * 1024u)
#define AVM_SND_ENTRY_COUNT      4096u
#define AVM_SPRITE_MAX_W         2048u
#define AVM_SPRITE_MAX_H         2048u
#define AVM_SPRITE_WORK_BYTES    (16u * 1024u * 1024u)
#define AVM_SOUND_PAYLOAD_BYTES  (8u * 1024u * 1024u)
#define AVM_SOUND_SAMPLE_COUNT   (8u * 1024u * 1024u)
```

Los límites del decoder SFF están en
`third_party/sff_fixed/sff/sff_config.h`:

```c
#define SFF_MAX_SPRITES      8192u
#define SFF_MAX_PALETTES      512u
#define SFF_MAP_CAPACITY    16384u
```

Si un recurso rebasa un límite, la operación devuelve un error de capacidad. No existe un fallback al heap.

## Límites deliberados de esta versión

- El preview GDI doble-buffered muestra transparencia del sprite, escala y flips. Los modos AIR aditivo/sustractivo y la rotación se conservan en el IR, pero el compositor GDI de esta versión todavía no los reproduce fielmente.
- El importador abre SFF y AIR como recursos obligatorios; SND es opcional y produce una advertencia si falta o está dañado.
- Archivos individuales mayores de 4 GiB no son aceptados por la interfaz de I/O de 32 bits.
- El visor no ejecuta CNS/CMD: inspecciona exclusivamente la capa audiovisual del personaje.

## Licencias

El código nuevo de `audiovisualmugen` se entrega bajo CC0. Las dependencias copiadas en `third_party/` conservan sus avisos y condiciones originales. Véase `THIRD_PARTY_NOTICES.md`.
