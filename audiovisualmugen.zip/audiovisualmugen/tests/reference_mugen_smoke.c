#include <stdio.h>
#include <string.h>
#include "audiovisualmugen/audiovisualmugen.h"

#define REF_DEF_BYTES 65535u
#define REF_AIR_BYTES (2u * 1024u * 1024u)
#define REF_ASSET_BYTES (12u * 1024u * 1024u)
#define REF_SCRATCH_BYTES (64u * 1024u * 1024u)
#define REF_SND_ENTRIES 4096u
#define REF_RGBA_BYTES (16u * 1024u * 1024u)
#define REF_WORK_BYTES (16u * 1024u * 1024u)
#define REF_SOUND_BYTES (8u * 1024u * 1024u)
#define REF_PCM_SAMPLES (8u * 1024u * 1024u)

static avm_character g_character;
static char g_def_text[REF_DEF_BYTES];
static char g_air_text[REF_AIR_BYTES];
static avm_u8 g_asset[REF_ASSET_BYTES];
static avm_u8 g_scratch[REF_SCRATCH_BYTES];
static sndmug_entry g_entries[REF_SND_ENTRIES];
static avm_u8 g_rgba[REF_RGBA_BYTES];
static avm_u8 g_work[REF_WORK_BYTES];
static avm_u8 g_sound[REF_SOUND_BYTES];
static wavc89_s16 g_pcm[REF_PCM_SAMPLES];

static avm_file_ref ref_open(void *user, const char *path)
{
    (void)user;
    return (avm_file_ref)fopen(path, "rb");
}

static void ref_close(void *user, avm_file_ref file)
{
    (void)user;
    if (file != 0) fclose((FILE *)file);
}

static int ref_read_at(void *user, avm_file_ref file, avm_u32 offset,
                       void *dst, avm_u32 size, avm_u32 *out_read)
{
    size_t got;
    (void)user;
    if (fseek((FILE *)file, (long)offset, SEEK_SET) != 0) return 0;
    got = fread(dst, 1u, (size_t)size, (FILE *)file);
    *out_read = (avm_u32)got;
    return ferror((FILE *)file) == 0;
}

static int ref_size(void *user, avm_file_ref file, avm_u32 *out_size)
{
    long old_pos;
    long size;
    (void)user;
    old_pos = ftell((FILE *)file);
    if (old_pos < 0) return 0;
    if (fseek((FILE *)file, 0L, SEEK_END) != 0) return 0;
    size = ftell((FILE *)file);
    if (size < 0) return 0;
    if (fseek((FILE *)file, old_pos, SEEK_SET) != 0) return 0;
    *out_size = (avm_u32)size;
    return 1;
}

static int validate_sprites(void)
{
    avm_u32 i;
    avm_u16 w;
    avm_u16 h;
    avm_status status;

    for (i = 0u; i < avm_character_sprite_count(&g_character); ++i) {
        status = avm_character_decode_sprite_rgba(&g_character,
                                                   i,
                                                   g_rgba,
                                                   REF_RGBA_BYTES,
                                                   &w,
                                                   &h,
                                                   g_work,
                                                   REF_WORK_BYTES);
        if (status != AVM_STATUS_OK || w == 0u || h == 0u) {
            printf("sprite decode failed at %lu status=%d size=%ux%u\n",
                   (unsigned long)i, (int)status,
                   (unsigned)w, (unsigned)h);
            return 0;
        }
    }
    return 1;
}

static int validate_actions(void)
{
    avm_u32 i;
    avm_u32 j;
    const air_action *action;
    air_vm_state vm;
    air_pose_sample sample;
    air_diag diag_storage[16];
    air_diag_list diags;
    air_status rc;

    air_diag_list_init(&diags, diag_storage, 16u);
    for (i = 0u; i < avm_character_action_count(&g_character); ++i) {
        action = avm_character_action_at(&g_character, i);
        if (action == 0 || action->elem_count == 0u) {
            printf("invalid action at %lu\n", (unsigned long)i);
            return 0;
        }
        air_diag_list_reset(&diags);
        air_vm_init(&vm, &g_character.air_program_data);
        rc = air_vm_bind_action(&vm, action->action_no, &diags);
        if (rc != AIR_STATUS_OK) {
            printf("action bind failed at %lu action=%ld\n",
                   (unsigned long)i, (long)action->action_no);
            return 0;
        }
        for (j = 0u; j < action->elem_count; ++j) {
            rc = air_vm_step_elem(&vm, &sample, &diags);
            if (rc != AIR_STATUS_OK || sample.elem_index != j) {
                printf("action step failed action=%ld elem=%lu rc=%d got=%lu\n",
                       (long)action->action_no,
                       (unsigned long)j,
                       (int)rc,
                       (unsigned long)sample.elem_index);
                return 0;
            }
            if (sample.clsn1.first + sample.clsn1.count >
                    g_character.air_program_data.rect_count ||
                sample.clsn2.first + sample.clsn2.count >
                    g_character.air_program_data.rect_count) {
                printf("box range failed action=%ld elem=%lu\n",
                       (long)action->action_no, (unsigned long)j);
                return 0;
            }
        }
    }
    return 1;
}

static int validate_playback_timeline(void)
{
    const air_action *action;
    const air_pose_sample *sample;
    avm_u32 tick;
    avm_u32 sprite_index;
    avm_status sprite_status;
    air_status rc;

    action = avm_character_action_at(&g_character, 0u);
    if (action == 0 || action->elem_count == 0u) {
        printf("playback action unavailable\n");
        return 0;
    }
    air_diag_list_reset(&g_character.air_diags);
    rc = air_runtime_set_action(&g_character.air_runtime_data,
                                action->action_no,
                                &g_character.air_diags);
    if (rc != AIR_STATUS_OK) {
        printf("playback bind failed action=%ld rc=%d\n",
               (long)action->action_no, (int)rc);
        return 0;
    }
    for (tick = 0u; tick < 240u; ++tick) {
        sample = air_runtime_get_pose(&g_character.air_runtime_data);
        if (sample == 0) {
            printf("playback pose missing at tick=%lu\n",
                   (unsigned long)tick);
            return 0;
        }
        if (sample->pose.group_no >= 0 && sample->pose.image_no >= 0 &&
            sample->pose.group_no <= 65535 && sample->pose.image_no <= 65535) {
            sprite_status = avm_character_find_sprite(&g_character,
                                                       (avm_u16)sample->pose.group_no,
                                                       (avm_u16)sample->pose.image_no,
                                                       &sprite_index);
            if (sprite_status != AVM_STATUS_OK) {
                printf("playback sprite missing tick=%lu sprite=%ld,%ld\n",
                       (unsigned long)tick,
                       (long)sample->pose.group_no,
                       (long)sample->pose.image_no);
                return 0;
            }
        }
        air_diag_list_reset(&g_character.air_diags);
        rc = air_runtime_step_ticks(&g_character.air_runtime_data,
                                    1,
                                    &g_character.air_diags);
        if (rc != AIR_STATUS_OK) {
            printf("playback step failed tick=%lu rc=%d\n",
                   (unsigned long)tick, (int)rc);
            return 0;
        }
    }
    return 1;
}

static int validate_sounds(void)
{
    avm_u32 i;
    avm_u32 payload_size;
    avm_status status;
    wavc89_io io;
    wavc89_mem_reader mem;
    wavc89_reader reader;
    wavc89_u32 sample_count;
    int rc;

    for (i = 0u; i < avm_character_sound_count(&g_character); ++i) {
        status = avm_character_read_sound_payload(&g_character,
                                                   i,
                                                   g_sound,
                                                   REF_SOUND_BYTES,
                                                   &payload_size);
        if (status != AVM_STATUS_OK || payload_size == 0u) {
            printf("sound read failed at %lu status=%d size=%lu\n",
                   (unsigned long)i, (int)status,
                   (unsigned long)payload_size);
            return 0;
        }
        rc = wavc89_io_mem_reader_init(&io, &mem, g_sound, payload_size);
        if (rc != WAVC89_OK) {
            printf("sound memory I/O failed at %lu rc=%d\n",
                   (unsigned long)i, rc);
            return 0;
        }
        rc = wavc89_reader_open(&reader, &io, 0u, payload_size);
        if (rc != WAVC89_OK) {
            printf("WAV open failed at %lu rc=%d\n",
                   (unsigned long)i, rc);
            return 0;
        }
        sample_count = 0u;
        rc = wavc89_decode_to_s16(&reader.info,
                                  g_sound + reader.info.data_offset,
                                  reader.info.data_size,
                                  g_pcm,
                                  REF_PCM_SAMPLES,
                                  &sample_count);
        if (rc != WAVC89_OK || sample_count == 0u) {
            printf("WAV decode failed at %lu rc=%d samples=%lu\n",
                   (unsigned long)i, rc,
                   (unsigned long)sample_count);
            return 0;
        }
    }
    return 1;
}

int main(int argc, char **argv)
{
    avm_file_api api;
    avm_memory memory;
    avm_report report;
    avm_status status;

    if (argc != 2) {
        printf("usage: reference_mugen_smoke path/to/character.def\n");
        return 2;
    }

    api.open_read = ref_open;
    api.close = ref_close;
    api.read_at = ref_read_at;
    api.get_size = ref_size;
    api.user = 0;

    avm_memory_init(&memory);
    memory.def_text = g_def_text;
    memory.def_text_capacity = REF_DEF_BYTES;
    memory.air_text = g_air_text;
    memory.air_text_capacity = REF_AIR_BYTES;
    memory.air_asset_memory = g_asset;
    memory.air_asset_capacity = REF_ASSET_BYTES;
    memory.air_scratch_memory = g_scratch;
    memory.air_scratch_capacity = REF_SCRATCH_BYTES;
    memory.snd_entries = g_entries;
    memory.snd_entry_capacity = REF_SND_ENTRIES;

    avm_character_init(&g_character);
    status = avm_character_open(&g_character,
                                argv[1],
                                &api,
                                &memory,
                                &report);
    if (status != AVM_STATUS_OK) {
        printf("open failed: %s native=%d\n",
               report.message, report.native_status);
        return 3;
    }

    if (avm_character_sprite_count(&g_character) == 0u ||
        avm_character_action_count(&g_character) == 0u ||
        avm_character_sound_count(&g_character) == 0u) {
        printf("empty asset domain sprites=%lu actions=%lu sounds=%lu\n",
               (unsigned long)avm_character_sprite_count(&g_character),
               (unsigned long)avm_character_action_count(&g_character),
               (unsigned long)avm_character_sound_count(&g_character));
        return 4;
    }

    if (!validate_sprites()) return 5;
    if (!validate_actions()) return 6;
    if (!validate_playback_timeline()) return 7;
    if (!validate_sounds()) return 8;

    printf("reference character ok: sprites=%lu actions=%lu sounds=%lu warnings=0x%08lx\n",
           (unsigned long)avm_character_sprite_count(&g_character),
           (unsigned long)avm_character_action_count(&g_character),
           (unsigned long)avm_character_sound_count(&g_character),
           (unsigned long)report.warning_flags);
    avm_character_close(&g_character);
    return 0;
}
