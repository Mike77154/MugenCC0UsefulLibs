#include <stdio.h>
#include <string.h>
#include "audiovisualmugen/audiovisualmugen.h"

static avm_character g_character;
static char g_def_text[65535];
static char g_air_text[65536];
static unsigned char g_asset[1024 * 1024];
static unsigned char g_scratch[2 * 1024 * 1024];
static sndmug_entry g_entries[64];
static unsigned char g_rgba[16];
static unsigned char g_work[4096];
static unsigned char g_sound[16384];
static wavc89_s16 g_pcm[16384];

static avm_file_ref test_open(void *user, const char *path)
{
    (void)user;
    return (avm_file_ref)fopen(path, "rb");
}

static void test_close(void *user, avm_file_ref file)
{
    (void)user;
    if (file != 0) fclose((FILE *)file);
}

static int test_read_at(void *user, avm_file_ref file, avm_u32 offset,
                        void *dst, avm_u32 size, avm_u32 *out_read)
{
    size_t got;
    (void)user;
    if (fseek((FILE *)file, (long)offset, SEEK_SET) != 0) return 0;
    got = fread(dst, 1u, (size_t)size, (FILE *)file);
    *out_read = (avm_u32)got;
    return ferror((FILE *)file) == 0;
}

static int test_size(void *user, avm_file_ref file, avm_u32 *out_size)
{
    long old_pos;
    long size;
    (void)user;
    old_pos = ftell((FILE *)file);
    if (old_pos < 0) return 0;
    if (fseek((FILE *)file, 0L, SEEK_END) != 0) return 0;
    size = ftell((FILE *)file);
    if (size < 0) return 0;
    if (fseek((FILE *)file, old_pos, SEEK_SET) != 0) return 0;
    *out_size = (avm_u32)size;
    return 1;
}

int main(int argc, char **argv)
{
    avm_file_api api;
    avm_memory memory;
    avm_report report;
    avm_status status;
    avm_u16 w;
    avm_u16 h;
    avm_u32 payload_size;
    avm_u32 sprite_index;
    avm_u32 action_index;
    avm_u32 sound_index;
    SffSpriteInfo sprite_info;
    const air_action *action;
    air_vm_state vm;
    air_pose_sample sample;
    air_diag diag_storage[8];
    air_diag_list diags;
    air_status air_rc;
    wavc89_io wav_io;
    wavc89_mem_reader wav_mem;
    wavc89_reader wav_reader;
    wavc89_u32 pcm_count;
    int wav_rc;

    if (argc != 2) {
        printf("usage: integration_smoke sample.def\n");
        return 2;
    }

    api.open_read = test_open;
    api.close = test_close;
    api.read_at = test_read_at;
    api.get_size = test_size;
    api.user = 0;

    avm_memory_init(&memory);
    memory.def_text = g_def_text;
    memory.def_text_capacity = sizeof(g_def_text);
    memory.air_text = g_air_text;
    memory.air_text_capacity = sizeof(g_air_text);
    memory.air_asset_memory = g_asset;
    memory.air_asset_capacity = sizeof(g_asset);
    memory.air_scratch_memory = g_scratch;
    memory.air_scratch_capacity = sizeof(g_scratch);
    memory.snd_entries = g_entries;
    memory.snd_entry_capacity = 64u;

    avm_character_init(&g_character);
    status = avm_character_open(&g_character, argv[1], &api, &memory, &report);
    if (status != AVM_STATUS_OK) {
        printf("open failed: %s native=%d\n", report.message, report.native_status);
        return 3;
    }
    if (avm_character_sprite_count(&g_character) != 1u) {
        printf("unexpected sprite count\n");
        return 4;
    }
    if (avm_character_action_count(&g_character) != 2u) {
        printf("unexpected action count: %lu\n",
               (unsigned long)avm_character_action_count(&g_character));
        return 5;
    }
    if (avm_character_sound_count(&g_character) != 1u) {
        printf("unexpected sound count\n");
        return 6;
    }
    status = avm_character_decode_sprite_rgba(&g_character, 0u,
                                               g_rgba, sizeof(g_rgba),
                                               &w, &h,
                                               g_work, sizeof(g_work));
    if (status != AVM_STATUS_OK || w != 1u || h != 1u) {
        printf("sprite decode failed status=%d w=%u h=%u\n",
               (int)status, (unsigned)w, (unsigned)h);
        return 7;
    }
    status = avm_character_sprite_info(&g_character, 0u, &sprite_info);
    if (status != AVM_STATUS_OK || sprite_info.group != 0u ||
        sprite_info.item != 0u) {
        printf("sprite info failed\n");
        return 8;
    }
    status = avm_character_find_sprite(&g_character, 0u, 0u, &sprite_index);
    if (status != AVM_STATUS_OK || sprite_index != 0u) {
        printf("sprite lookup failed\n");
        return 9;
    }
    status = avm_character_find_action(&g_character, 200, &action_index);
    if (status != AVM_STATUS_OK || action_index != 1u) {
        printf("action lookup failed\n");
        return 10;
    }
    status = avm_character_find_sound(&g_character, 0u, 0u, &sound_index);
    if (status != AVM_STATUS_OK || sound_index != 0u) {
        printf("sound lookup failed\n");
        return 11;
    }
    action = avm_character_action_at(&g_character, action_index);
    if (action == 0 || action->action_no != 200 || action->elem_count != 3u) {
        printf("action mapping failed\n");
        return 12;
    }
    air_diag_list_init(&diags, diag_storage, 8u);
    air_vm_init(&vm, &g_character.air_program_data);
    air_rc = air_vm_bind_action(&vm, 200, &diags);
    if (air_rc != AIR_STATUS_OK) {
        printf("action bind failed\n");
        return 13;
    }
    air_rc = air_vm_step_elem(&vm, &sample, &diags);
    if (air_rc != AIR_STATUS_OK || sample.elem_index != 0u ||
        sample.clsn1.count != 1u || sample.clsn2.count != 1u) {
        printf("AIR box/sample mapping failed\n");
        return 14;
    }
    status = avm_character_read_sound_payload(&g_character, 0u,
                                               g_sound, sizeof(g_sound),
                                               &payload_size);
    if (status != AVM_STATUS_OK || payload_size == 0u) {
        printf("sound payload read failed\n");
        return 15;
    }
    wav_rc = wavc89_io_mem_reader_init(&wav_io, &wav_mem,
                                       g_sound, payload_size);
    if (wav_rc != WAVC89_OK) {
        printf("WAV memory I/O failed\n");
        return 16;
    }
    wav_rc = wavc89_reader_open(&wav_reader, &wav_io, 0u, payload_size);
    if (wav_rc != WAVC89_OK) {
        printf("WAV open failed\n");
        return 17;
    }
    pcm_count = 0u;
    wav_rc = wavc89_decode_to_s16(&wav_reader.info,
                                  g_sound + wav_reader.info.data_offset,
                                  wav_reader.info.data_size,
                                  g_pcm,
                                  16384u,
                                  &pcm_count);
    if (wav_rc != WAVC89_OK || pcm_count == 0u) {
        printf("WAV decode failed\n");
        return 18;
    }

    avm_character_close(&g_character);
    printf("audiovisualmugen integration smoke: ok\n");
    return 0;
}
