#include <stdio.h>
#include <string.h>
#include "air/air_api.h"
#include "sndmug/sndmug.h"
#include "sff_api.h"
#include "sff_pcx.h"

static unsigned char g_air_asset[65536];
static unsigned char g_air_scratch[131072];
static air_diag g_air_diag_storage[16];
static unsigned char g_snd[573];
static sndmug_entry g_entry[1];
static unsigned char g_payload[45];
static wavc89_s16 g_pcm[8];
static unsigned char g_pcx_no_palette[1028];
static unsigned char g_pcx_with_palette[1797];
static unsigned char g_pcx_pixels[900];
static unsigned char g_pcx_palette[768];
static unsigned char g_stream_sff[2048];
static unsigned char g_stream_rgba_memory[8];
static unsigned char g_stream_rgba_io[8];
static unsigned char g_stream_work_memory[2048];
static unsigned char g_stream_work_io[2048];
static SffFile g_stream_file_memory;
static SffFile g_stream_file_io;

static void put_le16(unsigned char *p, unsigned long value)
{
    p[0] = (unsigned char)(value & 255u);
    p[1] = (unsigned char)((value >> 8) & 255u);
}

static void put_le32(unsigned char *p, unsigned long value)
{
    p[0] = (unsigned char)(value & 255u);
    p[1] = (unsigned char)((value >> 8) & 255u);
    p[2] = (unsigned char)((value >> 16) & 255u);
    p[3] = (unsigned char)((value >> 24) & 255u);
}

typedef struct test_sff_io_tag {
    const unsigned char *data;
    sff_u32 size;
} test_sff_io;

static int test_sff_read_at(void *user, sff_u32 offset, void *dst, sff_u32 size)
{
    test_sff_io *io;
    io = (test_sff_io *)user;
    if (io == 0 || dst == 0) return 0;
    if (offset > io->size || size > io->size - offset) return 0;
    memcpy(dst, io->data + offset, (size_t)size);
    return 1;
}

static void build_pcx_header(unsigned char *pcx, unsigned long width,
                             unsigned long height)
{
    memset(pcx, 0, 128u);
    pcx[0] = 0x0Au;
    pcx[1] = 5u;
    pcx[2] = 1u;
    pcx[3] = 8u;
    put_le16(pcx + 8u, width - 1u);
    put_le16(pcx + 10u, height - 1u);
    put_le16(pcx + 12u, width);
    put_le16(pcx + 14u, height);
    pcx[65] = 1u;
    put_le16(pcx + 66u, width);
    put_le16(pcx + 68u, 1u);
}

static int test_pcx_false_palette_marker(void)
{
    unsigned long i;
    unsigned long marker;
    sff_u16 w;
    sff_u16 h;
    int has_palette;

    build_pcx_header(g_pcx_no_palette, 900u, 1u);
    for (i = 0u; i < 900u; ++i) {
        g_pcx_no_palette[128u + i] = (unsigned char)(i & 0x7Fu);
    }
    marker = sizeof(g_pcx_no_palette) - 769u;
    g_pcx_no_palette[marker] = 12u;

    if (sff_pcx_has_palette(g_pcx_no_palette,
                            (sff_u32)sizeof(g_pcx_no_palette))) {
        printf("PCX false palette marker was accepted\n");
        return 0;
    }
    has_palette = 1;
    if (!sff_pcx_decode_8bpp_into(g_pcx_no_palette,
                                  (sff_u32)sizeof(g_pcx_no_palette),
                                  g_pcx_pixels,
                                  (sff_u32)sizeof(g_pcx_pixels),
                                  &w, &h,
                                  g_pcx_palette,
                                  &has_palette) ||
        w != 900u || h != 1u || has_palette != 0) {
        printf("PCX palette-less decode regression\n");
        return 0;
    }

    memcpy(g_pcx_with_palette, g_pcx_no_palette,
           sizeof(g_pcx_no_palette));
    g_pcx_with_palette[sizeof(g_pcx_no_palette)] = 12u;
    memset(g_pcx_with_palette + sizeof(g_pcx_no_palette) + 1u,
           0, 768u);
    g_pcx_with_palette[sizeof(g_pcx_no_palette) + 1u + 3u] = 10u;
    g_pcx_with_palette[sizeof(g_pcx_no_palette) + 1u + 4u] = 20u;
    g_pcx_with_palette[sizeof(g_pcx_no_palette) + 1u + 5u] = 30u;

    if (!sff_pcx_has_palette(g_pcx_with_palette,
                             (sff_u32)sizeof(g_pcx_with_palette))) {
        printf("PCX real palette was not detected\n");
        return 0;
    }
    has_palette = 0;
    if (!sff_pcx_decode_8bpp_into(g_pcx_with_palette,
                                  (sff_u32)sizeof(g_pcx_with_palette),
                                  g_pcx_pixels,
                                  (sff_u32)sizeof(g_pcx_pixels),
                                  &w, &h,
                                  g_pcx_palette,
                                  &has_palette) ||
        has_palette != 1 || g_pcx_palette[3] != 10u ||
        g_pcx_palette[4] != 20u || g_pcx_palette[5] != 30u) {
        printf("PCX real palette decode regression\n");
        return 0;
    }
    return 1;
}

static unsigned long build_small_pcx(unsigned char *pcx, int with_palette)
{
    unsigned long len;
    build_pcx_header(pcx, 2u, 1u);
    pcx[128] = 1u;
    pcx[129] = 2u;
    len = 130u;
    if (with_palette) {
        unsigned char *pal;
        pcx[len++] = 12u;
        pal = pcx + len;
        memset(pal, 0, 768u);
        pal[3] = 10u;
        pal[4] = 20u;
        pal[5] = 30u;
        pal[6] = 40u;
        pal[7] = 50u;
        pal[8] = 60u;
        len += 768u;
    }
    return len;
}

static unsigned long build_stream_sff(void)
{
    unsigned long first_off;
    unsigned long second_off;
    unsigned long first_len;
    unsigned long second_len;
    unsigned char *sub;

    memset(g_stream_sff, 0, sizeof(g_stream_sff));
    memcpy(g_stream_sff, "ElecbyteSpr", 11u);
    g_stream_sff[12] = 0u;
    g_stream_sff[13] = 1u;
    g_stream_sff[14] = 0u;
    g_stream_sff[15] = 1u;
    put_le32(g_stream_sff + 16u, 1u);
    put_le32(g_stream_sff + 20u, 2u);
    put_le32(g_stream_sff + 24u, 512u);
    put_le32(g_stream_sff + 28u, 32u);
    g_stream_sff[32] = 1u;

    first_off = 512u;
    first_len = build_small_pcx(g_stream_sff + first_off + 32u, 1);
    second_off = first_off + 32u + first_len;
    second_len = build_small_pcx(g_stream_sff + second_off + 32u, 0);

    sub = g_stream_sff + first_off;
    put_le32(sub + 0u, second_off);
    put_le32(sub + 4u, first_len);
    put_le16(sub + 12u, 0u);
    put_le16(sub + 14u, 0u);
    put_le16(sub + 16u, 0u);
    sub[18] = 0u;

    sub = g_stream_sff + second_off;
    put_le32(sub + 0u, 0u);
    put_le32(sub + 4u, second_len);
    put_le16(sub + 12u, 0u);
    put_le16(sub + 14u, 1u);
    put_le16(sub + 16u, 0u);
    sub[18] = 1u;

    return second_off + 32u + second_len;
}

static int test_sff_streamed_shared_palette(void)
{
    unsigned long size;
    SffOpenOptions opts;
    SffIo io_api;
    test_sff_io io;
    sff_u16 w;
    sff_u16 h;
    int rc;

    size = build_stream_sff();
    opts.tolerant = 1;
    opts.codec = 0;

    rc = sff_open_memory(&g_stream_file_memory,
                         g_stream_sff, (sff_u32)size, &opts);
    if (rc != SFF_OK) {
        printf("SFF memory fixture open failed rc=%d\n", rc);
        return 0;
    }

    io.data = g_stream_sff;
    io.size = (sff_u32)size;
    io_api.read_at = test_sff_read_at;
    io_api.user = &io;
    io_api.size = (sff_u32)size;
    rc = sff_open_io(&g_stream_file_io, &io_api, &opts);
    if (rc != SFF_OK) {
        printf("SFF streamed fixture open failed rc=%d\n", rc);
        return 0;
    }

    rc = sff_decode_sprite_rgba_into(&g_stream_file_memory, 1u,
                                     g_stream_rgba_memory,
                                     (sff_u32)sizeof(g_stream_rgba_memory),
                                     &w, &h,
                                     g_stream_work_memory,
                                     (sff_u32)sizeof(g_stream_work_memory));
    if (rc != SFF_OK || w != 2u || h != 1u) {
        printf("SFF memory shared-palette decode failed rc=%d\n", rc);
        return 0;
    }
    rc = sff_decode_sprite_rgba_into(&g_stream_file_io, 1u,
                                     g_stream_rgba_io,
                                     (sff_u32)sizeof(g_stream_rgba_io),
                                     &w, &h,
                                     g_stream_work_io,
                                     (sff_u32)sizeof(g_stream_work_io));
    if (rc != SFF_OK || memcmp(g_stream_rgba_memory,
                               g_stream_rgba_io,
                               sizeof(g_stream_rgba_io)) != 0) {
        printf("SFF streamed shared-palette mismatch rc=%d\n", rc);
        return 0;
    }
    if (g_stream_rgba_io[0] != 10u || g_stream_rgba_io[1] != 20u ||
        g_stream_rgba_io[2] != 30u || g_stream_rgba_io[3] != 255u ||
        g_stream_rgba_io[4] != 40u || g_stream_rgba_io[5] != 50u ||
        g_stream_rgba_io[6] != 60u || g_stream_rgba_io[7] != 255u) {
        printf("SFF streamed shared-palette colors are wrong\n");
        return 0;
    }
    return 1;
}

static int test_air_compatibility(void)
{
    static const char text[] =
        "\xEF\xBB\xBF; UTF-8 BOM like Elecbyte KFM\n"
        "[Begin Action 0]\n"
        "Clsn1: 1\n"
        " Clsn2[0] = -10,-20,10,0\n"
        "0,0,0,0,1,0\n";
    air_arena asset_arena;
    air_arena scratch_arena;
    air_program program;
    air_diag_list diags;
    air_build_options opts;
    air_vm_state vm;
    air_pose_sample sample;
    air_status rc;

    air_arena_init(&asset_arena, g_air_asset, sizeof(g_air_asset));
    air_arena_init(&scratch_arena, g_air_scratch, sizeof(g_air_scratch));
    air_program_zero(&program);
    air_diag_list_init(&diags, g_air_diag_storage, 16u);
    air_build_options_default(&opts);
    opts.parse.permissive = AIR_TRUE;

    rc = air_program_build_from_text(&program,
                                     &asset_arena,
                                     &scratch_arena,
                                     text,
                                     (air_u32)(sizeof(text) - 1u),
                                     &opts,
                                     &diags);
    if (rc != AIR_STATUS_OK || program.action_count != 1u ||
        diags.error_count != 0u || diags.warning_count != 1u) {
        printf("AIR compatibility parse failed rc=%d actions=%lu errors=%u warnings=%u\n",
               (int)rc,
               (unsigned long)program.action_count,
               (unsigned)diags.error_count,
               (unsigned)diags.warning_count);
        return 0;
    }

    air_diag_list_reset(&diags);
    air_vm_init(&vm, &program);
    rc = air_vm_bind_action(&vm, 0, &diags);
    if (rc != AIR_STATUS_OK) return 0;
    rc = air_vm_step_elem(&vm, &sample, &diags);
    if (rc != AIR_STATUS_OK || sample.clsn1.count != 1u ||
        sample.clsn2.count != 0u) {
        printf("AIR declaration-owned collision recovery failed\n");
        return 0;
    }
    return 1;
}

static void build_reference_style_snd(void)
{
    unsigned char *sub;
    unsigned char *wav;

    memset(g_snd, 0, sizeof(g_snd));
    memcpy(g_snd, "ElecbyteSnd\0", 12u);
    g_snd[12] = 1u;
    put_le32(g_snd + 16, 1u);
    put_le32(g_snd + 20, 512u);

    sub = g_snd + 512u;
    put_le32(sub + 0, (unsigned long)sizeof(g_snd));
    put_le32(sub + 4, 45u);
    put_le32(sub + 8, 0u);
    put_le32(sub + 12, 0u);

    wav = sub + 16u;
    memcpy(wav + 0, "RIFF", 4u);
    put_le32(wav + 4, 37u);
    memcpy(wav + 8, "WAVE", 4u);
    memcpy(wav + 12, "fmt ", 4u);
    put_le32(wav + 16, 16u);
    put_le16(wav + 20, 1u);
    put_le16(wav + 22, 1u);
    put_le32(wav + 24, 8000u);
    put_le32(wav + 28, 8000u);
    put_le16(wav + 32, 1u);
    put_le16(wav + 34, 8u);
    memcpy(wav + 36, "data", 4u);
    put_le32(wav + 40, 1u);
    wav[44] = 128u;
}

static int test_snd_wav_compatibility(void)
{
    sndmug_io snd_io;
    sndmug_mem_reader snd_mem;
    sndmug_reader snd_reader;
    sndmug_u32 payload_size;
    wavc89_io wav_io;
    wavc89_mem_reader wav_mem;
    wavc89_reader wav_reader;
    wavc89_u32 sample_count;
    int rc;

    build_reference_style_snd();
    rc = sndmug_io_mem_reader_init(&snd_io, &snd_mem,
                                   g_snd, (sndmug_u32)sizeof(g_snd));
    if (rc != SNDMUG_OK) return 0;
    rc = sndmug_reader_open(&snd_reader, &snd_io, g_entry, 1u);
    if (rc != SNDMUG_OK || snd_reader.entry_count != 1u) {
        printf("SND EOF-sentinel compatibility failed rc=%d count=%lu\n",
               rc, (unsigned long)snd_reader.entry_count);
        return 0;
    }
    payload_size = 0u;
    rc = sndmug_reader_read_payload(&snd_reader, 0u,
                                    g_payload, sizeof(g_payload),
                                    &payload_size);
    if (rc != SNDMUG_OK || payload_size != sizeof(g_payload)) return 0;

    rc = wavc89_io_mem_reader_init(&wav_io, &wav_mem,
                                   g_payload, payload_size);
    if (rc != WAVC89_OK) return 0;
    rc = wavc89_reader_open(&wav_reader, &wav_io, 0u, payload_size);
    if (rc != WAVC89_OK) {
        printf("WAV missing-final-pad compatibility failed rc=%d\n", rc);
        return 0;
    }
    sample_count = 0u;
    rc = wavc89_decode_to_s16(&wav_reader.info,
                              g_payload + wav_reader.info.data_offset,
                              wav_reader.info.data_size,
                              g_pcm,
                              8u,
                              &sample_count);
    if (rc != WAVC89_OK || sample_count != 1u) {
        printf("WAV compatibility decode failed rc=%d samples=%lu\n",
               rc, (unsigned long)sample_count);
        return 0;
    }
    return 1;
}

int main(void)
{
    if (!test_air_compatibility()) return 2;
    if (!test_snd_wav_compatibility()) return 3;
    if (!test_pcx_false_palette_marker()) return 4;
    if (!test_sff_streamed_shared_palette()) return 5;
    printf("audiovisualmugen compatibility smoke: ok\n");
    return 0;
}
