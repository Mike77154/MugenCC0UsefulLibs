#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
. scripts/source_lists.sh

compiler_target() {
    "$1" -dumpmachine 2>/dev/null || true
}

is_mingw32_compiler() {
    local candidate="$1"
    local target

    if ! command -v "$candidate" >/dev/null 2>&1 && [ ! -x "$candidate" ]; then
        return 1
    fi

    target="$(compiler_target "$candidate")"
    case "$target" in
        i?86-w64-mingw32*) return 0 ;;
        *) return 1 ;;
    esac
}

# In an MSYS2 MINGW32 shell the native tools are normally named gcc/ar.
# Prefer those over /usr/bin/i686-w64-mingw32-* cross tools so portable
# installations do not accidentally mix two different toolchain layouts.
if [ -n "${CC:-}" ]; then
    if ! is_mingw32_compiler "$CC"; then
        echo "error: CC='$CC' is unavailable or is not a 32-bit MinGW compiler." >&2
        exit 1
    fi
elif is_mingw32_compiler gcc; then
    CC="gcc"
elif is_mingw32_compiler i686-w64-mingw32-gcc; then
    CC="i686-w64-mingw32-gcc"
else
    echo "error: no 32-bit MinGW C compiler found." >&2
    echo "Open the portable MSYS2 MINGW32 shell, not MSYS or MINGW64." >&2
    exit 1
fi

TARGET="$(compiler_target "$CC")"

resolve_tool() {
    local candidate="$1"

    [ -n "$candidate" ] || return 1
    case "$candidate" in
        */*|*\\*)
            [ -x "$candidate" ] && printf '%s\n' "$candidate" && return 0
            ;;
        *)
            command -v "$candidate" 2>/dev/null && return 0
            ;;
    esac
    return 1
}

find_archiver() {
    local requested="${AR:-}"
    local cc_path
    local cc_dir
    local printed
    local candidate
    local resolved

    if [ -n "$requested" ]; then
        resolved="$(resolve_tool "$requested" || true)"
        if [ -z "$resolved" ]; then
            echo "warning: requested AR='$requested' was not found." >&2
        else
            printf '%s\n' "$resolved"
            return 0
        fi
    fi

    cc_path="$(command -v "$CC" 2>/dev/null || true)"
    if [ -n "$cc_path" ]; then
        cc_dir="$(cd "$(dirname "$cc_path")" 2>/dev/null && pwd || true)"
    else
        cc_dir=""
    fi

    printed="$("$CC" -print-prog-name=ar 2>/dev/null || true)"

    # First prefer the native MINGW32 names found through PATH. This is the
    # common layout used by portable MSYS2 distributions.
    for candidate in ar gcc-ar \
        "$cc_dir/ar.exe" "$cc_dir/ar" \
        "$cc_dir/gcc-ar.exe" "$cc_dir/gcc-ar" \
        "$printed" i686-w64-mingw32-ar; do
        resolved="$(resolve_tool "$candidate" || true)"
        if [ -n "$resolved" ]; then
            printf '%s\n' "$resolved"
            return 0
        fi
    done

    return 1
}

AR_TOOL="$(find_archiver || true)"

OUT="build/win32"
OBJ="$OUT/obj"
rm -rf "$OBJ"
mkdir -p "$OBJ"

CFLAGS="${CFLAGS:--O2 -std=gnu89 -pedantic -Wall -Wextra -Werror -fno-strict-aliasing}"
LDFLAGS="${LDFLAGS:--mwindows -static-libgcc}"

echo "Toolchain: CC=$CC"
echo "Target:    $TARGET"
if [ -n "$AR_TOOL" ]; then
    echo "Archiver:  $AR_TOOL"
else
    echo "Archiver:  unavailable; EXE will still be linked directly" >&2
fi
echo

compile_one() {
    local source="$1"
    local object="$OBJ/${source%.c}.o"
    mkdir -p "$(dirname "$object")"
    echo "CC  $source"
    # Intentional splitting: flags and include paths are compiler arguments.
    # shellcheck disable=SC2086
    "$CC" $CFLAGS $AVM_INCLUDE_FLAGS -c "$source" -o "$object"
}

CORE_OBJECTS=""
for source in $AVM_CORE_SOURCES; do
    compile_one "$source"
    CORE_OBJECTS="$CORE_OBJECTS $OBJ/${source%.c}.o"
done

WIN32_OBJECTS=""
for source in $AVM_WIN32_SOURCES; do
    compile_one "$source"
    WIN32_OBJECTS="$WIN32_OBJECTS $OBJ/${source%.c}.o"
done

# Link the application directly from all object files. The executable no
# longer depends on the optional static-library archive step succeeding.
echo "LD  $OUT/audiovisualmugen.exe"
# Intentional splitting: object and linker flag lists are compiler arguments.
# shellcheck disable=SC2086
"$CC" $LDFLAGS -o "$OUT/audiovisualmugen.exe" \
    $WIN32_OBJECTS $CORE_OBJECTS \
    -lgdi32 -lcomdlg32 -lshell32 -lwinmm

LIB_BUILT=0
if [ -n "$AR_TOOL" ]; then
    echo "AR  $OUT/libaudiovisualmugen.a"
    # Intentional splitting: object list is generated from trusted paths.
    # shellcheck disable=SC2086
    if "$AR_TOOL" rcs "$OUT/libaudiovisualmugen.a" $CORE_OBJECTS; then
        LIB_BUILT=1
    else
        echo "warning: static library creation failed; the EXE was built successfully." >&2
        rm -f "$OUT/libaudiovisualmugen.a"
    fi
else
    rm -f "$OUT/libaudiovisualmugen.a"
    echo "warning: install/provide 'ar' to also generate libaudiovisualmugen.a." >&2
fi

cp -f examples/sample_char/sample.def "$OUT/sample.def"
cp -f examples/sample_char/sample.air "$OUT/sample.air"
cp -f examples/sample_char/sample.sff "$OUT/sample.sff"
cp -f examples/sample_char/sample.snd "$OUT/sample.snd"

if [ ! -s "$OUT/audiovisualmugen.exe" ]; then
    echo "error: linker returned success but no executable was produced." >&2
    exit 1
fi

echo
echo "Built: $OUT/audiovisualmugen.exe"
if [ "$LIB_BUILT" -eq 1 ]; then
    echo "Built: $OUT/libaudiovisualmugen.a"
else
    echo "Skipped: $OUT/libaudiovisualmugen.a (archiver unavailable)"
fi
echo "Try:   $OUT/audiovisualmugen.exe $OUT/sample.def"
