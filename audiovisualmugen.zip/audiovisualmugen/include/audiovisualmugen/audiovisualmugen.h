#ifndef AUDIOVISUALMUGEN_H
#define AUDIOVISUALMUGEN_H

/* audiovisualmugen - reusable M.U.G.E.N character audiovisual importer.
   C89, no malloc/realloc/free, integer/fixed-point only.
   All variable-sized storage and all file handles are caller/host owned. */

#include <stddef.h>
#include <limits.h>
#include "cfg_parser.h"
#include "mugen_char_def.h"
#include "sff_api.h"
#include "air/air_api.h"
#include "sndmug/sndmug.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AVM_VERSION_MAJOR 0
#define AVM_VERSION_MINOR 1
#define AVM_VERSION_PATCH 4

#define AVM_WARNING_SND_PARSE_FAILED 0x00000001u
#define AVM_WARNING_SND_OPEN_FAILED  0x00000002u
#define AVM_WARNING_AIR_RECOVERED    0x00000004u
#define AVM_WARNING_DEF_SHIFT        8u

#ifndef AVM_PATH_CAPACITY
#define AVM_PATH_CAPACITY 1024u
#endif

#ifndef AVM_NAME_CAPACITY
#define AVM_NAME_CAPACITY 256u
#endif

#ifndef AVM_REPORT_CAPACITY
#define AVM_REPORT_CAPACITY 512u
#endif

typedef unsigned char avm_u8;
typedef signed char avm_s8;
typedef unsigned short avm_u16;
typedef signed short avm_s16;
#if UINT_MAX == 0xFFFFFFFFu
typedef unsigned int avm_u32;
typedef signed int avm_s32;
#else
typedef unsigned long avm_u32;
typedef signed long avm_s32;
#endif

typedef void *avm_file_ref;

typedef struct avm_file_api_tag {
    avm_file_ref (*open_read)(void *user, const char *path);
    void (*close)(void *user, avm_file_ref file);
    int (*read_at)(void *user, avm_file_ref file, avm_u32 offset,
                   void *dst, avm_u32 size, avm_u32 *out_read);
    int (*get_size)(void *user, avm_file_ref file, avm_u32 *out_size);
    void *user;
} avm_file_api;

typedef enum avm_status_tag {
    AVM_STATUS_OK = 0,
    AVM_STATUS_BAD_ARGUMENT = -1,
    AVM_STATUS_OPEN_DEF_FAILED = -2,
    AVM_STATUS_DEF_TOO_LARGE = -3,
    AVM_STATUS_DEF_READ_FAILED = -4,
    AVM_STATUS_DEF_PARSE_FAILED = -5,
    AVM_STATUS_DEF_MISSING_SPRITE = -6,
    AVM_STATUS_DEF_MISSING_ANIM = -7,
    AVM_STATUS_OPEN_SFF_FAILED = -8,
    AVM_STATUS_SFF_PARSE_FAILED = -9,
    AVM_STATUS_OPEN_AIR_FAILED = -10,
    AVM_STATUS_AIR_TOO_LARGE = -11,
    AVM_STATUS_AIR_READ_FAILED = -12,
    AVM_STATUS_AIR_COMPILE_FAILED = -13,
    AVM_STATUS_OPEN_SND_FAILED = -14,
    AVM_STATUS_SND_PARSE_FAILED = -15,
    AVM_STATUS_CAPACITY = -16,
    AVM_STATUS_NOT_LOADED = -17,
    AVM_STATUS_NOT_FOUND = -18,
    AVM_STATUS_DECODE_FAILED = -19
} avm_status;

typedef struct avm_memory_tag {
    char *def_text;
    avm_u32 def_text_capacity;
    char *air_text;
    avm_u32 air_text_capacity;
    void *air_asset_memory;
    avm_u32 air_asset_capacity;
    void *air_scratch_memory;
    avm_u32 air_scratch_capacity;
    sndmug_entry *snd_entries;
    avm_u32 snd_entry_capacity;
} avm_memory;

typedef struct avm_file_state_tag {
    const avm_file_api *api;
    avm_file_ref ref;
    avm_u32 size;
    avm_u32 pos;
} avm_file_state;

typedef struct avm_report_tag {
    avm_status status;
    int native_status;
    avm_u32 warning_flags;
    char message[AVM_REPORT_CAPACITY];
} avm_report;

typedef struct avm_character_tag {
    const avm_file_api *file_api;
    avm_memory memory;

    char def_path[AVM_PATH_CAPACITY];
    char sprite_path[AVM_PATH_CAPACITY];
    char anim_path[AVM_PATH_CAPACITY];
    char sound_path[AVM_PATH_CAPACITY];
    char name[AVM_NAME_CAPACITY];
    char display_name[AVM_NAME_CAPACITY];
    char author[AVM_NAME_CAPACITY];

    cfg_document def_document;
    mugen_char_def def_character;

    avm_file_state sff_file;
    SffIo sff_io;
    SffFile sff;

    air_arena air_asset_arena;
    air_arena air_scratch_arena;
    air_program air_program_data;
    air_diag air_diag_storage[AIR_MAX_DIAGS];
    air_diag_list air_diags;
    air_runtime air_runtime_data;

    avm_file_state snd_file;
    sndmug_io snd_io;
    sndmug_reader snd;

    avm_u32 def_text_size;
    avm_u32 air_text_size;
    int has_sff;
    int has_air;
    int has_snd;
    int loaded;
} avm_character;

void avm_memory_init(avm_memory *memory);
void avm_report_clear(avm_report *report);
const char *avm_status_string(avm_status status);

void avm_character_init(avm_character *character);
void avm_character_close(avm_character *character);
avm_status avm_character_open(avm_character *character,
                              const char *def_path,
                              const avm_file_api *file_api,
                              const avm_memory *memory,
                              avm_report *report);

avm_u32 avm_character_sprite_count(const avm_character *character);
avm_u32 avm_character_action_count(const avm_character *character);
avm_u32 avm_character_sound_count(const avm_character *character);

avm_status avm_character_decode_sprite_rgba(const avm_character *character,
                                            avm_u32 sprite_index,
                                            avm_u8 *rgba,
                                            avm_u32 rgba_capacity,
                                            avm_u16 *out_w,
                                            avm_u16 *out_h,
                                            avm_u8 *work,
                                            avm_u32 work_capacity);

avm_status avm_character_sprite_info(const avm_character *character,
                                     avm_u32 sprite_index,
                                     SffSpriteInfo *out_info);
avm_status avm_character_find_sprite(const avm_character *character,
                                     avm_u16 group_no,
                                     avm_u16 image_no,
                                     avm_u32 *out_index);
avm_status avm_character_find_action(const avm_character *character,
                                     avm_s32 action_no,
                                     avm_u32 *out_index);
avm_status avm_character_find_sound(const avm_character *character,
                                    avm_u32 group_no,
                                    avm_u32 sound_no,
                                    avm_u32 *out_index);

const air_action *avm_character_action_at(const avm_character *character,
                                          avm_u32 action_index);
const sndmug_entry *avm_character_sound_at(const avm_character *character,
                                           avm_u32 sound_index);

avm_status avm_character_read_sound_payload(const avm_character *character,
                                            avm_u32 sound_index,
                                            void *dst,
                                            avm_u32 capacity,
                                            avm_u32 *out_size);

#ifdef __cplusplus
}
#endif

#endif /* AUDIOVISUALMUGEN_H */
