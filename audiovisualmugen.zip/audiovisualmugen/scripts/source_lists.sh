# Shared source lists for audiovisualmugen build scripts.
# This file is sourced by Bash; it is not part of the runtime.

AVM_INCLUDE_FLAGS="\
-Iinclude \
-Ithird_party/defroute89/include \
-Ithird_party/airdsl_irvm/include \
-Ithird_party/sff_fixed/sff \
-Ithird_party/sff_fixed/sublibs/pcx89 \
-Ithird_party/sff_fixed/sublibs/png89 \
-Ithird_party/sff_fixed/sublibs/zlib89 \
-Ithird_party/sndmuglib/include \
-Ithird_party/sndmuglib/sublibs/wavc89/include"

AVM_CORE_SOURCES="\
src/core/audiovisualmugen.c \
third_party/defroute89/src/cfg_fix.c \
third_party/defroute89/src/cfg_parser.c \
third_party/defroute89/src/cfg_router.c \
third_party/defroute89/src/mugen_char_def.c \
third_party/airdsl_irvm/air_base/air_arena.c \
third_party/airdsl_irvm/air_base/air_fixed.c \
third_party/airdsl_irvm/air_base/air_status.c \
third_party/airdsl_irvm/air_text/air_token.c \
third_party/airdsl_irvm/air_text/air_lexer.c \
third_party/airdsl_irvm/air_text/air_syntax.c \
third_party/airdsl_irvm/air_ast/air_ast.c \
third_party/airdsl_irvm/air_ast/air_parser.c \
third_party/airdsl_irvm/air_ir/air_ir.c \
third_party/airdsl_irvm/air_ir/air_compile.c \
third_party/airdsl_irvm/air_ir/air_validate.c \
third_party/airdsl_irvm/air_vm/air_bc.c \
third_party/airdsl_irvm/air_vm/air_vm.c \
third_party/airdsl_irvm/air_vm/air_vm_decode.c \
third_party/airdsl_irvm/air_runtime/air_pose.c \
third_party/airdsl_irvm/air_runtime/air_runtime.c \
third_party/airdsl_irvm/air_runtime/air_timeline.c \
third_party/airdsl_irvm/air_boxes/air_box_transform.c \
third_party/airdsl_irvm/air_boxes/air_boxes.c \
third_party/airdsl_irvm/air_boxes/air_boxset.c \
third_party/airdsl_irvm/air_debug/air_trace.c \
third_party/sff_fixed/sff/sff_api.c \
third_party/sff_fixed/sff/sff_endian.c \
third_party/sff_fixed/sff/sff_map.c \
third_party/sff_fixed/sff/sff_decomp.c \
third_party/sff_fixed/sff/sff_pcx.c \
third_party/sff_fixed/sff/sff_png.c \
third_party/sff_fixed/sff/sff_png_builtin.c \
third_party/sff_fixed/sff/sff_v1.c \
third_party/sff_fixed/sff/sff_v2.c \
third_party/sff_fixed/sublibs/pcx89/pcx89.c \
third_party/sff_fixed/sublibs/png89/png89.c \
third_party/sff_fixed/sublibs/png89/png89_zlib89.c \
third_party/sff_fixed/sublibs/zlib89/zlib89.c \
third_party/sndmuglib/src/sndmug_index.c \
third_party/sndmuglib/src/sndmug_io_mem.c \
third_party/sndmuglib/src/sndmug_reader.c \
third_party/sndmuglib/src/sndmug_status.c \
third_party/sndmuglib/src/sndmug_utils.c \
third_party/sndmuglib/src/sndmug_wav_bridge.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_fixed.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_imaadpcm.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_io_mem.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_msadpcm.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_pcm.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_reader.c \
third_party/sndmuglib/sublibs/wavc89/src/wavc89_status.c"

AVM_WIN32_SOURCES="\
src/win32/avm_win32_file.c \
src/win32/audiovisualmugen_win32.c"
