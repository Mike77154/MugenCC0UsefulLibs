#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
. scripts/source_lists.sh
CC="${CC:-cc}"
OUT="build/linux"
mkdir -p "$OUT"
CFLAGS="${CFLAGS:--O2 -std=gnu89 -pedantic -Wall -Wextra -Werror -fno-strict-aliasing}"
# Intentional splitting: source/include strings contain trusted repository paths.
# shellcheck disable=SC2086
$CC $CFLAGS $AVM_INCLUDE_FLAGS tests/integration_smoke.c $AVM_CORE_SOURCES \
    -o "$OUT/integration_smoke"
"$OUT/integration_smoke" examples/sample_char/sample.def

# Self-contained regressions for quirks present in Elecbyte's own KFM files:
# UTF-8 BOM, declaration-owned collision labels, SND EOF sentinel and an
# unpadded odd-sized terminal WAV data chunk.
# shellcheck disable=SC2086
$CC $CFLAGS $AVM_INCLUDE_FLAGS tests/compatibility_smoke.c $AVM_CORE_SOURCES \
    -o "$OUT/compatibility_smoke"
"$OUT/compatibility_smoke"
