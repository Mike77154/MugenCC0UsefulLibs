#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
. scripts/source_lists.sh
FILES="include/audiovisualmugen/audiovisualmugen.h $AVM_CORE_SOURCES $AVM_WIN32_SOURCES"
PATTERN='\b(malloc|calloc|realloc|free)[[:space:]]*\(|\b(float|double)\b'
if grep -nE "$PATTERN" $FILES; then
    echo "constraint audit: FAILED" >&2
    exit 1
fi
echo "constraint audit: ok (no heap calls, float, or double in shipped runtime sources)"
