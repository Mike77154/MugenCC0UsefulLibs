#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
. scripts/source_lists.sh

if [ "$#" -lt 1 ]; then
    echo "usage: $0 path/to/kfm.def [path/to/kfm720.def ...]" >&2
    exit 2
fi

CC="${CC:-cc}"
OUT="build/linux"
mkdir -p "$OUT"
CFLAGS="${CFLAGS:--O2 -std=gnu89 -pedantic -Wall -Wextra -Werror -fno-strict-aliasing}"
# shellcheck disable=SC2086
$CC $CFLAGS $AVM_INCLUDE_FLAGS tests/reference_mugen_smoke.c $AVM_CORE_SOURCES \
    -o "$OUT/reference_mugen_smoke"

for def_path in "$@"; do
    echo "TEST $def_path"
    "$OUT/reference_mugen_smoke" "$def_path"
done
