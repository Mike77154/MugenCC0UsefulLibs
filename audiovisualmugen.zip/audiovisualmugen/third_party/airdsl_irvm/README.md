# AIRDSL Industrial

A **C89**, **no-heap**, **fixed-point**, **caller-owned arena** stack for parsing, compiling, validating and running **M.U.G.E.N AIR / AIR-like DSLs**.

This revision pushes the project from “small modular lib” into a more formal stack with:

- **hard layers and narrower ABI surfaces**
- **explicit IR / VM opcodes**
- **compiled immutable assets** (`air_program`)
- **instantiable runtime state** (`air_runtime`)
- **boxes as a separate subsystem**
- **offline bytecode serialization** (`.airbc` style payload)
- **subcommand CLI tooling**
- **diagnostic lists, warnings vs errors**
- **strict/permissive parsing modes**
- **sub-libraries for selective linkage**

## Layer map

```text
air_base/
  air_types.h      air_limits.h     air_status.h/.c
  air_fixed.h/.c   air_span.h       air_arena.h/.c

air_text/
  air_token.h/.c   air_lexer.h/.c   air_syntax.h/.c

air_ast/
  air_ast.h/.c     air_parser.h/.c

air_ir/
  air_ir.h/.c      air_compile.h/.c air_validate.h/.c

air_vm/
  air_bc.h/.c      air_vm_ops.h
  air_vm.h/.c      air_vm_decode.h/.c
  air_vm_dump.h/.c

air_runtime/
  air_pose.h/.c    air_timeline.h/.c
  air_runtime.h/.c

air_boxes/
  air_boxset.h/.c
  air_box_transform.h/.c
  air_boxes.h/.c

air_debug/
  air_trace.h/.c   air_debugdraw.h/.c   air_dump.h/.c

air_io_optional/
  air_file_stdio.h/.c
  air_cli_main.c

air_tests/
  selftest.c

air_examples/
  sample.air
  weird_spacing.air
  integration_minimal.c
```

## Core design

### 1. Normalized IR first, VM asset second

`air_ir_program` is the normalized semantic layer:

- action table
- element table
- final inherited collision refs per element
- interpolation edges

`air_program` is the lowered VM/bytecode asset:

- actions
- rect tables
- fixed-size VM instructions

That asset can be shared by many runtime instances with no recompilation.

### 2. Instantiable runtime

`air_runtime` keeps only live execution state:

- current action
- current element
- current element-local tick
- global tick
- loop markers and flags
- current sampled pose

### 3. Separate boxes subsystem

Collision/debug boxes are not hidden inside the runtime. The runtime exposes pose + raw refs, and `air_boxes_*` transforms them with policies.

### 4. No sprite backend lock-in

AIR sprite references remain logical `(group_no, image_no)` keys.
You can map them to:

- SFF
- texture atlases
- sprite sheets
- imported JSON lookup tables
- any custom asset system

## VM opcodes

The lowered VM program is a real instruction stream with stable decoding/dumping:

- `AIR_OP_SET_SPRITE`
- `AIR_OP_SET_TIME`
- `AIR_OP_SET_OFFSET`
- `AIR_OP_SET_FLIP`
- `AIR_OP_SET_BLEND`
- `AIR_OP_SET_SCALE`
- `AIR_OP_SET_ANGLE`
- `AIR_OP_SET_INTERP`
- `AIR_OP_SET_CLSN_DEFAULT`
- `AIR_OP_SET_CLSN_ONCE`
- `AIR_OP_PUSH_ELEM_BOXES`
- `AIR_OP_MARK_LOOP`
- `AIR_OP_COMMIT_ELEM`
- `AIR_OP_END_ACTION`
- `AIR_OP_NOP`

Each instruction uses a fixed record:

```c
typedef struct air_insn
{
    air_u8  opcode;
    air_u8  flags;
    air_u16 reserved;
    air_i32 operand_a;
    air_i32 operand_b;
    air_i32 operand_c;
} air_insn;
```

## Public host-facing flow

```c
air_ir_build_from_text(...)
air_ir_build_from_tokens(...)
air_program_build_from_ir(...)
air_program_build_from_text(...)
air_program_build_from_tokens(...)
air_program_validate(...)

air_runtime_init(...)
air_runtime_set_action(...)
air_runtime_step_ticks(...)
air_runtime_seek_tick(...)
air_runtime_rewind(...)
air_runtime_get_pose(...)
air_runtime_get_boxes(...)

air_boxes_build_from_pose(...)
air_debug_build_primitives(...)

air_program_write_serialized(...)
air_program_read_serialized(...)
air_program_dump(...)
air_diag_format(...)
```

## Build

```sh
make
```

Outputs:

- `libairbase.a`
- `libairtext.a`
- `libairast.a`
- `libairir.a`
- `libairvm.a`
- `libairruntime.a`
- `libairboxes.a`
- `libairdebug.a`
- `libairdsl.a`
- `airtool`
- `selftest`

## CLI

```sh
./airtool lex air_examples/sample.air
./airtool parse air_examples/sample.air
./airtool ast air_examples/sample.air
./airtool ir air_examples/sample.air
./airtool compile air_examples/sample.air
./airtool dump-bc air_examples/sample.air
./airtool validate air_examples/sample.air
./airtool run air_examples/sample.air --action 200 --ticks 2
./airtool boxes air_examples/sample.air --action 200 --tick 2
./airtool save-bc air_examples/sample.air /tmp/sample.airbc
./airtool load-bc /tmp/sample.airbc
./airtool corpus air_examples
./airtool selftest
```

Modes/flags:

```text
--strict
--json-ish        (reserved for further expansion)
--no-color        (reserved; CLI already avoids ANSI)
--fail-fast
--quiet
--trace
```

## AIR support in this stack

Implemented syntax includes:

- `[Begin Action n]`
- `Clsn1`, `Clsn2`, `Clsn1Default`, `Clsn2Default`
- `Clsn1[i] = x1,y1,x2,y2`
- `Clsn2[i] = x1,y1,x2,y2`
- `Loopstart`
- `Interpolate Offset|Blend|Scale|Angle`
- element lines with:
  - `group,image,x,y,time`
  - optional flip
  - optional blend
  - optional scale
  - optional angle

Permissive mode tolerates a chunk of messy community formatting:

- case-insensitive keywords
- weird spacing
- blank lines
- comments mixed into files
- some recoverable line-level failures

## Diagnostics

Diagnostics are caller-owned and structured:

```c
typedef struct air_diag
{
    air_status code;
    air_diag_severity severity;
    air_i32 line;
    air_i32 column;
    air_i32 action_no;
    air_i32 elem_index;
    char message[AIR_MAX_DIAG_MESSAGE];
} air_diag;
```

Use `air_diag_list` to accumulate warnings/errors without heap allocation.

## Serialization

Compiled programs can be serialized to a compact AIRBC-style blob with:

- magic
- version
- ABI version
- counts
- checksum

This enables offline pipelines:

```text
AIR text -> parse -> compile -> validate -> save .airbc
.airbc   -> load -> validate -> runtime / tools
```

## Notes

- Everything is **caller-buffer / caller-arena owned**
- No hidden globals
- Core library avoids mandatory stdio/file dependencies
- CLI/file IO live in `air_io_optional/`
- Current box transform path supports classic + scaled policies and intentionally ignores rotation in the geometry transform unless you build that policy later

See `docs/ARCHITECTURE.md` for the detailed rationale.
