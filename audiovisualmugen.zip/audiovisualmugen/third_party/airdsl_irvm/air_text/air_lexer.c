#include "air/air_lexer.h"

static air_bool air_is_ident_start(char ch)
{
    return (air_bool)(((ch >= 'A') && (ch <= 'Z')) ||
                      ((ch >= 'a') && (ch <= 'z')) ||
                      ch == '_');
}

static air_bool air_is_ident_body(char ch)
{
    return (air_bool)(air_is_ident_start(ch) || ((ch >= '0') && (ch <= '9')));
}

static air_bool air_is_number_char(char ch)
{
    return (air_bool)(((ch >= '0') && (ch <= '9')) || ch == '-' || ch == '+' || ch == '.');
}

void air_lex_options_default(air_lex_options* opts)
{
    if (opts == AIR_NULL)
    {
        return;
    }
    opts->reserved = 0;
}

air_status air_lex_line(const char* text,
                        air_u16 len,
                        air_u16 line_number,
                        air_token_line* out_tokens,
                        air_diag_list* diags)
{
    air_u16 i;
    air_u16 count;

    if (text == AIR_NULL || out_tokens == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, line_number, 1, -1, -1, "lexer: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    out_tokens->count = 0;
    out_tokens->line_begin = text;
    out_tokens->line_len = len;
    out_tokens->line_no = line_number;

    i = 0;
    /*
     * Elecbyte's reference KFM AIR is shipped with an UTF-8 BOM.
     * AIR itself is an ASCII-oriented text format, but the BOM is a
     * transport marker rather than part of the first token.  Accept it
     * only at the start of the first line so arbitrary high bytes do not
     * get silently swallowed elsewhere in the file.
     */
    if (line_number == 1 && len >= 3 &&
        (unsigned char)text[0] == 0xEFu &&
        (unsigned char)text[1] == 0xBBu &&
        (unsigned char)text[2] == 0xBFu)
    {
        i = 3;
    }
    count = 0;
    while (i < len)
    {
        char ch;
        air_token* tok;
        air_u16 start;

        ch = text[i];
        if (ch == ';')
        {
            break;
        }
        if (ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n')
        {
            ++i;
            continue;
        }

        if (count >= AIR_MAX_TOKENS_PER_LINE)
        {
            air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, line_number, (air_i32)(i + 1), -1, -1, "lexer: too many tokens on line");
            return AIR_STATUS_EOVERFLOW;
        }

        tok = &out_tokens->tokens[count];
        tok->ptr = text + i;
        tok->line = line_number;
        tok->col = (air_u16)(i + 1);
        tok->len = 1;
        tok->kind = AIR_TOK_EOF;

        switch (ch)
        {
        case ',': tok->kind = AIR_TOK_COMMA; ++i; break;
        case ':': tok->kind = AIR_TOK_COLON; ++i; break;
        case '[': tok->kind = AIR_TOK_LBRACKET; ++i; break;
        case ']': tok->kind = AIR_TOK_RBRACKET; ++i; break;
        case '=': tok->kind = AIR_TOK_EQUAL; ++i; break;
        default:
            if (air_is_ident_start(ch))
            {
                start = i;
                ++i;
                while (i < len && air_is_ident_body(text[i]))
                {
                    ++i;
                }
                tok->kind = AIR_TOK_IDENT;
                tok->ptr = text + start;
                tok->len = (air_u16)(i - start);
            }
            else if (air_is_number_char(ch))
            {
                start = i;
                ++i;
                while (i < len && air_is_number_char(text[i]))
                {
                    ++i;
                }
                tok->kind = AIR_TOK_NUMBER;
                tok->ptr = text + start;
                tok->len = (air_u16)(i - start);
            }
            else
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, line_number, (air_i32)(i + 1), -1, -1, "lexer: unexpected character");
                return AIR_STATUS_ESYNTAX;
            }
            break;
        }
        ++count;
    }

    out_tokens->count = count;
    return AIR_STATUS_OK;
}

static air_status air_read_line(const char* text,
                                air_u32 len,
                                air_u32* inout_off,
                                const char** out_line,
                                air_u16* out_len)
{
    air_u32 off;
    air_u32 start;

    if (inout_off == AIR_NULL || out_line == AIR_NULL || out_len == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }
    off = *inout_off;
    if (off >= len)
    {
        return AIR_STATUS_ENOTFOUND;
    }

    start = off;
    while (off < len && text[off] != '\n')
    {
        ++off;
    }
    *out_line = text + start;
    *out_len = (air_u16)(off - start);
    if (off < len && text[off] == '\n')
    {
        ++off;
    }
    *inout_off = off;
    return AIR_STATUS_OK;
}

air_status air_lex_text(air_token_stream* out_stream,
                        air_arena* arena,
                        const char* text,
                        air_u32 len,
                        const air_lex_options* opts,
                        air_diag_list* diags)
{
    air_u32 off;
    air_u16 line_no;
    air_u32 line_count;
    air_u32 total_tokens;
    air_status status;
    air_token_line* lines;

    (void)opts;

    if (out_stream == AIR_NULL || arena == AIR_NULL || text == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "lexer: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    off = 0;
    line_no = 1;
    line_count = 0;
    total_tokens = 0;
    while (off < len)
    {
        const char* line;
        air_u16 line_len;
        air_token_line scratch;

        status = air_read_line(text, len, &off, &line, &line_len);
        if (status != AIR_STATUS_OK)
        {
            break;
        }
        if (line_len > AIR_MAX_LINE_LEN)
        {
            air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, line_no, 1, -1, -1, "lexer: line exceeds AIR_MAX_LINE_LEN");
            return AIR_STATUS_EOVERFLOW;
        }
        status = air_lex_line(line, line_len, line_no, &scratch, diags);
        if (status != AIR_STATUS_OK)
        {
            return status;
        }
        total_tokens += scratch.count;
        if (line_count >= AIR_MAX_LINES || total_tokens > AIR_MAX_TOKENS)
        {
            air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, line_no, 1, -1, -1, "lexer: configured token or line limits exceeded");
            return AIR_STATUS_EOVERFLOW;
        }
        ++line_count;
        ++line_no;
    }

    lines = (air_token_line*)air_arena_alloc(arena, line_count * (air_u32)sizeof(air_token_line), 4U);
    if (lines == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ENOMEM, AIR_DIAG_ERROR, 0, 0, -1, -1, "lexer: arena exhausted");
        return AIR_STATUS_ENOMEM;
    }

    off = 0;
    line_no = 1;
    line_count = 0;
    total_tokens = 0;
    while (off < len)
    {
        const char* line;
        air_u16 line_len;

        status = air_read_line(text, len, &off, &line, &line_len);
        if (status != AIR_STATUS_OK)
        {
            break;
        }
        status = air_lex_line(line, line_len, line_no, &lines[line_count], diags);
        if (status != AIR_STATUS_OK)
        {
            return status;
        }
        total_tokens += lines[line_count].count;
        ++line_count;
        ++line_no;
    }

    out_stream->lines = lines;
    out_stream->line_count = line_count;
    out_stream->total_tokens = total_tokens;
    return AIR_STATUS_OK;
}
