#include "air/air_token.h"

static char air_ascii_lower(char ch)
{
    if (ch >= 'A' && ch <= 'Z')
    {
        return (char)(ch - 'A' + 'a');
    }
    return ch;
}

air_bool air_token_eq(const air_token* tok, const char* text, air_bool case_sensitive)
{
    air_u16 i;

    if (tok == AIR_NULL || text == AIR_NULL)
    {
        return AIR_FALSE;
    }
    for (i = 0; i < tok->len; ++i)
    {
        char a;
        char b;
        a = tok->ptr[i];
        b = text[i];
        if (b == '\0')
        {
            return AIR_FALSE;
        }
        if (!case_sensitive)
        {
            a = air_ascii_lower(a);
            b = air_ascii_lower(b);
        }
        if (a != b)
        {
            return AIR_FALSE;
        }
    }
    return (air_bool)(text[tok->len] == '\0');
}

air_bool air_token_starts_with(const air_token* tok, const char* prefix, air_bool case_sensitive)
{
    air_u16 i;

    if (tok == AIR_NULL || prefix == AIR_NULL)
    {
        return AIR_FALSE;
    }
    for (i = 0; prefix[i] != '\0'; ++i)
    {
        char a;
        char b;
        if (i >= tok->len)
        {
            return AIR_FALSE;
        }
        a = tok->ptr[i];
        b = prefix[i];
        if (!case_sensitive)
        {
            if (a >= 'A' && a <= 'Z') a = (char)(a - 'A' + 'a');
            if (b >= 'A' && b <= 'Z') b = (char)(b - 'A' + 'a');
        }
        if (a != b)
        {
            return AIR_FALSE;
        }
    }
    return AIR_TRUE;
}
