#include "air/air_syntax.h"

static air_status air_parse_i32_token(const air_token* tok, air_i32* out_value)
{
    air_i32 sign;
    air_i32 value;
    air_u16 i;

    if (tok == AIR_NULL || out_value == AIR_NULL || tok->len == 0)
    {
        return AIR_STATUS_EINVAL;
    }

    sign = 1;
    value = 0;
    i = 0;
    if (tok->ptr[i] == '-')
    {
        sign = -1;
        ++i;
    }
    else if (tok->ptr[i] == '+')
    {
        ++i;
    }
    if (i >= tok->len)
    {
        return AIR_STATUS_ESYNTAX;
    }
    for (; i < tok->len; ++i)
    {
        char ch;
        ch = tok->ptr[i];
        if (ch < '0' || ch > '9')
        {
            return AIR_STATUS_ESYNTAX;
        }
        value = (air_i32)(value * 10 + (air_i32)(ch - '0'));
    }
    *out_value = (air_i32)(sign * value);
    return AIR_STATUS_OK;
}

static air_status air_parse_i32_text(const char* text, air_u16 len, air_i32* out_value)
{
    air_token tok;
    tok.ptr = text;
    tok.len = len;
    tok.kind = AIR_TOK_NUMBER;
    tok.line = 0;
    tok.col = 0;
    return air_parse_i32_token(&tok, out_value);
}

static air_bool air_ident_is(const air_token* tok, const char* name, const air_parse_options* opts)
{
    return air_token_eq(tok, name, (air_bool)(opts == AIR_NULL ? AIR_FALSE : opts->case_sensitive_keywords));
}

static air_bool air_starts_with(const air_token* tok, const char* prefix, const air_parse_options* opts)
{
    return air_token_starts_with(tok, prefix, (air_bool)(opts == AIR_NULL ? AIR_FALSE : opts->case_sensitive_keywords));
}

static air_status air_parse_clsn_ident(const air_token* tok,
                                       const air_parse_options* opts,
                                       air_u8* out_kind,
                                       air_u8* out_is_default)
{
    if (air_ident_is(tok, "Clsn1", opts))
    {
        *out_kind = AIR_CLSN_KIND_1;
        *out_is_default = AIR_FALSE;
        return AIR_STATUS_OK;
    }
    if (air_ident_is(tok, "Clsn2", opts))
    {
        *out_kind = AIR_CLSN_KIND_2;
        *out_is_default = AIR_FALSE;
        return AIR_STATUS_OK;
    }
    if (air_ident_is(tok, "Clsn1Default", opts))
    {
        *out_kind = AIR_CLSN_KIND_1;
        *out_is_default = AIR_TRUE;
        return AIR_STATUS_OK;
    }
    if (air_ident_is(tok, "Clsn2Default", opts))
    {
        *out_kind = AIR_CLSN_KIND_2;
        *out_is_default = AIR_TRUE;
        return AIR_STATUS_OK;
    }
    return AIR_STATUS_ESYNTAX;
}

static air_status air_parse_flip(const char* text, air_u16 len, air_u8* out_flip)
{
    air_token tok;
    tok.ptr = text;
    tok.len = len;
    tok.kind = AIR_TOK_IDENT;
    tok.line = 0;
    tok.col = 0;

    if (len == 0 || (len == 1 && text[0] == '0'))
    {
        *out_flip = AIR_FLIP_NONE;
        return AIR_STATUS_OK;
    }
    if (air_token_eq(&tok, "H", AIR_FALSE))
    {
        *out_flip = AIR_FLIP_H;
        return AIR_STATUS_OK;
    }
    if (air_token_eq(&tok, "V", AIR_FALSE))
    {
        *out_flip = AIR_FLIP_V;
        return AIR_STATUS_OK;
    }
    if (air_token_eq(&tok, "VH", AIR_FALSE) || air_token_eq(&tok, "HV", AIR_FALSE))
    {
        *out_flip = (air_u8)(AIR_FLIP_H | AIR_FLIP_V);
        return AIR_STATUS_OK;
    }
    return AIR_STATUS_ESYNTAX;
}

static air_status air_parse_blend(const char* text,
                                  air_u16 len,
                                  air_u8* out_fn,
                                  air_u16* out_src,
                                  air_u16* out_dst)
{
    air_i32 value;
    air_u16 split;
    air_token tok;

    *out_fn = AIR_BLEND_NONE;
    *out_src = 0;
    *out_dst = 0;

    if (len == 0)
    {
        return AIR_STATUS_OK;
    }

    tok.ptr = text;
    tok.len = len;
    tok.kind = AIR_TOK_IDENT;
    tok.line = 0;
    tok.col = 0;

    if (air_token_eq(&tok, "A", AIR_FALSE))
    {
        *out_fn = AIR_BLEND_ADD;
        *out_src = 256;
        *out_dst = 256;
        return AIR_STATUS_OK;
    }
    if (air_token_eq(&tok, "S", AIR_FALSE))
    {
        *out_fn = AIR_BLEND_SUB;
        *out_src = 256;
        *out_dst = 256;
        return AIR_STATUS_OK;
    }
    if (air_token_eq(&tok, "A1", AIR_FALSE))
    {
        *out_fn = AIR_BLEND_ADD;
        *out_src = 256;
        *out_dst = 128;
        return AIR_STATUS_OK;
    }

    if (len >= 4 &&
        ((text[0] == 'A' || text[0] == 'a') &&
         (text[1] == 'S' || text[1] == 's')))
    {
        split = 2;
        while (split < len && text[split] >= '0' && text[split] <= '9')
        {
            ++split;
        }
        if (split >= len || !(text[split] == 'D' || text[split] == 'd'))
        {
            return AIR_STATUS_ESYNTAX;
        }
        if (air_parse_i32_text(text + 2, (air_u16)(split - 2), &value) != AIR_STATUS_OK)
        {
            return AIR_STATUS_ESYNTAX;
        }
        *out_src = (air_u16)value;
        if (air_parse_i32_text(text + split + 1, (air_u16)(len - split - 1), &value) != AIR_STATUS_OK)
        {
            return AIR_STATUS_ESYNTAX;
        }
        *out_dst = (air_u16)value;
        *out_fn = AIR_BLEND_ADD;
        return AIR_STATUS_OK;
    }

    return AIR_STATUS_ESYNTAX;
}

static void air_trim_field(const char** inout_ptr, air_u16* inout_len)
{
    const char* ptr;
    air_u16 len;

    ptr = *inout_ptr;
    len = *inout_len;
    while (len > 0 && (*ptr == ' ' || *ptr == '\t' || *ptr == '\r' || *ptr == '\n'))
    {
        ++ptr;
        --len;
    }
    while (len > 0)
    {
        char ch;
        ch = ptr[len - 1];
        if (ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n')
        {
            --len;
        }
        else
        {
            break;
        }
    }
    *inout_ptr = ptr;
    *inout_len = len;
}

static air_status air_split_csv(const char* line,
                                air_u16 len,
                                const char** out_ptrs,
                                air_u16* out_lens,
                                air_u16* out_count)
{
    air_u16 i;
    air_u16 field_count;
    air_u16 start;
    air_u16 end;

    field_count = 0;
    start = 0;
    end = len;
    for (i = 0; i < len; ++i)
    {
        if (line[i] == ';')
        {
            end = i;
            break;
        }
    }
    for (i = 0; i <= end; ++i)
    {
        if (i == end || line[i] == ',')
        {
            const char* ptr;
            air_u16 flen;
            if (field_count >= 16)
            {
                return AIR_STATUS_EOVERFLOW;
            }
            ptr = line + start;
            flen = (air_u16)(i - start);
            air_trim_field(&ptr, &flen);
            out_ptrs[field_count] = ptr;
            out_lens[field_count] = flen;
            ++field_count;
            start = (air_u16)(i + 1);
        }
    }
    *out_count = field_count;
    return AIR_STATUS_OK;
}

static air_status air_parse_element_csv(const air_token_line* tokens,
                                        air_syn_stmt* out_stmt,
                                        air_diag_list* diags)
{
    const char* fields[16];
    air_u16 lens[16];
    air_u16 field_count;
    air_syn_element elem;
    air_status status;

    status = air_split_csv(tokens->line_begin, tokens->line_len, fields, lens, &field_count);
    if (status != AIR_STATUS_OK)
    {
        air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: element has too many csv fields");
        return status;
    }
    if (field_count < 5)
    {
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: element needs at least 5 fields");
        return AIR_STATUS_ESYNTAX;
    }

    elem.group_no = 0;
    elem.image_no = 0;
    elem.x = 0;
    elem.y = 0;
    elem.time = 0;
    elem.flip = AIR_FLIP_NONE;
    elem.blend_fn = AIR_BLEND_NONE;
    elem.src_alpha = 0;
    elem.dst_alpha = 0;
    elem.scale_x = AIR_FIXED_ONE;
    elem.scale_y = AIR_FIXED_ONE;
    elem.angle_deg = 0;

    if (air_parse_i32_text(fields[0], lens[0], &elem.group_no) != AIR_STATUS_OK ||
        air_parse_i32_text(fields[1], lens[1], &elem.image_no) != AIR_STATUS_OK ||
        air_parse_i32_text(fields[2], lens[2], &elem.x) != AIR_STATUS_OK ||
        air_parse_i32_text(fields[3], lens[3], &elem.y) != AIR_STATUS_OK ||
        air_parse_i32_text(fields[4], lens[4], &elem.time) != AIR_STATUS_OK)
    {
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: invalid integer in element");
        return AIR_STATUS_ESYNTAX;
    }

    if (field_count >= 6 && lens[5] > 0)
    {
        if (air_parse_flip(fields[5], lens[5], &elem.flip) != AIR_STATUS_OK)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: invalid flip field");
            return AIR_STATUS_ESYNTAX;
        }
    }
    if (field_count >= 7 && lens[6] > 0)
    {
        if (air_parse_blend(fields[6], lens[6], &elem.blend_fn, &elem.src_alpha, &elem.dst_alpha) != AIR_STATUS_OK)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: invalid blend field");
            return AIR_STATUS_ESYNTAX;
        }
    }
    if (field_count >= 8 && lens[7] > 0)
    {
        if (field_count < 9 || lens[8] == 0)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: scale_y required when scale_x is present");
            return AIR_STATUS_ESYNTAX;
        }
        if (air_fx_parse(fields[7], lens[7], &elem.scale_x) != AIR_STATUS_OK ||
            air_fx_parse(fields[8], lens[8], &elem.scale_y) != AIR_STATUS_OK)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: invalid scale value");
            return AIR_STATUS_ESYNTAX;
        }
    }
    if (field_count >= 10 && lens[9] > 0)
    {
        if (air_fx_parse(fields[9], lens[9], &elem.angle_deg) != AIR_STATUS_OK)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, 1, -1, -1, "syntax: invalid angle value");
            return AIR_STATUS_ESYNTAX;
        }
    }

    out_stmt->kind = AIR_SYN_ELEMENT;
    out_stmt->v.element = elem;
    return AIR_STATUS_OK;
}

void air_parse_options_default(air_parse_options* opts)
{
    if (opts == AIR_NULL)
    {
        return;
    }
    opts->permissive = AIR_FALSE;
    opts->case_sensitive_keywords = AIR_FALSE;
    opts->trace = AIR_NULL;
}

air_status air_syntax_parse_line(const air_token_line* tokens,
                                 const air_parse_options* opts,
                                 air_syn_stmt* out_stmt,
                                 air_diag_list* diags)
{
    const air_token* t0;
    air_status status;

    if (tokens == AIR_NULL || out_stmt == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "syntax: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    out_stmt->kind = AIR_SYN_EMPTY;
    out_stmt->line = 0;
    if (tokens->count == 0)
    {
        return AIR_STATUS_OK;
    }

    out_stmt->line = tokens->tokens[0].line;
    t0 = &tokens->tokens[0];

    if (t0->kind == AIR_TOK_LBRACKET)
    {
        if (tokens->count == 5 &&
            air_ident_is(&tokens->tokens[1], "Begin", opts) &&
            air_ident_is(&tokens->tokens[2], "Action", opts) &&
            tokens->tokens[3].kind == AIR_TOK_NUMBER &&
            tokens->tokens[4].kind == AIR_TOK_RBRACKET)
        {
            out_stmt->kind = AIR_SYN_BEGIN_ACTION;
            if (air_parse_i32_token(&tokens->tokens[3], &out_stmt->v.begin_action.action_no) != AIR_STATUS_OK)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, tokens->tokens[3].col, -1, -1, "syntax: invalid action number");
                return AIR_STATUS_ESYNTAX;
            }
            return AIR_STATUS_OK;
        }
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: malformed [Begin Action n]");
        return AIR_STATUS_ESYNTAX;
    }

    if (t0->kind == AIR_TOK_IDENT && air_ident_is(t0, "Loopstart", opts))
    {
        if (tokens->count != 1)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: Loopstart takes no arguments");
            return AIR_STATUS_ESYNTAX;
        }
        out_stmt->kind = AIR_SYN_LOOPSTART;
        return AIR_STATUS_OK;
    }

    if (t0->kind == AIR_TOK_IDENT && air_ident_is(t0, "Interpolate", opts))
    {
        if (tokens->count != 2 || tokens->tokens[1].kind != AIR_TOK_IDENT)
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: malformed Interpolate line");
            return AIR_STATUS_ESYNTAX;
        }
        out_stmt->kind = AIR_SYN_INTERPOLATE;
        out_stmt->v.interpolate.mask = 0;
        if (air_ident_is(&tokens->tokens[1], "Offset", opts)) out_stmt->v.interpolate.mask = AIR_INTERP_OFFSET;
        else if (air_ident_is(&tokens->tokens[1], "Blend", opts)) out_stmt->v.interpolate.mask = AIR_INTERP_BLEND;
        else if (air_ident_is(&tokens->tokens[1], "Scale", opts)) out_stmt->v.interpolate.mask = AIR_INTERP_SCALE;
        else if (air_ident_is(&tokens->tokens[1], "Angle", opts)) out_stmt->v.interpolate.mask = AIR_INTERP_ANGLE;
        else
        {
            air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, tokens->tokens[1].col, -1, -1, "syntax: unknown interpolation kind");
            return AIR_STATUS_ESYNTAX;
        }
        return AIR_STATUS_OK;
    }

    if (t0->kind == AIR_TOK_IDENT && air_starts_with(t0, "Clsn", opts))
    {
        air_u8 clsn_kind;
        air_u8 is_default;

        clsn_kind = AIR_CLSN_KIND_NONE;
        is_default = AIR_FALSE;

        if (tokens->count >= 3 && tokens->tokens[1].kind == AIR_TOK_COLON)
        {
            if (air_parse_clsn_ident(t0, opts, &clsn_kind, &is_default) != AIR_STATUS_OK)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: invalid collision declaration");
                return AIR_STATUS_ESYNTAX;
            }
            if (tokens->count != 3 || tokens->tokens[2].kind != AIR_TOK_NUMBER)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: malformed collision declaration");
                return AIR_STATUS_ESYNTAX;
            }
            out_stmt->kind = AIR_SYN_CLSN_DECL;
            out_stmt->v.clsn_decl.clsn_kind = clsn_kind;
            out_stmt->v.clsn_decl.is_default = is_default;
            if (air_parse_i32_token(&tokens->tokens[2], &out_stmt->v.clsn_decl.rect_count) != AIR_STATUS_OK)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, tokens->tokens[2].col, -1, -1, "syntax: invalid collision count");
                return AIR_STATUS_ESYNTAX;
            }
            return AIR_STATUS_OK;
        }

        if (tokens->count == 12 &&
            tokens->tokens[1].kind == AIR_TOK_LBRACKET &&
            tokens->tokens[2].kind == AIR_TOK_NUMBER &&
            tokens->tokens[3].kind == AIR_TOK_RBRACKET &&
            tokens->tokens[4].kind == AIR_TOK_EQUAL &&
            tokens->tokens[5].kind == AIR_TOK_NUMBER &&
            tokens->tokens[6].kind == AIR_TOK_COMMA &&
            tokens->tokens[7].kind == AIR_TOK_NUMBER &&
            tokens->tokens[8].kind == AIR_TOK_COMMA &&
            tokens->tokens[9].kind == AIR_TOK_NUMBER &&
            tokens->tokens[10].kind == AIR_TOK_COMMA &&
            tokens->tokens[11].kind == AIR_TOK_NUMBER)
        {
            if (air_parse_clsn_ident(t0, opts, &clsn_kind, &is_default) != AIR_STATUS_OK || is_default)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: invalid collision rectangle kind");
                return AIR_STATUS_ESYNTAX;
            }
            out_stmt->kind = AIR_SYN_CLSN_RECT;
            out_stmt->v.clsn_rect.clsn_kind = clsn_kind;
            if (air_parse_i32_token(&tokens->tokens[2], &out_stmt->v.clsn_rect.rect_index) != AIR_STATUS_OK ||
                air_parse_i32_token(&tokens->tokens[5], &out_stmt->v.clsn_rect.x1) != AIR_STATUS_OK ||
                air_parse_i32_token(&tokens->tokens[7], &out_stmt->v.clsn_rect.y1) != AIR_STATUS_OK ||
                air_parse_i32_token(&tokens->tokens[9], &out_stmt->v.clsn_rect.x2) != AIR_STATUS_OK ||
                air_parse_i32_token(&tokens->tokens[11], &out_stmt->v.clsn_rect.y2) != AIR_STATUS_OK)
            {
                air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: invalid collision rectangle value");
                return AIR_STATUS_ESYNTAX;
            }
            return AIR_STATUS_OK;
        }

        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: malformed collision statement");
        return AIR_STATUS_ESYNTAX;
    }

    if (t0->kind == AIR_TOK_NUMBER)
    {
        return air_parse_element_csv(tokens, out_stmt, diags);
    }

    status = AIR_STATUS_ESYNTAX;
    air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, out_stmt->line, t0->col, -1, -1, "syntax: unknown statement");
    return status;
}
