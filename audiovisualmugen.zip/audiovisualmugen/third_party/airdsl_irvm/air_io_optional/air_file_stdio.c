#include <stdio.h>
#include "air/air_file_stdio.h"

air_status air_file_read_all(const char* path, void* buffer, air_u32 capacity, air_u32* out_size)
{
    FILE* fp;
    air_u32 n;

    if (path == AIR_NULL || buffer == AIR_NULL || out_size == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }

    fp = fopen(path, "rb");
    if (fp == AIR_NULL)
    {
        return AIR_STATUS_EIO;
    }

    n = (air_u32)fread(buffer, 1, capacity, fp);
    if (ferror(fp))
    {
        fclose(fp);
        return AIR_STATUS_EIO;
    }
    if (!feof(fp))
    {
        fclose(fp);
        return AIR_STATUS_EOVERFLOW;
    }
    fclose(fp);

    *out_size = n;
    return AIR_STATUS_OK;
}

air_status air_file_write_all(const char* path, const void* data, air_u32 size)
{
    FILE* fp;
    air_u32 n;

    if (path == AIR_NULL || data == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }
    fp = fopen(path, "wb");
    if (fp == AIR_NULL)
    {
        return AIR_STATUS_EIO;
    }
    n = (air_u32)fwrite(data, 1, size, fp);
    fclose(fp);
    if (n != size)
    {
        return AIR_STATUS_EIO;
    }
    return AIR_STATUS_OK;
}
