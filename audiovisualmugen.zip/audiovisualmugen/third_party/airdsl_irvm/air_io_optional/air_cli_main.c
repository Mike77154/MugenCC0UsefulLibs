#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include "air/air_api.h"

static void stdout_sink(void* user, const char* text, air_u32 len)
{
    (void)user;
    fwrite(text, 1, len, stdout);
}

static void stderr_trace_sink(void* user, const air_trace_event* ev)
{
    const char* name;
    (void)user;
    switch (ev->kind)
    {
    case AIR_TRACE_PARSER: name = "parser"; break;
    case AIR_TRACE_COMPILE: name = "compile"; break;
    case AIR_TRACE_ACTION_CHANGE: name = "action"; break;
    case AIR_TRACE_LOOP_HIT: name = "loop"; break;
    case AIR_TRACE_ELEM_ADVANCE: name = "elem"; break;
    case AIR_TRACE_POSE_UPDATE: name = "pose"; break;
    case AIR_TRACE_BOX_BUILD: name = "boxes"; break;
    default: name = "trace"; break;
    }
    fprintf(stderr, "[trace:%s] action=%ld elem=%ld tick=%ld pc=%lu %s\n",
            name,
            (long)ev->action_no,
            (long)ev->elem_index,
            (long)ev->tick,
            (unsigned long)ev->pc,
            ev->message ? ev->message : "");
}

static void print_usage(void)
{
    printf("airtool <command> [options]\n");
    printf("commands:\n");
    printf("  lex file.air\n");
    printf("  parse file.air\n");
    printf("  ast file.air\n");
    printf("  ir file.air\n");
    printf("  compile file.air\n");
    printf("  dump-bc file.air\n");
    printf("  validate file.air\n");
    printf("  run file.air --action N --ticks T\n");
    printf("  boxes file.air --action N --tick T\n");
    printf("  save-bc file.air out.airbc\n");
    printf("  load-bc file.airbc\n");
    printf("  selftest\n");
    printf("  corpus path/\n");
    printf("flags:\n");
    printf("  --strict --json-ish --no-color --fail-fast --quiet --trace\n");
}

static int parse_i32(const char* text, air_i32* out_value)
{
    char* end_ptr;
    long v;

    if (text == AIR_NULL || out_value == AIR_NULL)
    {
        return 0;
    }
    v = strtol(text, &end_ptr, 10);
    if (*text == '\0' || *end_ptr != '\0')
    {
        return 0;
    }
    *out_value = (air_i32)v;
    return 1;
}

static void print_diags(const air_diag_list* diags)
{
    air_u16 i;
    char line[256];

    if (diags == AIR_NULL)
    {
        return;
    }
    for (i = 0; i < diags->count; ++i)
    {
        air_diag_format(&diags->items[i], line, (air_u32)sizeof(line));
        fprintf(stderr, "%s\n", line);
    }
}

static air_status load_text_program(const char* path,
                                    air_program* program,
                                    air_arena* asset_arena,
                                    air_arena* scratch_arena,
                                    const air_build_options* opts,
                                    air_diag_list* diags,
                                    char* file_buf,
                                    air_u32 file_cap)
{
    air_u32 file_size;
    air_status status;

    file_size = 0;
    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        air_diag_push(diags, AIR_STATUS_EIO, AIR_DIAG_ERROR, 0, 0, -1, -1, "cli: failed to read file");
        return status;
    }
    air_arena_reset(asset_arena);
    air_arena_reset(scratch_arena);
    return air_program_build_from_text(program, asset_arena, scratch_arena, file_buf, file_size, opts, diags);
}

static air_status load_text_ir(const char* path,
                               air_ir_program* ir,
                               air_arena* ir_arena,
                               air_arena* scratch_arena,
                               const air_parse_options* opts,
                               air_diag_list* diags,
                               char* file_buf,
                               air_u32 file_cap)
{
    air_u32 file_size;
    air_status status;

    file_size = 0;
    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        air_diag_push(diags, AIR_STATUS_EIO, AIR_DIAG_ERROR, 0, 0, -1, -1, "cli: failed to read file");
        return status;
    }
    air_arena_reset(ir_arena);
    air_arena_reset(scratch_arena);
    return air_ir_build_from_text(ir, ir_arena, scratch_arena, file_buf, file_size, opts, diags);
}

static air_status dump_lex(const char* path,
                           air_arena* scratch_arena,
                           air_diag_list* diags,
                           char* file_buf,
                           air_u32 file_cap)
{
    air_u32 file_size;
    air_token_stream stream;
    air_lex_options lex_opts;
    air_status status;
    air_u32 i;
    air_u16 j;

    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    air_arena_reset(scratch_arena);
    air_lex_options_default(&lex_opts);
    status = air_lex_text(&stream, scratch_arena, file_buf, file_size, &lex_opts, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }

    for (i = 0; i < stream.line_count; ++i)
    {
        const air_token_line* line;
        line = &stream.lines[i];
        printf("line %u:", (unsigned)line->line_no);
        for (j = 0; j < line->count; ++j)
        {
            printf(" [%u:'%.*s']", (unsigned)line->tokens[j].kind, (int)line->tokens[j].len, line->tokens[j].ptr);
        }
        printf("\n");
    }
    return AIR_STATUS_OK;
}

static air_status dump_parse(const char* path,
                             air_arena* scratch_arena,
                             const air_parse_options* parse_opts,
                             air_diag_list* diags,
                             char* file_buf,
                             air_u32 file_cap,
                             air_bool ast_mode)
{
    air_parse_result parsed;
    air_u32 file_size;
    air_status status;
    air_dump_sink sink;

    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    air_arena_reset(scratch_arena);
    status = air_parser_parse_text(&parsed, scratch_arena, file_buf, file_size, parse_opts, diags);
    if (status != AIR_STATUS_OK && !(parse_opts->permissive && !air_diag_has_errors(diags)))
    {
        return status;
    }

    printf("actions=%lu stmts=%lu lines=%lu tokens=%lu\n",
           (unsigned long)parsed.ast.action_count,
           (unsigned long)parsed.ast.stmt_count,
           (unsigned long)parsed.tokens.line_count,
           (unsigned long)parsed.tokens.total_tokens);
    if (ast_mode)
    {
        sink.fn = stdout_sink;
        sink.user = AIR_NULL;
        air_ast_dump(&parsed.ast, &sink, diags);
    }
    return AIR_STATUS_OK;
}

static void print_pose(const air_pose_sample* sample)
{
    printf("action=%ld elem=%lu tick=%ld sprite=(%ld,%ld) off=(%ld,%ld) time=%ld scale=(%ld,%ld) angle=%ld interp=%u clsn1=%u clsn2=%u\n",
           (long)sample->action_no,
           (unsigned long)sample->elem_index,
           (long)sample->tick_in_elem,
           (long)sample->pose.group_no,
           (long)sample->pose.image_no,
           (long)air_fx_to_int_floor(sample->pose.x),
           (long)air_fx_to_int_floor(sample->pose.y),
           (long)sample->pose.time,
           (long)air_fx_to_int_floor(sample->pose.scale_x),
           (long)air_fx_to_int_floor(sample->pose.scale_y),
           (long)air_fx_to_int_floor(sample->pose.angle_deg),
           (unsigned)sample->pose.interp_mask,
           (unsigned)sample->clsn1.count,
           (unsigned)sample->clsn2.count);
}

static air_status run_boxes(const air_program* program,
                            const air_pose_sample* sample,
                            air_diag_list* diags)
{
    air_box_transform xf;
    air_boxset set;
    air_rect_fx red[128];
    air_rect_fx blue[128];
    air_debug_primitive prims[AIR_MAX_DEBUG_PRIMS];
    air_u16 prim_count;
    air_u16 i;
    air_status status;

    air_box_transform_default(&xf);
    status = air_boxes_build_from_pose(program,
                                       sample,
                                       &xf,
                                       &set,
                                       red,
                                       (air_u16)AIR_COUNTOF(red),
                                       blue,
                                       (air_u16)AIR_COUNTOF(blue),
                                       diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    status = air_debug_build_primitives(&set, prims, (air_u16)AIR_COUNTOF(prims), &prim_count, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    for (i = 0; i < prim_count; ++i)
    {
        printf("%s %ld,%ld -> %ld,%ld\n",
               prims[i].color == AIR_DEBUG_COLOR_RED ? "RED" : "BLUE",
               (long)air_fx_to_int_floor(prims[i].rect.x1),
               (long)air_fx_to_int_floor(prims[i].rect.y1),
               (long)air_fx_to_int_floor(prims[i].rect.x2),
               (long)air_fx_to_int_floor(prims[i].rect.y2));
    }
    return AIR_STATUS_OK;
}

static int run_selftest(void)
{
    int rc;
    rc = system("./selftest");
    if (rc == -1)
    {
        fprintf(stderr, "failed to execute selftest\n");
        return 1;
    }
    return rc;
}

static int run_corpus(const char* path,
                      air_arena* asset_arena,
                      air_arena* scratch_arena,
                      const air_build_options* opts,
                      air_diag_list* diags,
                      char* file_buf,
                      air_u32 file_cap,
                      air_bool fail_fast,
                      air_bool quiet)
{
    DIR* dir;
    struct dirent* ent;
    int fail_count;

    dir = opendir(path);
    if (dir == AIR_NULL)
    {
        fprintf(stderr, "could not open directory: %s\n", path);
        return 1;
    }

    fail_count = 0;
    while ((ent = readdir(dir)) != AIR_NULL)
    {
        const char* dot;
        char full[512];
        air_program program;
        air_status status;

        dot = strrchr(ent->d_name, '.');
        if (dot == AIR_NULL || strcmp(dot, ".air") != 0)
        {
            continue;
        }

        sprintf(full, "%s/%s", path, ent->d_name);
        air_diag_list_reset(diags);
        status = load_text_program(full, &program, asset_arena, scratch_arena, opts, diags, file_buf, file_cap);
        if (status != AIR_STATUS_OK || air_diag_has_errors(diags))
        {
            ++fail_count;
            if (!quiet)
            {
                fprintf(stderr, "FAIL %s\n", full);
                print_diags(diags);
            }
            if (fail_fast)
            {
                break;
            }
        }
        else if (!quiet)
        {
            printf("PASS %s\n", full);
        }
    }
    closedir(dir);
    return fail_count == 0 ? 0 : 1;
}

int main(int argc, char** argv)
{
    static char file_buf[AIR_MAX_FILE_BYTES];
    static unsigned char asset_mem[1024 * 1024];
    static unsigned char scratch_mem[1024 * 1024];
    static air_diag diag_storage[AIR_MAX_DIAGS];
    air_arena asset_arena;
    air_arena scratch_arena;
    air_diag_list diags;
    air_build_options build_opts;
    air_parse_options parse_opts;
    air_trace_sink trace_sink;
    air_program program;
    air_ir_program ir;
    air_runtime rt;
    air_dump_sink dump_sink;
    air_status status;
    air_i32 action_no;
    air_i32 tick_value;
    air_bool trace_enabled;
    air_bool strict_mode;
    air_bool fail_fast;
    air_bool quiet;
    int argi;

    action_no = 0;
    tick_value = 0;
    trace_enabled = AIR_FALSE;
    strict_mode = AIR_FALSE;
    fail_fast = AIR_FALSE;
    quiet = AIR_FALSE;

    if (argc < 2)
    {
        print_usage();
        return 1;
    }

    for (argi = 1; argi < argc; ++argi)
    {
        if (strcmp(argv[argi], "--trace") == 0) trace_enabled = AIR_TRUE;
        else if (strcmp(argv[argi], "--strict") == 0) strict_mode = AIR_TRUE;
        else if (strcmp(argv[argi], "--fail-fast") == 0) fail_fast = AIR_TRUE;
        else if (strcmp(argv[argi], "--quiet") == 0) quiet = AIR_TRUE;
    }

    air_arena_init(&asset_arena, asset_mem, (air_u32)sizeof(asset_mem));
    air_arena_init(&scratch_arena, scratch_mem, (air_u32)sizeof(scratch_mem));
    air_diag_list_init(&diags, diag_storage, (air_u16)AIR_COUNTOF(diag_storage));
    air_build_options_default(&build_opts);
    air_parse_options_default(&parse_opts);
    build_opts.parse.permissive = strict_mode ? AIR_FALSE : AIR_TRUE;
    parse_opts.permissive = strict_mode ? AIR_FALSE : AIR_TRUE;

    if (trace_enabled)
    {
        trace_sink.fn = stderr_trace_sink;
        trace_sink.user = AIR_NULL;
        trace_sink.mask = AIR_TRACE_MASK_ALL;
        build_opts.trace = &trace_sink;
        build_opts.parse.trace = &trace_sink;
    }
    else
    {
        trace_sink.fn = AIR_NULL;
        trace_sink.user = AIR_NULL;
        trace_sink.mask = 0;
    }

    if (strcmp(argv[1], "selftest") == 0)
    {
        return run_selftest();
    }

    if (strcmp(argv[1], "corpus") == 0)
    {
        if (argc < 3)
        {
            print_usage();
            return 1;
        }
        return run_corpus(argv[2], &asset_arena, &scratch_arena, &build_opts, &diags, file_buf, (air_u32)sizeof(file_buf), fail_fast, quiet);
    }

    if (argc < 3)
    {
        print_usage();
        return 1;
    }

    if (strcmp(argv[1], "lex") == 0)
    {
        status = dump_lex(argv[2], &scratch_arena, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        return 0;
    }

    if (strcmp(argv[1], "parse") == 0)
    {
        status = dump_parse(argv[2], &scratch_arena, &parse_opts, &diags, file_buf, (air_u32)sizeof(file_buf), AIR_FALSE);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        print_diags(&diags);
        return air_diag_has_errors(&diags) ? 1 : 0;
    }

    if (strcmp(argv[1], "ast") == 0)
    {
        status = dump_parse(argv[2], &scratch_arena, &parse_opts, &diags, file_buf, (air_u32)sizeof(file_buf), AIR_TRUE);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        print_diags(&diags);
        return air_diag_has_errors(&diags) ? 1 : 0;
    }

    if (strcmp(argv[1], "ir") == 0)
    {
        air_diag_list_reset(&diags);
        status = load_text_ir(argv[2], &ir, &asset_arena, &scratch_arena, &parse_opts, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK && !(parse_opts.permissive && !air_diag_has_errors(&diags)))
        {
            print_diags(&diags);
            return 1;
        }
        dump_sink.fn = stdout_sink;
        dump_sink.user = AIR_NULL;
        status = air_ir_dump(&ir, &dump_sink, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        print_diags(&diags);
        return air_diag_has_errors(&diags) ? 1 : 0;
    }

    if (strcmp(argv[1], "compile") == 0)
    {
        air_diag_list_reset(&diags);
        status = load_text_ir(argv[2], &ir, &scratch_arena, &asset_arena, &build_opts.parse, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK || air_diag_has_errors(&diags))
        {
            print_diags(&diags);
            return 1;
        }
        air_arena_reset(&asset_arena);
        status = air_program_build_from_ir(&program, &asset_arena, &ir, &build_opts, &diags);
        if (status != AIR_STATUS_OK || air_diag_has_errors(&diags))
        {
            print_diags(&diags);
            return 1;
        }
        printf("ir_actions=%lu ir_elems=%lu ir_rects=%lu bc_actions=%lu insns=%lu rects=%lu\n",
               (unsigned long)ir.action_count,
               (unsigned long)ir.elem_count,
               (unsigned long)ir.rect_count,
               (unsigned long)program.action_count,
               (unsigned long)program.insn_count,
               (unsigned long)program.rect_count);
        return 0;
    }

    if (strcmp(argv[1], "validate") == 0 || strcmp(argv[1], "dump-bc") == 0)
    {
        air_diag_list_reset(&diags);
        status = load_text_program(argv[2], &program, &asset_arena, &scratch_arena, &build_opts, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK || air_diag_has_errors(&diags))
        {
            print_diags(&diags);
            return 1;
        }
        if (strcmp(argv[1], "validate") == 0)
        {
            printf("OK\n");
            return 0;
        }
        dump_sink.fn = stdout_sink;
        dump_sink.user = AIR_NULL;
        status = air_program_dump(&program, &dump_sink, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        return 0;
    }

    if (strcmp(argv[1], "save-bc") == 0)
    {
        static unsigned char bc_buf[1024 * 1024];
        air_u32 out_size;

        if (argc < 4)
        {
            print_usage();
            return 1;
        }
        air_diag_list_reset(&diags);
        status = load_text_program(argv[2], &program, &asset_arena, &scratch_arena, &build_opts, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        status = air_program_write_serialized(&program, bc_buf, (air_u32)sizeof(bc_buf), &out_size, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        status = air_file_write_all(argv[3], bc_buf, out_size);
        if (status != AIR_STATUS_OK)
        {
            fprintf(stderr, "failed to write %s\n", argv[3]);
            return 1;
        }
        printf("wrote %lu bytes\n", (unsigned long)out_size);
        return 0;
    }

    if (strcmp(argv[1], "load-bc") == 0)
    {
        static unsigned char bc_buf[1024 * 1024];
        air_u32 file_size;

        air_diag_list_reset(&diags);
        status = air_file_read_all(argv[2], bc_buf, (air_u32)sizeof(bc_buf), &file_size);
        if (status != AIR_STATUS_OK)
        {
            fprintf(stderr, "failed to read %s\n", argv[2]);
            return 1;
        }
        air_arena_reset(&asset_arena);
        status = air_program_read_serialized(&program, &asset_arena, bc_buf, file_size, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        printf("actions=%lu insns=%lu rects=%lu\n",
               (unsigned long)program.action_count,
               (unsigned long)program.insn_count,
               (unsigned long)program.rect_count);
        return 0;
    }

    if (strcmp(argv[1], "run") == 0 || strcmp(argv[1], "boxes") == 0)
    {
        air_diag_list_reset(&diags);
        status = load_text_program(argv[2], &program, &asset_arena, &scratch_arena, &build_opts, &diags, file_buf, (air_u32)sizeof(file_buf));
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }

        for (argi = 3; argi < argc; ++argi)
        {
            if ((strcmp(argv[argi], "--action") == 0 || strcmp(argv[argi], "-a") == 0) && argi + 1 < argc)
            {
                ++argi;
                if (!parse_i32(argv[argi], &action_no))
                {
                    fprintf(stderr, "bad action number\n");
                    return 1;
                }
            }
            else if ((strcmp(argv[argi], "--ticks") == 0 || strcmp(argv[argi], "--tick") == 0 || strcmp(argv[argi], "-t") == 0) && argi + 1 < argc)
            {
                ++argi;
                if (!parse_i32(argv[argi], &tick_value))
                {
                    fprintf(stderr, "bad tick value\n");
                    return 1;
                }
            }
        }

        air_runtime_init(&rt, &program, trace_enabled ? &trace_sink : AIR_NULL);
        status = air_runtime_set_action(&rt, action_no, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }
        status = air_runtime_step_ticks(&rt, tick_value, &diags);
        if (status != AIR_STATUS_OK)
        {
            print_diags(&diags);
            return 1;
        }

        print_pose(air_runtime_get_pose(&rt));
        if (strcmp(argv[1], "boxes") == 0)
        {
            status = run_boxes(&program, air_runtime_get_pose(&rt), &diags);
            if (status != AIR_STATUS_OK)
            {
                print_diags(&diags);
                return 1;
            }
        }
        return 0;
    }

    print_usage();
    return 1;
}
