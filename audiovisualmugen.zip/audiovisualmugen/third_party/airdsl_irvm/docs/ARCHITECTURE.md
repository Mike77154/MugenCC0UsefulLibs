# Architecture Notes

## Why this cut

The main rule in this version is:

> do not grow by stacking features on top;
> grow by separating responsibilities and formalizing contracts.

That means each layer should be:

- testable alone
- compilable alone
- reusable alone
- linkable alone

## Asset vs instance

### `air_ir_program`
Normalized semantic asset:
- actions
- elements
- rect tables
- inherited boxes resolved per element

### `air_program`
Immutable lowered VM asset:
- actions
- instructions
- rect tables

### `air_runtime`
Per-entity live state:
- current action binding
- current element index
- per-element tick
- global tick
- loop flags
- finished flag for `-1` terminal holds

This lets one compiled AIR serve many entities.

## Text pipeline

```text
source text
  -> lexer
  -> syntax classifier
  -> AST parser
  -> IR builder
  -> IR validate
  -> lower to VM bytecode
  -> bytecode verifier
  -> VM/runtime
```

## VM responsibilities

The VM is intentionally smaller than the runtime.

VM handles:
- opcode interpretation
- current default/once box refs
- action-local instruction pointer
- emitting the next committed element sample

Runtime adds:
- tick stepping
- seek / rewind
- action change flags
- loop counters
- finished state
- trace emission

## Boxes subsystem

The runtime does not directly world-transform rectangles.

Instead:

1. runtime exposes the current pose sample
2. boxes layer resolves raw rect refs
3. transform layer applies:
   - scaling policy
   - facing
   - origin
4. debugdraw layer emits red/blue primitives

That makes collision integration host-agnostic.

## Strict vs permissive

Strict mode:
- fail fast
- useful for authoring and CI

Permissive mode:
- keep moving through line-level junk when possible
- good for corpus inspection and community files

## Selective linkage

The Makefile emits layer libraries so a host can link only what it needs.

Examples:

- syntax tooling only  
  `libairbase + libairtext + libairast`

- IR inspection only  
  `+ libairir`

- offline compiler / VM dump  
  `+ libairir + libairvm`

- runtime playback on precompiled data  
  `libairbase + libairir + libairvm + libairruntime + libairboxes`

- tooling / dumps  
  `+ libairdebug`

## Known next extensions

This version already formalizes the stack, but the obvious next upgrades are:

- deeper recoverable parsing
- stronger corpus coverage
- optional diff tooling for AIRBC blobs
- perf counters
- richer JSON-ish CLI output
- optional rotated box policy
