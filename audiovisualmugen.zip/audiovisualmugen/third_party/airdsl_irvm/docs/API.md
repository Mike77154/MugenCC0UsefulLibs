# Minimal Host Integration

```c
#include "air/air_api.h"

static unsigned char asset_mem[512 * 1024];
static unsigned char scratch_mem[512 * 1024];
static air_diag diag_storage[AIR_MAX_DIAGS];

int load_and_play(const char* text, air_u32 len)
{
    air_arena asset_arena;
    air_arena scratch_arena;
    air_diag_list diags;
    air_build_options opts;
    air_program program;
    air_runtime rt;
    const air_pose_sample* sample;

    air_arena_init(&asset_arena, asset_mem, (air_u32)sizeof(asset_mem));
    air_arena_init(&scratch_arena, scratch_mem, (air_u32)sizeof(scratch_mem));
    air_diag_list_init(&diags, diag_storage, (air_u16)AIR_COUNTOF(diag_storage));
    air_build_options_default(&opts);

    if (air_program_build_from_text(&program, &asset_arena, &scratch_arena, text, len, &opts, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }

    air_runtime_init(&rt, &program, AIR_NULL);
    if (air_runtime_set_action(&rt, 0, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }
    if (air_runtime_step_ticks(&rt, 3, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }

    sample = air_runtime_get_pose(&rt);

    /*
      sample->pose.group_no / image_no are backend-agnostic keys.
      Resolve them however your renderer wants.
    */

    return sample != AIR_NULL ? 0 : 1;
}
```

## IR-first flow

```c
air_ir_program ir;
air_program program;

air_ir_build_from_text(&ir, &scratch_arena, &asset_arena, text, len, &opts.parse, &diags);
air_program_build_from_ir(&program, &asset_arena, &ir, &opts, &diags);
```

Use this path when you want to:

- inspect normalized AIR semantics before lowering
- run extra validation or transforms
- cache or diff the IR stage separately from VM bytecode

## Collision hookup

```c
air_box_transform xf;
air_boxset set;
air_rect_fx clsn1[64];
air_rect_fx clsn2[64];

air_box_transform_default(&xf);
xf.origin_x = air_fx_from_int(world_x);
xf.origin_y = air_fx_from_int(world_y);
xf.facing_right = facing_right;

air_boxes_build_from_pose(&program,
                          air_runtime_get_pose(&rt),
                          &xf,
                          &set,
                          clsn1, 64,
                          clsn2, 64,
                          &diags);
```

## Debug rectangles

```c
air_debug_primitive prims[128];
air_u16 prim_count;

air_debug_build_primitives(&set, prims, 128, &prim_count, &diags);
```
