# IR / VM Split

This revision makes the pipeline explicit instead of treating the compiled program as the only intermediate.

```text
AIR text
  -> lexer / syntax / AST
  -> air_ir_program      (normalized semantic IR)
  -> air_program         (lowered VM bytecode)
  -> air_vm / air_runtime
```

## `air_ir_program`

The IR resolves the AIR authoring model into stable semantic records:

- action table
- element table
- per-element final collision refs after default/one-shot inheritance
- interpolation edge mask carried by each element toward the next one

It is ideal for:

- inspectors
- custom validators
- alternate lowerings
- corpus tooling
- editor integration

## `air_program`

The VM asset is the compact executable form:

- bytecode instructions
- action to instruction ranges
- rect table for runtime / boxes
- serializable `.airbc` payload

It is ideal for:

- shipping precompiled data
- fast runtime stepping
- disassembly / dumps
- sharing one immutable asset across many entities

## Important behavior preserved by the IR

- `Loopstart` becomes `loop_elem`
- `Clsn1` / `Clsn2` inheritance is resolved per element
- one-shot empty declarations such as `Clsn2: 0` override defaults for the next element
- interpolation lines are attached to the outgoing edge of the current element
