#include <string.h>
#include "air/air_runtime.h"

air_status air_runtime_init(air_runtime* rt, const air_program* program, const air_trace_sink* trace)
{
    if (rt == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }
    memset(rt, 0, sizeof(*rt));
    rt->program = program;
    rt->trace = trace;
    rt->sample.action_no = -1;
    air_vm_init(&rt->vm, program);
    air_timeline_reset(&rt->timeline);
    return AIR_STATUS_OK;
}

void air_runtime_reset(air_runtime* rt)
{
    if (rt == AIR_NULL)
    {
        return;
    }
    rt->action = AIR_NULL;
    air_vm_init(&rt->vm, rt->program);
    air_timeline_reset(&rt->timeline);
    air_pose_sample_clear(&rt->sample);
    rt->time_left = 0;
    rt->loop_count = 0;
    rt->active = AIR_FALSE;
    rt->valid = AIR_FALSE;
    rt->finished = AIR_FALSE;
    rt->changed_action = AIR_FALSE;
    rt->looped = AIR_FALSE;
}

static air_status air_runtime_load_current(air_runtime* rt, air_diag_list* diags)
{
    air_u32 prev_loop_hits;
    air_status status;

    prev_loop_hits = rt->vm.loop_hits;
    status = air_vm_advance_to_commit(&rt->vm, &rt->sample, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    rt->time_left = rt->sample.pose.time;
    rt->timeline.tick_in_elem = 0;
    rt->sample.tick_in_elem = 0;
    rt->looped = (air_bool)(rt->vm.loop_hits != prev_loop_hits);
    if (rt->looped)
    {
        ++rt->loop_count;
        air_trace_emit(rt->trace, AIR_TRACE_LOOP_HIT, 0, rt->sample.action_no, (air_i32)rt->sample.elem_index, rt->timeline.global_tick, rt->vm.pc, "loop");
    }
    air_trace_emit(rt->trace, AIR_TRACE_ELEM_ADVANCE, 0, rt->sample.action_no, (air_i32)rt->sample.elem_index, rt->timeline.global_tick, rt->vm.pc, "elem");
    return AIR_STATUS_OK;
}

air_status air_runtime_set_action(air_runtime* rt, air_i32 action_no, air_diag_list* diags)
{
    air_status status;

    if (rt == AIR_NULL || rt->program == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, action_no, -1, "runtime: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    status = air_vm_bind_action(&rt->vm, action_no, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }

    rt->action = rt->vm.action;
    air_timeline_reset(&rt->timeline);
    rt->time_left = 0;
    rt->active = AIR_TRUE;
    rt->valid = AIR_TRUE;
    rt->finished = AIR_FALSE;
    rt->changed_action = AIR_TRUE;
    rt->looped = AIR_FALSE;
    rt->loop_count = 0;

    air_trace_emit(rt->trace, AIR_TRACE_ACTION_CHANGE, rt->action->line, action_no, -1, 0, rt->vm.pc, "action");
    return air_runtime_load_current(rt, diags);
}

air_status air_runtime_step_ticks(air_runtime* rt, air_tick_t ticks, air_diag_list* diags)
{
    if (rt == AIR_NULL || !rt->active)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "runtime: inactive runtime");
        return AIR_STATUS_EINVAL;
    }
    if (ticks < 0)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, rt->sample.action_no, -1, "runtime: negative tick count");
        return AIR_STATUS_EINVAL;
    }

    rt->changed_action = AIR_FALSE;
    rt->looped = AIR_FALSE;

    while (ticks > 0)
    {
        if (rt->time_left == -1)
        {
            rt->timeline.global_tick += ticks;
            rt->timeline.action_tick += ticks;
            rt->timeline.tick_in_elem += ticks;
            rt->sample.tick_in_elem = rt->timeline.tick_in_elem;
            rt->finished = AIR_TRUE;
            return AIR_STATUS_OK;
        }
        if (rt->time_left <= 0)
        {
            air_status status;
            status = air_runtime_load_current(rt, diags);
            if (status != AIR_STATUS_OK)
            {
                return status;
            }
            continue;
        }
        if (ticks < rt->time_left)
        {
            rt->time_left -= ticks;
            rt->timeline.global_tick += ticks;
            rt->timeline.action_tick += ticks;
            rt->timeline.tick_in_elem += ticks;
            rt->sample.tick_in_elem = rt->timeline.tick_in_elem;
            return AIR_STATUS_OK;
        }

        ticks -= rt->time_left;
        rt->timeline.global_tick += rt->time_left;
        rt->timeline.action_tick += rt->time_left;
        rt->timeline.tick_in_elem += rt->time_left;
        rt->sample.tick_in_elem = rt->timeline.tick_in_elem;
        rt->time_left = 0;
        {
            air_status status;
            status = air_runtime_load_current(rt, diags);
            if (status != AIR_STATUS_OK)
            {
                return status;
            }
        }
    }

    return AIR_STATUS_OK;
}

air_status air_runtime_seek_tick(air_runtime* rt, air_tick_t tick, air_diag_list* diags)
{
    air_i32 action_no;

    if (rt == AIR_NULL || rt->action == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ESTATE, AIR_DIAG_ERROR, 0, 0, -1, -1, "runtime: no current action");
        return AIR_STATUS_ESTATE;
    }
    if (tick < 0)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, rt->action->action_no, -1, "runtime: negative tick");
        return AIR_STATUS_EINVAL;
    }
    action_no = rt->action->action_no;
    if (air_runtime_set_action(rt, action_no, diags) != AIR_STATUS_OK)
    {
        return AIR_STATUS_ESTATE;
    }
    return air_runtime_step_ticks(rt, tick, diags);
}

air_status air_runtime_rewind(air_runtime* rt, air_diag_list* diags)
{
    if (rt == AIR_NULL || rt->action == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ESTATE, AIR_DIAG_ERROR, 0, 0, -1, -1, "runtime: no action to rewind");
        return AIR_STATUS_ESTATE;
    }
    return air_runtime_set_action(rt, rt->action->action_no, diags);
}

const air_pose_sample* air_runtime_get_pose(const air_runtime* rt)
{
    if (rt == AIR_NULL || !rt->valid)
    {
        return AIR_NULL;
    }
    return &rt->sample;
}

air_status air_runtime_get_boxes(const air_runtime* rt,
                                 const air_rect_i** out_clsn1,
                                 air_u16* out_clsn1_count,
                                 const air_rect_i** out_clsn2,
                                 air_u16* out_clsn2_count)
{
    if (rt == AIR_NULL || rt->program == AIR_NULL || !rt->valid)
    {
        return AIR_STATUS_EINVAL;
    }
    if (out_clsn1 != AIR_NULL)
    {
        *out_clsn1 = rt->sample.clsn1.count != 0 ? rt->program->rects + rt->sample.clsn1.first : AIR_NULL;
    }
    if (out_clsn1_count != AIR_NULL)
    {
        *out_clsn1_count = rt->sample.clsn1.count;
    }
    if (out_clsn2 != AIR_NULL)
    {
        *out_clsn2 = rt->sample.clsn2.count != 0 ? rt->program->rects + rt->sample.clsn2.first : AIR_NULL;
    }
    if (out_clsn2_count != AIR_NULL)
    {
        *out_clsn2_count = rt->sample.clsn2.count;
    }
    return AIR_STATUS_OK;
}

air_bool air_runtime_has_looped(const air_runtime* rt)
{
    if (rt == AIR_NULL)
    {
        return AIR_FALSE;
    }
    return rt->looped;
}

air_bool air_runtime_is_finished(const air_runtime* rt)
{
    if (rt == AIR_NULL)
    {
        return AIR_FALSE;
    }
    return rt->finished;
}

air_tick_t air_runtime_global_ticks(const air_runtime* rt)
{
    if (rt == AIR_NULL)
    {
        return 0;
    }
    return rt->timeline.global_tick;
}

air_status air_runtime_sample_at(air_runtime* rt,
                                 air_i32 action_no,
                                 air_tick_t tick,
                                 air_pose_sample* out_sample,
                                 air_diag_list* diags)
{
    air_status status;

    if (rt == AIR_NULL || out_sample == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }
    status = air_runtime_set_action(rt, action_no, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    status = air_runtime_step_ticks(rt, tick, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    *out_sample = rt->sample;
    return AIR_STATUS_OK;
}
