#include <string.h>
#include "air/air_timeline.h"

void air_timeline_reset(air_timeline* timeline)
{
    if (timeline == AIR_NULL)
    {
        return;
    }
    memset(timeline, 0, sizeof(*timeline));
}
