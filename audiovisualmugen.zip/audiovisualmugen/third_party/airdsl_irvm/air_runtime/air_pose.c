#include <string.h>
#include "air/air_pose.h"

void air_pose_clear(air_pose* pose)
{
    if (pose == AIR_NULL)
    {
        return;
    }
    memset(pose, 0, sizeof(*pose));
    pose->scale_x = AIR_FIXED_ONE;
    pose->scale_y = AIR_FIXED_ONE;
}

void air_pose_sample_clear(air_pose_sample* sample)
{
    if (sample == AIR_NULL)
    {
        return;
    }
    memset(sample, 0, sizeof(*sample));
    sample->action_no = -1;
    air_pose_clear(&sample->pose);
}
