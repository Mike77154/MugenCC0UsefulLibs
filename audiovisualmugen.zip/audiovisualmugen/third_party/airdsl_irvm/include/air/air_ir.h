#ifndef AIR_IR_H
#define AIR_IR_H

#include "air_ast.h"
#include "air_bc.h"
#include "air_dump_sink.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef struct air_ir_box_ref
{
    air_u32 first;
    air_u16 count;
} air_ir_box_ref;

typedef struct air_ir_rect
{
    air_i32 x1;
    air_i32 y1;
    air_i32 x2;
    air_i32 y2;
} air_ir_rect;

typedef struct air_ir_elem
{
    air_i32 group_no;
    air_i32 image_no;
    air_i32 x;
    air_i32 y;
    air_tick_t time;
    air_u8 flip;
    air_u8 blend_fn;
    air_u16 src_alpha;
    air_u16 dst_alpha;
    air_fx scale_x;
    air_fx scale_y;
    air_fx angle_deg;
    air_u8 interp_to_next_mask;
    air_u8 reserved0;
    air_u16 line;
    air_ir_box_ref clsn1;
    air_ir_box_ref clsn2;
} air_ir_elem;

enum
{
    AIR_IR_ACTION_FLAG_HAS_LOOP = 1U,
    AIR_IR_ACTION_FLAG_NO_LOOP = 2U
};

typedef struct air_ir_action
{
    air_i32 action_no;
    air_u32 elem_first;
    air_u32 elem_count;
    air_u32 loop_elem;
    air_u16 line;
    air_u16 flags;
} air_ir_action;

typedef struct air_ir_program
{
    air_u32 abi_version;
    air_ir_action* actions;
    air_u32 action_count;
    air_ir_elem* elems;
    air_u32 elem_count;
    air_ir_rect* rects;
    air_u32 rect_count;
} air_ir_program;

void air_ir_program_zero(air_ir_program* ir);
const air_ir_action* air_ir_find_action(const air_ir_program* ir, air_i32 action_no);
air_status air_ir_build_from_ast(air_ir_program* out_ir,
                                 air_arena* arena,
                                 const air_ast* ast,
                                 air_diag_list* diags);
air_status air_ir_build_from_text(air_ir_program* out_ir,
                                  air_arena* ir_arena,
                                  air_arena* scratch_arena,
                                  const char* text,
                                  air_u32 len,
                                  const air_parse_options* opts,
                                  air_diag_list* diags);
air_status air_ir_build_from_tokens(air_ir_program* out_ir,
                                    air_arena* ir_arena,
                                    air_arena* scratch_arena,
                                    const air_token_stream* tokens,
                                    const air_parse_options* opts,
                                    air_diag_list* diags);
air_status air_ir_validate(const air_ir_program* ir, air_diag_list* diags);
air_status air_ir_dump(const air_ir_program* ir, const air_dump_sink* sink, air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
