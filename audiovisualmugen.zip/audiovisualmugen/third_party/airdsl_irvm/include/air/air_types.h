#ifndef AIR_TYPES_H
#define AIR_TYPES_H

#include <limits.h>

#ifdef __cplusplus
extern "C" {
#endif

#if UCHAR_MAX != 255U
#error "airdsl requires 8-bit unsigned char"
#endif

#if USHRT_MAX != 65535U
#error "airdsl requires 16-bit unsigned short"
#endif

#if INT_MAX == 2147483647
typedef signed int air_i32;
typedef unsigned int air_u32;
#elif LONG_MAX == 2147483647L
typedef signed long air_i32;
typedef unsigned long air_u32;
#else
#error "airdsl requires a 32-bit int or long"
#endif

typedef signed char air_i8;
typedef unsigned char air_u8;
typedef signed short air_i16;
typedef unsigned short air_u16;
typedef int air_bool;
typedef air_i32 air_tick_t;

#ifndef AIR_TRUE
#define AIR_TRUE 1
#endif

#ifndef AIR_FALSE
#define AIR_FALSE 0
#endif

#ifndef AIR_NULL
#define AIR_NULL ((void*)0)
#endif

#ifndef AIR_API_VERSION
#define AIR_API_VERSION 0x00010000UL
#endif

#define AIR_COUNTOF(a) ((air_u32)(sizeof(a) / sizeof((a)[0])))

#ifdef __cplusplus
}
#endif

#endif
