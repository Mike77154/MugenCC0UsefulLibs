#ifndef AIR_VM_DECODE_H
#define AIR_VM_DECODE_H

#include "air_bc.h"

#ifdef __cplusplus
extern "C" {
#endif

const char* air_vm_opcode_name(air_u8 opcode);
air_status air_vm_decode_insn(const air_insn* insn, char* buffer, air_u32 capacity);

#ifdef __cplusplus
}
#endif

#endif
