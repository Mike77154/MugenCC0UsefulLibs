#ifndef AIR_BOXES_H
#define AIR_BOXES_H

#include "air_box_transform.h"

#ifdef __cplusplus
extern "C" {
#endif

air_status air_boxes_to_rects(const air_program* program,
                              air_box_ref ref,
                              air_rect_fx* out_rects,
                              air_u16 capacity,
                              air_diag_list* diags);

air_status air_boxes_build_from_pose(const air_program* program,
                                     const air_pose_sample* sample,
                                     const air_box_transform* xf,
                                     air_boxset* out_set,
                                     air_rect_fx* clsn1_buffer,
                                     air_u16 clsn1_capacity,
                                     air_rect_fx* clsn2_buffer,
                                     air_u16 clsn2_capacity,
                                     air_diag_list* diags);

void air_boxes_debug_colors(air_u8* out_clsn1_color, air_u8* out_clsn2_color);

#ifdef __cplusplus
}
#endif

#endif
