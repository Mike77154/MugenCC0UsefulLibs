#ifndef AIR_STATUS_H
#define AIR_STATUS_H

#include "air_types.h"
#include "air_limits.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_status
{
    AIR_STATUS_OK = 0,
    AIR_STATUS_EINVAL = 1,
    AIR_STATUS_ENOMEM = 2,
    AIR_STATUS_ESYNTAX = 3,
    AIR_STATUS_ESEMANTIC = 4,
    AIR_STATUS_EVERIFY = 5,
    AIR_STATUS_ERANGE = 6,
    AIR_STATUS_ENOTFOUND = 7,
    AIR_STATUS_ESTATE = 8,
    AIR_STATUS_EIO = 9,
    AIR_STATUS_EUNSUPPORTED = 10,
    AIR_STATUS_EOVERFLOW = 11
} air_status;

typedef enum air_diag_severity
{
    AIR_DIAG_INFO = 0,
    AIR_DIAG_WARNING = 1,
    AIR_DIAG_ERROR = 2
} air_diag_severity;

typedef struct air_diag
{
    air_status code;
    air_diag_severity severity;
    air_i32 line;
    air_i32 column;
    air_i32 action_no;
    air_i32 elem_index;
    char message[AIR_MAX_DIAG_MESSAGE];
} air_diag;

typedef struct air_diag_list
{
    air_diag* items;
    air_u16 capacity;
    air_u16 count;
    air_u16 error_count;
    air_u16 warning_count;
} air_diag_list;

const char* air_status_name(air_status status);
const char* air_diag_severity_name(air_diag_severity severity);

void air_diag_list_init(air_diag_list* list, air_diag* storage, air_u16 capacity);
void air_diag_list_reset(air_diag_list* list);
air_status air_diag_push(air_diag_list* list,
                         air_status code,
                         air_diag_severity severity,
                         air_i32 line,
                         air_i32 column,
                         air_i32 action_no,
                         air_i32 elem_index,
                         const char* message);
const air_diag* air_diag_last(const air_diag_list* list);
air_bool air_diag_has_errors(const air_diag_list* list);
void air_diag_format(const air_diag* diag, char* buffer, air_u32 capacity);

#ifdef __cplusplus
}
#endif

#endif
