#ifndef AIR_TRACE_H
#define AIR_TRACE_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_trace_kind
{
    AIR_TRACE_PARSER = 0,
    AIR_TRACE_COMPILE = 1,
    AIR_TRACE_ACTION_CHANGE = 2,
    AIR_TRACE_LOOP_HIT = 3,
    AIR_TRACE_ELEM_ADVANCE = 4,
    AIR_TRACE_POSE_UPDATE = 5,
    AIR_TRACE_BOX_BUILD = 6
} air_trace_kind;

#define AIR_TRACE_MASK(kind) (1UL << (air_u32)(kind))
#define AIR_TRACE_MASK_ALL 0xFFFFFFFFUL

typedef struct air_trace_event
{
    air_trace_kind kind;
    air_i32 line;
    air_i32 action_no;
    air_i32 elem_index;
    air_tick_t tick;
    air_u32 pc;
    const char* message;
} air_trace_event;

typedef void (*air_trace_fn)(void* user, const air_trace_event* event);

typedef struct air_trace_sink
{
    air_trace_fn fn;
    void* user;
    air_u32 mask;
} air_trace_sink;

void air_trace_emit(const air_trace_sink* sink,
                    air_trace_kind kind,
                    air_i32 line,
                    air_i32 action_no,
                    air_i32 elem_index,
                    air_tick_t tick,
                    air_u32 pc,
                    const char* message);

#ifdef __cplusplus
}
#endif

#endif
