#ifndef AIR_VM_OPS_H
#define AIR_VM_OPS_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_opcode
{
    AIR_OP_NOP = 0,
    AIR_OP_SET_SPRITE = 1,
    AIR_OP_SET_TIME = 2,
    AIR_OP_SET_OFFSET = 3,
    AIR_OP_SET_FLIP = 4,
    AIR_OP_SET_BLEND = 5,
    AIR_OP_SET_SCALE = 6,
    AIR_OP_SET_ANGLE = 7,
    AIR_OP_SET_INTERP = 8,
    AIR_OP_SET_CLSN_DEFAULT = 9,
    AIR_OP_SET_CLSN_ONCE = 10,
    AIR_OP_PUSH_ELEM_BOXES = 11,
    AIR_OP_MARK_LOOP = 12,
    AIR_OP_COMMIT_ELEM = 13,
    AIR_OP_END_ACTION = 14
} air_opcode;

#ifdef __cplusplus
}
#endif

#endif
