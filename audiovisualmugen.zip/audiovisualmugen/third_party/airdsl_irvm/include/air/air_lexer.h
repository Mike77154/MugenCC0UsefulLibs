#ifndef AIR_LEXER_H
#define AIR_LEXER_H

#include "air_status.h"
#include "air_arena.h"
#include "air_token.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_lex_options
{
    air_bool reserved;
} air_lex_options;

void air_lex_options_default(air_lex_options* opts);
air_status air_lex_line(const char* text,
                        air_u16 len,
                        air_u16 line_number,
                        air_token_line* out_tokens,
                        air_diag_list* diags);
air_status air_lex_text(air_token_stream* out_stream,
                        air_arena* arena,
                        const char* text,
                        air_u32 len,
                        const air_lex_options* opts,
                        air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
