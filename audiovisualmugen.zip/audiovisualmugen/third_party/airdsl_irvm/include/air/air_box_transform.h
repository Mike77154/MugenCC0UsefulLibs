#ifndef AIR_BOX_TRANSFORM_H
#define AIR_BOX_TRANSFORM_H

#include "air_boxset.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_box_policy
{
    AIR_BOX_POLICY_CLASSIC = 1,
    AIR_BOX_POLICY_SCALE_XY = 2,
    AIR_BOX_POLICY_IGNORE_ANGLE = 4,
    AIR_BOX_POLICY_VISUAL_MATCH = 8
} air_box_policy;

typedef struct air_box_transform
{
    air_fx origin_x;
    air_fx origin_y;
    air_bool facing_right;
    air_fx scale_x;
    air_fx scale_y;
    air_u32 policy;
} air_box_transform;

void air_box_transform_default(air_box_transform* xf);
void air_boxes_apply_origin(air_rect_fx* rects, air_u16 count, air_fx origin_x, air_fx origin_y);
void air_boxes_apply_facing(air_rect_fx* rects, air_u16 count, air_bool facing_right);
void air_boxes_apply_scale_policy(air_rect_fx* rects,
                                  air_u16 count,
                                  air_fx scale_x,
                                  air_fx scale_y,
                                  air_u32 policy);

#ifdef __cplusplus
}
#endif

#endif
