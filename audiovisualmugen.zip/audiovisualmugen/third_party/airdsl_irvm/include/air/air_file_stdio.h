#ifndef AIR_FILE_STDIO_H
#define AIR_FILE_STDIO_H

#include "air_status.h"

#ifdef __cplusplus
extern "C" {
#endif

air_status air_file_read_all(const char* path, void* buffer, air_u32 capacity, air_u32* out_size);
air_status air_file_write_all(const char* path, const void* data, air_u32 size);

#ifdef __cplusplus
}
#endif

#endif
