#ifndef AIR_PARSER_H
#define AIR_PARSER_H

#include "air_ast.h"
#include "air_arena.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_parse_result
{
    air_token_stream tokens;
    air_ast ast;
} air_parse_result;

air_status air_parser_parse_text(air_parse_result* out_result,
                                 air_arena* arena,
                                 const char* text,
                                 air_u32 len,
                                 const air_parse_options* opts,
                                 air_diag_list* diags);

air_status air_parser_parse_tokens(air_parse_result* out_result,
                                   air_arena* arena,
                                   const air_token_stream* tokens,
                                   const air_parse_options* opts,
                                   air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
