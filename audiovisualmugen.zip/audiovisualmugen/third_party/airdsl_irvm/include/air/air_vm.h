#ifndef AIR_VM_H
#define AIR_VM_H

#include "air_pose.h"
#include "air_vm_dump.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_vm_state
{
    const air_program* program;
    const air_action* action;
    air_u32 pc;
    air_u32 elem_index;
    air_u32 loop_hits;
    air_box_ref def1;
    air_box_ref def2;
    air_box_ref once1;
    air_box_ref once2;
    air_u8 has_once1;
    air_u8 has_once2;
    air_pose current_pose;
    air_u8 current_boxes_pushed;
    air_box_ref current_clsn1;
    air_box_ref current_clsn2;
} air_vm_state;

void air_vm_init(air_vm_state* vm, const air_program* program);
air_status air_vm_bind_action(air_vm_state* vm, air_i32 action_no, air_diag_list* diags);
air_status air_vm_reset_action(air_vm_state* vm, air_diag_list* diags);
air_status air_vm_advance_to_commit(air_vm_state* vm, air_pose_sample* out_sample, air_diag_list* diags);
air_status air_vm_step_elem(air_vm_state* vm, air_pose_sample* out_sample, air_diag_list* diags);
const air_pose* air_vm_current_pose(const air_vm_state* vm);
air_u32 air_vm_loop_count(const air_vm_state* vm);

#ifdef __cplusplus
}
#endif

#endif
