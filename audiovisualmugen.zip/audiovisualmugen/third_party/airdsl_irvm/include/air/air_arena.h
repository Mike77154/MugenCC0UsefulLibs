#ifndef AIR_ARENA_H
#define AIR_ARENA_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_arena
{
    air_u8* base;
    air_u32 capacity;
    air_u32 used;
    air_u32 peak_used;
} air_arena;

void air_arena_init(air_arena* arena, void* memory, air_u32 capacity);
void air_arena_reset(air_arena* arena);
void* air_arena_alloc(air_arena* arena, air_u32 size, air_u32 align);
air_u32 air_arena_mark(const air_arena* arena);
void air_arena_rewind(air_arena* arena, air_u32 mark);

#ifdef __cplusplus
}
#endif

#endif
