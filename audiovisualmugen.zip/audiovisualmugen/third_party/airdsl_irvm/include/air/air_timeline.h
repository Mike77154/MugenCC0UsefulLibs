#ifndef AIR_TIMELINE_H
#define AIR_TIMELINE_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_step_mode
{
    AIR_STEP_FIXED_TICK = 0,
    AIR_STEP_SAMPLE_EXACT_TICK = 1,
    AIR_STEP_ADVANCE_N_TICKS = 2
} air_step_mode;

typedef struct air_timeline
{
    air_tick_t global_tick;
    air_tick_t action_tick;
    air_tick_t tick_in_elem;
} air_timeline;

void air_timeline_reset(air_timeline* timeline);

#ifdef __cplusplus
}
#endif

#endif
