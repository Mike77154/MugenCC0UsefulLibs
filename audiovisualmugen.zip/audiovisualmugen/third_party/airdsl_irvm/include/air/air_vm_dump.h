#ifndef AIR_VM_DUMP_H
#define AIR_VM_DUMP_H

#include "air_vm_decode.h"
#include "air_dump_sink.h"

#ifdef __cplusplus
extern "C" {
#endif

air_status air_vm_dump_program(const air_program* program, const air_dump_sink* sink, air_diag_list* diags);
air_status air_vm_dump_action(const air_program* program, air_i32 action_no, const air_dump_sink* sink, air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
