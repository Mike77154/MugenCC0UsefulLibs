#ifndef AIR_RUNTIME_H
#define AIR_RUNTIME_H

#include "air_vm.h"
#include "air_timeline.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_runtime
{
    const air_program* program;
    const air_action* action;
    air_vm_state vm;
    air_timeline timeline;
    air_pose_sample sample;
    air_tick_t time_left;
    air_u32 loop_count;
    air_bool active;
    air_bool valid;
    air_bool finished;
    air_bool changed_action;
    air_bool looped;
    const air_trace_sink* trace;
} air_runtime;

air_status air_runtime_init(air_runtime* rt, const air_program* program, const air_trace_sink* trace);
void air_runtime_reset(air_runtime* rt);
air_status air_runtime_set_action(air_runtime* rt, air_i32 action_no, air_diag_list* diags);
air_status air_runtime_step_ticks(air_runtime* rt, air_tick_t ticks, air_diag_list* diags);
air_status air_runtime_seek_tick(air_runtime* rt, air_tick_t tick, air_diag_list* diags);
air_status air_runtime_rewind(air_runtime* rt, air_diag_list* diags);
const air_pose_sample* air_runtime_get_pose(const air_runtime* rt);
air_status air_runtime_get_boxes(const air_runtime* rt,
                                 const air_rect_i** out_clsn1,
                                 air_u16* out_clsn1_count,
                                 const air_rect_i** out_clsn2,
                                 air_u16* out_clsn2_count);
air_bool air_runtime_has_looped(const air_runtime* rt);
air_bool air_runtime_is_finished(const air_runtime* rt);
air_tick_t air_runtime_global_ticks(const air_runtime* rt);
air_status air_runtime_sample_at(air_runtime* rt,
                                 air_i32 action_no,
                                 air_tick_t tick,
                                 air_pose_sample* out_sample,
                                 air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
