#ifndef AIR_BC_H
#define AIR_BC_H

#include "air_ast.h"
#include "air_vm_ops.h"

#ifdef __cplusplus
extern "C" {
#endif

#define AIR_PROGRAM_MAGIC 0x31434241UL
#define AIR_PROGRAM_SERIAL_VERSION 1UL

typedef struct air_rect_i
{
    air_i32 x1;
    air_i32 y1;
    air_i32 x2;
    air_i32 y2;
} air_rect_i;

typedef struct air_insn
{
    air_u8 opcode;
    air_u8 flags;
    air_u16 reserved;
    air_i32 operand_a;
    air_i32 operand_b;
    air_i32 operand_c;
} air_insn;

typedef struct air_action
{
    air_i32 action_no;
    air_u32 insn_first;
    air_u32 insn_count;
    air_u32 elem_count;
    air_u32 loop_insn;
    air_u32 loop_elem;
    air_u16 line;
    air_u16 flags;
} air_action;

typedef struct air_program
{
    air_u32 abi_version;
    air_action* actions;
    air_u32 action_count;
    air_insn* insns;
    air_u32 insn_count;
    air_rect_i* rects;
    air_u32 rect_count;
} air_program;

void air_program_zero(air_program* program);
const air_action* air_program_find_action(const air_program* program, air_i32 action_no);

air_status air_program_measure_serialized(const air_program* program, air_u32* out_size);
air_status air_program_write_serialized(const air_program* program,
                                        void* buffer,
                                        air_u32 capacity,
                                        air_u32* out_size,
                                        air_diag_list* diags);
air_status air_program_read_serialized(air_program* out_program,
                                       air_arena* arena,
                                       const void* buffer,
                                       air_u32 size,
                                       air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
