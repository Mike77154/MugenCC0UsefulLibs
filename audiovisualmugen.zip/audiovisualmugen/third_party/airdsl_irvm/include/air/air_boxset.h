#ifndef AIR_BOXSET_H
#define AIR_BOXSET_H

#include "air_pose.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_rect_fx
{
    air_fx x1;
    air_fx y1;
    air_fx x2;
    air_fx y2;
} air_rect_fx;

typedef struct air_boxset
{
    air_rect_fx* clsn1;
    air_u16 clsn1_count;
    air_rect_fx* clsn2;
    air_u16 clsn2_count;
} air_boxset;

void air_boxset_init(air_boxset* set,
                     air_rect_fx* clsn1,
                     air_u16 clsn1_count,
                     air_rect_fx* clsn2,
                     air_u16 clsn2_count);
air_bool air_boxset_overlap(const air_rect_fx* a, const air_rect_fx* b);
air_bool air_boxset_attack_hits(const air_boxset* attacker, const air_boxset* defender);

#ifdef __cplusplus
}
#endif

#endif
