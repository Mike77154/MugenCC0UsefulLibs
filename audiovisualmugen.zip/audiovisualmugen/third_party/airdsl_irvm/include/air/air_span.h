#ifndef AIR_SPAN_H
#define AIR_SPAN_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_span
{
    const void* ptr;
    air_u32 count;
} air_span;

typedef struct air_mut_span
{
    void* ptr;
    air_u32 count;
} air_mut_span;

#ifdef __cplusplus
}
#endif

#endif
