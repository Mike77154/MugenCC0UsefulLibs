#ifndef AIR_VALIDATE_H
#define AIR_VALIDATE_H

#include "air_bc.h"

#ifdef __cplusplus
extern "C" {
#endif

air_status air_program_validate(const air_program* program, air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
