#ifndef AIR_AST_H
#define AIR_AST_H

#include "air_syntax.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_ast_action
{
    air_i32 action_no;
    air_u32 stmt_first;
    air_u32 stmt_count;
    air_u32 elem_count;
    air_u16 line;
} air_ast_action;

typedef struct air_ast
{
    air_ast_action* actions;
    air_u32 action_count;
    air_syn_stmt* stmts;
    air_u32 stmt_count;
} air_ast;

const air_ast_action* air_ast_find_action(const air_ast* ast, air_i32 action_no);

#ifdef __cplusplus
}
#endif

#endif
