#ifndef AIR_LIMITS_H
#define AIR_LIMITS_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef AIR_MAX_TOKENS
#define AIR_MAX_TOKENS 1048576UL
#endif

#ifndef AIR_MAX_TOKENS_PER_LINE
#define AIR_MAX_TOKENS_PER_LINE 32U
#endif

#ifndef AIR_MAX_LINES
#define AIR_MAX_LINES 65535UL
#endif

#ifndef AIR_MAX_ACTIONS
#define AIR_MAX_ACTIONS 1024UL
#endif

#ifndef AIR_MAX_ELEMS_PER_ACTION
#define AIR_MAX_ELEMS_PER_ACTION 4096UL
#endif

#ifndef AIR_MAX_BOXES_PER_ELEM
#define AIR_MAX_BOXES_PER_ELEM 128U
#endif

#ifndef AIR_MAX_COMPILED_INSNS
#define AIR_MAX_COMPILED_INSNS 131072UL
#endif

#ifndef AIR_MAX_DIAGS
#define AIR_MAX_DIAGS 256U
#endif

#ifndef AIR_MAX_LINE_LEN
#define AIR_MAX_LINE_LEN 1024U
#endif

#ifndef AIR_MAX_FILE_BYTES
#define AIR_MAX_FILE_BYTES (2UL * 1024UL * 1024UL)
#endif

#ifndef AIR_MAX_DIAG_MESSAGE
#define AIR_MAX_DIAG_MESSAGE 160U
#endif

#ifndef AIR_MAX_DUMP_LINE
#define AIR_MAX_DUMP_LINE 256U
#endif

#ifndef AIR_MAX_DEBUG_PRIMS
#define AIR_MAX_DEBUG_PRIMS 256U
#endif

#ifdef __cplusplus
}
#endif

#endif
