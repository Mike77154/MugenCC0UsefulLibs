#ifndef AIR_FIXED_H
#define AIR_FIXED_H

#include "air_types.h"
#include "air_status.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef air_i32 air_fx;

#define AIR_FIXED_SHIFT 16
#define AIR_FIXED_ONE ((air_fx)(1L << AIR_FIXED_SHIFT))
#define AIR_FIXED_HALF ((air_fx)(1L << (AIR_FIXED_SHIFT - 1)))

air_fx air_fx_from_int(air_i32 value);
air_i32 air_fx_to_int_floor(air_fx value);
air_fx air_fx_abs(air_fx value);
air_fx air_fx_mul(air_fx a, air_fx b);
air_fx air_fx_div(air_fx a, air_fx b);
air_status air_fx_parse(const char* text, air_u16 len, air_fx* out_value);

#ifdef __cplusplus
}
#endif

#endif
