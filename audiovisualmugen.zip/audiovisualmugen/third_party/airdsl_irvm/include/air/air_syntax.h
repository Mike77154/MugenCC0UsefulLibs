#ifndef AIR_SYNTAX_H
#define AIR_SYNTAX_H

#include "air_fixed.h"
#include "air_lexer.h"
#include "air_trace.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_blend_mode
{
    AIR_BLEND_NONE = 0,
    AIR_BLEND_ADD = 1,
    AIR_BLEND_SUB = 2
} air_blend_mode;

typedef enum air_flip_mode
{
    AIR_FLIP_NONE = 0,
    AIR_FLIP_H = 1,
    AIR_FLIP_V = 2
} air_flip_mode;

typedef enum air_clsn_kind
{
    AIR_CLSN_KIND_NONE = 0,
    AIR_CLSN_KIND_1 = 1,
    AIR_CLSN_KIND_2 = 2
} air_clsn_kind;

typedef enum air_interp_mask
{
    AIR_INTERP_OFFSET = 1,
    AIR_INTERP_BLEND = 2,
    AIR_INTERP_SCALE = 4,
    AIR_INTERP_ANGLE = 8
} air_interp_mask;

typedef enum air_syn_kind
{
    AIR_SYN_EMPTY = 0,
    AIR_SYN_BEGIN_ACTION = 1,
    AIR_SYN_CLSN_DECL = 2,
    AIR_SYN_CLSN_RECT = 3,
    AIR_SYN_LOOPSTART = 4,
    AIR_SYN_INTERPOLATE = 5,
    AIR_SYN_ELEMENT = 6
} air_syn_kind;

typedef struct air_parse_options
{
    air_bool permissive;
    air_bool case_sensitive_keywords;
    const air_trace_sink* trace;
} air_parse_options;

typedef struct air_syn_begin_action
{
    air_i32 action_no;
} air_syn_begin_action;

typedef struct air_syn_clsn_decl
{
    air_u8 clsn_kind;
    air_u8 is_default;
    air_i32 rect_count;
} air_syn_clsn_decl;

typedef struct air_syn_clsn_rect
{
    air_u8 clsn_kind;
    air_i32 rect_index;
    air_i32 x1;
    air_i32 y1;
    air_i32 x2;
    air_i32 y2;
} air_syn_clsn_rect;

typedef struct air_syn_interpolate
{
    air_u8 mask;
} air_syn_interpolate;

typedef struct air_syn_element
{
    air_i32 group_no;
    air_i32 image_no;
    air_i32 x;
    air_i32 y;
    air_i32 time;
    air_u8 flip;
    air_u8 blend_fn;
    air_u16 src_alpha;
    air_u16 dst_alpha;
    air_fx scale_x;
    air_fx scale_y;
    air_fx angle_deg;
} air_syn_element;

typedef struct air_syn_stmt
{
    air_u8 kind;
    air_u16 line;
    union
    {
        air_syn_begin_action begin_action;
        air_syn_clsn_decl clsn_decl;
        air_syn_clsn_rect clsn_rect;
        air_syn_interpolate interpolate;
        air_syn_element element;
    } v;
} air_syn_stmt;

void air_parse_options_default(air_parse_options* opts);
air_status air_syntax_parse_line(const air_token_line* tokens,
                                 const air_parse_options* opts,
                                 air_syn_stmt* out_stmt,
                                 air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
