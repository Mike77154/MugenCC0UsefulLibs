#ifndef AIR_COMPILE_H
#define AIR_COMPILE_H

#include "air_ir.h"
#include "air_parser.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_build_options
{
    air_parse_options parse;
    air_bool validate_after_compile;
    const air_trace_sink* trace;
} air_build_options;

void air_build_options_default(air_build_options* opts);

air_status air_compile_program(air_program* out_program,
                               air_arena* arena,
                               const air_ast* ast,
                               const air_build_options* opts,
                               air_diag_list* diags);

air_status air_program_build_from_ir(air_program* out_program,
                                     air_arena* asset_arena,
                                     const air_ir_program* ir,
                                     const air_build_options* opts,
                                     air_diag_list* diags);

air_status air_program_build_from_text(air_program* out_program,
                                       air_arena* asset_arena,
                                       air_arena* scratch_arena,
                                       const char* text,
                                       air_u32 len,
                                       const air_build_options* opts,
                                       air_diag_list* diags);

air_status air_program_build_from_tokens(air_program* out_program,
                                         air_arena* asset_arena,
                                         air_arena* scratch_arena,
                                         const air_token_stream* tokens,
                                         const air_build_options* opts,
                                         air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
