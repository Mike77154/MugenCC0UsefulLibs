#ifndef AIR_DEBUGDRAW_H
#define AIR_DEBUGDRAW_H

#include "air_boxes.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_debug_color
{
    AIR_DEBUG_COLOR_RED = 1,
    AIR_DEBUG_COLOR_BLUE = 2
} air_debug_color;

typedef struct air_debug_primitive
{
    air_rect_fx rect;
    air_u8 color;
} air_debug_primitive;

air_status air_debug_build_primitives(const air_boxset* set,
                                      air_debug_primitive* out_prims,
                                      air_u16 prim_capacity,
                                      air_u16* out_count,
                                      air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
