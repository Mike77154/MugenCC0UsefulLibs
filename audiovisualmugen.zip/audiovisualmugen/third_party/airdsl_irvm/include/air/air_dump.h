#ifndef AIR_DUMP_H
#define AIR_DUMP_H

#include "air_runtime.h"

#ifdef __cplusplus
extern "C" {
#endif

air_status air_ast_dump(const air_ast* ast, const air_dump_sink* sink, air_diag_list* diags);
air_status air_program_dump(const air_program* program, const air_dump_sink* sink, air_diag_list* diags);

#ifdef __cplusplus
}
#endif

#endif
