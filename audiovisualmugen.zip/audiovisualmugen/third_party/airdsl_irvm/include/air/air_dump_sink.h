#ifndef AIR_DUMP_SINK_H
#define AIR_DUMP_SINK_H

#include "air_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*air_dump_write_fn)(void* user, const char* text, air_u32 len);

typedef struct air_dump_sink
{
    air_dump_write_fn fn;
    void* user;
} air_dump_sink;

#ifdef __cplusplus
}
#endif

#endif
