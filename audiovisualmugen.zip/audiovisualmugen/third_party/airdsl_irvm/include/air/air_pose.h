#ifndef AIR_POSE_H
#define AIR_POSE_H

#include "air_fixed.h"
#include "air_bc.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct air_box_ref
{
    air_u32 first;
    air_u16 count;
} air_box_ref;

typedef struct air_pose
{
    air_i32 group_no;
    air_i32 image_no;
    air_fx x;
    air_fx y;
    air_tick_t time;
    air_u8 flip;
    air_u8 blend_fn;
    air_u16 src_alpha;
    air_u16 dst_alpha;
    air_fx scale_x;
    air_fx scale_y;
    air_fx angle_deg;
    air_u8 interp_mask;
} air_pose;

typedef struct air_pose_sample
{
    air_i32 action_no;
    air_u32 elem_index;
    air_tick_t tick_in_elem;
    air_pose pose;
    air_box_ref clsn1;
    air_box_ref clsn2;
} air_pose_sample;

void air_pose_clear(air_pose* pose);
void air_pose_sample_clear(air_pose_sample* sample);

#ifdef __cplusplus
}
#endif

#endif
