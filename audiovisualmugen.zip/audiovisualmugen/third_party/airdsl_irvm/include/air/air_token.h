#ifndef AIR_TOKEN_H
#define AIR_TOKEN_H

#include "air_types.h"
#include "air_limits.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum air_token_kind
{
    AIR_TOK_EOF = 0,
    AIR_TOK_IDENT = 1,
    AIR_TOK_NUMBER = 2,
    AIR_TOK_COMMA = 3,
    AIR_TOK_COLON = 4,
    AIR_TOK_LBRACKET = 5,
    AIR_TOK_RBRACKET = 6,
    AIR_TOK_EQUAL = 7
} air_token_kind;

typedef struct air_token
{
    air_u8 kind;
    const char* ptr;
    air_u16 len;
    air_u16 line;
    air_u16 col;
} air_token;

typedef struct air_token_line
{
    air_token tokens[AIR_MAX_TOKENS_PER_LINE];
    air_u16 count;
    const char* line_begin;
    air_u16 line_len;
    air_u16 line_no;
} air_token_line;

typedef struct air_token_stream
{
    air_token_line* lines;
    air_u32 line_count;
    air_u32 total_tokens;
} air_token_stream;

air_bool air_token_eq(const air_token* tok, const char* text, air_bool case_sensitive);
air_bool air_token_starts_with(const air_token* tok, const char* prefix, air_bool case_sensitive);

#ifdef __cplusplus
}
#endif

#endif
