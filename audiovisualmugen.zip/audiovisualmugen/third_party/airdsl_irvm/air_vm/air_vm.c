#include "air/air_vm.h"

static void air_vm_reset_state(air_vm_state* vm)
{
    air_pose_clear(&vm->current_pose);
    vm->pc = 0;
    vm->elem_index = 0;
    vm->loop_hits = 0;
    vm->def1.first = 0; vm->def1.count = 0;
    vm->def2.first = 0; vm->def2.count = 0;
    vm->once1.first = 0; vm->once1.count = 0;
    vm->once2.first = 0; vm->once2.count = 0;
    vm->has_once1 = AIR_FALSE;
    vm->has_once2 = AIR_FALSE;
    vm->current_boxes_pushed = AIR_FALSE;
    vm->current_clsn1.first = 0; vm->current_clsn1.count = 0;
    vm->current_clsn2.first = 0; vm->current_clsn2.count = 0;
}

void air_vm_init(air_vm_state* vm, const air_program* program)
{
    if (vm == AIR_NULL)
    {
        return;
    }
    vm->program = program;
    vm->action = AIR_NULL;
    air_vm_reset_state(vm);
}

air_status air_vm_bind_action(air_vm_state* vm, air_i32 action_no, air_diag_list* diags)
{
    if (vm == AIR_NULL || vm->program == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, action_no, -1, "vm: invalid arguments");
        return AIR_STATUS_EINVAL;
    }
    vm->action = air_program_find_action(vm->program, action_no);
    if (vm->action == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ENOTFOUND, AIR_DIAG_ERROR, 0, 0, action_no, -1, "vm: action not found");
        return AIR_STATUS_ENOTFOUND;
    }
    return air_vm_reset_action(vm, diags);
}

air_status air_vm_reset_action(air_vm_state* vm, air_diag_list* diags)
{
    if (vm == AIR_NULL || vm->action == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ESTATE, AIR_DIAG_ERROR, 0, 0, -1, -1, "vm: no bound action");
        return AIR_STATUS_ESTATE;
    }
    air_vm_reset_state(vm);
    vm->pc = vm->action->insn_first;
    return AIR_STATUS_OK;
}

static void air_vm_set_box_ref(air_box_ref* ref, air_i32 first, air_i32 count)
{
    ref->first = (air_u32)first;
    ref->count = (air_u16)count;
}

static void air_vm_push_current_boxes(air_vm_state* vm)
{
    if (vm->has_once1)
    {
        vm->current_clsn1 = vm->once1;
    }
    else
    {
        vm->current_clsn1 = vm->def1;
    }

    if (vm->has_once2)
    {
        vm->current_clsn2 = vm->once2;
    }
    else
    {
        vm->current_clsn2 = vm->def2;
    }
    vm->current_boxes_pushed = AIR_TRUE;
}

air_status air_vm_advance_to_commit(air_vm_state* vm, air_pose_sample* out_sample, air_diag_list* diags)
{
    air_u32 guard;

    if (vm == AIR_NULL || vm->program == AIR_NULL || vm->action == AIR_NULL || out_sample == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "vm: invalid state");
        return AIR_STATUS_EINVAL;
    }

    guard = vm->program->insn_count + 1U;
    while (guard-- > 0U)
    {
        const air_insn* insn;
        if (vm->pc >= vm->program->insn_count)
        {
            air_diag_push(diags, AIR_STATUS_ESTATE, AIR_DIAG_ERROR, 0, 0, vm->action->action_no, -1, "vm: pc out of range");
            return AIR_STATUS_ESTATE;
        }

        insn = &vm->program->insns[vm->pc++];
        switch (insn->opcode)
        {
        case AIR_OP_NOP:
            break;
        case AIR_OP_SET_SPRITE:
            vm->current_pose.group_no = insn->operand_a;
            vm->current_pose.image_no = insn->operand_b;
            break;
        case AIR_OP_SET_TIME:
            vm->current_pose.time = insn->operand_a;
            break;
        case AIR_OP_SET_OFFSET:
            vm->current_pose.x = air_fx_from_int(insn->operand_a);
            vm->current_pose.y = air_fx_from_int(insn->operand_b);
            break;
        case AIR_OP_SET_FLIP:
            vm->current_pose.flip = (air_u8)insn->operand_a;
            break;
        case AIR_OP_SET_BLEND:
            vm->current_pose.blend_fn = (air_u8)insn->operand_a;
            vm->current_pose.src_alpha = (air_u16)insn->operand_b;
            vm->current_pose.dst_alpha = (air_u16)insn->operand_c;
            break;
        case AIR_OP_SET_SCALE:
            vm->current_pose.scale_x = (air_fx)insn->operand_a;
            vm->current_pose.scale_y = (air_fx)insn->operand_b;
            break;
        case AIR_OP_SET_ANGLE:
            vm->current_pose.angle_deg = (air_fx)insn->operand_a;
            break;
        case AIR_OP_SET_INTERP:
            vm->current_pose.interp_mask = (air_u8)insn->operand_a;
            break;
        case AIR_OP_SET_CLSN_DEFAULT:
            if (insn->operand_a == AIR_CLSN_KIND_1)
            {
                air_vm_set_box_ref(&vm->def1, insn->operand_c, insn->operand_b);
            }
            else if (insn->operand_a == AIR_CLSN_KIND_2)
            {
                air_vm_set_box_ref(&vm->def2, insn->operand_c, insn->operand_b);
            }
            break;
        case AIR_OP_SET_CLSN_ONCE:
            if (insn->operand_a == AIR_CLSN_KIND_1)
            {
                air_vm_set_box_ref(&vm->once1, insn->operand_c, insn->operand_b);
                vm->has_once1 = AIR_TRUE;
            }
            else if (insn->operand_a == AIR_CLSN_KIND_2)
            {
                air_vm_set_box_ref(&vm->once2, insn->operand_c, insn->operand_b);
                vm->has_once2 = AIR_TRUE;
            }
            break;
        case AIR_OP_PUSH_ELEM_BOXES:
            air_vm_push_current_boxes(vm);
            break;
        case AIR_OP_MARK_LOOP:
            break;
        case AIR_OP_COMMIT_ELEM:
            out_sample->action_no = vm->action->action_no;
            out_sample->elem_index = vm->elem_index;
            out_sample->tick_in_elem = 0;
            out_sample->pose = vm->current_pose;
            if (!vm->current_boxes_pushed)
            {
                air_vm_push_current_boxes(vm);
            }
            out_sample->clsn1 = vm->current_clsn1;
            out_sample->clsn2 = vm->current_clsn2;
            vm->once1.count = 0;
            vm->once2.count = 0;
            vm->has_once1 = AIR_FALSE;
            vm->has_once2 = AIR_FALSE;
            vm->current_boxes_pushed = AIR_FALSE;
            ++vm->elem_index;
            return AIR_STATUS_OK;

        case AIR_OP_END_ACTION:
            if ((vm->action->flags & 2U) != 0U)
            {
                vm->pc = vm->action->insn_first;
            }
            else if ((vm->action->flags & 1U) != 0U)
            {
                vm->pc = vm->action->loop_insn;
            }
            else
            {
                vm->pc = vm->action->insn_first;
            }
            vm->elem_index = vm->action->loop_elem;
            ++vm->loop_hits;
            break;

        default:
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, 0, 0, vm->action->action_no, -1, "vm: unknown opcode");
            return AIR_STATUS_EVERIFY;
        }
    }

    air_diag_push(diags, AIR_STATUS_ESTATE, AIR_DIAG_ERROR, 0, 0, vm->action->action_no, -1, "vm: exceeded instruction guard");
    return AIR_STATUS_ESTATE;
}


air_status air_vm_step_elem(air_vm_state* vm, air_pose_sample* out_sample, air_diag_list* diags)
{
    return air_vm_advance_to_commit(vm, out_sample, diags);
}

const air_pose* air_vm_current_pose(const air_vm_state* vm)
{
    if (vm == AIR_NULL)
    {
        return AIR_NULL;
    }
    return &vm->current_pose;
}

air_u32 air_vm_loop_count(const air_vm_state* vm)
{
    if (vm == AIR_NULL)
    {
        return 0U;
    }
    return vm->loop_hits;
}
