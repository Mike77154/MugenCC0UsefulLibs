#include <string.h>
#include "air/air_bc.h"

typedef struct air_program_file_header
{
    air_u32 magic;
    air_u32 version;
    air_u32 abi_version;
    air_u32 action_count;
    air_u32 insn_count;
    air_u32 rect_count;
    air_u32 checksum;
} air_program_file_header;

static air_u32 air_checksum_bytes(const air_u8* data, air_u32 size)
{
    air_u32 hash;
    air_u32 i;

    hash = 2166136261U;
    for (i = 0; i < size; ++i)
    {
        hash ^= (air_u32)data[i];
        hash *= 16777619U;
    }
    return hash;
}

static void air_write_u32_le(air_u8* dst, air_u32 value)
{
    dst[0] = (air_u8)(value & 0xFFU);
    dst[1] = (air_u8)((value >> 8) & 0xFFU);
    dst[2] = (air_u8)((value >> 16) & 0xFFU);
    dst[3] = (air_u8)((value >> 24) & 0xFFU);
}

static void air_write_i32_le(air_u8* dst, air_i32 value)
{
    air_write_u32_le(dst, (air_u32)value);
}

static air_u32 air_read_u32_le(const air_u8* src)
{
    return (air_u32)src[0] |
           ((air_u32)src[1] << 8) |
           ((air_u32)src[2] << 16) |
           ((air_u32)src[3] << 24);
}

static air_i32 air_read_i32_le(const air_u8* src)
{
    return (air_i32)air_read_u32_le(src);
}

void air_program_zero(air_program* program)
{
    if (program == AIR_NULL)
    {
        return;
    }
    program->abi_version = AIR_API_VERSION;
    program->actions = AIR_NULL;
    program->action_count = 0;
    program->insns = AIR_NULL;
    program->insn_count = 0;
    program->rects = AIR_NULL;
    program->rect_count = 0;
}

const air_action* air_program_find_action(const air_program* program, air_i32 action_no)
{
    air_u32 i;

    if (program == AIR_NULL)
    {
        return AIR_NULL;
    }
    for (i = 0; i < program->action_count; ++i)
    {
        if (program->actions[i].action_no == action_no)
        {
            return &program->actions[i];
        }
    }
    return AIR_NULL;
}

air_status air_program_measure_serialized(const air_program* program, air_u32* out_size)
{
    air_u32 size;

    if (program == AIR_NULL || out_size == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }

    size = 32U;
    size += program->action_count * 32U;
    size += program->insn_count * 16U;
    size += program->rect_count * 16U;
    *out_size = size;
    return AIR_STATUS_OK;
}

air_status air_program_write_serialized(const air_program* program,
                                        void* buffer,
                                        air_u32 capacity,
                                        air_u32* out_size,
                                        air_diag_list* diags)
{
    air_program_file_header hdr;
    air_u8* dst;
    air_u8* bytes;
    air_u32 size;
    air_u32 i;
    air_u32 checksum_off;

    if (program == AIR_NULL || buffer == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "serialize: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    air_program_measure_serialized(program, &size);
    if (capacity < size)
    {
        air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, 0, 0, -1, -1, "serialize: output buffer too small");
        return AIR_STATUS_EOVERFLOW;
    }

    hdr.magic = AIR_PROGRAM_MAGIC;
    hdr.version = AIR_PROGRAM_SERIAL_VERSION;
    hdr.abi_version = AIR_API_VERSION;
    hdr.action_count = program->action_count;
    hdr.insn_count = program->insn_count;
    hdr.rect_count = program->rect_count;
    hdr.checksum = 0;

    bytes = (air_u8*)buffer;
    dst = bytes;

    air_write_u32_le(dst + 0, hdr.magic);
    air_write_u32_le(dst + 4, hdr.version);
    air_write_u32_le(dst + 8, hdr.abi_version);
    air_write_u32_le(dst + 12, hdr.action_count);
    air_write_u32_le(dst + 16, hdr.insn_count);
    air_write_u32_le(dst + 20, hdr.rect_count);
    air_write_u32_le(dst + 24, hdr.checksum);
    memset(dst + 28, 0, 4U);
    dst += 32;
    checksum_off = 24U;

    for (i = 0; i < program->action_count; ++i)
    {
        const air_action* a;
        a = &program->actions[i];
        air_write_i32_le(dst + 0, a->action_no);
        air_write_u32_le(dst + 4, a->insn_first);
        air_write_u32_le(dst + 8, a->insn_count);
        air_write_u32_le(dst + 12, a->elem_count);
        air_write_u32_le(dst + 16, a->loop_insn);
        air_write_u32_le(dst + 20, a->loop_elem);
        air_write_u32_le(dst + 24, (air_u32)a->line);
        air_write_u32_le(dst + 28, (air_u32)a->flags);
        dst += 32;
    }
    for (i = 0; i < program->insn_count; ++i)
    {
        const air_insn* insn;
        insn = &program->insns[i];
        dst[0] = insn->opcode;
        dst[1] = insn->flags;
        dst[2] = (air_u8)(insn->reserved & 0xFFU);
        dst[3] = (air_u8)((insn->reserved >> 8) & 0xFFU);
        air_write_i32_le(dst + 4, insn->operand_a);
        air_write_i32_le(dst + 8, insn->operand_b);
        air_write_i32_le(dst + 12, insn->operand_c);
        dst += 16;
    }
    for (i = 0; i < program->rect_count; ++i)
    {
        const air_rect_i* r;
        r = &program->rects[i];
        air_write_i32_le(dst + 0, r->x1);
        air_write_i32_le(dst + 4, r->y1);
        air_write_i32_le(dst + 8, r->x2);
        air_write_i32_le(dst + 12, r->y2);
        dst += 16;
    }

    hdr.checksum = air_checksum_bytes(bytes + 32, size - 32U);
    air_write_u32_le(bytes + checksum_off, hdr.checksum);

    if (out_size != AIR_NULL)
    {
        *out_size = size;
    }
    return AIR_STATUS_OK;
}

air_status air_program_read_serialized(air_program* out_program,
                                       air_arena* arena,
                                       const void* buffer,
                                       air_u32 size,
                                       air_diag_list* diags)
{
    const air_u8* src;
    air_u32 magic;
    air_u32 version;
    air_u32 abi_version;
    air_u32 action_count;
    air_u32 insn_count;
    air_u32 rect_count;
    air_u32 checksum;
    air_u32 expected_size;
    air_u32 actual_checksum;
    air_action* actions;
    air_insn* insns;
    air_rect_i* rects;
    air_u32 i;

    if (out_program == AIR_NULL || arena == AIR_NULL || buffer == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: invalid arguments");
        return AIR_STATUS_EINVAL;
    }
    if (size < 32U)
    {
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: truncated header");
        return AIR_STATUS_ESYNTAX;
    }

    src = (const air_u8*)buffer;
    magic = air_read_u32_le(src + 0);
    version = air_read_u32_le(src + 4);
    abi_version = air_read_u32_le(src + 8);
    action_count = air_read_u32_le(src + 12);
    insn_count = air_read_u32_le(src + 16);
    rect_count = air_read_u32_le(src + 20);
    checksum = air_read_u32_le(src + 24);

    if (magic != AIR_PROGRAM_MAGIC || version != AIR_PROGRAM_SERIAL_VERSION)
    {
        air_diag_push(diags, AIR_STATUS_EUNSUPPORTED, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: unsupported AIRBC header");
        return AIR_STATUS_EUNSUPPORTED;
    }

    expected_size = 32U + action_count * 32U + insn_count * 16U + rect_count * 16U;
    if (expected_size != size)
    {
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: size mismatch");
        return AIR_STATUS_ESYNTAX;
    }
    actual_checksum = air_checksum_bytes(src + 32, size - 32U);
    if (checksum != actual_checksum)
    {
        air_diag_push(diags, AIR_STATUS_ESYNTAX, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: checksum mismatch");
        return AIR_STATUS_ESYNTAX;
    }

    actions = (air_action*)air_arena_alloc(arena, action_count * (air_u32)sizeof(air_action), 4U);
    insns = (air_insn*)air_arena_alloc(arena, insn_count * (air_u32)sizeof(air_insn), 4U);
    rects = (air_rect_i*)air_arena_alloc(arena, rect_count * (air_u32)sizeof(air_rect_i), 4U);
    if ((action_count != 0U && actions == AIR_NULL) ||
        (insn_count != 0U && insns == AIR_NULL) ||
        (rect_count != 0U && rects == AIR_NULL))
    {
        air_diag_push(diags, AIR_STATUS_ENOMEM, AIR_DIAG_ERROR, 0, 0, -1, -1, "deserialize: arena exhausted");
        return AIR_STATUS_ENOMEM;
    }

    src += 32;
    for (i = 0; i < action_count; ++i)
    {
        actions[i].action_no = air_read_i32_le(src + 0);
        actions[i].insn_first = air_read_u32_le(src + 4);
        actions[i].insn_count = air_read_u32_le(src + 8);
        actions[i].elem_count = air_read_u32_le(src + 12);
        actions[i].loop_insn = air_read_u32_le(src + 16);
        actions[i].loop_elem = air_read_u32_le(src + 20);
        actions[i].line = (air_u16)air_read_u32_le(src + 24);
        actions[i].flags = (air_u16)air_read_u32_le(src + 28);
        src += 32;
    }
    for (i = 0; i < insn_count; ++i)
    {
        insns[i].opcode = src[0];
        insns[i].flags = src[1];
        insns[i].reserved = (air_u16)(src[2] | ((air_u16)src[3] << 8));
        insns[i].operand_a = air_read_i32_le(src + 4);
        insns[i].operand_b = air_read_i32_le(src + 8);
        insns[i].operand_c = air_read_i32_le(src + 12);
        src += 16;
    }
    for (i = 0; i < rect_count; ++i)
    {
        rects[i].x1 = air_read_i32_le(src + 0);
        rects[i].y1 = air_read_i32_le(src + 4);
        rects[i].x2 = air_read_i32_le(src + 8);
        rects[i].y2 = air_read_i32_le(src + 12);
        src += 16;
    }

    out_program->abi_version = abi_version;
    out_program->actions = actions;
    out_program->action_count = action_count;
    out_program->insns = insns;
    out_program->insn_count = insn_count;
    out_program->rects = rects;
    out_program->rect_count = rect_count;
    return AIR_STATUS_OK;
}
