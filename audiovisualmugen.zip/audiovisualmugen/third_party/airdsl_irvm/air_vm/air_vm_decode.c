#include "air/air_vm_decode.h"

static void air_copy_text(char* dst, air_u32 capacity, const char* src)
{
    air_u32 i;
    if (capacity == 0U)
    {
        return;
    }
    i = 0U;
    while (i + 1U < capacity && src[i] != '\0')
    {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = '\0';
}

static void air_append_text(char* dst, air_u32 capacity, air_u32* used, const char* src)
{
    while (*src != '\0' && *used + 1U < capacity)
    {
        dst[*used] = *src;
        ++(*used);
        ++src;
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_append_i32(char* dst, air_u32 capacity, air_u32* used, air_i32 value)
{
    char temp[32];
    air_u32 len;
    air_u32 mag;
    air_bool neg;

    neg = AIR_FALSE;
    if (value < 0)
    {
        neg = AIR_TRUE;
        mag = (air_u32)(-value);
    }
    else
    {
        mag = (air_u32)value;
    }
    len = 0U;
    do
    {
        temp[len++] = (char)('0' + (mag % 10U));
        mag /= 10U;
    } while (mag != 0U);
    if (neg)
    {
        temp[len++] = '-';
    }
    while (len > 0U && *used + 1U < capacity)
    {
        --len;
        dst[*used] = temp[len];
        ++(*used);
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

const char* air_vm_opcode_name(air_u8 opcode)
{
    switch (opcode)
    {
    case AIR_OP_NOP: return "NOP";
    case AIR_OP_SET_SPRITE: return "SET_SPRITE";
    case AIR_OP_SET_TIME: return "SET_TIME";
    case AIR_OP_SET_OFFSET: return "SET_OFFSET";
    case AIR_OP_SET_FLIP: return "SET_FLIP";
    case AIR_OP_SET_BLEND: return "SET_BLEND";
    case AIR_OP_SET_SCALE: return "SET_SCALE";
    case AIR_OP_SET_ANGLE: return "SET_ANGLE";
    case AIR_OP_SET_INTERP: return "SET_INTERP";
    case AIR_OP_SET_CLSN_DEFAULT: return "SET_CLSN_DEFAULT";
    case AIR_OP_SET_CLSN_ONCE: return "SET_CLSN_ONCE";
    case AIR_OP_PUSH_ELEM_BOXES: return "PUSH_ELEM_BOXES";
    case AIR_OP_MARK_LOOP: return "MARK_LOOP";
    case AIR_OP_COMMIT_ELEM: return "COMMIT_ELEM";
    case AIR_OP_END_ACTION: return "END_ACTION";
    default: return "UNKNOWN";
    }
}

air_status air_vm_decode_insn(const air_insn* insn, char* buffer, air_u32 capacity)
{
    const char* name;
    air_u32 used;

    if (insn == AIR_NULL || buffer == AIR_NULL)
    {
        return AIR_STATUS_EINVAL;
    }

    name = air_vm_opcode_name(insn->opcode);
    air_copy_text(buffer, capacity, name);
    used = 0U;
    buffer[0] = '\0';
    air_append_text(buffer, capacity, &used, name);

    switch (insn->opcode)
    {
    case AIR_OP_SET_SPRITE:
        air_append_text(buffer, capacity, &used, " group=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        air_append_text(buffer, capacity, &used, " image=");
        air_append_i32(buffer, capacity, &used, insn->operand_b);
        break;
    case AIR_OP_SET_TIME:
        air_append_text(buffer, capacity, &used, " ticks=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        break;
    case AIR_OP_SET_OFFSET:
        air_append_text(buffer, capacity, &used, " x=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        air_append_text(buffer, capacity, &used, " y=");
        air_append_i32(buffer, capacity, &used, insn->operand_b);
        break;
    case AIR_OP_SET_FLIP:
        air_append_text(buffer, capacity, &used, " mode=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        break;
    case AIR_OP_SET_BLEND:
        air_append_text(buffer, capacity, &used, " fn=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        air_append_text(buffer, capacity, &used, " src=");
        air_append_i32(buffer, capacity, &used, insn->operand_b);
        air_append_text(buffer, capacity, &used, " dst=");
        air_append_i32(buffer, capacity, &used, insn->operand_c);
        break;
    case AIR_OP_SET_SCALE:
        air_append_text(buffer, capacity, &used, " xfx=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        air_append_text(buffer, capacity, &used, " yfx=");
        air_append_i32(buffer, capacity, &used, insn->operand_b);
        break;
    case AIR_OP_SET_ANGLE:
        air_append_text(buffer, capacity, &used, " degfx=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        break;
    case AIR_OP_SET_INTERP:
        air_append_text(buffer, capacity, &used, " mask=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        break;
    case AIR_OP_SET_CLSN_DEFAULT:
    case AIR_OP_SET_CLSN_ONCE:
        air_append_text(buffer, capacity, &used, " kind=");
        air_append_i32(buffer, capacity, &used, insn->operand_a);
        air_append_text(buffer, capacity, &used, " count=");
        air_append_i32(buffer, capacity, &used, insn->operand_b);
        air_append_text(buffer, capacity, &used, " first=");
        air_append_i32(buffer, capacity, &used, insn->operand_c);
        break;
    case AIR_OP_MARK_LOOP:
    case AIR_OP_PUSH_ELEM_BOXES:
    case AIR_OP_COMMIT_ELEM:
    case AIR_OP_END_ACTION:
    case AIR_OP_NOP:
    default:
        break;
    }

    return AIR_STATUS_OK;
}
