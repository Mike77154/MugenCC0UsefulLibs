#include "air/air_vm_dump.h"

static void air_sink_text(const air_dump_sink* sink, const char* text)
{
    air_u32 len;

    if (sink == AIR_NULL || sink->fn == AIR_NULL || text == AIR_NULL)
    {
        return;
    }
    len = 0U;
    while (text[len] != '\0')
    {
        ++len;
    }
    sink->fn(sink->user, text, len);
}

static void air_append_text(char* dst, air_u32 capacity, air_u32* used, const char* src)
{
    while (*src != '\0' && *used + 1U < capacity)
    {
        dst[*used] = *src;
        ++(*used);
        ++src;
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_append_i32(char* dst, air_u32 capacity, air_u32* used, air_i32 value)
{
    char temp[32];
    air_u32 len;
    air_u32 mag;
    air_bool neg;

    neg = AIR_FALSE;
    if (value < 0)
    {
        neg = AIR_TRUE;
        mag = (air_u32)(-value);
    }
    else
    {
        mag = (air_u32)value;
    }
    len = 0U;
    do
    {
        temp[len++] = (char)('0' + (mag % 10U));
        mag /= 10U;
    } while (mag != 0U);
    if (neg)
    {
        temp[len++] = '-';
    }
    while (len > 0U && *used + 1U < capacity)
    {
        --len;
        dst[*used] = temp[len];
        ++(*used);
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_emit_action_header(const air_dump_sink* sink, const air_action* action)
{
    char line[AIR_MAX_DUMP_LINE];
    air_u32 used;

    used = 0U;
    line[0] = '\0';
    air_append_text(line, sizeof(line), &used, "Action ");
    air_append_i32(line, sizeof(line), &used, action->action_no);
    air_append_text(line, sizeof(line), &used, " pc=");
    air_append_i32(line, sizeof(line), &used, (air_i32)action->insn_first);
    air_append_text(line, sizeof(line), &used, "..");
    air_append_i32(line, sizeof(line), &used, (air_i32)(action->insn_first + action->insn_count - 1U));
    air_append_text(line, sizeof(line), &used, " elems=");
    air_append_i32(line, sizeof(line), &used, (air_i32)action->elem_count);
    air_append_text(line, sizeof(line), &used, " loop_elem=");
    air_append_i32(line, sizeof(line), &used, (air_i32)action->loop_elem);
    air_append_text(line, sizeof(line), &used, "\n");
    air_sink_text(sink, line);
}

static void air_emit_insn_line(const air_dump_sink* sink, air_u32 pc, const air_insn* insn)
{
    char line[AIR_MAX_DUMP_LINE];
    char decoded[160];
    air_u32 used;

    air_vm_decode_insn(insn, decoded, (air_u32)sizeof(decoded));
    used = 0U;
    line[0] = '\0';
    air_append_text(line, sizeof(line), &used, "  [");
    air_append_i32(line, sizeof(line), &used, (air_i32)pc);
    air_append_text(line, sizeof(line), &used, "] ");
    air_append_text(line, sizeof(line), &used, decoded);
    air_append_text(line, sizeof(line), &used, "\n");
    air_sink_text(sink, line);
}

air_status air_vm_dump_action(const air_program* program, air_i32 action_no, const air_dump_sink* sink, air_diag_list* diags)
{
    const air_action* action;
    air_u32 i;

    action = air_program_find_action(program, action_no);
    if (action == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ENOTFOUND, AIR_DIAG_ERROR, 0, 0, action_no, -1, "dump: action not found");
        return AIR_STATUS_ENOTFOUND;
    }
    air_emit_action_header(sink, action);
    for (i = 0U; i < action->insn_count; ++i)
    {
        air_emit_insn_line(sink, action->insn_first + i, &program->insns[action->insn_first + i]);
    }
    return AIR_STATUS_OK;
}

air_status air_vm_dump_program(const air_program* program, const air_dump_sink* sink, air_diag_list* diags)
{
    air_u32 i;

    if (program == AIR_NULL || sink == AIR_NULL || sink->fn == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "dump: invalid arguments");
        return AIR_STATUS_EINVAL;
    }
    for (i = 0U; i < program->action_count; ++i)
    {
        air_vm_dump_action(program, program->actions[i].action_no, sink, diags);
    }
    return AIR_STATUS_OK;
}
