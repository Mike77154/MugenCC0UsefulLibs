#include "air/air_ir.h"
#include "air/air_parser.h"
#include "air/air_vm_dump.h"

static air_u32 air_ir_count_rects(const air_ast* ast)
{
    air_u32 i;
    air_u32 count;

    count = 0;
    for (i = 0; i < ast->stmt_count; ++i)
    {
        if (ast->stmts[i].kind == AIR_SYN_CLSN_RECT)
        {
            ++count;
        }
    }
    return count;
}

static air_u32 air_ir_count_elems(const air_ast* ast)
{
    air_u32 i;
    air_u32 count;

    count = 0;
    for (i = 0; i < ast->stmt_count; ++i)
    {
        if (ast->stmts[i].kind == AIR_SYN_ELEMENT)
        {
            ++count;
        }
    }
    return count;
}

static void air_ir_set_box_ref(air_ir_box_ref* ref, air_u32 first, air_u16 count)
{
    ref->first = first;
    ref->count = count;
}

static void air_ir_append_text(char* dst, air_u32 capacity, air_u32* used, const char* src)
{
    while (*src != '\0' && *used + 1U < capacity)
    {
        dst[*used] = *src;
        ++(*used);
        ++src;
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_ir_append_i32(char* dst, air_u32 capacity, air_u32* used, air_i32 value)
{
    char temp[32];
    air_u32 len;
    air_u32 mag;
    air_bool neg;

    neg = AIR_FALSE;
    if (value < 0)
    {
        neg = AIR_TRUE;
        mag = (air_u32)(-value);
    }
    else
    {
        mag = (air_u32)value;
    }

    len = 0;
    do
    {
        temp[len++] = (char)('0' + (mag % 10U));
        mag /= 10U;
    } while (mag != 0U);

    if (neg)
    {
        temp[len++] = '-';
    }
    while (len > 0U && *used + 1U < capacity)
    {
        --len;
        dst[*used] = temp[len];
        ++(*used);
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_ir_sink_text(const air_dump_sink* sink, const char* text)
{
    air_u32 len;

    if (sink == AIR_NULL || sink->fn == AIR_NULL || text == AIR_NULL)
    {
        return;
    }
    len = 0;
    while (text[len] != '\0')
    {
        ++len;
    }
    sink->fn(sink->user, text, len);
}

void air_ir_program_zero(air_ir_program* ir)
{
    if (ir == AIR_NULL)
    {
        return;
    }
    ir->abi_version = AIR_API_VERSION;
    ir->actions = AIR_NULL;
    ir->action_count = 0;
    ir->elems = AIR_NULL;
    ir->elem_count = 0;
    ir->rects = AIR_NULL;
    ir->rect_count = 0;
}

const air_ir_action* air_ir_find_action(const air_ir_program* ir, air_i32 action_no)
{
    air_u32 i;

    if (ir == AIR_NULL)
    {
        return AIR_NULL;
    }
    for (i = 0; i < ir->action_count; ++i)
    {
        if (ir->actions[i].action_no == action_no)
        {
            return &ir->actions[i];
        }
    }
    return AIR_NULL;
}

air_status air_ir_build_from_ast(air_ir_program* out_ir,
                                 air_arena* arena,
                                 const air_ast* ast,
                                 air_diag_list* diags)
{
    air_u32 rect_cap;
    air_u32 elem_cap;
    air_u32 action_i;
    air_u32 elem_write;
    air_u32 rect_write;

    if (out_ir == AIR_NULL || arena == AIR_NULL || ast == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "ir: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    air_ir_program_zero(out_ir);
    rect_cap = air_ir_count_rects(ast);
    elem_cap = air_ir_count_elems(ast);

    out_ir->actions = (air_ir_action*)air_arena_alloc(arena, ast->action_count * (air_u32)sizeof(air_ir_action), 4U);
    out_ir->elems = (air_ir_elem*)air_arena_alloc(arena, elem_cap * (air_u32)sizeof(air_ir_elem), 4U);
    out_ir->rects = (air_ir_rect*)air_arena_alloc(arena, rect_cap * (air_u32)sizeof(air_ir_rect), 4U);
    if (out_ir->actions == AIR_NULL || out_ir->elems == AIR_NULL || (rect_cap != 0U && out_ir->rects == AIR_NULL))
    {
        air_diag_push(diags, AIR_STATUS_ENOMEM, AIR_DIAG_ERROR, 0, 0, -1, -1, "ir: arena exhausted");
        return AIR_STATUS_ENOMEM;
    }

    out_ir->abi_version = AIR_API_VERSION;
    out_ir->action_count = ast->action_count;
    out_ir->elem_count = 0;
    out_ir->rect_count = 0;
    elem_write = 0;
    rect_write = 0;

    for (action_i = 0; action_i < ast->action_count; ++action_i)
    {
        const air_ast_action* src_action;
        air_ir_action* dst_action;
        air_u32 stmt_i;
        air_u32 stmt_end;
        air_bool pending_decl_active;
        air_u8 pending_decl_kind;
        air_u8 pending_decl_default;
        air_i32 pending_decl_remaining;
        air_i32 pending_decl_total;
        air_u32 pending_decl_first_rect;
        air_u8 pending_edge_mask;
        air_u8 first_edge_mask;
        air_bool first_edge_seen;
        air_i32 prev_elem_index;
        air_ir_box_ref default1;
        air_ir_box_ref default2;
        air_ir_box_ref once1;
        air_ir_box_ref once2;
        air_bool have_once1;
        air_bool have_once2;

        src_action = &ast->actions[action_i];
        dst_action = &out_ir->actions[action_i];
        dst_action->action_no = src_action->action_no;
        dst_action->elem_first = elem_write;
        dst_action->elem_count = 0;
        dst_action->loop_elem = 0;
        dst_action->line = src_action->line;
        dst_action->flags = 0;

        pending_decl_active = AIR_FALSE;
        pending_decl_kind = AIR_CLSN_KIND_NONE;
        pending_decl_default = AIR_FALSE;
        pending_decl_remaining = 0;
        pending_decl_total = 0;
        pending_decl_first_rect = 0;
        pending_edge_mask = 0;
        first_edge_mask = 0;
        first_edge_seen = AIR_FALSE;
        prev_elem_index = -1;
        air_ir_set_box_ref(&default1, 0U, 0U);
        air_ir_set_box_ref(&default2, 0U, 0U);
        air_ir_set_box_ref(&once1, 0U, 0U);
        air_ir_set_box_ref(&once2, 0U, 0U);
        have_once1 = AIR_FALSE;
        have_once2 = AIR_FALSE;

        stmt_end = src_action->stmt_first + src_action->stmt_count;
        for (stmt_i = src_action->stmt_first; stmt_i < stmt_end; ++stmt_i)
        {
            const air_syn_stmt* stmt;
            stmt = &ast->stmts[stmt_i];

            switch (stmt->kind)
            {
            case AIR_SYN_CLSN_DECL:
                pending_decl_kind = stmt->v.clsn_decl.clsn_kind;
                pending_decl_default = stmt->v.clsn_decl.is_default;
                pending_decl_total = stmt->v.clsn_decl.rect_count;
                pending_decl_remaining = stmt->v.clsn_decl.rect_count;
                pending_decl_first_rect = rect_write;
                if (pending_decl_total == 0)
                {
                    if (pending_decl_default)
                    {
                        if (pending_decl_kind == AIR_CLSN_KIND_1)
                        {
                            air_ir_set_box_ref(&default1, 0U, 0U);
                        }
                        else if (pending_decl_kind == AIR_CLSN_KIND_2)
                        {
                            air_ir_set_box_ref(&default2, 0U, 0U);
                        }
                    }
                    else
                    {
                        if (pending_decl_kind == AIR_CLSN_KIND_1)
                        {
                            air_ir_set_box_ref(&once1, 0U, 0U);
                            have_once1 = AIR_TRUE;
                        }
                        else if (pending_decl_kind == AIR_CLSN_KIND_2)
                        {
                            air_ir_set_box_ref(&once2, 0U, 0U);
                            have_once2 = AIR_TRUE;
                        }
                    }
                }
                else
                {
                    pending_decl_active = AIR_TRUE;
                }
                break;

            case AIR_SYN_CLSN_RECT:
                if (!pending_decl_active)
                {
                    air_diag_push(diags, AIR_STATUS_ESEMANTIC, AIR_DIAG_ERROR, stmt->line, 1, src_action->action_no, -1, "ir: unexpected collision rectangle");
                    return AIR_STATUS_ESEMANTIC;
                }
                out_ir->rects[rect_write].x1 = stmt->v.clsn_rect.x1;
                out_ir->rects[rect_write].y1 = stmt->v.clsn_rect.y1;
                out_ir->rects[rect_write].x2 = stmt->v.clsn_rect.x2;
                out_ir->rects[rect_write].y2 = stmt->v.clsn_rect.y2;
                ++rect_write;
                --pending_decl_remaining;
                if (pending_decl_remaining == 0)
                {
                    if (pending_decl_default)
                    {
                        if (pending_decl_kind == AIR_CLSN_KIND_1)
                        {
                            air_ir_set_box_ref(&default1, pending_decl_first_rect, (air_u16)pending_decl_total);
                        }
                        else if (pending_decl_kind == AIR_CLSN_KIND_2)
                        {
                            air_ir_set_box_ref(&default2, pending_decl_first_rect, (air_u16)pending_decl_total);
                        }
                    }
                    else
                    {
                        if (pending_decl_kind == AIR_CLSN_KIND_1)
                        {
                            air_ir_set_box_ref(&once1, pending_decl_first_rect, (air_u16)pending_decl_total);
                            have_once1 = AIR_TRUE;
                        }
                        else if (pending_decl_kind == AIR_CLSN_KIND_2)
                        {
                            air_ir_set_box_ref(&once2, pending_decl_first_rect, (air_u16)pending_decl_total);
                            have_once2 = AIR_TRUE;
                        }
                    }
                    pending_decl_active = AIR_FALSE;
                }
                break;

            case AIR_SYN_LOOPSTART:
                dst_action->loop_elem = dst_action->elem_count;
                dst_action->flags |= (air_u16)AIR_IR_ACTION_FLAG_HAS_LOOP;
                break;

            case AIR_SYN_INTERPOLATE:
                pending_edge_mask = (air_u8)(pending_edge_mask | stmt->v.interpolate.mask);
                break;

            case AIR_SYN_ELEMENT:
            {
                air_ir_elem* elem;

                elem = &out_ir->elems[elem_write];
                elem->group_no = stmt->v.element.group_no;
                elem->image_no = stmt->v.element.image_no;
                elem->x = stmt->v.element.x;
                elem->y = stmt->v.element.y;
                elem->time = stmt->v.element.time;
                elem->flip = stmt->v.element.flip;
                elem->blend_fn = stmt->v.element.blend_fn;
                elem->src_alpha = stmt->v.element.src_alpha;
                elem->dst_alpha = stmt->v.element.dst_alpha;
                elem->scale_x = stmt->v.element.scale_x;
                elem->scale_y = stmt->v.element.scale_y;
                elem->angle_deg = stmt->v.element.angle_deg;
                elem->interp_to_next_mask = 0U;
                elem->reserved0 = 0U;
                elem->line = stmt->line;

                if (pending_edge_mask != 0U)
                {
                    if (prev_elem_index >= 0)
                    {
                        out_ir->elems[prev_elem_index].interp_to_next_mask = pending_edge_mask;
                    }
                    else
                    {
                        first_edge_mask = pending_edge_mask;
                        first_edge_seen = AIR_TRUE;
                    }
                }
                pending_edge_mask = 0U;

                if (have_once1)
                {
                    elem->clsn1 = once1;
                }
                else
                {
                    elem->clsn1 = default1;
                }
                if (have_once2)
                {
                    elem->clsn2 = once2;
                }
                else
                {
                    elem->clsn2 = default2;
                }
                air_ir_set_box_ref(&once1, 0U, 0U);
                air_ir_set_box_ref(&once2, 0U, 0U);
                have_once1 = AIR_FALSE;
                have_once2 = AIR_FALSE;

                if (elem->time == -1)
                {
                    dst_action->flags |= (air_u16)AIR_IR_ACTION_FLAG_NO_LOOP;
                }
                prev_elem_index = (air_i32)elem_write;
                ++elem_write;
                ++dst_action->elem_count;
            } break;

            default:
                break;
            }
        }

        if (pending_decl_active)
        {
            air_diag_push(diags, AIR_STATUS_ESEMANTIC, AIR_DIAG_ERROR, src_action->line, 1, src_action->action_no, -1, "ir: incomplete collision declaration");
            return AIR_STATUS_ESEMANTIC;
        }
        if (dst_action->elem_count == 0U)
        {
            air_diag_push(diags, AIR_STATUS_ESEMANTIC, AIR_DIAG_ERROR, src_action->line, 1, src_action->action_no, -1, "ir: action has no elements");
            return AIR_STATUS_ESEMANTIC;
        }
        if (first_edge_seen && prev_elem_index >= 0)
        {
            out_ir->elems[prev_elem_index].interp_to_next_mask = first_edge_mask;
        }
    }

    out_ir->elem_count = elem_write;
    out_ir->rect_count = rect_write;
    return air_ir_validate(out_ir, diags);
}

air_status air_ir_build_from_text(air_ir_program* out_ir,
                                  air_arena* ir_arena,
                                  air_arena* scratch_arena,
                                  const char* text,
                                  air_u32 len,
                                  const air_parse_options* opts,
                                  air_diag_list* diags)
{
    air_parse_result parsed;
    air_parse_options defaults;
    const air_parse_options* parse_opts;

    if (opts == AIR_NULL)
    {
        air_parse_options_default(&defaults);
        parse_opts = &defaults;
    }
    else
    {
        parse_opts = opts;
    }

    air_arena_reset(scratch_arena);
    if (air_parser_parse_text(&parsed, scratch_arena, text, len, parse_opts, diags) != AIR_STATUS_OK &&
        !(parse_opts->permissive && !air_diag_has_errors(diags)))
    {
        return AIR_STATUS_ESEMANTIC;
    }
    return air_ir_build_from_ast(out_ir, ir_arena, &parsed.ast, diags);
}

air_status air_ir_build_from_tokens(air_ir_program* out_ir,
                                    air_arena* ir_arena,
                                    air_arena* scratch_arena,
                                    const air_token_stream* tokens,
                                    const air_parse_options* opts,
                                    air_diag_list* diags)
{
    air_parse_result parsed;
    air_parse_options defaults;
    const air_parse_options* parse_opts;

    if (opts == AIR_NULL)
    {
        air_parse_options_default(&defaults);
        parse_opts = &defaults;
    }
    else
    {
        parse_opts = opts;
    }

    air_arena_reset(scratch_arena);
    if (air_parser_parse_tokens(&parsed, scratch_arena, tokens, parse_opts, diags) != AIR_STATUS_OK &&
        !(parse_opts->permissive && !air_diag_has_errors(diags)))
    {
        return AIR_STATUS_ESEMANTIC;
    }
    return air_ir_build_from_ast(out_ir, ir_arena, &parsed.ast, diags);
}

air_status air_ir_validate(const air_ir_program* ir, air_diag_list* diags)
{
    air_u32 i;
    air_u32 j;

    if (ir == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "ir: invalid program");
        return AIR_STATUS_EINVAL;
    }
    if (ir->action_count == 0U)
    {
        air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, 0, 0, -1, -1, "ir: no actions");
        return AIR_STATUS_EVERIFY;
    }

    for (i = 0; i < ir->action_count; ++i)
    {
        const air_ir_action* a;
        a = &ir->actions[i];

        if (a->elem_first >= ir->elem_count || a->elem_first + a->elem_count > ir->elem_count)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "ir: action element range is invalid");
            return AIR_STATUS_EVERIFY;
        }
        if (a->elem_count == 0U)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "ir: action is empty");
            return AIR_STATUS_EVERIFY;
        }
        if (a->loop_elem >= a->elem_count)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "ir: loop element out of range");
            return AIR_STATUS_EVERIFY;
        }
        for (j = i + 1U; j < ir->action_count; ++j)
        {
            if (ir->actions[j].action_no == a->action_no)
            {
                air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "ir: duplicate action number");
                return AIR_STATUS_EVERIFY;
            }
        }
        for (j = 0U; j < a->elem_count; ++j)
        {
            const air_ir_elem* elem;
            elem = &ir->elems[a->elem_first + j];
            if (elem->clsn1.first + elem->clsn1.count > ir->rect_count)
            {
                air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, elem->line, 1, a->action_no, (air_i32)j, "ir: clsn1 range out of bounds");
                return AIR_STATUS_EVERIFY;
            }
            if (elem->clsn2.first + elem->clsn2.count > ir->rect_count)
            {
                air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, elem->line, 1, a->action_no, (air_i32)j, "ir: clsn2 range out of bounds");
                return AIR_STATUS_EVERIFY;
            }
        }
    }

    return AIR_STATUS_OK;
}

air_status air_ir_dump(const air_ir_program* ir, const air_dump_sink* sink, air_diag_list* diags)
{
    air_u32 i;
    char line[AIR_MAX_DUMP_LINE];

    if (ir == AIR_NULL || sink == AIR_NULL || sink->fn == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "ir dump: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    for (i = 0; i < ir->action_count; ++i)
    {
        const air_ir_action* action;
        air_u32 j;
        air_u32 used;

        action = &ir->actions[i];
        used = 0;
        line[0] = '\0';
        air_ir_append_text(line, sizeof(line), &used, "IR Action ");
        air_ir_append_i32(line, sizeof(line), &used, action->action_no);
        air_ir_append_text(line, sizeof(line), &used, " elems=");
        air_ir_append_i32(line, sizeof(line), &used, (air_i32)action->elem_count);
        air_ir_append_text(line, sizeof(line), &used, " loop=");
        air_ir_append_i32(line, sizeof(line), &used, (air_i32)action->loop_elem);
        if ((action->flags & AIR_IR_ACTION_FLAG_NO_LOOP) != 0U)
        {
            air_ir_append_text(line, sizeof(line), &used, " terminal");
        }
        air_ir_append_text(line, sizeof(line), &used, "\n");
        air_ir_sink_text(sink, line);

        for (j = 0U; j < action->elem_count; ++j)
        {
            const air_ir_elem* elem;
            used = 0;
            line[0] = '\0';
            elem = &ir->elems[action->elem_first + j];
            air_ir_append_text(line, sizeof(line), &used, "  elem ");
            air_ir_append_i32(line, sizeof(line), &used, (air_i32)j);
            air_ir_append_text(line, sizeof(line), &used, " sprite=(");
            air_ir_append_i32(line, sizeof(line), &used, elem->group_no);
            air_ir_append_text(line, sizeof(line), &used, ",");
            air_ir_append_i32(line, sizeof(line), &used, elem->image_no);
            air_ir_append_text(line, sizeof(line), &used, ") off=(");
            air_ir_append_i32(line, sizeof(line), &used, elem->x);
            air_ir_append_text(line, sizeof(line), &used, ",");
            air_ir_append_i32(line, sizeof(line), &used, elem->y);
            air_ir_append_text(line, sizeof(line), &used, ") time=");
            air_ir_append_i32(line, sizeof(line), &used, elem->time);
            air_ir_append_text(line, sizeof(line), &used, " interp=");
            air_ir_append_i32(line, sizeof(line), &used, elem->interp_to_next_mask);
            air_ir_append_text(line, sizeof(line), &used, " c1=");
            air_ir_append_i32(line, sizeof(line), &used, (air_i32)elem->clsn1.count);
            air_ir_append_text(line, sizeof(line), &used, " c2=");
            air_ir_append_i32(line, sizeof(line), &used, (air_i32)elem->clsn2.count);
            air_ir_append_text(line, sizeof(line), &used, "\n");
            air_ir_sink_text(sink, line);
        }
    }
    return AIR_STATUS_OK;
}
