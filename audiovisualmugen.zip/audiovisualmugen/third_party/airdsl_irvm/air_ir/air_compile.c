#include "air/air_compile.h"
#include "air/air_validate.h"

#define AIR_ACTION_FLAG_HAS_LOOP 1U
#define AIR_ACTION_FLAG_NO_LOOP  2U

static air_u32 air_count_insns_from_ir(const air_ir_program* ir)
{
    air_u32 i;
    air_u32 count;

    count = 0;
    for (i = 0; i < ir->action_count; ++i)
    {
        const air_ir_action* action;
        action = &ir->actions[i];
        count += action->elem_count * 12U;
        count += 1U;
        if ((action->flags & AIR_IR_ACTION_FLAG_HAS_LOOP) != 0U)
        {
            ++count;
        }
    }
    return count;
}

static void air_insn_set(air_insn* insn, air_u8 opcode, air_i32 a, air_i32 b, air_i32 c)
{
    insn->opcode = opcode;
    insn->flags = 0;
    insn->reserved = 0;
    insn->operand_a = a;
    insn->operand_b = b;
    insn->operand_c = c;
}

static air_status air_lower_ir_to_program(air_program* out_program,
                                          air_arena* arena,
                                          const air_ir_program* ir,
                                          const air_build_options* opts,
                                          air_diag_list* diags)
{
    air_u32 insn_cap;
    air_u32 action_i;
    air_u32 code_write;

    if (out_program == AIR_NULL || arena == AIR_NULL || ir == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "compile: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    air_program_zero(out_program);
    insn_cap = air_count_insns_from_ir(ir);

    out_program->actions = (air_action*)air_arena_alloc(arena, ir->action_count * (air_u32)sizeof(air_action), 4U);
    out_program->insns = (air_insn*)air_arena_alloc(arena, insn_cap * (air_u32)sizeof(air_insn), 4U);
    out_program->rects = (air_rect_i*)air_arena_alloc(arena, ir->rect_count * (air_u32)sizeof(air_rect_i), 4U);
    if (out_program->actions == AIR_NULL || out_program->insns == AIR_NULL || (ir->rect_count != 0U && out_program->rects == AIR_NULL))
    {
        air_diag_push(diags, AIR_STATUS_ENOMEM, AIR_DIAG_ERROR, 0, 0, -1, -1, "compile: arena exhausted");
        return AIR_STATUS_ENOMEM;
    }

    out_program->abi_version = AIR_API_VERSION;
    out_program->action_count = ir->action_count;
    out_program->insn_count = 0;
    out_program->rect_count = ir->rect_count;

    if (ir->rect_count != 0U)
    {
        air_u32 r;
        for (r = 0U; r < ir->rect_count; ++r)
        {
            out_program->rects[r].x1 = ir->rects[r].x1;
            out_program->rects[r].y1 = ir->rects[r].y1;
            out_program->rects[r].x2 = ir->rects[r].x2;
            out_program->rects[r].y2 = ir->rects[r].y2;
        }
    }

    code_write = 0;
    for (action_i = 0; action_i < ir->action_count; ++action_i)
    {
        const air_ir_action* src_action;
        air_action* dst_action;
        air_u32 j;

        src_action = &ir->actions[action_i];
        dst_action = &out_program->actions[action_i];

        dst_action->action_no = src_action->action_no;
        dst_action->insn_first = code_write;
        dst_action->insn_count = 0;
        dst_action->elem_count = src_action->elem_count;
        dst_action->loop_insn = code_write;
        dst_action->loop_elem = src_action->loop_elem;
        dst_action->line = src_action->line;
        dst_action->flags = 0;
        if ((src_action->flags & AIR_IR_ACTION_FLAG_HAS_LOOP) != 0U)
        {
            dst_action->flags |= AIR_ACTION_FLAG_HAS_LOOP;
        }
        if ((src_action->flags & AIR_IR_ACTION_FLAG_NO_LOOP) != 0U)
        {
            dst_action->flags |= AIR_ACTION_FLAG_NO_LOOP;
        }

        for (j = 0U; j < src_action->elem_count; ++j)
        {
            const air_ir_elem* elem;
            elem = &ir->elems[src_action->elem_first + j];

            if ((src_action->flags & AIR_IR_ACTION_FLAG_HAS_LOOP) != 0U && j == src_action->loop_elem)
            {
                air_insn_set(&out_program->insns[code_write], AIR_OP_MARK_LOOP, 0, 0, 0);
                ++code_write;
                dst_action->loop_insn = code_write;
            }

            air_insn_set(&out_program->insns[code_write + 0U], AIR_OP_SET_CLSN_DEFAULT, AIR_CLSN_KIND_1, elem->clsn1.count, (air_i32)elem->clsn1.first);
            air_insn_set(&out_program->insns[code_write + 1U], AIR_OP_SET_CLSN_DEFAULT, AIR_CLSN_KIND_2, elem->clsn2.count, (air_i32)elem->clsn2.first);
            air_insn_set(&out_program->insns[code_write + 2U], AIR_OP_SET_SPRITE, elem->group_no, elem->image_no, 0);
            air_insn_set(&out_program->insns[code_write + 3U], AIR_OP_SET_TIME, elem->time, 0, 0);
            air_insn_set(&out_program->insns[code_write + 4U], AIR_OP_SET_OFFSET, elem->x, elem->y, 0);
            air_insn_set(&out_program->insns[code_write + 5U], AIR_OP_SET_FLIP, elem->flip, 0, 0);
            air_insn_set(&out_program->insns[code_write + 6U], AIR_OP_SET_BLEND, elem->blend_fn, elem->src_alpha, elem->dst_alpha);
            air_insn_set(&out_program->insns[code_write + 7U], AIR_OP_SET_SCALE, elem->scale_x, elem->scale_y, 0);
            air_insn_set(&out_program->insns[code_write + 8U], AIR_OP_SET_ANGLE, elem->angle_deg, 0, 0);
            air_insn_set(&out_program->insns[code_write + 9U], AIR_OP_SET_INTERP, elem->interp_to_next_mask, 0, 0);
            air_insn_set(&out_program->insns[code_write + 10U], AIR_OP_PUSH_ELEM_BOXES, 0, 0, 0);
            air_insn_set(&out_program->insns[code_write + 11U], AIR_OP_COMMIT_ELEM, 0, 0, 0);

            if (opts != AIR_NULL && opts->trace != AIR_NULL)
            {
                air_trace_emit(opts->trace, AIR_TRACE_COMPILE, elem->line, src_action->action_no, (air_i32)j, 0, code_write, "lower-ir");
            }
            code_write += 12U;
        }

        air_insn_set(&out_program->insns[code_write], AIR_OP_END_ACTION, 0, 0, 0);
        ++code_write;
        dst_action->insn_count = code_write - dst_action->insn_first;
    }

    out_program->insn_count = code_write;
    if (opts == AIR_NULL || opts->validate_after_compile)
    {
        return air_program_validate(out_program, diags);
    }
    return AIR_STATUS_OK;
}

void air_build_options_default(air_build_options* opts)
{
    if (opts == AIR_NULL)
    {
        return;
    }
    air_parse_options_default(&opts->parse);
    opts->validate_after_compile = AIR_TRUE;
    opts->trace = AIR_NULL;
}

air_status air_program_build_from_ir(air_program* out_program,
                                     air_arena* asset_arena,
                                     const air_ir_program* ir,
                                     const air_build_options* opts,
                                     air_diag_list* diags)
{
    return air_lower_ir_to_program(out_program, asset_arena, ir, opts, diags);
}

air_status air_compile_program(air_program* out_program,
                               air_arena* arena,
                               const air_ast* ast,
                               const air_build_options* opts,
                               air_diag_list* diags)
{
    air_ir_program ir;
    air_status status;

    status = air_ir_build_from_ast(&ir, arena, ast, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    return air_lower_ir_to_program(out_program, arena, &ir, opts, diags);
}

air_status air_program_build_from_text(air_program* out_program,
                                       air_arena* asset_arena,
                                       air_arena* scratch_arena,
                                       const char* text,
                                       air_u32 len,
                                       const air_build_options* opts,
                                       air_diag_list* diags)
{
    air_ir_program ir;
    air_build_options defaults;
    const air_build_options* build_opts;

    if (opts == AIR_NULL)
    {
        air_build_options_default(&defaults);
        build_opts = &defaults;
    }
    else
    {
        build_opts = opts;
    }

    air_arena_reset(scratch_arena);
    if (air_ir_build_from_text(&ir, scratch_arena, scratch_arena, text, len, &build_opts->parse, diags) != AIR_STATUS_OK &&
        !(build_opts->parse.permissive && !air_diag_has_errors(diags)))
    {
        return AIR_STATUS_ESEMANTIC;
    }
    air_arena_reset(asset_arena);
    return air_lower_ir_to_program(out_program, asset_arena, &ir, build_opts, diags);
}

air_status air_program_build_from_tokens(air_program* out_program,
                                         air_arena* asset_arena,
                                         air_arena* scratch_arena,
                                         const air_token_stream* tokens,
                                         const air_build_options* opts,
                                         air_diag_list* diags)
{
    air_ir_program ir;
    air_parse_result parsed;
    air_build_options defaults;
    const air_build_options* build_opts;

    if (opts == AIR_NULL)
    {
        air_build_options_default(&defaults);
        build_opts = &defaults;
    }
    else
    {
        build_opts = opts;
    }

    air_arena_reset(scratch_arena);
    if (air_parser_parse_tokens(&parsed, scratch_arena, tokens, &build_opts->parse, diags) != AIR_STATUS_OK &&
        !(build_opts->parse.permissive && !air_diag_has_errors(diags)))
    {
        return AIR_STATUS_ESEMANTIC;
    }
    if (air_ir_build_from_ast(&ir, scratch_arena, &parsed.ast, diags) != AIR_STATUS_OK)
    {
        return AIR_STATUS_ESEMANTIC;
    }
    air_arena_reset(asset_arena);
    return air_lower_ir_to_program(out_program, asset_arena, &ir, build_opts, diags);
}
