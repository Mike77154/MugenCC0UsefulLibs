#include "air/air_validate.h"

air_status air_program_validate(const air_program* program, air_diag_list* diags)
{
    air_u32 i;
    air_u32 j;

    if (program == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "validate: invalid program");
        return AIR_STATUS_EINVAL;
    }

    if (program->action_count == 0U)
    {
        air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, 0, 0, -1, -1, "validate: program has no actions");
        return AIR_STATUS_EVERIFY;
    }
    if (program->insn_count > AIR_MAX_COMPILED_INSNS)
    {
        air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, 0, 0, -1, -1, "validate: AIR_MAX_COMPILED_INSNS exceeded");
        return AIR_STATUS_EVERIFY;
    }

    for (i = 0; i < program->action_count; ++i)
    {
        const air_action* a;
        air_u32 seen_loop;
        air_u32 elem_count;

        a = &program->actions[i];

        if (a->insn_first >= program->insn_count || a->insn_first + a->insn_count > program->insn_count)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: action instruction range is invalid");
            return AIR_STATUS_EVERIFY;
        }

        for (j = i + 1; j < program->action_count; ++j)
        {
            if (program->actions[j].action_no == a->action_no)
            {
                air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: duplicate action number");
                return AIR_STATUS_EVERIFY;
            }
        }

        seen_loop = 0U;
        elem_count = 0U;
        for (j = 0; j < a->insn_count; ++j)
        {
            const air_insn* insn;
            insn = &program->insns[a->insn_first + j];

            switch (insn->opcode)
            {
            case AIR_OP_NOP:
            case AIR_OP_SET_SPRITE:
            case AIR_OP_SET_TIME:
            case AIR_OP_SET_OFFSET:
            case AIR_OP_SET_FLIP:
            case AIR_OP_SET_BLEND:
            case AIR_OP_SET_SCALE:
            case AIR_OP_SET_ANGLE:
            case AIR_OP_SET_INTERP:
            case AIR_OP_PUSH_ELEM_BOXES:
                break;

            case AIR_OP_SET_CLSN_DEFAULT:
            case AIR_OP_SET_CLSN_ONCE:
                if (insn->operand_b < 0 || (air_u32)insn->operand_b > program->rect_count)
                {
                    air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: box count out of range");
                    return AIR_STATUS_EVERIFY;
                }
                if (insn->operand_c < 0 || (air_u32)(insn->operand_c + insn->operand_b) > program->rect_count)
                {
                    air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: box table range out of range");
                    return AIR_STATUS_EVERIFY;
                }
                break;

            case AIR_OP_MARK_LOOP:
                ++seen_loop;
                break;

            case AIR_OP_COMMIT_ELEM:
                ++elem_count;
                break;

            case AIR_OP_END_ACTION:
                break;

            default:
                air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: unknown opcode");
                return AIR_STATUS_EVERIFY;
            }
        }

        if (seen_loop > 1U)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: multiple loop markers");
            return AIR_STATUS_EVERIFY;
        }
        if (elem_count == 0U || elem_count != a->elem_count)
        {
            air_diag_push(diags, AIR_STATUS_EVERIFY, AIR_DIAG_ERROR, a->line, 1, a->action_no, -1, "validate: action has invalid element count");
            return AIR_STATUS_EVERIFY;
        }
    }

    return AIR_STATUS_OK;
}
