#include "air/air_ast.h"

const air_ast_action* air_ast_find_action(const air_ast* ast, air_i32 action_no)
{
    air_u32 i;

    if (ast == AIR_NULL)
    {
        return AIR_NULL;
    }
    for (i = 0; i < ast->action_count; ++i)
    {
        if (ast->actions[i].action_no == action_no)
        {
            return &ast->actions[i];
        }
    }
    return AIR_NULL;
}
