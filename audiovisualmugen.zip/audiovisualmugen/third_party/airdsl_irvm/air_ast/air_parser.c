#include "air/air_parser.h"

static air_bool air_parser_is_permissive(const air_parse_options* opts)
{
    return (air_bool)(opts != AIR_NULL && opts->permissive);
}

static void air_parser_downgrade_diags(air_diag_list* diags, air_u16 first)
{
    air_u16 i;

    if (diags == AIR_NULL || diags->items == AIR_NULL)
    {
        return;
    }
    for (i = first; i < diags->count; ++i)
    {
        if (diags->items[i].severity == AIR_DIAG_ERROR)
        {
            diags->items[i].severity = AIR_DIAG_WARNING;
            if (diags->error_count > 0)
            {
                --diags->error_count;
            }
            ++diags->warning_count;
        }
    }
}

static air_status air_count_nodes(const air_token_stream* tokens,
                                  const air_parse_options* opts,
                                  air_u32* out_actions,
                                  air_u32* out_stmts,
                                  air_diag_list* diags)
{
    air_u32 i;
    air_u32 actions;
    air_u32 stmts;

    actions = 0;
    stmts = 0;
    for (i = 0; i < tokens->line_count; ++i)
    {
        air_syn_stmt syn;
        air_status status;
        status = air_syntax_parse_line(&tokens->lines[i], opts, &syn,
                                       air_parser_is_permissive(opts) ? AIR_NULL : diags);
        if (status != AIR_STATUS_OK)
        {
            if (opts != AIR_NULL && opts->permissive)
            {
                continue;
            }
            return status;
        }
        if (syn.kind == AIR_SYN_BEGIN_ACTION)
        {
            ++actions;
        }
        else if (syn.kind != AIR_SYN_EMPTY)
        {
            ++stmts;
        }
    }

    *out_actions = actions;
    *out_stmts = stmts;
    return AIR_STATUS_OK;
}

air_status air_parser_parse_tokens(air_parse_result* out_result,
                                   air_arena* arena,
                                   const air_token_stream* tokens,
                                   const air_parse_options* opts,
                                   air_diag_list* diags)
{
    air_u32 action_cap;
    air_u32 stmt_cap;
    air_u32 action_write;
    air_u32 stmt_write;
    air_i32 current_action;
    air_i32 pending_rects;
    air_u8 pending_kind;
    air_i32 pending_index;
    air_bool loopstart_seen;
    air_u32 i;
    air_status status;

    if (out_result == AIR_NULL || arena == AIR_NULL || tokens == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "parser: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    out_result->tokens = *tokens;
    out_result->ast.actions = AIR_NULL;
    out_result->ast.action_count = 0;
    out_result->ast.stmts = AIR_NULL;
    out_result->ast.stmt_count = 0;

    status = air_count_nodes(tokens, opts, &action_cap, &stmt_cap, diags);
    if (status != AIR_STATUS_OK && !(opts != AIR_NULL && opts->permissive))
    {
        return status;
    }

    if (action_cap == 0)
    {
        air_diag_push(diags, AIR_STATUS_ESEMANTIC, AIR_DIAG_ERROR, 0, 0, -1, -1, "parser: no [Begin Action] blocks found");
        return AIR_STATUS_ESEMANTIC;
    }
    if (action_cap > AIR_MAX_ACTIONS)
    {
        air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, 0, 0, -1, -1, "parser: AIR_MAX_ACTIONS exceeded");
        return AIR_STATUS_EOVERFLOW;
    }

    out_result->ast.actions = (air_ast_action*)air_arena_alloc(arena, action_cap * (air_u32)sizeof(air_ast_action), 4U);
    out_result->ast.stmts = (air_syn_stmt*)air_arena_alloc(arena, stmt_cap * (air_u32)sizeof(air_syn_stmt), 4U);
    if (out_result->ast.actions == AIR_NULL || out_result->ast.stmts == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_ENOMEM, AIR_DIAG_ERROR, 0, 0, -1, -1, "parser: arena exhausted");
        return AIR_STATUS_ENOMEM;
    }

    action_write = 0;
    stmt_write = 0;
    current_action = -1;
    pending_rects = 0;
    pending_kind = AIR_CLSN_KIND_NONE;
    pending_index = 0;
    loopstart_seen = AIR_FALSE;

    for (i = 0; i < tokens->line_count; ++i)
    {
        air_syn_stmt syn;
        const air_token_line* line;
        air_u16 diag_first;
        line = &tokens->lines[i];

        diag_first = diags != AIR_NULL ? diags->count : 0;
        status = air_syntax_parse_line(line, opts, &syn, diags);
        if (status == AIR_STATUS_OK && syn.kind != AIR_SYN_EMPTY && opts != AIR_NULL && opts->trace != AIR_NULL)
        {
            air_trace_emit(opts->trace, AIR_TRACE_PARSER, line->line_no, current_action >= 0 ? out_result->ast.actions[current_action].action_no : -1, -1, 0, 0, "line");
        }
        if (status != AIR_STATUS_OK)
        {
            if (air_parser_is_permissive(opts))
            {
                air_parser_downgrade_diags(diags, diag_first);
                pending_rects = 0;
                pending_index = 0;
                pending_kind = AIR_CLSN_KIND_NONE;
                continue;
            }
            return status;
        }
        if (syn.kind == AIR_SYN_EMPTY)
        {
            continue;
        }

        if (syn.kind == AIR_SYN_BEGIN_ACTION)
        {
            if (pending_rects != 0)
            {
                air_diag_push(diags,
                              AIR_STATUS_ESEMANTIC,
                              air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                              line->line_no,
                              1,
                              -1,
                              -1,
                              "parser: incomplete collision list before new action");
                if (!air_parser_is_permissive(opts))
                {
                    return AIR_STATUS_ESEMANTIC;
                }
                pending_rects = 0;
            }
            out_result->ast.actions[action_write].action_no = syn.v.begin_action.action_no;
            out_result->ast.actions[action_write].stmt_first = stmt_write;
            out_result->ast.actions[action_write].stmt_count = 0;
            out_result->ast.actions[action_write].elem_count = 0;
            out_result->ast.actions[action_write].line = line->line_no;
            current_action = (air_i32)action_write;
            ++action_write;
            loopstart_seen = AIR_FALSE;
            continue;
        }

        if (current_action < 0)
        {
            air_diag_push(diags,
                          AIR_STATUS_ESEMANTIC,
                          air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                          line->line_no,
                          1,
                          -1,
                          -1,
                          "parser: statement before first [Begin Action]");
            if (air_parser_is_permissive(opts))
            {
                continue;
            }
            return AIR_STATUS_ESEMANTIC;
        }

        if (pending_rects != 0)
        {
            if (syn.kind != AIR_SYN_CLSN_RECT)
            {
                air_diag_push(diags,
                              AIR_STATUS_ESEMANTIC,
                              air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                              line->line_no,
                              1,
                              out_result->ast.actions[current_action].action_no,
                              -1,
                              "parser: expected more collision rectangles");
                if (!air_parser_is_permissive(opts))
                {
                    return AIR_STATUS_ESEMANTIC;
                }
                pending_rects = 0;
                pending_index = 0;
                pending_kind = AIR_CLSN_KIND_NONE;
            }
            else if (syn.v.clsn_rect.clsn_kind != pending_kind || syn.v.clsn_rect.rect_index != pending_index)
            {
                air_diag_push(diags,
                              AIR_STATUS_ESEMANTIC,
                              air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                              line->line_no,
                              1,
                              out_result->ast.actions[current_action].action_no,
                              -1,
                              "parser: collision label/index differs from declaration; declaration order used");
                if (!air_parser_is_permissive(opts))
                {
                    return AIR_STATUS_ESEMANTIC;
                }
                /*
                 * Elecbyte's own KFM720 AIR contains several Clsn1
                 * declarations followed by rectangles labelled Clsn2.
                 * M.U.G.E.N accepts that file.  In compatibility mode,
                 * the declaration owns the following N rectangles, so
                 * coerce the decorative label/index to declaration order.
                 */
                syn.v.clsn_rect.clsn_kind = pending_kind;
                syn.v.clsn_rect.rect_index = pending_index;
                --pending_rects;
                ++pending_index;
            }
            else
            {
                --pending_rects;
                ++pending_index;
            }
        }
        else if (syn.kind == AIR_SYN_CLSN_RECT)
        {
            air_diag_push(diags,
                          AIR_STATUS_ESEMANTIC,
                          air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                          line->line_no,
                          1,
                          out_result->ast.actions[current_action].action_no,
                          -1,
                          "parser: collision rectangle without prior declaration");
            if (air_parser_is_permissive(opts))
            {
                continue;
            }
            return AIR_STATUS_ESEMANTIC;
        }

        if (syn.kind == AIR_SYN_CLSN_DECL)
        {
            pending_rects = syn.v.clsn_decl.rect_count;
            pending_kind = syn.v.clsn_decl.clsn_kind;
            pending_index = 0;
        }

        if (syn.kind == AIR_SYN_LOOPSTART)
        {
            if (loopstart_seen)
            {
                air_diag_push(diags,
                              AIR_STATUS_ESEMANTIC,
                              air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                              line->line_no,
                              1,
                              out_result->ast.actions[current_action].action_no,
                              -1,
                              "parser: multiple Loopstart; keeping first");
                if (!air_parser_is_permissive(opts))
                {
                    return AIR_STATUS_ESEMANTIC;
                }
                continue;
            }
            loopstart_seen = AIR_TRUE;
        }

        if (stmt_write >= stmt_cap)
        {
            air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, line->line_no, 1, -1, -1, "parser: statement capacity exhausted");
            return AIR_STATUS_EOVERFLOW;
        }

        out_result->ast.stmts[stmt_write] = syn;
        ++stmt_write;
        ++out_result->ast.actions[current_action].stmt_count;
        if (syn.kind == AIR_SYN_ELEMENT)
        {
            ++out_result->ast.actions[current_action].elem_count;
            if (out_result->ast.actions[current_action].elem_count > AIR_MAX_ELEMS_PER_ACTION)
            {
                air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, line->line_no, 1, out_result->ast.actions[current_action].action_no, -1, "parser: AIR_MAX_ELEMS_PER_ACTION exceeded");
                return AIR_STATUS_EOVERFLOW;
            }
        }
    }

    if (pending_rects != 0)
    {
        air_diag_push(diags,
                      AIR_STATUS_ESEMANTIC,
                      air_parser_is_permissive(opts) ? AIR_DIAG_WARNING : AIR_DIAG_ERROR,
                      (air_i32)tokens->line_count,
                      1,
                      -1,
                      -1,
                      "parser: file ended before collision list finished");
        if (!air_parser_is_permissive(opts))
        {
            return AIR_STATUS_ESEMANTIC;
        }
    }

    out_result->ast.action_count = action_write;
    out_result->ast.stmt_count = stmt_write;
    return air_diag_has_errors(diags) ? AIR_STATUS_ESEMANTIC : AIR_STATUS_OK;
}

air_status air_parser_parse_text(air_parse_result* out_result,
                                 air_arena* arena,
                                 const char* text,
                                 air_u32 len,
                                 const air_parse_options* opts,
                                 air_diag_list* diags)
{
    air_token_stream tokens;
    air_lex_options lex_opts;
    air_status status;

    if (out_result == AIR_NULL || arena == AIR_NULL || text == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "parser: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    air_lex_options_default(&lex_opts);
    status = air_lex_text(&tokens, arena, text, len, &lex_opts, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }

    return air_parser_parse_tokens(out_result, arena, &tokens, opts, diags);
}
