#include "air/air_dump.h"

static void air_sink_text(const air_dump_sink* sink, const char* text)
{
    air_u32 len;
    if (sink == AIR_NULL || sink->fn == AIR_NULL || text == AIR_NULL)
    {
        return;
    }
    len = 0;
    while (text[len] != '\0')
    {
        ++len;
    }
    sink->fn(sink->user, text, len);
}

static void air_append_text(char* dst, air_u32 capacity, air_u32* used, const char* src)
{
    while (*src != '\0' && *used + 1 < capacity)
    {
        dst[*used] = *src;
        ++(*used);
        ++src;
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_append_i32(char* dst, air_u32 capacity, air_u32* used, air_i32 value)
{
    char temp[32];
    air_u32 len;
    air_u32 mag;
    air_bool neg;

    neg = AIR_FALSE;
    if (value < 0)
    {
        neg = AIR_TRUE;
        mag = (air_u32)(-value);
    }
    else
    {
        mag = (air_u32)value;
    }

    len = 0;
    do
    {
        temp[len++] = (char)('0' + (mag % 10U));
        mag /= 10U;
    } while (mag != 0U);

    if (neg)
    {
        temp[len++] = '-';
    }
    while (len > 0 && *used + 1 < capacity)
    {
        --len;
        dst[*used] = temp[len];
        ++(*used);
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

air_status air_ast_dump(const air_ast* ast, const air_dump_sink* sink, air_diag_list* diags)
{
    air_u32 i;
    air_u32 j;
    char line[AIR_MAX_DUMP_LINE];

    if (ast == AIR_NULL || sink == AIR_NULL || sink->fn == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "dump: invalid ast or sink");
        return AIR_STATUS_EINVAL;
    }

    for (i = 0; i < ast->action_count; ++i)
    {
        const air_ast_action* action;
        air_u32 used;
        action = &ast->actions[i];

        used = 0;
        line[0] = '\0';
        air_append_text(line, sizeof(line), &used, "Action ");
        air_append_i32(line, sizeof(line), &used, action->action_no);
        air_append_text(line, sizeof(line), &used, "\n");
        air_sink_text(sink, line);

        for (j = action->stmt_first; j < action->stmt_first + action->stmt_count; ++j)
        {
            const air_syn_stmt* stmt;
            used = 0;
            line[0] = '\0';
            stmt = &ast->stmts[j];
            air_append_text(line, sizeof(line), &used, "  kind=");
            air_append_i32(line, sizeof(line), &used, stmt->kind);
            air_append_text(line, sizeof(line), &used, " line=");
            air_append_i32(line, sizeof(line), &used, stmt->line);
            air_append_text(line, sizeof(line), &used, "\n");
            air_sink_text(sink, line);
        }
    }
    return AIR_STATUS_OK;
}

air_status air_program_dump(const air_program* program, const air_dump_sink* sink, air_diag_list* diags)
{
    return air_vm_dump_program(program, sink, diags);
}
