#include "air/air_debugdraw.h"

air_status air_debug_build_primitives(const air_boxset* set,
                                      air_debug_primitive* out_prims,
                                      air_u16 prim_capacity,
                                      air_u16* out_count,
                                      air_diag_list* diags)
{
    air_u16 i;
    air_u16 count;

    if (set == AIR_NULL || out_prims == AIR_NULL || out_count == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "debugdraw: invalid arguments");
        return AIR_STATUS_EINVAL;
    }
    if ((air_u32)set->clsn1_count + (air_u32)set->clsn2_count > prim_capacity)
    {
        air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, 0, 0, -1, -1, "debugdraw: primitive capacity too small");
        return AIR_STATUS_EOVERFLOW;
    }

    count = 0;
    for (i = 0; i < set->clsn1_count; ++i)
    {
        out_prims[count].rect = set->clsn1[i];
        out_prims[count].color = AIR_DEBUG_COLOR_RED;
        ++count;
    }
    for (i = 0; i < set->clsn2_count; ++i)
    {
        out_prims[count].rect = set->clsn2[i];
        out_prims[count].color = AIR_DEBUG_COLOR_BLUE;
        ++count;
    }
    *out_count = count;
    return AIR_STATUS_OK;
}
