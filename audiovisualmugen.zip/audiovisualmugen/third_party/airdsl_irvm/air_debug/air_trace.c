#include "air/air_trace.h"

void air_trace_emit(const air_trace_sink* sink,
                    air_trace_kind kind,
                    air_i32 line,
                    air_i32 action_no,
                    air_i32 elem_index,
                    air_tick_t tick,
                    air_u32 pc,
                    const char* message)
{
    air_trace_event ev;
    air_u32 bit;

    if (sink == AIR_NULL || sink->fn == AIR_NULL)
    {
        return;
    }
    bit = AIR_TRACE_MASK(kind);
    if ((sink->mask & bit) == 0U)
    {
        return;
    }
    ev.kind = kind;
    ev.line = line;
    ev.action_no = action_no;
    ev.elem_index = elem_index;
    ev.tick = tick;
    ev.pc = pc;
    ev.message = message;
    sink->fn(sink->user, &ev);
}
