#include "air/air_boxset.h"

void air_boxset_init(air_boxset* set,
                     air_rect_fx* clsn1,
                     air_u16 clsn1_count,
                     air_rect_fx* clsn2,
                     air_u16 clsn2_count)
{
    if (set == AIR_NULL)
    {
        return;
    }
    set->clsn1 = clsn1;
    set->clsn1_count = clsn1_count;
    set->clsn2 = clsn2;
    set->clsn2_count = clsn2_count;
}

air_bool air_boxset_overlap(const air_rect_fx* a, const air_rect_fx* b)
{
    if (a == AIR_NULL || b == AIR_NULL)
    {
        return AIR_FALSE;
    }
    if (a->x2 < b->x1 || b->x2 < a->x1)
    {
        return AIR_FALSE;
    }
    if (a->y2 < b->y1 || b->y2 < a->y1)
    {
        return AIR_FALSE;
    }
    return AIR_TRUE;
}

air_bool air_boxset_attack_hits(const air_boxset* attacker, const air_boxset* defender)
{
    air_u16 i;
    air_u16 j;

    if (attacker == AIR_NULL || defender == AIR_NULL)
    {
        return AIR_FALSE;
    }
    for (i = 0; i < attacker->clsn1_count; ++i)
    {
        for (j = 0; j < defender->clsn2_count; ++j)
        {
            if (air_boxset_overlap(&attacker->clsn1[i], &defender->clsn2[j]))
            {
                return AIR_TRUE;
            }
        }
    }
    return AIR_FALSE;
}
