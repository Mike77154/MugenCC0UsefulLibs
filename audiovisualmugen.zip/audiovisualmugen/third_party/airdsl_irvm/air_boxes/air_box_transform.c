#include "air/air_box_transform.h"

void air_box_transform_default(air_box_transform* xf)
{
    if (xf == AIR_NULL)
    {
        return;
    }
    xf->origin_x = 0;
    xf->origin_y = 0;
    xf->facing_right = AIR_TRUE;
    xf->scale_x = AIR_FIXED_ONE;
    xf->scale_y = AIR_FIXED_ONE;
    xf->policy = AIR_BOX_POLICY_CLASSIC | AIR_BOX_POLICY_IGNORE_ANGLE;
}

void air_boxes_apply_origin(air_rect_fx* rects, air_u16 count, air_fx origin_x, air_fx origin_y)
{
    air_u16 i;

    for (i = 0; i < count; ++i)
    {
        rects[i].x1 += origin_x;
        rects[i].x2 += origin_x;
        rects[i].y1 += origin_y;
        rects[i].y2 += origin_y;
    }
}

void air_boxes_apply_facing(air_rect_fx* rects, air_u16 count, air_bool facing_right)
{
    air_u16 i;

    if (facing_right)
    {
        return;
    }
    for (i = 0; i < count; ++i)
    {
        air_fx x1;
        air_fx x2;
        x1 = -rects[i].x2;
        x2 = -rects[i].x1;
        rects[i].x1 = x1;
        rects[i].x2 = x2;
    }
}

void air_boxes_apply_scale_policy(air_rect_fx* rects,
                                  air_u16 count,
                                  air_fx scale_x,
                                  air_fx scale_y,
                                  air_u32 policy)
{
    air_u16 i;
    air_bool do_scale;

    do_scale = (air_bool)((policy & AIR_BOX_POLICY_SCALE_XY) != 0U ||
                          (policy & AIR_BOX_POLICY_VISUAL_MATCH) != 0U);
    if (!do_scale)
    {
        return;
    }

    for (i = 0; i < count; ++i)
    {
        rects[i].x1 = air_fx_mul(rects[i].x1, scale_x);
        rects[i].x2 = air_fx_mul(rects[i].x2, scale_x);
        rects[i].y1 = air_fx_mul(rects[i].y1, scale_y);
        rects[i].y2 = air_fx_mul(rects[i].y2, scale_y);
        if (rects[i].x1 > rects[i].x2)
        {
            air_fx t;
            t = rects[i].x1;
            rects[i].x1 = rects[i].x2;
            rects[i].x2 = t;
        }
        if (rects[i].y1 > rects[i].y2)
        {
            air_fx t2;
            t2 = rects[i].y1;
            rects[i].y1 = rects[i].y2;
            rects[i].y2 = t2;
        }
    }
}
