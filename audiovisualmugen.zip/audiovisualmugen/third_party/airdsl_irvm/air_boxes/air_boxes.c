#include "air/air_boxes.h"

air_status air_boxes_to_rects(const air_program* program,
                              air_box_ref ref,
                              air_rect_fx* out_rects,
                              air_u16 capacity,
                              air_diag_list* diags)
{
    air_u16 i;

    if (program == AIR_NULL || out_rects == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "boxes: invalid arguments");
        return AIR_STATUS_EINVAL;
    }
    if (ref.count > capacity)
    {
        air_diag_push(diags, AIR_STATUS_EOVERFLOW, AIR_DIAG_ERROR, 0, 0, -1, -1, "boxes: output buffer too small");
        return AIR_STATUS_EOVERFLOW;
    }
    if (ref.first + ref.count > program->rect_count)
    {
        air_diag_push(diags, AIR_STATUS_ERANGE, AIR_DIAG_ERROR, 0, 0, -1, -1, "boxes: box ref out of range");
        return AIR_STATUS_ERANGE;
    }

    for (i = 0; i < ref.count; ++i)
    {
        const air_rect_i* src;
        src = &program->rects[ref.first + i];
        out_rects[i].x1 = air_fx_from_int(src->x1);
        out_rects[i].y1 = air_fx_from_int(src->y1);
        out_rects[i].x2 = air_fx_from_int(src->x2);
        out_rects[i].y2 = air_fx_from_int(src->y2);
    }
    return AIR_STATUS_OK;
}

air_status air_boxes_build_from_pose(const air_program* program,
                                     const air_pose_sample* sample,
                                     const air_box_transform* xf,
                                     air_boxset* out_set,
                                     air_rect_fx* clsn1_buffer,
                                     air_u16 clsn1_capacity,
                                     air_rect_fx* clsn2_buffer,
                                     air_u16 clsn2_capacity,
                                     air_diag_list* diags)
{
    air_box_transform local_xf;
    air_status status;

    if (program == AIR_NULL || sample == AIR_NULL || out_set == AIR_NULL)
    {
        air_diag_push(diags, AIR_STATUS_EINVAL, AIR_DIAG_ERROR, 0, 0, -1, -1, "boxes: invalid arguments");
        return AIR_STATUS_EINVAL;
    }

    if (xf == AIR_NULL)
    {
        air_box_transform_default(&local_xf);
        xf = &local_xf;
    }

    status = air_boxes_to_rects(program, sample->clsn1, clsn1_buffer, clsn1_capacity, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }
    status = air_boxes_to_rects(program, sample->clsn2, clsn2_buffer, clsn2_capacity, diags);
    if (status != AIR_STATUS_OK)
    {
        return status;
    }

    air_boxes_apply_scale_policy(clsn1_buffer, sample->clsn1.count, xf->scale_x, xf->scale_y, xf->policy);
    air_boxes_apply_scale_policy(clsn2_buffer, sample->clsn2.count, xf->scale_x, xf->scale_y, xf->policy);

    air_boxes_apply_facing(clsn1_buffer, sample->clsn1.count, xf->facing_right);
    air_boxes_apply_facing(clsn2_buffer, sample->clsn2.count, xf->facing_right);

    air_boxes_apply_origin(clsn1_buffer, sample->clsn1.count, xf->origin_x, xf->origin_y);
    air_boxes_apply_origin(clsn2_buffer, sample->clsn2.count, xf->origin_x, xf->origin_y);

    air_boxset_init(out_set, clsn1_buffer, sample->clsn1.count, clsn2_buffer, sample->clsn2.count);
    return AIR_STATUS_OK;
}

void air_boxes_debug_colors(air_u8* out_clsn1_color, air_u8* out_clsn2_color)
{
    if (out_clsn1_color != AIR_NULL)
    {
        *out_clsn1_color = 1;
    }
    if (out_clsn2_color != AIR_NULL)
    {
        *out_clsn2_color = 2;
    }
}
