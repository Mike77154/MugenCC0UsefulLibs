#include "air/air_status.h"

static void air_copy_message(char* dst, air_u32 capacity, const char* src)
{
    air_u32 i;

    if (capacity == 0)
    {
        return;
    }
    if (src == AIR_NULL)
    {
        dst[0] = '\0';
        return;
    }

    i = 0;
    while (i + 1 < capacity && src[i] != '\0')
    {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = '\0';
}

const char* air_status_name(air_status status)
{
    switch (status)
    {
    case AIR_STATUS_OK: return "AIR_STATUS_OK";
    case AIR_STATUS_EINVAL: return "AIR_STATUS_EINVAL";
    case AIR_STATUS_ENOMEM: return "AIR_STATUS_ENOMEM";
    case AIR_STATUS_ESYNTAX: return "AIR_STATUS_ESYNTAX";
    case AIR_STATUS_ESEMANTIC: return "AIR_STATUS_ESEMANTIC";
    case AIR_STATUS_EVERIFY: return "AIR_STATUS_EVERIFY";
    case AIR_STATUS_ERANGE: return "AIR_STATUS_ERANGE";
    case AIR_STATUS_ENOTFOUND: return "AIR_STATUS_ENOTFOUND";
    case AIR_STATUS_ESTATE: return "AIR_STATUS_ESTATE";
    case AIR_STATUS_EIO: return "AIR_STATUS_EIO";
    case AIR_STATUS_EUNSUPPORTED: return "AIR_STATUS_EUNSUPPORTED";
    case AIR_STATUS_EOVERFLOW: return "AIR_STATUS_EOVERFLOW";
    default: return "AIR_STATUS_UNKNOWN";
    }
}

const char* air_diag_severity_name(air_diag_severity severity)
{
    switch (severity)
    {
    case AIR_DIAG_INFO: return "info";
    case AIR_DIAG_WARNING: return "warning";
    case AIR_DIAG_ERROR: return "error";
    default: return "unknown";
    }
}

void air_diag_list_init(air_diag_list* list, air_diag* storage, air_u16 capacity)
{
    if (list == AIR_NULL)
    {
        return;
    }
    list->items = storage;
    list->capacity = capacity;
    list->count = 0;
    list->error_count = 0;
    list->warning_count = 0;
}

void air_diag_list_reset(air_diag_list* list)
{
    if (list == AIR_NULL)
    {
        return;
    }
    list->count = 0;
    list->error_count = 0;
    list->warning_count = 0;
}

air_status air_diag_push(air_diag_list* list,
                         air_status code,
                         air_diag_severity severity,
                         air_i32 line,
                         air_i32 column,
                         air_i32 action_no,
                         air_i32 elem_index,
                         const char* message)
{
    air_diag* diag;

    if (list == AIR_NULL || list->items == AIR_NULL || list->capacity == 0)
    {
        return code;
    }
    if (list->count >= list->capacity)
    {
        return AIR_STATUS_EOVERFLOW;
    }
    diag = &list->items[list->count++];
    diag->code = code;
    diag->severity = severity;
    diag->line = line;
    diag->column = column;
    diag->action_no = action_no;
    diag->elem_index = elem_index;
    air_copy_message(diag->message, (air_u32)sizeof(diag->message), message);

    if (severity == AIR_DIAG_ERROR)
    {
        ++list->error_count;
    }
    else if (severity == AIR_DIAG_WARNING)
    {
        ++list->warning_count;
    }
    return code;
}

const air_diag* air_diag_last(const air_diag_list* list)
{
    if (list == AIR_NULL || list->count == 0)
    {
        return AIR_NULL;
    }
    return &list->items[list->count - 1];
}

air_bool air_diag_has_errors(const air_diag_list* list)
{
    if (list == AIR_NULL)
    {
        return AIR_FALSE;
    }
    return (air_bool)(list->error_count != 0);
}

static void air_append_text(char* dst, air_u32 capacity, air_u32* used, const char* src)
{
    while (*src != '\0' && *used + 1 < capacity)
    {
        dst[*used] = *src;
        ++(*used);
        ++src;
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

static void air_append_i32(char* dst, air_u32 capacity, air_u32* used, air_i32 value)
{
    char temp[32];
    air_u32 len;
    air_u32 i;
    air_u32 j;
    air_u32 magnitude;
    air_bool negative;

    negative = AIR_FALSE;
    if (value < 0)
    {
        negative = AIR_TRUE;
        magnitude = (air_u32)(-value);
    }
    else
    {
        magnitude = (air_u32)value;
    }

    len = 0;
    do
    {
        temp[len++] = (char)('0' + (magnitude % 10U));
        magnitude /= 10U;
    } while (magnitude != 0U && len < (air_u32)sizeof(temp));

    if (negative && len < (air_u32)sizeof(temp))
    {
        temp[len++] = '-';
    }

    j = 0;
    for (i = 0; i < len; ++i)
    {
        j = len - 1 - i;
        if (*used + 1 >= capacity)
        {
            break;
        }
        dst[*used] = temp[j];
        ++(*used);
    }
    if (*used < capacity)
    {
        dst[*used] = '\0';
    }
}

void air_diag_format(const air_diag* diag, char* buffer, air_u32 capacity)
{
    air_u32 used;

    if (buffer == AIR_NULL || capacity == 0)
    {
        return;
    }
    buffer[0] = '\0';
    if (diag == AIR_NULL)
    {
        return;
    }

    used = 0;
    air_append_text(buffer, capacity, &used, air_diag_severity_name(diag->severity));
    air_append_text(buffer, capacity, &used, ": ");
    air_append_text(buffer, capacity, &used, air_status_name(diag->code));
    if (diag->line > 0)
    {
        air_append_text(buffer, capacity, &used, " @ ");
        air_append_i32(buffer, capacity, &used, diag->line);
        air_append_text(buffer, capacity, &used, ":");
        air_append_i32(buffer, capacity, &used, diag->column);
    }
    if (diag->action_no >= 0)
    {
        air_append_text(buffer, capacity, &used, " action=");
        air_append_i32(buffer, capacity, &used, diag->action_no);
    }
    if (diag->elem_index >= 0)
    {
        air_append_text(buffer, capacity, &used, " elem=");
        air_append_i32(buffer, capacity, &used, diag->elem_index);
    }
    air_append_text(buffer, capacity, &used, " ");
    air_append_text(buffer, capacity, &used, diag->message);
}
