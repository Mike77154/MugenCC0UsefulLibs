#include "air/air_arena.h"

void air_arena_init(air_arena* arena, void* memory, air_u32 capacity)
{
    if (arena == AIR_NULL)
    {
        return;
    }
    arena->base = (air_u8*)memory;
    arena->capacity = capacity;
    arena->used = 0;
    arena->peak_used = 0;
}

void air_arena_reset(air_arena* arena)
{
    if (arena == AIR_NULL)
    {
        return;
    }
    arena->used = 0;
}

void* air_arena_alloc(air_arena* arena, air_u32 size, air_u32 align)
{
    air_u32 mask;
    air_u32 start;
    air_u32 end;

    if (arena == AIR_NULL || arena->base == AIR_NULL || align == 0)
    {
        return AIR_NULL;
    }

    mask = align - 1;
    start = (arena->used + mask) & ~mask;
    end = start + size;
    if (end < start || end > arena->capacity)
    {
        return AIR_NULL;
    }
    arena->used = end;
    if (arena->peak_used < end)
    {
        arena->peak_used = end;
    }
    return arena->base + start;
}

air_u32 air_arena_mark(const air_arena* arena)
{
    if (arena == AIR_NULL)
    {
        return 0;
    }
    return arena->used;
}

void air_arena_rewind(air_arena* arena, air_u32 mark)
{
    if (arena == AIR_NULL)
    {
        return;
    }
    if (mark <= arena->used)
    {
        arena->used = mark;
    }
}
