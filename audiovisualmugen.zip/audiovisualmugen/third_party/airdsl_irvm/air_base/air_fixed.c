#include "air/air_fixed.h"

air_fx air_fx_from_int(air_i32 value)
{
    return (air_fx)(value << AIR_FIXED_SHIFT);
}

air_i32 air_fx_to_int_floor(air_fx value)
{
    return (air_i32)(value >> AIR_FIXED_SHIFT);
}

air_fx air_fx_abs(air_fx value)
{
    return value < 0 ? -value : value;
}

air_fx air_fx_mul(air_fx a, air_fx b)
{
    air_i32 sign;
    air_u32 ua;
    air_u32 ub;
    air_u32 ahi;
    air_u32 alo;
    air_u32 bhi;
    air_u32 blo;
    air_i32 result;

    sign = 1;
    if (a < 0)
    {
        sign = -sign;
        a = -a;
    }
    if (b < 0)
    {
        sign = -sign;
        b = -b;
    }

    ua = (air_u32)a;
    ub = (air_u32)b;
    ahi = ua >> AIR_FIXED_SHIFT;
    alo = ua & 0xFFFFU;
    bhi = ub >> AIR_FIXED_SHIFT;
    blo = ub & 0xFFFFU;

    result = (air_i32)((ahi * bhi) << AIR_FIXED_SHIFT);
    result += (air_i32)(ahi * blo);
    result += (air_i32)(bhi * alo);
    result += (air_i32)((alo * blo) >> AIR_FIXED_SHIFT);

    if (sign < 0)
    {
        result = -result;
    }
    return result;
}

air_fx air_fx_div(air_fx a, air_fx b)
{
    air_i32 sign;
    air_i32 q;
    air_i32 r;
    air_i32 frac;

    if (b == 0)
    {
        return 0;
    }

    sign = 1;
    if (a < 0)
    {
        sign = -sign;
        a = -a;
    }
    if (b < 0)
    {
        sign = -sign;
        b = -b;
    }

    q = (air_i32)(a / b);
    r = (air_i32)(a % b);

    frac = (air_i32)(((air_u32)r << 8) / (air_u32)b);
    r = (air_i32)(((air_u32)r << 8) % (air_u32)b);
    frac = (air_i32)((frac << 8) + (((air_u32)r << 8) / (air_u32)b));

    q = (air_i32)((q << AIR_FIXED_SHIFT) + frac);
    if (sign < 0)
    {
        q = -q;
    }
    return q;
}

air_status air_fx_parse(const char* text, air_u16 len, air_fx* out_value)
{
    air_i32 sign;
    air_i32 integer_part;
    air_i32 frac_fixed;
    air_fx unit;
    air_u16 i;
    air_bool seen_dot;

    if (text == AIR_NULL || out_value == AIR_NULL || len == 0)
    {
        return AIR_STATUS_EINVAL;
    }

    sign = 1;
    integer_part = 0;
    frac_fixed = 0;
    unit = AIR_FIXED_ONE / 10;
    seen_dot = AIR_FALSE;
    i = 0;

    if (text[i] == '-')
    {
        sign = -1;
        ++i;
    }
    else if (text[i] == '+')
    {
        ++i;
    }

    for (; i < len; ++i)
    {
        char ch;
        ch = text[i];
        if (ch == '.')
        {
            if (seen_dot)
            {
                return AIR_STATUS_ESYNTAX;
            }
            seen_dot = AIR_TRUE;
            continue;
        }
        if (ch < '0' || ch > '9')
        {
            return AIR_STATUS_ESYNTAX;
        }
        if (!seen_dot)
        {
            integer_part = (air_i32)(integer_part * 10 + (air_i32)(ch - '0'));
        }
        else if (unit > 0)
        {
            frac_fixed = (air_i32)(frac_fixed + (air_i32)(ch - '0') * unit);
            unit = unit / 10;
        }
    }

    *out_value = air_fx_from_int((air_i32)(sign * integer_part));
    if (sign < 0)
    {
        *out_value = (air_fx)(*out_value - air_fx_abs(frac_fixed));
    }
    else
    {
        *out_value = (air_fx)(*out_value + frac_fixed);
    }
    return AIR_STATUS_OK;
}
