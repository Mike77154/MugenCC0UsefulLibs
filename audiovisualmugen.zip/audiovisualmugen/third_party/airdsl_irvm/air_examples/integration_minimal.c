#include "air/air_api.h"

static unsigned char asset_mem[256 * 1024];
static unsigned char scratch_mem[256 * 1024];
static air_diag diag_storage[AIR_MAX_DIAGS];

int main(void)
{
    air_arena asset_arena;
    air_arena scratch_arena;
    air_diag_list diags;
    air_build_options opts;
    air_ir_program ir;
    air_program program;
    air_runtime rt;
    const air_pose_sample* sample;
    const char* text =
        "[Begin Action 0]\n"
        "0,0, 0,0, 3\n"
        "Loopstart\n"
        "0,1, 0,0, -1\n";

    air_arena_init(&asset_arena, asset_mem, (air_u32)sizeof(asset_mem));
    air_arena_init(&scratch_arena, scratch_mem, (air_u32)sizeof(scratch_mem));
    air_diag_list_init(&diags, diag_storage, (air_u16)AIR_COUNTOF(diag_storage));
    air_build_options_default(&opts);

    if (air_ir_build_from_text(&ir, &scratch_arena, &asset_arena, text, 52U, &opts.parse, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }

    air_arena_reset(&asset_arena);
    if (air_program_build_from_ir(&program, &asset_arena, &ir, &opts, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }

    air_runtime_init(&rt, &program, AIR_NULL);
    if (air_runtime_set_action(&rt, 0, &diags) != AIR_STATUS_OK)
    {
        return 1;
    }
    sample = air_runtime_get_pose(&rt);
    return sample != AIR_NULL ? 0 : 1;
}
