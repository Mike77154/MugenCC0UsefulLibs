#include <stdio.h>
#include <string.h>
#include "air/air_api.h"

static int expect_true(air_bool cond, const char* msg)
{
    if (!cond)
    {
        printf("FAIL: %s\n", msg);
        return 1;
    }
    return 0;
}

static int build_from_file(const char* path,
                           air_program* program,
                           air_arena* asset_arena,
                           air_arena* scratch_arena,
                           air_diag_list* diags,
                           char* file_buf,
                           air_u32 file_cap)
{
    air_build_options opts;
    air_u32 file_size;
    air_status status;

    air_build_options_default(&opts);
    opts.parse.permissive = AIR_TRUE;

    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        return 1;
    }
    air_diag_list_reset(diags);
    air_arena_reset(asset_arena);
    air_arena_reset(scratch_arena);
    status = air_program_build_from_text(program, asset_arena, scratch_arena, file_buf, file_size, &opts, diags);
    if (status != AIR_STATUS_OK || air_diag_has_errors(diags))
    {
        return 1;
    }
    return 0;
}

static int build_ir_from_file(const char* path,
                              air_ir_program* ir,
                              air_arena* ir_arena,
                              air_arena* scratch_arena,
                              air_diag_list* diags,
                              char* file_buf,
                              air_u32 file_cap)
{
    air_parse_options opts;
    air_u32 file_size;
    air_status status;

    air_parse_options_default(&opts);
    opts.permissive = AIR_TRUE;

    status = air_file_read_all(path, file_buf, file_cap, &file_size);
    if (status != AIR_STATUS_OK)
    {
        return 1;
    }
    air_diag_list_reset(diags);
    air_arena_reset(ir_arena);
    air_arena_reset(scratch_arena);
    status = air_ir_build_from_text(ir, ir_arena, scratch_arena, file_buf, file_size, &opts, diags);
    if (status != AIR_STATUS_OK || air_diag_has_errors(diags))
    {
        return 1;
    }
    return 0;
}

int main(void)
{
    static unsigned char asset_mem[1024 * 1024];
    static unsigned char scratch_mem[1024 * 1024];
    static air_diag diag_storage[AIR_MAX_DIAGS];
    static char file_buf[AIR_MAX_FILE_BYTES];
    static unsigned char bc_buf[1024 * 1024];
    air_arena asset_arena;
    air_arena scratch_arena;
    air_diag_list diags;
    air_program program;
    air_program loaded;
    air_program direct_program;
    air_ir_program ir;
    air_runtime rt;
    air_box_transform xf;
    air_boxset set;
    air_rect_fx clsn1[64];
    air_rect_fx clsn2[64];
    air_u32 bc_size;
    int fails;
    air_status status;

    fails = 0;
    air_arena_init(&asset_arena, asset_mem, (air_u32)sizeof(asset_mem));
    air_arena_init(&scratch_arena, scratch_mem, (air_u32)sizeof(scratch_mem));
    air_diag_list_init(&diags, diag_storage, (air_u16)AIR_COUNTOF(diag_storage));

    if (build_ir_from_file("air_examples/sample.air", &ir, &scratch_arena, &asset_arena, &diags, file_buf, (air_u32)sizeof(file_buf)) != 0)
    {
        printf("FAIL: build IR sample.air\n");
        return 1;
    }

    fails += expect_true(ir.action_count == 2U, "expected 2 IR actions");
    fails += expect_true(ir.elem_count == 8U, "expected 8 IR elems");
    fails += expect_true(ir.rect_count == 6U, "expected 6 IR rects");
    fails += expect_true(ir.actions[0].loop_elem == 2U, "expected loop elem on action 0");

    air_arena_reset(&asset_arena);
    status = air_program_build_from_ir(&program, &asset_arena, &ir, AIR_NULL, &diags);
    fails += expect_true(status == AIR_STATUS_OK, "lower IR to program");
    fails += expect_true(program.action_count == 2U, "expected 2 actions");
    fails += expect_true(program.rect_count == 6U, "expected 6 rects");

    if (build_from_file("air_examples/sample.air", &direct_program, &asset_arena, &scratch_arena, &diags, file_buf, (air_u32)sizeof(file_buf)) != 0)
    {
        printf("FAIL: direct build sample.air\n");
        return 1;
    }
    fails += expect_true(direct_program.action_count == program.action_count, "direct build action count");
    fails += expect_true(direct_program.rect_count == program.rect_count, "direct build rect count");

    air_runtime_init(&rt, &program, AIR_NULL);
    status = air_runtime_set_action(&rt, 200, &diags);
    fails += expect_true(status == AIR_STATUS_OK, "runtime set action");
    status = air_runtime_step_ticks(&rt, 2, &diags);
    fails += expect_true(status == AIR_STATUS_OK, "runtime step");
    fails += expect_true(air_runtime_get_pose(&rt)->clsn1.count == 1U, "attack box should be visible");

    air_box_transform_default(&xf);
    status = air_boxes_build_from_pose(&program,
                                       air_runtime_get_pose(&rt),
                                       &xf,
                                       &set,
                                       clsn1,
                                       (air_u16)AIR_COUNTOF(clsn1),
                                       clsn2,
                                       (air_u16)AIR_COUNTOF(clsn2),
                                       &diags);
    fails += expect_true(status == AIR_STATUS_OK, "box build");
    fails += expect_true(set.clsn1_count == 1U, "one clsn1");

    status = air_program_write_serialized(&program, bc_buf, (air_u32)sizeof(bc_buf), &bc_size, &diags);
    fails += expect_true(status == AIR_STATUS_OK, "serialize");

    {
        const char* bad_text = "Clsn2[0] = 0,0,1,1\n";
        air_build_options bad_opts;
        air_program bad_program;
        air_build_options_default(&bad_opts);
        bad_opts.parse.permissive = AIR_FALSE;
        air_diag_list_reset(&diags);
        air_arena_reset(&asset_arena);
        air_arena_reset(&scratch_arena);
        status = air_program_build_from_text(&bad_program, &asset_arena, &scratch_arena, bad_text, 19, &bad_opts, &diags);
        fails += expect_true(status != AIR_STATUS_OK, "negative parse should fail");
    }
    {
        const char* clear_once_text =
            "[Begin Action 0]\n"
            "Clsn2Default: 1\n"
            "Clsn2[0] = 0,0,10,10\n"
            "0,0, 0,0, 1\n"
            "Clsn2: 0\n"
            "0,1, 0,0, -1\n";
        air_ir_program clear_ir;
        air_program clear_program;
        air_runtime clear_rt;
        air_parse_options clear_parse;
        air_parse_options_default(&clear_parse);
        clear_parse.permissive = AIR_FALSE;
        air_diag_list_reset(&diags);
        air_arena_reset(&scratch_arena);
        air_arena_reset(&asset_arena);
        status = air_ir_build_from_text(&clear_ir, &scratch_arena, &asset_arena, clear_once_text, (air_u32)strlen(clear_once_text), &clear_parse, &diags);
        fails += expect_true(status == AIR_STATUS_OK, "build once-clear IR");
        if (status == AIR_STATUS_OK)
        {
            fails += expect_true(clear_ir.elems[1].clsn2.count == 0U, "once-clear should override default boxes");
            air_arena_reset(&asset_arena);
            status = air_program_build_from_ir(&clear_program, &asset_arena, &clear_ir, AIR_NULL, &diags);
            fails += expect_true(status == AIR_STATUS_OK, "lower once-clear IR");
            if (status == AIR_STATUS_OK)
            {
                air_runtime_init(&clear_rt, &clear_program, AIR_NULL);
                status = air_runtime_set_action(&clear_rt, 0, &diags);
                fails += expect_true(status == AIR_STATUS_OK, "set once-clear action");
                if (status == AIR_STATUS_OK)
                {
                    status = air_runtime_step_ticks(&clear_rt, 1, &diags);
                    fails += expect_true(status == AIR_STATUS_OK, "step once-clear action");
                    if (status == AIR_STATUS_OK)
                    {
                        fails += expect_true(air_runtime_get_pose(&clear_rt)->clsn2.count == 0U, "runtime should expose cleared hurtboxes");
                    }
                }
            }
        }
    }
    air_arena_reset(&asset_arena);
    status = air_program_read_serialized(&loaded, &asset_arena, bc_buf, bc_size, &diags);
    fails += expect_true(status == AIR_STATUS_OK, "deserialize");
    fails += expect_true(loaded.action_count == program.action_count, "serialized action count");

    if (fails == 0)
    {
        printf("PASS\n");
    }
    return fails ? 1 : 0;
}
