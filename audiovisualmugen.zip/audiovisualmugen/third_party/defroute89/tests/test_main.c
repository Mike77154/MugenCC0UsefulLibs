#include <stdio.h>
#include <string.h>

#include "mugen_char_def.h"

#define TEST_ASSERT(expr) \
    do { \
        if (!(expr)) { \
            fprintf(stderr, "assertion failed: %s (%s:%d)\n", #expr, __FILE__, __LINE__); \
            return 1; \
        } \
    } while (0)

static int test_basic_character_parse(void)
{
    static const char text[] =
        "; Character DEF\n"
        "[Info]\n"
        "name = \"Unit Test\"\n"
        "displayname = \"Unit Test EX\"\n"
        "versiondate = 01,02,2026\n"
        "mugenversion = 1.1\n"
        "author = \"Tester\"\n"
        "pal.defaults = 1,2,3,4\n"
        "localcoord = 320,240\n"
        "\n"
        "[Files]\n"
        "cmd = unit.cmd\n"
        "cns = unit.cns\n"
        "st = unit.cns\n"
        "st1 = states1.cns\n"
        "st2 = states2.cns\n"
        "stcommon = common1.cns\n"
        "sprite = unit.sff\n"
        "anim = unit.air\n"
        "sound = unit.snd\n"
        "ai = unit.ai\n"
        "\n"
        "[Palette Keymap]\n"
        "x = 1\n"
        "y = 2\n"
        "z = 3\n"
        "a = 4\n"
        "b = 5\n"
        "c = 6\n"
        "\n"
        "[Arcade]\n"
        "intro.storyboard = intro.def\n"
        "ending.storyboard = ending.def\n";

    cfg_document doc;
    cfg_parse_options options;
    mugen_char_def character;
    unsigned short record_index;
    cfg_fix_t delta_values[2];
    int count;
    int status;
    char text_out[64];

    cfg_parse_options_mugen(&options);
    status = cfg_parse_buffer(&doc,
                              "unit.def",
                              text,
                              sizeof(text) - 1U,
                              &options);
    TEST_ASSERT(status == CFG_STATUS_OK);

    status = cfg_route_find(&doc, "Arcade/intro/storyboard", 0, &record_index);
    TEST_ASSERT(status == CFG_STATUS_OK);
    TEST_ASSERT(cfg_copy_value(&doc,
                               &doc.records[record_index],
                               text_out,
                               sizeof(text_out),
                               1) == CFG_STATUS_OK);
    TEST_ASSERT(strcmp(text_out, "intro.def") == 0);

    TEST_ASSERT(mugen_char_load(&doc, &character) == CFG_STATUS_OK);
    TEST_ASSERT(character.info.name.present);
    TEST_ASSERT(character.info.displayname.present);
    TEST_ASSERT(character.info.author.present);
    TEST_ASSERT(character.info.has_versiondate_tuple);
    TEST_ASSERT(character.info.versiondate_tuple[0] == 1L);
    TEST_ASSERT(character.info.versiondate_tuple[1] == 2L);
    TEST_ASSERT(character.info.versiondate_tuple[2] == 2026L);
    TEST_ASSERT(character.info.has_mugenversion);
    TEST_ASSERT(character.info.has_localcoord);
    TEST_ASSERT(character.info.localcoord[0] == 320L);
    TEST_ASSERT(character.info.localcoord[1] == 240L);
    TEST_ASSERT(character.info.pal_default_count == 4);
    TEST_ASSERT(character.files.state_file_count == 3);
    TEST_ASSERT(character.palette_keymap.present[0] == 1U);
    TEST_ASSERT(character.palette_keymap.values[0] == 1L);
    TEST_ASSERT(character.arcade.intro_storyboard.present);

    TEST_ASSERT(mugen_char_copy_view(&doc,
                                     character.files.sprite,
                                     text_out,
                                     sizeof(text_out)) == CFG_STATUS_OK);
    TEST_ASSERT(strcmp(text_out, "unit.sff") == 0);

    TEST_ASSERT(cfg_fix_to_cstr(character.info.mugenversion,
                                text_out,
                                sizeof(text_out),
                                2U));
    TEST_ASSERT(strcmp(text_out, "1.10") == 0 || strcmp(text_out, "1.09") == 0);

    {
        static const char stage_text[] =
            "[BG Floor]\n"
            "delta = .8,.75\n";
        cfg_document stage_doc;

        status = cfg_parse_buffer(&stage_doc,
                                  "stage.def",
                                  stage_text,
                                  sizeof(stage_text) - 1U,
                                  &options);
        TEST_ASSERT(status == CFG_STATUS_OK);
        status = cfg_route_find(&stage_doc, "BG/Floor/delta", 0, &record_index);
        TEST_ASSERT(status == CFG_STATUS_OK);
        status = cfg_parse_list_fix(&stage_doc,
                                    &stage_doc.records[record_index],
                                    delta_values,
                                    2,
                                    &count);
        TEST_ASSERT(status == CFG_STATUS_OK);
        TEST_ASSERT(count == 2);
    }

    return 0;
}

int main(void)
{
    if (test_basic_character_parse() != 0) {
        return 1;
    }

    printf("all tests passed\n");
    return 0;
}
