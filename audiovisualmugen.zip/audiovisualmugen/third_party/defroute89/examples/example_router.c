#include <stdio.h>
#include <string.h>

#include "cfg_router.h"

static int print_route(const cfg_document *doc,
                       const cfg_record *record,
                       const cfg_path *path,
                       void *user_data)
{
    char route[128];
    char value[CFG_MAX_VALUE_COPY];
    int status;

    (void) user_data;

    status = cfg_path_copy(doc, path, route, sizeof(route));
    if (status != CFG_STATUS_OK) {
        return status;
    }

    status = cfg_copy_value(doc, record, value, sizeof(value), 1);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    if (record->kind == CFG_RECORD_BARE) {
        printf("%s -> %s\n", route, value);
    } else {
        printf("%s = %s\n", route, value);
    }

    return 0;
}

int main(void)
{
    static const char sample_text[] =
        "; tiny bridge demo\n"
        "[Info]\n"
        "name = \"Router Demo\"\n"
        "localcoord = 320,240\n"
        "[BG Floor]\n"
        "delta = .8,.75\n"
        "[Characters]\n"
        "kfm, stages/kfm.def\n";

    cfg_document doc;
    cfg_parse_options options;
    int status;

    cfg_parse_options_mugen(&options);
    status = cfg_parse_buffer(&doc,
                              "demo.def",
                              sample_text,
                              sizeof(sample_text) - 1U,
                              &options);
    if (status != CFG_STATUS_OK) {
        fprintf(stderr, "parse error: %s\n", cfg_status_string(status));
        return 1;
    }

    status = cfg_route_walk(&doc, print_route, (void *) 0);
    if (status != CFG_STATUS_OK) {
        fprintf(stderr, "walk error: %s\n", cfg_status_string(status));
        return 1;
    }

    return 0;
}
