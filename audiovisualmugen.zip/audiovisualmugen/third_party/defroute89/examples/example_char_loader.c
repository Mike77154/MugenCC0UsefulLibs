#include <stdio.h>
#include <string.h>

#include "mugen_char_def.h"

static void print_view_line(const char *label,
                            const cfg_document *doc,
                            mugen_value_view view)
{
    char text[CFG_MAX_VALUE_COPY];
    int status;

    status = mugen_char_copy_view(doc, view, text, sizeof(text));
    if (status == CFG_STATUS_OK) {
        printf("%s: %s\n", label, text);
    } else {
        printf("%s: <missing>\n", label);
    }
}

int main(int argc, char **argv)
{
    cfg_document doc;
    mugen_char_def character;
    cfg_parse_options options;
    char version_text[32];
    int status;
    int index;

    if (argc < 2) {
        fprintf(stderr, "usage: %s <character.def>\n", argv[0]);
        return 1;
    }

    cfg_parse_options_mugen(&options);
    status = mugen_char_load_file(argv[1], &doc, &character, &options);
    if (status != CFG_STATUS_OK) {
        fprintf(stderr, "parse error: %s\n", cfg_status_string(status));
        return 1;
    }

    print_view_line("name", &doc, character.info.name);
    print_view_line("displayname", &doc, character.info.displayname);
    print_view_line("author", &doc, character.info.author);

    if (character.info.has_mugenversion &&
        cfg_fix_to_cstr(character.info.mugenversion,
                        version_text,
                        sizeof(version_text),
                        3U)) {
        printf("mugenversion: %s\n", version_text);
    }

    if (character.info.has_localcoord) {
        printf("localcoord: %ld,%ld\n",
               character.info.localcoord[0],
               character.info.localcoord[1]);
    }

    print_view_line("cmd", &doc, character.files.cmd);
    print_view_line("cns", &doc, character.files.cns);
    print_view_line("stcommon", &doc, character.files.stcommon);
    print_view_line("sprite", &doc, character.files.sprite);
    print_view_line("anim", &doc, character.files.anim);
    print_view_line("sound", &doc, character.files.sound);
    print_view_line("intro.storyboard", &doc, character.arcade.intro_storyboard);
    print_view_line("ending.storyboard", &doc, character.arcade.ending_storyboard);

    printf("state files: %d\n", character.files.state_file_count);
    for (index = 0; index < character.files.state_file_count; ++index) {
        print_view_line("  st", &doc, character.files.state_files[index]);
    }

    if (character.info.pal_default_count > 0) {
        printf("pal.defaults:");
        for (index = 0; index < character.info.pal_default_count; ++index) {
            printf(" %ld", character.info.pal_defaults[index]);
        }
        printf("\n");
    }

    if (character.warnings != 0UL) {
        printf("warnings: 0x%08lx\n", character.warnings);
    }

    return 0;
}
