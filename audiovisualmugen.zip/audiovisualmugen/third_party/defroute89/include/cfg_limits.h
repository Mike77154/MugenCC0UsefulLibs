#ifndef CFG_LIMITS_H
#define CFG_LIMITS_H

#ifndef CFG_MAX_SECTIONS
#define CFG_MAX_SECTIONS 128
#endif

#ifndef CFG_MAX_RECORDS
#define CFG_MAX_RECORDS 1024
#endif

#ifndef CFG_TEXT_CAPACITY
#define CFG_TEXT_CAPACITY 32768
#endif

#ifndef CFG_LINE_CAPACITY
#define CFG_LINE_CAPACITY 512
#endif

#ifndef CFG_MAX_PATH_SEGMENTS
#define CFG_MAX_PATH_SEGMENTS 16
#endif

#ifndef CFG_MAX_LIST_ITEMS
#define CFG_MAX_LIST_ITEMS 32
#endif

#ifndef CFG_MAX_ERRORS
#define CFG_MAX_ERRORS 32
#endif

#ifndef CFG_MAX_VALUE_COPY
#define CFG_MAX_VALUE_COPY 256
#endif

#endif
