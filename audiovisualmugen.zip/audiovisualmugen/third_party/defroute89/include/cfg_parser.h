#ifndef CFG_PARSER_H
#define CFG_PARSER_H

#include <stddef.h>
#include "cfg_limits.h"
#include "cfg_fix.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CFG_NO_SECTION 65535U

enum cfg_status_code {
    CFG_STATUS_OK = 0,
    CFG_STATUS_BAD_ARGUMENT = -1,
    CFG_STATUS_OPEN_FAILED = -2,
    CFG_STATUS_LINE_TOO_LONG = -3,
    CFG_STATUS_TOO_MANY_SECTIONS = -4,
    CFG_STATUS_TOO_MANY_RECORDS = -5,
    CFG_STATUS_TEXT_OVERFLOW = -6,
    CFG_STATUS_SYNTAX = -7,
    CFG_STATUS_RANGE = -8,
    CFG_STATUS_NOT_FOUND = -9,
    CFG_STATUS_TRUNCATED = -10
};

enum cfg_record_kind {
    CFG_RECORD_KEY_VALUE = 0,
    CFG_RECORD_BARE = 1
};

typedef struct cfg_span_tag {
    unsigned short offset;
    unsigned short length;
} cfg_span;

typedef struct cfg_section_tag {
    cfg_span full_name;
    cfg_span base_name;
    cfg_span arg_name;
    unsigned long line;
} cfg_section;

typedef struct cfg_record_tag {
    int kind;
    unsigned short section_index;
    cfg_span key;
    cfg_span value;
    unsigned long line;
} cfg_record;

typedef struct cfg_error_tag {
    int code;
    unsigned long line;
    cfg_span message;
} cfg_error;

typedef struct cfg_parse_options_tag {
    int case_insensitive;
    int hash_comments;
    int split_section_arg;
    int strip_quotes_on_copy;
} cfg_parse_options;

typedef struct cfg_document_tag {
    cfg_section sections[CFG_MAX_SECTIONS];
    unsigned short section_count;
    cfg_record records[CFG_MAX_RECORDS];
    unsigned short record_count;
    cfg_error errors[CFG_MAX_ERRORS];
    unsigned short error_count;
    char text[CFG_TEXT_CAPACITY];
    unsigned short text_used;
    unsigned long line_count;
    int case_insensitive;
    int strip_quotes_on_copy;
} cfg_document;

void cfg_document_init(cfg_document *doc);
void cfg_parse_options_default(cfg_parse_options *options);
void cfg_parse_options_mugen(cfg_parse_options *options);

int cfg_parse_file(cfg_document *doc,
                   const char *path,
                   const cfg_parse_options *options);

int cfg_parse_buffer(cfg_document *doc,
                     const char *source_name,
                     const char *buffer,
                     size_t buffer_size,
                     const cfg_parse_options *options);

const char *cfg_status_string(int status);

const cfg_section *cfg_get_section(const cfg_document *doc,
                                   unsigned short section_index);

const cfg_record *cfg_get_record(const cfg_document *doc,
                                 unsigned short record_index);

const char *cfg_span_ptr(const cfg_document *doc, cfg_span span);

int cfg_copy_span(const cfg_document *doc,
                  cfg_span span,
                  char *out_text,
                  size_t out_capacity);

int cfg_copy_value(const cfg_document *doc,
                   const cfg_record *record,
                   char *out_text,
                   size_t out_capacity,
                   int strip_quotes);

int cfg_find_section(const cfg_document *doc,
                     const char *name,
                     int occurrence,
                     unsigned short *out_section_index);

int cfg_find_section_base(const cfg_document *doc,
                          const char *base_name,
                          int occurrence,
                          unsigned short *out_section_index);

int cfg_find_record(const cfg_document *doc,
                    unsigned short section_index,
                    const char *key,
                    int occurrence,
                    unsigned short *out_record_index);

int cfg_find_record_global(const cfg_document *doc,
                           const char *section_name,
                           int section_occurrence,
                           const char *key,
                           int record_occurrence,
                           unsigned short *out_record_index);

int cfg_span_equals(const cfg_document *doc, cfg_span span, const char *text);
int cfg_span_equals_ci(const cfg_document *doc, cfg_span span, const char *text);

int cfg_parse_long_from_text(const char *text, long *out_value);
int cfg_parse_bool_from_text(const char *text, int *out_value);

int cfg_parse_long_record(const cfg_document *doc,
                          const cfg_record *record,
                          long *out_value);

int cfg_parse_fix_record(const cfg_document *doc,
                         const cfg_record *record,
                         cfg_fix_t *out_value);

int cfg_parse_pair_long(const cfg_document *doc,
                        const cfg_record *record,
                        long *out_a,
                        long *out_b);

int cfg_parse_pair_fix(const cfg_document *doc,
                       const cfg_record *record,
                       cfg_fix_t *out_a,
                       cfg_fix_t *out_b);

int cfg_parse_list_long(const cfg_document *doc,
                        const cfg_record *record,
                        long *out_values,
                        int max_values,
                        int *out_count);

int cfg_parse_list_fix(const cfg_document *doc,
                       const cfg_record *record,
                       cfg_fix_t *out_values,
                       int max_values,
                       int *out_count);

#ifdef __cplusplus
}
#endif

#endif
