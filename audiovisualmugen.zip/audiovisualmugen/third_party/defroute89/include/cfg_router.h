#ifndef CFG_ROUTER_H
#define CFG_ROUTER_H

#include <stddef.h>
#include "cfg_parser.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct cfg_path_tag {
    int segment_count;
    int is_bare;
    cfg_span segments[CFG_MAX_PATH_SEGMENTS];
} cfg_path;

typedef int (*cfg_route_callback)(const cfg_document *doc,
                                  const cfg_record *record,
                                  const cfg_path *path,
                                  void *user_data);

int cfg_record_make_path(const cfg_document *doc,
                         const cfg_record *record,
                         cfg_path *out_path);

int cfg_route_walk(const cfg_document *doc,
                   cfg_route_callback callback,
                   void *user_data);

int cfg_route_find(const cfg_document *doc,
                   const char *path,
                   int occurrence,
                   unsigned short *out_record_index);

int cfg_path_copy(const cfg_document *doc,
                  const cfg_path *path,
                  char *out_text,
                  size_t out_capacity);

#ifdef __cplusplus
}
#endif

#endif
