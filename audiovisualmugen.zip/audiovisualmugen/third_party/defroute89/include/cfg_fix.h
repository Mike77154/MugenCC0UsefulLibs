#ifndef CFG_FIX_H
#define CFG_FIX_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef long cfg_fix_t;

#define CFG_FIX_SHIFT 16
#define CFG_FIX_ONE ((cfg_fix_t)65536L)

int cfg_fix_from_cstr(const char *text, cfg_fix_t *out_value);
long cfg_fix_to_int_floor(cfg_fix_t value);
long cfg_fix_to_int_round(cfg_fix_t value);
int cfg_fix_to_cstr(cfg_fix_t value,
                    char *out_text,
                    size_t out_capacity,
                    unsigned int fractional_digits);

#ifdef __cplusplus
}
#endif

#endif
