#ifndef MUGEN_CHAR_DEF_H
#define MUGEN_CHAR_DEF_H

#include <stddef.h>
#include "cfg_router.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MUGEN_CHAR_MAX_ST_FILES
#define MUGEN_CHAR_MAX_ST_FILES 16
#endif

#ifndef MUGEN_CHAR_MAX_PALETTES
#define MUGEN_CHAR_MAX_PALETTES 12
#endif

#define MUGEN_CHAR_WARN_MISSING_INFO      0x0001UL
#define MUGEN_CHAR_WARN_MISSING_FILES     0x0002UL
#define MUGEN_CHAR_WARN_TRUNCATED_ST      0x0004UL
#define MUGEN_CHAR_WARN_TRUNCATED_PALS    0x0008UL
#define MUGEN_CHAR_WARN_UNKNOWN_KEYMAP    0x0010UL

typedef struct mugen_value_view_tag {
    int present;
    cfg_span span;
} mugen_value_view;

typedef struct mugen_char_info_tag {
    mugen_value_view name;
    mugen_value_view displayname;
    mugen_value_view author;
    int has_versiondate_tuple;
    long versiondate_tuple[3];
    int has_version_scalar;
    cfg_fix_t version_scalar;
    int has_mugenversion;
    cfg_fix_t mugenversion;
    int has_localcoord;
    long localcoord[2];
    long pal_defaults[MUGEN_CHAR_MAX_PALETTES];
    int pal_default_count;
} mugen_char_info;

typedef struct mugen_char_files_tag {
    mugen_value_view cmd;
    mugen_value_view cns;
    mugen_value_view st;
    mugen_value_view stcommon;
    mugen_value_view sprite;
    mugen_value_view anim;
    mugen_value_view sound;
    mugen_value_view ai;
    mugen_value_view state_files[MUGEN_CHAR_MAX_ST_FILES];
    int state_file_count;
} mugen_char_files;

typedef struct mugen_palette_keymap_tag {
    long values[12];
    unsigned char present[12];
} mugen_palette_keymap;

typedef struct mugen_char_arcade_tag {
    mugen_value_view intro_storyboard;
    mugen_value_view ending_storyboard;
} mugen_char_arcade;

typedef struct mugen_char_def_tag {
    const cfg_document *document;
    mugen_char_info info;
    mugen_char_files files;
    mugen_palette_keymap palette_keymap;
    mugen_char_arcade arcade;
    unsigned long warnings;
} mugen_char_def;

void mugen_char_def_init(mugen_char_def *out_char_def);

int mugen_char_load(const cfg_document *doc, mugen_char_def *out_char_def);

int mugen_char_load_file(const char *path,
                         cfg_document *doc,
                         mugen_char_def *out_char_def,
                         const cfg_parse_options *options);

int mugen_char_copy_view(const cfg_document *doc,
                         mugen_value_view view,
                         char *out_text,
                         size_t out_capacity);

int mugen_char_resolve_view_path(const char *def_path,
                                 const cfg_document *doc,
                                 mugen_value_view view,
                                 char *out_text,
                                 size_t out_capacity);

#ifdef __cplusplus
}
#endif

#endif
