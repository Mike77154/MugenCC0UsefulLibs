# defroute89

`defroute89` es una librería **C89**, **sin heap**, **sin `malloc`**, **sin `realloc`**, **sin `double`** y **sin `float`**, pensada para parsear archivos tipo `DEF/INI` y rutearlos como si fueran una estructura jerárquica.

La hice para cubrir el caso de **MUGEN character `.def`**, pero el núcleo está separado para que te sirva también como parser genérico de engine:

- secciones `[Info]`
- secciones repetidas `[BG Floor]`
- claves con punto `intro.storyboard`
- listas CSV `1,2,3,4`
- líneas “sueltas” sin `=` como en `select.def`
- parsing numérico entero y **fixed point Q16.16**

---

## Qué trae

### Núcleo genérico
- `cfg_parser.h/.c`
  - parser DEF/INI sin heap
  - secciones, records y spans sobre un pool estático
  - comentarios `;` y opcionalmente `#`
  - records `key=value` y records bare
- `cfg_fix.h/.c`
  - fixed point Q16.16
  - parseo de `1.0`, `.75`, `-.1`, etc.
- `cfg_router.h/.c`
  - puente DEF/INI -> rutas tipo árbol
  - ejemplo:
    - `[Arcade] intro.storyboard = intro.def`
    - ruta resultante: `Arcade/intro/storyboard`
  - ejemplo:
    - `[BG Floor] delta = .8,.75`
    - ruta resultante: `BG/Floor/delta`
  - records sueltos:
    - `[Characters] kfm, stages/kfm.def`
    - ruta resultante: `Characters/@bare`

### Capa MUGEN
- `mugen_char_def.h/.c`
  - loader de personaje `.def`
  - extrae:
    - `[Info]`
    - `[Files]`
    - `[Palette Keymap]`
    - `[Arcade]`
  - soporta:
    - `versiondate` como fecha `MM,DD,YYYY` o escalar
    - `mugenversion` fixed point
    - `localcoord`
    - `pal.defaults`
    - archivos `st`, `st1`, `st2`, etc.
  - conserva compatibilidad con claves desconocidas porque el `cfg_document` original queda accesible

---

## Estructura

```text
include/
  cfg_limits.h
  cfg_fix.h
  cfg_parser.h
  cfg_router.h
  mugen_char_def.h

src/
  cfg_fix.c
  cfg_parser.c
  cfg_router.c
  mugen_char_def.c

examples/
  example_char_loader.c
  example_router.c

samples/
  char_sample.def
  stage_sample.def
  select_sample.def

tests/
  test_main.c
```

---

## Build

```bash
make
make test
```

Eso genera:

```text
build/libdefroute89.a
build/bin/example_char_loader
build/bin/example_router
build/bin/test_main
```

---

## Uso rápido

### 1) Cargar un `.def` de personaje MUGEN

```c
#include "mugen_char_def.h"

cfg_document doc;
mugen_char_def ch;
cfg_parse_options opt;
int status;

cfg_parse_options_mugen(&opt);
status = mugen_char_load_file("chars/kfm/kfm.def", &doc, &ch, &opt);
if (status != CFG_STATUS_OK) {
    /* manejar error */
}
```

### 2) Leer datos ya tipados

```c
if (ch.info.has_localcoord) {
    long w = ch.info.localcoord[0];
    long h = ch.info.localcoord[1];
}
```

### 3) Resolver una ruta como árbol

```c
unsigned short rec;
if (cfg_route_find(&doc, "Arcade/intro/storyboard", 0, &rec) == CFG_STATUS_OK) {
    char value[128];
    cfg_copy_value(&doc, &doc.records[rec], value, sizeof(value), 1);
}
```

### 4) Consumir como parser genérico

```c
cfg_document doc;
cfg_parse_options opt;

cfg_parse_options_default(&opt);
cfg_parse_buffer(&doc, "config.def", text, text_size, &opt);
```

---

## Fixed point

La librería usa **Q16.16**:

- `1.0`  -> `65536`
- `0.5`  -> `32768`
- `-.1`  -> valor fijo negativo
- `.75`  -> `49152`

No hay uso de `float` ni `double` en la implementación.

---

## Capacidades sin heap

Todo usa buffers estáticos configurables en `include/cfg_limits.h`:

```c
#define CFG_MAX_SECTIONS      128
#define CFG_MAX_RECORDS       1024
#define CFG_TEXT_CAPACITY     32768
#define CFG_LINE_CAPACITY     512
#define CFG_MAX_PATH_SEGMENTS 16
```

Si necesitas más capacidad, puedes sobreescribir estas macros en compilación o editar el header.

---

## Diseño

### 1) Parser por spans
El documento no duplica estructuras dinámicas. Guarda texto en un pool fijo y los nodos apuntan a offsets/longitudes.

### 2) Router
Convierte:
- nombre de sección
- argumento de sección
- clave con puntos

a una ruta navegable.

### 3) Loader MUGEN
Encima del parser genérico hay una capa especializada para personaje `.def`, sin romper el acceso al documento crudo.

---

## Limitaciones actuales

- no evalúa expresiones CNS/CMD
- no hace `include`
- no implementa line continuation especial
- no parsea binarios `.sff/.snd/.air`; solo referencias textuales desde `.def`
- el loader especializado está enfocado en **character `.def`**, mientras que stages/storyboards quedan cubiertos por el parser/ruteador genérico

---

## Mini ejemplo de rutas

Archivo:

```ini
[Arcade]
intro.storyboard = intro.def

[BG Floor]
delta = .8,.75

[Characters]
kfm, stages/kfm.def
```

Rutas:

```text
Arcade/intro/storyboard = intro.def
BG/Floor/delta = .8,.75
Characters/@bare -> kfm, stages/kfm.def
```

---

## Validación incluida

`tests/test_main.c` cubre:

- parseo de character DEF
- búsqueda por ruta
- listas CSV
- fixed point
- secciones repetidas estilo stage
- key routing con puntos
