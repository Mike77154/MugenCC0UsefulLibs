#include "cfg_parser.h"

#include <stdio.h>
#include <string.h>
#include <limits.h>

static int cfg_is_space_char(int ch)
{
    return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' ||
           ch == '\f' || ch == '\v';
}

static char cfg_fold_char(char ch)
{
    if (ch >= 'A' && ch <= 'Z') {
        return (char) (ch - 'A' + 'a');
    }
    return ch;
}

static void cfg_trim_bounds(const char *text, size_t *in_out_begin, size_t *in_out_end)
{
    size_t begin;
    size_t end;

    begin = *in_out_begin;
    end = *in_out_end;
    while (begin < end && cfg_is_space_char((unsigned char) text[begin])) {
        ++begin;
    }
    while (end > begin && cfg_is_space_char((unsigned char) text[end - 1U])) {
        --end;
    }
    *in_out_begin = begin;
    *in_out_end = end;
}

static int cfg_text_equals_raw(const char *left,
                               size_t left_length,
                               const char *right,
                               size_t right_length,
                               int case_insensitive)
{
    size_t index;
    char a;
    char b;

    if (left_length != right_length) {
        return 0;
    }

    for (index = 0U; index < left_length; ++index) {
        a = left[index];
        b = right[index];
        if (case_insensitive) {
            a = cfg_fold_char(a);
            b = cfg_fold_char(b);
        }
        if (a != b) {
            return 0;
        }
    }
    return 1;
}

static int cfg_store_text(cfg_document *doc,
                          const char *text,
                          size_t length,
                          cfg_span *out_span)
{
    unsigned short offset;
    size_t required;

    if (doc == (cfg_document *) 0 || out_span == (cfg_span *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (length == 0U) {
        out_span->offset = 0U;
        out_span->length = 0U;
        return CFG_STATUS_OK;
    }

    required = length + 1U;
    if ((size_t) doc->text_used + required > (size_t) CFG_TEXT_CAPACITY) {
        return CFG_STATUS_TEXT_OVERFLOW;
    }

    offset = doc->text_used;
    memcpy(doc->text + offset, text, length);
    doc->text[offset + (unsigned short) length] = '\0';
    doc->text_used = (unsigned short) (doc->text_used + required);

    out_span->offset = offset;
    out_span->length = (unsigned short) length;
    return CFG_STATUS_OK;
}

static int cfg_add_error(cfg_document *doc, int code, unsigned long line, const char *message)
{
    int status;
    size_t length;

    if (doc == (cfg_document *) 0) {
        return code;
    }

    if (doc->error_count >= CFG_MAX_ERRORS) {
        return code;
    }

    length = 0U;
    while (message[length] != '\0') {
        ++length;
    }

    doc->errors[doc->error_count].code = code;
    doc->errors[doc->error_count].line = line;
    status = cfg_store_text(doc,
                            message,
                            length,
                            &doc->errors[doc->error_count].message);
    if (status == CFG_STATUS_OK) {
        ++doc->error_count;
    }
    return code;
}

static size_t cfg_find_comment_cut(const char *text,
                                   size_t length,
                                   const cfg_parse_options *options)
{
    size_t index;
    int in_quotes;
    int escaping;
    char ch;

    in_quotes = 0;
    escaping = 0;
    index = 0U;
    while (index < length) {
        ch = text[index];
        if (escaping) {
            escaping = 0;
        } else if (ch == '\\') {
            escaping = 1;
        } else if (ch == '"') {
            in_quotes = !in_quotes;
        } else if (!in_quotes && ch == ';') {
            return index;
        } else if (!in_quotes && options != (const cfg_parse_options *) 0 &&
                   options->hash_comments && ch == '#') {
            return index;
        }
        ++index;
    }
    return length;
}

static int cfg_find_unquoted_char(const char *text, size_t length, char target)
{
    size_t index;
    int in_quotes;
    int escaping;

    in_quotes = 0;
    escaping = 0;
    for (index = 0U; index < length; ++index) {
        if (escaping) {
            escaping = 0;
            continue;
        }
        if (text[index] == '\\') {
            escaping = 1;
            continue;
        }
        if (text[index] == '"') {
            in_quotes = !in_quotes;
            continue;
        }
        if (!in_quotes && text[index] == target) {
            return (int) index;
        }
    }
    return -1;
}

static int cfg_parse_section_name(cfg_document *doc,
                                  const char *text,
                                  size_t length,
                                  const cfg_parse_options *options,
                                  cfg_section *out_section)
{
    size_t begin;
    size_t end;
    size_t split;
    int status;

    if (out_section == (cfg_section *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    begin = 0U;
    end = length;
    cfg_trim_bounds(text, &begin, &end);

    status = cfg_store_text(doc, text + begin, end - begin, &out_section->full_name);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    if (options != (const cfg_parse_options *) 0 && options->split_section_arg) {
        split = begin;
        while (split < end && !cfg_is_space_char((unsigned char) text[split])) {
            ++split;
        }

        status = cfg_store_text(doc, text + begin, split - begin, &out_section->base_name);
        if (status != CFG_STATUS_OK) {
            return status;
        }

        while (split < end && cfg_is_space_char((unsigned char) text[split])) {
            ++split;
        }

        status = cfg_store_text(doc, text + split, end - split, &out_section->arg_name);
        if (status != CFG_STATUS_OK) {
            return status;
        }
    } else {
        status = cfg_store_text(doc, text + begin, end - begin, &out_section->base_name);
        if (status != CFG_STATUS_OK) {
            return status;
        }
        out_section->arg_name.offset = 0U;
        out_section->arg_name.length = 0U;
    }

    return CFG_STATUS_OK;
}

static int cfg_add_section(cfg_document *doc,
                           const char *text,
                           size_t length,
                           unsigned long line,
                           const cfg_parse_options *options,
                           unsigned short *out_section_index)
{
    cfg_section section;
    int status;

    if (doc->section_count >= CFG_MAX_SECTIONS) {
        return cfg_add_error(doc, CFG_STATUS_TOO_MANY_SECTIONS, line, "too many sections");
    }

    memset(&section, 0, sizeof(section));
    status = cfg_parse_section_name(doc, text, length, options, &section);
    if (status != CFG_STATUS_OK) {
        return status;
    }
    section.line = line;

    doc->sections[doc->section_count] = section;
    if (out_section_index != (unsigned short *) 0) {
        *out_section_index = doc->section_count;
    }
    ++doc->section_count;
    return CFG_STATUS_OK;
}

static int cfg_add_record(cfg_document *doc,
                          int kind,
                          unsigned short section_index,
                          const char *key_text,
                          size_t key_length,
                          const char *value_text,
                          size_t value_length,
                          unsigned long line)
{
    cfg_record record;
    int status;

    if (doc->record_count >= CFG_MAX_RECORDS) {
        return cfg_add_error(doc, CFG_STATUS_TOO_MANY_RECORDS, line, "too many records");
    }

    memset(&record, 0, sizeof(record));
    record.kind = kind;
    record.section_index = section_index;
    record.line = line;

    status = cfg_store_text(doc, key_text, key_length, &record.key);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    status = cfg_store_text(doc, value_text, value_length, &record.value);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    doc->records[doc->record_count] = record;
    ++doc->record_count;
    return CFG_STATUS_OK;
}

static int cfg_parse_one_line(cfg_document *doc,
                              char *line_buffer,
                              unsigned long line_number,
                              const cfg_parse_options *options,
                              unsigned short *in_out_current_section)
{
    size_t length;
    size_t begin;
    size_t end;
    size_t inner_begin;
    size_t inner_end;
    size_t comment_cut;
    int equal_pos;
    size_t key_begin;
    size_t key_end;
    size_t value_begin;
    size_t value_end;
    int status;

    if (doc == (cfg_document *) 0 || line_buffer == (char *) 0 ||
        in_out_current_section == (unsigned short *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (line_number == 1UL &&
        (unsigned char) line_buffer[0] == 0xEFU &&
        (unsigned char) line_buffer[1] == 0xBBU &&
        (unsigned char) line_buffer[2] == 0xBFU) {
        memmove(line_buffer, line_buffer + 3, strlen(line_buffer + 3) + 1U);
    }

    length = strlen(line_buffer);
    while (length > 0U &&
           (line_buffer[length - 1U] == '\n' || line_buffer[length - 1U] == '\r')) {
        line_buffer[--length] = '\0';
    }

    comment_cut = cfg_find_comment_cut(line_buffer, length, options);
    line_buffer[comment_cut] = '\0';
    length = comment_cut;

    begin = 0U;
    end = length;
    cfg_trim_bounds(line_buffer, &begin, &end);
    if (begin == end) {
        return CFG_STATUS_OK;
    }

    if (line_buffer[begin] == '[') {
        if (end <= begin + 1U || line_buffer[end - 1U] != ']') {
            return cfg_add_error(doc, CFG_STATUS_SYNTAX, line_number, "malformed section header");
        }

        inner_begin = begin + 1U;
        inner_end = end - 1U;
        cfg_trim_bounds(line_buffer, &inner_begin, &inner_end);
        status = cfg_add_section(doc,
                                 line_buffer + inner_begin,
                                 inner_end - inner_begin,
                                 line_number,
                                 options,
                                 in_out_current_section);
        return status;
    }

    equal_pos = cfg_find_unquoted_char(line_buffer + begin, end - begin, '=');
    if (equal_pos >= 0) {
        key_begin = begin;
        key_end = begin + (size_t) equal_pos;
        value_begin = begin + (size_t) equal_pos + 1U;
        value_end = end;

        cfg_trim_bounds(line_buffer, &key_begin, &key_end);
        cfg_trim_bounds(line_buffer, &value_begin, &value_end);

        if (key_begin == key_end) {
            return cfg_add_error(doc, CFG_STATUS_SYNTAX, line_number, "empty key");
        }

        return cfg_add_record(doc,
                              CFG_RECORD_KEY_VALUE,
                              *in_out_current_section,
                              line_buffer + key_begin,
                              key_end - key_begin,
                              line_buffer + value_begin,
                              value_end - value_begin,
                              line_number);
    }

    return cfg_add_record(doc,
                          CFG_RECORD_BARE,
                          *in_out_current_section,
                          "",
                          0U,
                          line_buffer + begin,
                          end - begin,
                          line_number);
}

void cfg_document_init(cfg_document *doc)
{
    if (doc == (cfg_document *) 0) {
        return;
    }

    memset(doc, 0, sizeof(*doc));
    doc->text[0] = '\0';
    doc->text_used = 1U;
    doc->case_insensitive = 1;
    doc->strip_quotes_on_copy = 1;
}

void cfg_parse_options_default(cfg_parse_options *options)
{
    if (options == (cfg_parse_options *) 0) {
        return;
    }

    options->case_insensitive = 0;
    options->hash_comments = 1;
    options->split_section_arg = 1;
    options->strip_quotes_on_copy = 1;
}

void cfg_parse_options_mugen(cfg_parse_options *options)
{
    if (options == (cfg_parse_options *) 0) {
        return;
    }

    cfg_parse_options_default(options);
    options->case_insensitive = 1;
    options->hash_comments = 0;
    options->split_section_arg = 1;
    options->strip_quotes_on_copy = 1;
}

static void cfg_apply_options(cfg_document *doc, const cfg_parse_options *options)
{
    if (doc == (cfg_document *) 0) {
        return;
    }

    if (options == (const cfg_parse_options *) 0) {
        doc->case_insensitive = 0;
        doc->strip_quotes_on_copy = 1;
    } else {
        doc->case_insensitive = options->case_insensitive ? 1 : 0;
        doc->strip_quotes_on_copy = options->strip_quotes_on_copy ? 1 : 0;
    }
}

int cfg_parse_file(cfg_document *doc,
                   const char *path,
                   const cfg_parse_options *options)
{
    FILE *file;
    char line_buffer[CFG_LINE_CAPACITY + 2];
    unsigned long line_number;
    unsigned short current_section;
    int status;
    size_t length;

    if (doc == (cfg_document *) 0 || path == (const char *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    cfg_document_init(doc);
    cfg_apply_options(doc, options);

    file = fopen(path, "rb");
    if (file == (FILE *) 0) {
        return cfg_add_error(doc, CFG_STATUS_OPEN_FAILED, 0UL, "could not open file");
    }

    current_section = CFG_NO_SECTION;
    line_number = 0UL;
    while (fgets(line_buffer, sizeof(line_buffer), file) != (char *) 0) {
        ++line_number;
        length = strlen(line_buffer);
        if (length > 0U &&
            line_buffer[length - 1U] != '\n' &&
            !feof(file)) {
            fclose(file);
            return cfg_add_error(doc, CFG_STATUS_LINE_TOO_LONG, line_number, "line too long");
        }

        status = cfg_parse_one_line(doc,
                                    line_buffer,
                                    line_number,
                                    options,
                                    &current_section);
        if (status != CFG_STATUS_OK) {
            fclose(file);
            return status;
        }
    }

    fclose(file);
    doc->line_count = line_number;
    return CFG_STATUS_OK;
}

int cfg_parse_buffer(cfg_document *doc,
                     const char *source_name,
                     const char *buffer,
                     size_t buffer_size,
                     const cfg_parse_options *options)
{
    size_t cursor;
    size_t line_begin;
    size_t line_end;
    size_t line_length;
    unsigned long line_number;
    unsigned short current_section;
    char line_buffer[CFG_LINE_CAPACITY + 1];
    int status;

    (void) source_name;

    if (doc == (cfg_document *) 0 || buffer == (const char *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    cfg_document_init(doc);
    cfg_apply_options(doc, options);

    cursor = 0U;
    line_number = 0UL;
    current_section = CFG_NO_SECTION;

    while (cursor < buffer_size) {
        line_begin = cursor;
        while (cursor < buffer_size && buffer[cursor] != '\n') {
            ++cursor;
        }
        line_end = cursor;
        if (cursor < buffer_size && buffer[cursor] == '\n') {
            ++cursor;
        }

        ++line_number;
        line_length = line_end - line_begin;
        if (line_length >= (size_t) CFG_LINE_CAPACITY) {
            return cfg_add_error(doc, CFG_STATUS_LINE_TOO_LONG, line_number, "line too long");
        }

        memcpy(line_buffer, buffer + line_begin, line_length);
        line_buffer[line_length] = '\0';

        status = cfg_parse_one_line(doc,
                                    line_buffer,
                                    line_number,
                                    options,
                                    &current_section);
        if (status != CFG_STATUS_OK) {
            return status;
        }
    }

    doc->line_count = line_number;
    return CFG_STATUS_OK;
}

const char *cfg_status_string(int status)
{
    switch (status) {
    case CFG_STATUS_OK:
        return "ok";
    case CFG_STATUS_BAD_ARGUMENT:
        return "bad argument";
    case CFG_STATUS_OPEN_FAILED:
        return "open failed";
    case CFG_STATUS_LINE_TOO_LONG:
        return "line too long";
    case CFG_STATUS_TOO_MANY_SECTIONS:
        return "too many sections";
    case CFG_STATUS_TOO_MANY_RECORDS:
        return "too many records";
    case CFG_STATUS_TEXT_OVERFLOW:
        return "text overflow";
    case CFG_STATUS_SYNTAX:
        return "syntax error";
    case CFG_STATUS_RANGE:
        return "out of range";
    case CFG_STATUS_NOT_FOUND:
        return "not found";
    case CFG_STATUS_TRUNCATED:
        return "truncated";
    default:
        return "unknown";
    }
}

const cfg_section *cfg_get_section(const cfg_document *doc,
                                   unsigned short section_index)
{
    if (doc == (const cfg_document *) 0 || section_index >= doc->section_count) {
        return (const cfg_section *) 0;
    }
    return &doc->sections[section_index];
}

const cfg_record *cfg_get_record(const cfg_document *doc,
                                 unsigned short record_index)
{
    if (doc == (const cfg_document *) 0 || record_index >= doc->record_count) {
        return (const cfg_record *) 0;
    }
    return &doc->records[record_index];
}

const char *cfg_span_ptr(const cfg_document *doc, cfg_span span)
{
    if (doc == (const cfg_document *) 0) {
        return (const char *) 0;
    }
    return doc->text + span.offset;
}

int cfg_copy_span(const cfg_document *doc,
                  cfg_span span,
                  char *out_text,
                  size_t out_capacity)
{
    if (doc == (const cfg_document *) 0 || out_text == (char *) 0 || out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if ((size_t) span.length + 1U > out_capacity) {
        return CFG_STATUS_TRUNCATED;
    }

    memcpy(out_text, cfg_span_ptr(doc, span), (size_t) span.length);
    out_text[span.length] = '\0';
    return CFG_STATUS_OK;
}

static int cfg_strip_quoted_copy(const char *text,
                                 size_t length,
                                 char *out_text,
                                 size_t out_capacity)
{
    size_t begin;
    size_t end;
    size_t in_index;
    size_t out_index;
    int in_quotes;

    if (out_text == (char *) 0 || out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    begin = 0U;
    end = length;
    cfg_trim_bounds(text, &begin, &end);

    if (end >= begin + 2U && text[begin] == '"' && text[end - 1U] == '"') {
        ++begin;
        --end;
        in_quotes = 1;
    } else {
        in_quotes = 0;
    }

    out_index = 0U;
    in_index = begin;
    while (in_index < end) {
        if (out_index + 1U >= out_capacity) {
            return CFG_STATUS_TRUNCATED;
        }
        if (in_quotes &&
            text[in_index] == '\\' &&
            in_index + 1U < end &&
            (text[in_index + 1U] == '"' || text[in_index + 1U] == '\\')) {
            ++in_index;
        }
        out_text[out_index++] = text[in_index++];
    }
    out_text[out_index] = '\0';
    return CFG_STATUS_OK;
}

int cfg_copy_value(const cfg_document *doc,
                   const cfg_record *record,
                   char *out_text,
                   size_t out_capacity,
                   int strip_quotes)
{
    const char *text;

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_text == (char *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    text = cfg_span_ptr(doc, record->value);
    if (strip_quotes) {
        return cfg_strip_quoted_copy(text,
                                     (size_t) record->value.length,
                                     out_text,
                                     out_capacity);
    }

    return cfg_copy_span(doc, record->value, out_text, out_capacity);
}

int cfg_span_equals(const cfg_document *doc, cfg_span span, const char *text)
{
    size_t length;

    if (doc == (const cfg_document *) 0 || text == (const char *) 0) {
        return 0;
    }

    length = strlen(text);
    return cfg_text_equals_raw(cfg_span_ptr(doc, span),
                               (size_t) span.length,
                               text,
                               length,
                               0);
}

int cfg_span_equals_ci(const cfg_document *doc, cfg_span span, const char *text)
{
    size_t length;

    if (doc == (const cfg_document *) 0 || text == (const char *) 0) {
        return 0;
    }

    length = strlen(text);
    return cfg_text_equals_raw(cfg_span_ptr(doc, span),
                               (size_t) span.length,
                               text,
                               length,
                               1);
}

int cfg_find_section(const cfg_document *doc,
                     const char *name,
                     int occurrence,
                     unsigned short *out_section_index)
{
    unsigned short index;
    int seen;

    if (doc == (const cfg_document *) 0 || name == (const char *) 0 || occurrence < 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    seen = 0;
    for (index = 0U; index < doc->section_count; ++index) {
        if (cfg_text_equals_raw(cfg_span_ptr(doc, doc->sections[index].full_name),
                                (size_t) doc->sections[index].full_name.length,
                                name,
                                strlen(name),
                                doc->case_insensitive)) {
            if (seen == occurrence) {
                if (out_section_index != (unsigned short *) 0) {
                    *out_section_index = index;
                }
                return CFG_STATUS_OK;
            }
            ++seen;
        }
    }

    return CFG_STATUS_NOT_FOUND;
}

int cfg_find_section_base(const cfg_document *doc,
                          const char *base_name,
                          int occurrence,
                          unsigned short *out_section_index)
{
    unsigned short index;
    int seen;
    size_t length;

    if (doc == (const cfg_document *) 0 || base_name == (const char *) 0 || occurrence < 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    length = strlen(base_name);
    seen = 0;
    for (index = 0U; index < doc->section_count; ++index) {
        if (cfg_text_equals_raw(cfg_span_ptr(doc, doc->sections[index].base_name),
                                (size_t) doc->sections[index].base_name.length,
                                base_name,
                                length,
                                doc->case_insensitive)) {
            if (seen == occurrence) {
                if (out_section_index != (unsigned short *) 0) {
                    *out_section_index = index;
                }
                return CFG_STATUS_OK;
            }
            ++seen;
        }
    }

    return CFG_STATUS_NOT_FOUND;
}

int cfg_find_record(const cfg_document *doc,
                    unsigned short section_index,
                    const char *key,
                    int occurrence,
                    unsigned short *out_record_index)
{
    unsigned short index;
    int seen;
    size_t key_length;

    if (doc == (const cfg_document *) 0 || key == (const char *) 0 || occurrence < 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    key_length = strlen(key);
    seen = 0;
    for (index = 0U; index < doc->record_count; ++index) {
        if (doc->records[index].section_index != section_index) {
            continue;
        }
        if (doc->records[index].kind != CFG_RECORD_KEY_VALUE) {
            continue;
        }
        if (cfg_text_equals_raw(cfg_span_ptr(doc, doc->records[index].key),
                                (size_t) doc->records[index].key.length,
                                key,
                                key_length,
                                doc->case_insensitive)) {
            if (seen == occurrence) {
                if (out_record_index != (unsigned short *) 0) {
                    *out_record_index = index;
                }
                return CFG_STATUS_OK;
            }
            ++seen;
        }
    }

    return CFG_STATUS_NOT_FOUND;
}

int cfg_find_record_global(const cfg_document *doc,
                           const char *section_name,
                           int section_occurrence,
                           const char *key,
                           int record_occurrence,
                           unsigned short *out_record_index)
{
    unsigned short section_index;
    int status;

    if (doc == (const cfg_document *) 0 ||
        section_name == (const char *) 0 ||
        key == (const char *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    status = cfg_find_section(doc, section_name, section_occurrence, &section_index);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    return cfg_find_record(doc, section_index, key, record_occurrence, out_record_index);
}

int cfg_parse_long_from_text(const char *text, long *out_value)
{
    size_t begin;
    size_t end;
    size_t length;
    size_t index;
    int negative;
    unsigned long value;

    if (text == (const char *) 0 || out_value == (long *) 0) {
        return 0;
    }

    length = strlen(text);
    begin = 0U;
    end = length;
    cfg_trim_bounds(text, &begin, &end);
    if (begin == end) {
        return 0;
    }

    index = begin;
    negative = 0;
    if (text[index] == '+' || text[index] == '-') {
        negative = (text[index] == '-');
        ++index;
    }

    if (index >= end) {
        return 0;
    }

    value = 0UL;
    while (index < end && text[index] >= '0' && text[index] <= '9') {
        if (value > (unsigned long) LONG_MAX / 10UL) {
            return 0;
        }
        value = value * 10UL + (unsigned long) (text[index] - '0');
        ++index;
    }

    while (index < end && cfg_is_space_char((unsigned char) text[index])) {
        ++index;
    }
    if (index != end) {
        return 0;
    }

    if (negative) {
        if (value > (unsigned long) LONG_MAX + 1UL) {
            return 0;
        }
        if (value == (unsigned long) LONG_MAX + 1UL) {
            *out_value = LONG_MIN;
        } else {
            *out_value = -(long) value;
        }
    } else {
        if (value > (unsigned long) LONG_MAX) {
            return 0;
        }
        *out_value = (long) value;
    }

    return 1;
}

int cfg_parse_bool_from_text(const char *text, int *out_value)
{
    long value;
    size_t length;
    char lowered[16];
    size_t index;

    if (text == (const char *) 0 || out_value == (int *) 0) {
        return 0;
    }

    if (cfg_parse_long_from_text(text, &value)) {
        *out_value = value != 0L;
        return 1;
    }

    length = strlen(text);
    if (length >= sizeof(lowered)) {
        return 0;
    }

    for (index = 0U; index < length; ++index) {
        lowered[index] = cfg_fold_char(text[index]);
    }
    lowered[length] = '\0';

    if (strcmp(lowered, "true") == 0 || strcmp(lowered, "yes") == 0 ||
        strcmp(lowered, "on") == 0) {
        *out_value = 1;
        return 1;
    }
    if (strcmp(lowered, "false") == 0 || strcmp(lowered, "no") == 0 ||
        strcmp(lowered, "off") == 0) {
        *out_value = 0;
        return 1;
    }
    return 0;
}

int cfg_parse_long_record(const cfg_document *doc,
                          const cfg_record *record,
                          long *out_value)
{
    char temp[CFG_MAX_VALUE_COPY];

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_value == (long *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (cfg_copy_value(doc, record, temp, sizeof(temp), 0) != CFG_STATUS_OK) {
        return CFG_STATUS_TRUNCATED;
    }
    if (!cfg_parse_long_from_text(temp, out_value)) {
        return CFG_STATUS_SYNTAX;
    }
    return CFG_STATUS_OK;
}

int cfg_parse_fix_record(const cfg_document *doc,
                         const cfg_record *record,
                         cfg_fix_t *out_value)
{
    char temp[CFG_MAX_VALUE_COPY];

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_value == (cfg_fix_t *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (cfg_copy_value(doc, record, temp, sizeof(temp), 0) != CFG_STATUS_OK) {
        return CFG_STATUS_TRUNCATED;
    }
    if (!cfg_fix_from_cstr(temp, out_value)) {
        return CFG_STATUS_SYNTAX;
    }
    return CFG_STATUS_OK;
}

static int cfg_next_csv_item(const char *text,
                             size_t length,
                             size_t *in_out_cursor,
                             size_t *out_begin,
                             size_t *out_end)
{
    size_t begin;
    size_t end;
    size_t index;
    int in_quotes;
    int escaping;

    if (text == (const char *) 0 ||
        in_out_cursor == (size_t *) 0 ||
        out_begin == (size_t *) 0 ||
        out_end == (size_t *) 0) {
        return 0;
    }

    if (*in_out_cursor >= length) {
        return 0;
    }

    begin = *in_out_cursor;
    end = length;
    index = begin;
    in_quotes = 0;
    escaping = 0;

    while (index < length) {
        if (escaping) {
            escaping = 0;
        } else if (text[index] == '\\') {
            escaping = 1;
        } else if (text[index] == '"') {
            in_quotes = !in_quotes;
        } else if (!in_quotes && text[index] == ',') {
            end = index;
            *in_out_cursor = index + 1U;
            cfg_trim_bounds(text, &begin, &end);
            *out_begin = begin;
            *out_end = end;
            return 1;
        }
        ++index;
    }

    *in_out_cursor = length;
    cfg_trim_bounds(text, &begin, &end);
    *out_begin = begin;
    *out_end = end;
    return 1;
}

static int cfg_copy_range(const char *text,
                          size_t begin,
                          size_t end,
                          char *out_text,
                          size_t out_capacity)
{
    size_t length;

    if (out_text == (char *) 0 || out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    length = end - begin;
    if (length + 1U > out_capacity) {
        return CFG_STATUS_TRUNCATED;
    }

    memcpy(out_text, text + begin, length);
    out_text[length] = '\0';
    return CFG_STATUS_OK;
}

int cfg_parse_list_long(const cfg_document *doc,
                        const cfg_record *record,
                        long *out_values,
                        int max_values,
                        int *out_count)
{
    const char *text;
    size_t cursor;
    size_t begin;
    size_t end;
    int count;
    char temp[64];

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_values == (long *) 0 ||
        out_count == (int *) 0 ||
        max_values <= 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    text = cfg_span_ptr(doc, record->value);
    cursor = 0U;
    count = 0;
    while (cfg_next_csv_item(text, (size_t) record->value.length, &cursor, &begin, &end)) {
        if (count >= max_values) {
            return CFG_STATUS_RANGE;
        }
        if (cfg_copy_range(text, begin, end, temp, sizeof(temp)) != CFG_STATUS_OK) {
            return CFG_STATUS_TRUNCATED;
        }
        if (!cfg_parse_long_from_text(temp, &out_values[count])) {
            return CFG_STATUS_SYNTAX;
        }
        ++count;
    }

    *out_count = count;
    return CFG_STATUS_OK;
}

int cfg_parse_list_fix(const cfg_document *doc,
                       const cfg_record *record,
                       cfg_fix_t *out_values,
                       int max_values,
                       int *out_count)
{
    const char *text;
    size_t cursor;
    size_t begin;
    size_t end;
    int count;
    char temp[64];

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_values == (cfg_fix_t *) 0 ||
        out_count == (int *) 0 ||
        max_values <= 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    text = cfg_span_ptr(doc, record->value);
    cursor = 0U;
    count = 0;
    while (cfg_next_csv_item(text, (size_t) record->value.length, &cursor, &begin, &end)) {
        if (count >= max_values) {
            return CFG_STATUS_RANGE;
        }
        if (cfg_copy_range(text, begin, end, temp, sizeof(temp)) != CFG_STATUS_OK) {
            return CFG_STATUS_TRUNCATED;
        }
        if (!cfg_fix_from_cstr(temp, &out_values[count])) {
            return CFG_STATUS_SYNTAX;
        }
        ++count;
    }

    *out_count = count;
    return CFG_STATUS_OK;
}

int cfg_parse_pair_long(const cfg_document *doc,
                        const cfg_record *record,
                        long *out_a,
                        long *out_b)
{
    long values[2];
    int count;
    int status;

    if (out_a == (long *) 0 || out_b == (long *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    status = cfg_parse_list_long(doc, record, values, 2, &count);
    if (status != CFG_STATUS_OK) {
        return status;
    }
    if (count < 2) {
        return CFG_STATUS_SYNTAX;
    }

    *out_a = values[0];
    *out_b = values[1];
    return CFG_STATUS_OK;
}

int cfg_parse_pair_fix(const cfg_document *doc,
                       const cfg_record *record,
                       cfg_fix_t *out_a,
                       cfg_fix_t *out_b)
{
    cfg_fix_t values[2];
    int count;
    int status;

    if (out_a == (cfg_fix_t *) 0 || out_b == (cfg_fix_t *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    status = cfg_parse_list_fix(doc, record, values, 2, &count);
    if (status != CFG_STATUS_OK) {
        return status;
    }
    if (count < 2) {
        return CFG_STATUS_SYNTAX;
    }

    *out_a = values[0];
    *out_b = values[1];
    return CFG_STATUS_OK;
}
