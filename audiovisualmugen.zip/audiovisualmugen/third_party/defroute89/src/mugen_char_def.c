#include "mugen_char_def.h"

#include <string.h>

static char mugen_fold_char(char ch)
{
    if (ch >= 'A' && ch <= 'Z') {
        return (char) (ch - 'A' + 'a');
    }
    return ch;
}

static int mugen_span_equals_literal(const cfg_document *doc,
                                     cfg_span span,
                                     const char *text)
{
    const char *left;
    size_t left_length;
    size_t right_length;
    size_t index;
    char a;
    char b;
    int fold_case;

    if (doc == (const cfg_document *) 0 || text == (const char *) 0) {
        return 0;
    }

    left = cfg_span_ptr(doc, span);
    left_length = (size_t) span.length;
    right_length = strlen(text);
    if (left_length != right_length) {
        return 0;
    }

    fold_case = doc->case_insensitive ? 1 : 0;
    for (index = 0U; index < left_length; ++index) {
        a = left[index];
        b = text[index];
        if (fold_case) {
            a = mugen_fold_char(a);
            b = mugen_fold_char(b);
        }
        if (a != b) {
            return 0;
        }
    }
    return 1;
}

static int mugen_record_key_is_st_like(const cfg_document *doc, const cfg_record *record)
{
    const char *text;
    unsigned short index;
    char ch;

    if (doc == (const cfg_document *) 0 || record == (const cfg_record *) 0) {
        return 0;
    }
    if (record->kind != CFG_RECORD_KEY_VALUE) {
        return 0;
    }
    if (record->key.length < 2U) {
        return 0;
    }

    text = cfg_span_ptr(doc, record->key);
    if (mugen_fold_char(text[0]) != 's' || mugen_fold_char(text[1]) != 't') {
        return 0;
    }
    if (record->key.length == 2U) {
        return 1;
    }

    for (index = 2U; index < record->key.length; ++index) {
        ch = text[index];
        if (ch < '0' || ch > '9') {
            return 0;
        }
    }
    return 1;
}

static mugen_value_view mugen_find_view(const cfg_document *doc,
                                        const char *section_name,
                                        const char *key)
{
    mugen_value_view result;
    unsigned short record_index;
    int status;

    result.present = 0;
    result.span.offset = 0U;
    result.span.length = 0U;

    status = cfg_find_record_global(doc,
                                    section_name,
                                    0,
                                    key,
                                    0,
                                    &record_index);
    if (status == CFG_STATUS_OK) {
        result.present = 1;
        result.span = doc->records[record_index].value;
    }

    return result;
}

static int mugen_copy_span_value(const cfg_document *doc,
                                 cfg_span span,
                                 char *out_text,
                                 size_t out_capacity)
{
    const char *text;
    size_t begin;
    size_t end;
    size_t in_index;
    size_t out_index;
    int quoted;

    if (doc == (const cfg_document *) 0 ||
        out_text == (char *) 0 ||
        out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    text = cfg_span_ptr(doc, span);
    begin = 0U;
    end = (size_t) span.length;

    while (begin < end &&
           (text[begin] == ' ' || text[begin] == '\t' || text[begin] == '\r' ||
            text[begin] == '\n' || text[begin] == '\f' || text[begin] == '\v')) {
        ++begin;
    }
    while (end > begin &&
           (text[end - 1U] == ' ' || text[end - 1U] == '\t' || text[end - 1U] == '\r' ||
            text[end - 1U] == '\n' || text[end - 1U] == '\f' || text[end - 1U] == '\v')) {
        --end;
    }

    quoted = 0;
    if (end >= begin + 2U && text[begin] == '"' && text[end - 1U] == '"') {
        quoted = 1;
        ++begin;
        --end;
    }

    out_index = 0U;
    in_index = begin;
    while (in_index < end) {
        if (out_index + 1U >= out_capacity) {
            return CFG_STATUS_TRUNCATED;
        }
        if (quoted &&
            text[in_index] == '\\' &&
            in_index + 1U < end &&
            (text[in_index + 1U] == '"' || text[in_index + 1U] == '\\')) {
            ++in_index;
        }
        out_text[out_index++] = text[in_index++];
    }
    out_text[out_index] = '\0';
    return CFG_STATUS_OK;
}

static int mugen_is_absolute_path(const char *text)
{
    if (text == (const char *) 0 || text[0] == '\0') {
        return 0;
    }
    if (text[0] == '/' || text[0] == '\\') {
        return 1;
    }
    if (((text[0] >= 'A' && text[0] <= 'Z') || (text[0] >= 'a' && text[0] <= 'z')) &&
        text[1] == ':') {
        return 1;
    }
    return 0;
}

static void mugen_dirname(const char *path, char *out_text, size_t out_capacity)
{
    size_t length;
    size_t index;
    size_t cut;

    if (out_text == (char *) 0 || out_capacity == 0U) {
        return;
    }

    out_text[0] = '\0';
    if (path == (const char *) 0) {
        return;
    }

    length = strlen(path);
    cut = length;
    while (cut > 0U) {
        index = cut - 1U;
        if (path[index] == '/' || path[index] == '\\') {
            break;
        }
        --cut;
    }

    if (cut == 0U) {
        return;
    }

    if (cut >= out_capacity) {
        cut = out_capacity - 1U;
    }

    memcpy(out_text, path, cut);
    out_text[cut] = '\0';
}

void mugen_char_def_init(mugen_char_def *out_char_def)
{
    if (out_char_def == (mugen_char_def *) 0) {
        return;
    }

    memset(out_char_def, 0, sizeof(*out_char_def));
}

int mugen_char_load(const cfg_document *doc, mugen_char_def *out_char_def)
{
    unsigned short info_section;
    unsigned short files_section;
    unsigned short keymap_section;
    unsigned short index;
    long values[MUGEN_CHAR_MAX_PALETTES];
    int count;
    int status;
    long key_value;
    static const char *keymap_names[12] = {
        "x", "y", "z", "a", "b", "c",
        "x2", "y2", "z2", "a2", "b2", "c2"
    };

    if (doc == (const cfg_document *) 0 || out_char_def == (mugen_char_def *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    mugen_char_def_init(out_char_def);
    out_char_def->document = doc;

    if (cfg_find_section(doc, "Info", 0, &info_section) != CFG_STATUS_OK) {
        out_char_def->warnings |= MUGEN_CHAR_WARN_MISSING_INFO;
    } else {
        out_char_def->info.name = mugen_find_view(doc, "Info", "name");
        out_char_def->info.displayname = mugen_find_view(doc, "Info", "displayname");
        out_char_def->info.author = mugen_find_view(doc, "Info", "author");

        status = cfg_find_record_global(doc, "Info", 0, "versiondate", 0, &index);
        if (status == CFG_STATUS_OK) {
            count = 0;
            status = cfg_parse_list_long(doc, &doc->records[index],
                                         out_char_def->info.versiondate_tuple,
                                         3,
                                         &count);
            if (status == CFG_STATUS_OK && count == 3) {
                out_char_def->info.has_versiondate_tuple = 1;
            } else if (cfg_parse_fix_record(doc,
                                            &doc->records[index],
                                            &out_char_def->info.version_scalar) == CFG_STATUS_OK) {
                out_char_def->info.has_version_scalar = 1;
            }
        }

        status = cfg_find_record_global(doc, "Info", 0, "mugenversion", 0, &index);
        if (status == CFG_STATUS_OK &&
            cfg_parse_fix_record(doc, &doc->records[index], &out_char_def->info.mugenversion) == CFG_STATUS_OK) {
            out_char_def->info.has_mugenversion = 1;
        }

        status = cfg_find_record_global(doc, "Info", 0, "localcoord", 0, &index);
        if (status == CFG_STATUS_OK &&
            cfg_parse_pair_long(doc,
                                &doc->records[index],
                                &out_char_def->info.localcoord[0],
                                &out_char_def->info.localcoord[1]) == CFG_STATUS_OK) {
            out_char_def->info.has_localcoord = 1;
        }

        status = cfg_find_record_global(doc, "Info", 0, "pal.defaults", 0, &index);
        if (status == CFG_STATUS_OK) {
            count = 0;
            status = cfg_parse_list_long(doc,
                                         &doc->records[index],
                                         values,
                                         MUGEN_CHAR_MAX_PALETTES,
                                         &count);
            if (status == CFG_STATUS_OK) {
                memcpy(out_char_def->info.pal_defaults, values, (size_t) count * sizeof(long));
                out_char_def->info.pal_default_count = count;
            } else {
                out_char_def->warnings |= MUGEN_CHAR_WARN_TRUNCATED_PALS;
            }
        }

        (void) info_section;
    }

    if (cfg_find_section(doc, "Files", 0, &files_section) != CFG_STATUS_OK) {
        out_char_def->warnings |= MUGEN_CHAR_WARN_MISSING_FILES;
    } else {
        out_char_def->files.cmd = mugen_find_view(doc, "Files", "cmd");
        out_char_def->files.cns = mugen_find_view(doc, "Files", "cns");
        out_char_def->files.st = mugen_find_view(doc, "Files", "st");
        out_char_def->files.stcommon = mugen_find_view(doc, "Files", "stcommon");
        out_char_def->files.sprite = mugen_find_view(doc, "Files", "sprite");
        out_char_def->files.anim = mugen_find_view(doc, "Files", "anim");
        out_char_def->files.sound = mugen_find_view(doc, "Files", "sound");
        out_char_def->files.ai = mugen_find_view(doc, "Files", "ai");

        for (index = 0U; index < doc->record_count; ++index) {
            if (doc->records[index].section_index != files_section) {
                continue;
            }
            if (!mugen_record_key_is_st_like(doc, &doc->records[index])) {
                continue;
            }
            if (out_char_def->files.state_file_count >= MUGEN_CHAR_MAX_ST_FILES) {
                out_char_def->warnings |= MUGEN_CHAR_WARN_TRUNCATED_ST;
                continue;
            }
            out_char_def->files.state_files[out_char_def->files.state_file_count].present = 1;
            out_char_def->files.state_files[out_char_def->files.state_file_count].span =
                doc->records[index].value;
            ++out_char_def->files.state_file_count;
        }
    }

    if (cfg_find_section(doc, "Palette Keymap", 0, &keymap_section) == CFG_STATUS_OK) {
        for (index = 0U; index < 12U; ++index) {
            status = cfg_find_record(doc,
                                     keymap_section,
                                     keymap_names[index],
                                     0,
                                     &files_section);
            if (status == CFG_STATUS_OK &&
                cfg_parse_long_record(doc, &doc->records[files_section], &key_value) == CFG_STATUS_OK) {
                out_char_def->palette_keymap.present[index] = 1U;
                out_char_def->palette_keymap.values[index] = key_value;
            }
        }

        for (index = 0U; index < doc->record_count; ++index) {
            int known;
            int key_index;

            if (doc->records[index].section_index != keymap_section ||
                doc->records[index].kind != CFG_RECORD_KEY_VALUE) {
                continue;
            }

            known = 0;
            for (key_index = 0; key_index < 12; ++key_index) {
                if (mugen_span_equals_literal(doc,
                                              doc->records[index].key,
                                              keymap_names[key_index])) {
                    known = 1;
                    break;
                }
            }
            if (!known) {
                out_char_def->warnings |= MUGEN_CHAR_WARN_UNKNOWN_KEYMAP;
            }
        }
    }

    out_char_def->arcade.intro_storyboard = mugen_find_view(doc, "Arcade", "intro.storyboard");
    out_char_def->arcade.ending_storyboard = mugen_find_view(doc, "Arcade", "ending.storyboard");

    return CFG_STATUS_OK;
}

int mugen_char_load_file(const char *path,
                         cfg_document *doc,
                         mugen_char_def *out_char_def,
                         const cfg_parse_options *options)
{
    cfg_parse_options local_options;
    int status;

    if (doc == (cfg_document *) 0 ||
        out_char_def == (mugen_char_def *) 0 ||
        path == (const char *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (options == (const cfg_parse_options *) 0) {
        cfg_parse_options_mugen(&local_options);
        options = &local_options;
    }

    status = cfg_parse_file(doc, path, options);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    return mugen_char_load(doc, out_char_def);
}

int mugen_char_copy_view(const cfg_document *doc,
                         mugen_value_view view,
                         char *out_text,
                         size_t out_capacity)
{
    if (!view.present) {
        return CFG_STATUS_NOT_FOUND;
    }

    return mugen_copy_span_value(doc, view.span, out_text, out_capacity);
}

int mugen_char_resolve_view_path(const char *def_path,
                                 const cfg_document *doc,
                                 mugen_value_view view,
                                 char *out_text,
                                 size_t out_capacity)
{
    char relative[CFG_MAX_VALUE_COPY];
    char base_dir[CFG_MAX_VALUE_COPY];
    size_t base_length;
    size_t relative_length;
    size_t total_length;

    if (doc == (const cfg_document *) 0 ||
        out_text == (char *) 0 ||
        out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    if (!view.present) {
        return CFG_STATUS_NOT_FOUND;
    }

    if (mugen_char_copy_view(doc, view, relative, sizeof(relative)) != CFG_STATUS_OK) {
        return CFG_STATUS_TRUNCATED;
    }

    if (relative[0] == '\0' || mugen_is_absolute_path(relative) || def_path == (const char *) 0) {
        if (strlen(relative) + 1U > out_capacity) {
            return CFG_STATUS_TRUNCATED;
        }
        strcpy(out_text, relative);
        return CFG_STATUS_OK;
    }

    mugen_dirname(def_path, base_dir, sizeof(base_dir));
    base_length = strlen(base_dir);
    relative_length = strlen(relative);
    total_length = base_length + (base_length > 0U ? 1U : 0U) + relative_length;
    if (total_length + 1U > out_capacity) {
        return CFG_STATUS_TRUNCATED;
    }

    out_text[0] = '\0';
    if (base_length > 0U) {
        strcpy(out_text, base_dir);
        if (out_text[base_length - 1U] != '/' && out_text[base_length - 1U] != '\\') {
            out_text[base_length] = '/';
            out_text[base_length + 1U] = '\0';
        }
    }
    strcat(out_text, relative);
    return CFG_STATUS_OK;
}
