#include "cfg_fix.h"

#include <limits.h>

static int cfg_is_space_char(int ch)
{
    return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' ||
           ch == '\f' || ch == '\v';
}

static size_t cfg_trim_indices(const char *text, size_t length, size_t *out_begin, size_t *out_end)
{
    size_t begin;
    size_t end;

    begin = 0U;
    end = length;
    while (begin < length && cfg_is_space_char((unsigned char) text[begin])) {
        ++begin;
    }
    while (end > begin && cfg_is_space_char((unsigned char) text[end - 1U])) {
        --end;
    }
    *out_begin = begin;
    *out_end = end;
    return end - begin;
}

int cfg_fix_from_cstr(const char *text, cfg_fix_t *out_value)
{
    size_t length;
    size_t begin;
    size_t end;
    size_t index;
    int negative;
    unsigned long integer_part;
    unsigned long fraction_part;
    unsigned long fraction_scale;
    unsigned long whole_scaled;
    unsigned long fraction_scaled;
    cfg_fix_t result;

    if (text == (const char *) 0 || out_value == (cfg_fix_t *) 0) {
        return 0;
    }

    length = 0U;
    while (text[length] != '\0') {
        ++length;
    }

    cfg_trim_indices(text, length, &begin, &end);
    if (begin == end) {
        return 0;
    }

    index = begin;
    negative = 0;
    if (text[index] == '+' || text[index] == '-') {
        negative = (text[index] == '-');
        ++index;
    }
    if (index >= end) {
        return 0;
    }

    integer_part = 0UL;
    while (index < end && text[index] >= '0' && text[index] <= '9') {
        if (integer_part > (unsigned long) LONG_MAX / 10UL) {
            return 0;
        }
        integer_part = integer_part * 10UL + (unsigned long) (text[index] - '0');
        ++index;
    }

    fraction_part = 0UL;
    fraction_scale = 1UL;
    if (index < end && text[index] == '.') {
        ++index;
        while (index < end && text[index] >= '0' && text[index] <= '9') {
            if (fraction_scale < 100000000UL) {
                fraction_part = fraction_part * 10UL + (unsigned long) (text[index] - '0');
                fraction_scale *= 10UL;
            }
            ++index;
        }
    }

    while (index < end && cfg_is_space_char((unsigned char) text[index])) {
        ++index;
    }
    if (index != end) {
        return 0;
    }

    if (integer_part > (unsigned long) LONG_MAX / (unsigned long) CFG_FIX_ONE) {
        return 0;
    }
    whole_scaled = integer_part * (unsigned long) CFG_FIX_ONE;

    fraction_scaled = 0UL;
    if (fraction_scale > 1UL) {
        fraction_scaled = (fraction_part * (unsigned long) CFG_FIX_ONE + (fraction_scale / 2UL)) / fraction_scale;
    }

    if (whole_scaled > (unsigned long) LONG_MAX - fraction_scaled) {
        return 0;
    }

    result = (cfg_fix_t) (whole_scaled + fraction_scaled);
    if (negative) {
        if (result > (cfg_fix_t) LONG_MAX) {
            return 0;
        }
        result = -result;
    }

    *out_value = result;
    return 1;
}

long cfg_fix_to_int_floor(cfg_fix_t value)
{
    if (value >= 0) {
        return (long) (value >> CFG_FIX_SHIFT);
    }
    return -((long) (((-value) + (cfg_fix_t) CFG_FIX_ONE - 1) >> CFG_FIX_SHIFT));
}

long cfg_fix_to_int_round(cfg_fix_t value)
{
    if (value >= 0) {
        return (long) ((value + ((cfg_fix_t) CFG_FIX_ONE / 2)) >> CFG_FIX_SHIFT);
    }
    return -((long) (((-value) + ((cfg_fix_t) CFG_FIX_ONE / 2)) >> CFG_FIX_SHIFT));
}

int cfg_fix_to_cstr(cfg_fix_t value,
                    char *out_text,
                    size_t out_capacity,
                    unsigned int fractional_digits)
{
    char reverse_integer[32];
    char reverse_fraction[32];
    unsigned long integer_part;
    unsigned long fraction_part;
    unsigned long fraction_scale;
    unsigned long magnitude;
    unsigned int fraction_index;
    size_t out_index;
    size_t i;

    if (out_text == (char *) 0 || out_capacity == 0U) {
        return 0;
    }

    if (fractional_digits > 9U) {
        fractional_digits = 9U;
    }

    out_index = 0U;
    if (value < 0) {
        if (out_index + 1U >= out_capacity) {
            return 0;
        }
        out_text[out_index++] = '-';
        magnitude = (unsigned long) (-value);
    } else {
        magnitude = (unsigned long) value;
    }

    integer_part = magnitude >> CFG_FIX_SHIFT;
    fraction_part = magnitude & ((unsigned long) CFG_FIX_ONE - 1UL);

    i = 0U;
    do {
        reverse_integer[i++] = (char) ('0' + (integer_part % 10UL));
        integer_part /= 10UL;
    } while (integer_part > 0UL && i < sizeof(reverse_integer));

    while (i > 0U) {
        if (out_index + 1U >= out_capacity) {
            return 0;
        }
        out_text[out_index++] = reverse_integer[--i];
    }

    if (fractional_digits == 0U) {
        out_text[out_index] = '\0';
        return 1;
    }

    if (out_index + 1U >= out_capacity) {
        return 0;
    }
    out_text[out_index++] = '.';

    fraction_scale = 1UL;
    for (fraction_index = 0U; fraction_index < fractional_digits; ++fraction_index) {
        fraction_scale *= 10UL;
    }

    fraction_part = (fraction_part * fraction_scale + ((unsigned long) CFG_FIX_ONE / 2UL)) /
                    (unsigned long) CFG_FIX_ONE;

    if (fraction_part >= fraction_scale) {
        fraction_part = fraction_scale - 1UL;
    }

    fraction_index = 0U;
    while (fraction_index < fractional_digits) {
        reverse_fraction[fraction_index++] = (char) ('0' + (fraction_part % 10UL));
        fraction_part /= 10UL;
    }

    while (fraction_index > 0U) {
        if (out_index + 1U >= out_capacity) {
            return 0;
        }
        out_text[out_index++] = reverse_fraction[--fraction_index];
    }

    out_text[out_index] = '\0';
    return 1;
}
