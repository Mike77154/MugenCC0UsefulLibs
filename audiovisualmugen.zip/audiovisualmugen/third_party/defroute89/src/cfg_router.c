#include "cfg_router.h"

#include <string.h>

static char cfg_router_fold_char(char ch)
{
    if (ch >= 'A' && ch <= 'Z') {
        return (char) (ch - 'A' + 'a');
    }
    return ch;
}

static int cfg_router_text_equals_raw(const char *left,
                                      size_t left_length,
                                      const char *right,
                                      size_t right_length,
                                      int case_insensitive)
{
    size_t index;
    char a;
    char b;

    if (left_length != right_length) {
        return 0;
    }

    for (index = 0U; index < left_length; ++index) {
        a = left[index];
        b = right[index];
        if (case_insensitive) {
            a = cfg_router_fold_char(a);
            b = cfg_router_fold_char(b);
        }
        if (a != b) {
            return 0;
        }
    }
    return 1;
}

static int cfg_path_append(cfg_path *path, cfg_span span)
{
    if (path->segment_count >= CFG_MAX_PATH_SEGMENTS) {
        return CFG_STATUS_RANGE;
    }
    path->segments[path->segment_count++] = span;
    return CFG_STATUS_OK;
}

static int cfg_append_key_segments(const cfg_document *doc,
                                   const cfg_record *record,
                                   cfg_path *path)
{
    const char *text;
    unsigned short index;
    unsigned short local_begin;
    cfg_span span;
    int status;

    text = cfg_span_ptr(doc, record->key);
    local_begin = 0U;
    for (index = 0U; index <= record->key.length; ++index) {
        if (index == record->key.length || text[index] == '.') {
            span.offset = (unsigned short) (record->key.offset + local_begin);
            span.length = (unsigned short) (index - local_begin);
            status = cfg_path_append(path, span);
            if (status != CFG_STATUS_OK) {
                return status;
            }
            local_begin = (unsigned short) (index + 1U);
        }
    }
    return CFG_STATUS_OK;
}

int cfg_record_make_path(const cfg_document *doc,
                         const cfg_record *record,
                         cfg_path *out_path)
{
    const cfg_section *section;
    int status;

    if (doc == (const cfg_document *) 0 ||
        record == (const cfg_record *) 0 ||
        out_path == (cfg_path *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    memset(out_path, 0, sizeof(*out_path));

    if (record->section_index != CFG_NO_SECTION) {
        section = cfg_get_section(doc, record->section_index);
        if (section != (const cfg_section *) 0) {
            if (section->base_name.length > 0U) {
                status = cfg_path_append(out_path, section->base_name);
                if (status != CFG_STATUS_OK) {
                    return status;
                }
            } else if (section->full_name.length > 0U) {
                status = cfg_path_append(out_path, section->full_name);
                if (status != CFG_STATUS_OK) {
                    return status;
                }
            }

            if (section->arg_name.length > 0U) {
                status = cfg_path_append(out_path, section->arg_name);
                if (status != CFG_STATUS_OK) {
                    return status;
                }
            }
        }
    }

    if (record->kind == CFG_RECORD_BARE) {
        out_path->is_bare = 1;
        return CFG_STATUS_OK;
    }

    return cfg_append_key_segments(doc, record, out_path);
}

static int cfg_route_compare_segment(const cfg_document *doc,
                                     cfg_span span,
                                     const char *text,
                                     size_t length)
{
    return cfg_router_text_equals_raw(cfg_span_ptr(doc, span),
                                      (size_t) span.length,
                                      text,
                                      length,
                                      doc->case_insensitive);
}

static int cfg_parse_literal_path(const char *path_text,
                                  const char **out_segments,
                                  size_t *out_lengths,
                                  int max_segments,
                                  int *out_segment_count,
                                  int *out_is_bare)
{
    const char *cursor;
    const char *begin;
    int count;
    size_t length;

    if (path_text == (const char *) 0 ||
        out_segments == (const char **) 0 ||
        out_lengths == (size_t *) 0 ||
        out_segment_count == (int *) 0 ||
        out_is_bare == (int *) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    cursor = path_text;
    count = 0;
    *out_is_bare = 0;

    while (*cursor == '/') {
        ++cursor;
    }

    while (*cursor != '\0') {
        begin = cursor;
        while (*cursor != '\0' && *cursor != '/') {
            ++cursor;
        }
        length = (size_t) (cursor - begin);
        if (length > 0U) {
            if (length == 5U && strncmp(begin, "@bare", 5U) == 0) {
                *out_is_bare = 1;
            } else {
                if (count >= max_segments) {
                    return CFG_STATUS_RANGE;
                }
                out_segments[count] = begin;
                out_lengths[count] = length;
                ++count;
            }
        }
        while (*cursor == '/') {
            ++cursor;
        }
    }

    *out_segment_count = count;
    return CFG_STATUS_OK;
}

int cfg_route_walk(const cfg_document *doc,
                   cfg_route_callback callback,
                   void *user_data)
{
    unsigned short index;
    cfg_path path;
    int status;

    if (doc == (const cfg_document *) 0 || callback == (cfg_route_callback) 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    for (index = 0U; index < doc->record_count; ++index) {
        status = cfg_record_make_path(doc, &doc->records[index], &path);
        if (status != CFG_STATUS_OK) {
            return status;
        }
        status = callback(doc, &doc->records[index], &path, user_data);
        if (status != 0) {
            return status;
        }
    }

    return CFG_STATUS_OK;
}

int cfg_route_find(const cfg_document *doc,
                   const char *path,
                   int occurrence,
                   unsigned short *out_record_index)
{
    const char *segments[CFG_MAX_PATH_SEGMENTS];
    size_t lengths[CFG_MAX_PATH_SEGMENTS];
    int segment_count;
    int is_bare;
    int status;
    unsigned short index;
    cfg_path record_path;
    int seen;
    int match;
    int segment_index;

    if (doc == (const cfg_document *) 0 || path == (const char *) 0 || occurrence < 0) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    status = cfg_parse_literal_path(path,
                                    segments,
                                    lengths,
                                    CFG_MAX_PATH_SEGMENTS,
                                    &segment_count,
                                    &is_bare);
    if (status != CFG_STATUS_OK) {
        return status;
    }

    seen = 0;
    for (index = 0U; index < doc->record_count; ++index) {
        status = cfg_record_make_path(doc, &doc->records[index], &record_path);
        if (status != CFG_STATUS_OK) {
            return status;
        }

        if (record_path.is_bare != is_bare) {
            continue;
        }
        if (record_path.segment_count != segment_count) {
            continue;
        }

        match = 1;
        for (segment_index = 0; segment_index < segment_count; ++segment_index) {
            if (!cfg_route_compare_segment(doc,
                                           record_path.segments[segment_index],
                                           segments[segment_index],
                                           lengths[segment_index])) {
                match = 0;
                break;
            }
        }

        if (match) {
            if (seen == occurrence) {
                if (out_record_index != (unsigned short *) 0) {
                    *out_record_index = index;
                }
                return CFG_STATUS_OK;
            }
            ++seen;
        }
    }

    return CFG_STATUS_NOT_FOUND;
}

int cfg_path_copy(const cfg_document *doc,
                  const cfg_path *path,
                  char *out_text,
                  size_t out_capacity)
{
    size_t out_index;
    int segment_index;
    const char *segment_text;
    size_t segment_length;

    if (doc == (const cfg_document *) 0 ||
        path == (const cfg_path *) 0 ||
        out_text == (char *) 0 ||
        out_capacity == 0U) {
        return CFG_STATUS_BAD_ARGUMENT;
    }

    out_index = 0U;
    for (segment_index = 0; segment_index < path->segment_count; ++segment_index) {
        if (out_index > 0U) {
            if (out_index + 1U >= out_capacity) {
                return CFG_STATUS_TRUNCATED;
            }
            out_text[out_index++] = '/';
        }
        segment_text = cfg_span_ptr(doc, path->segments[segment_index]);
        segment_length = (size_t) path->segments[segment_index].length;
        if (out_index + segment_length + 1U > out_capacity) {
            return CFG_STATUS_TRUNCATED;
        }
        memcpy(out_text + out_index, segment_text, segment_length);
        out_index += segment_length;
    }

    if (path->is_bare) {
        if (out_index > 0U) {
            if (out_index + 1U >= out_capacity) {
                return CFG_STATUS_TRUNCATED;
            }
            out_text[out_index++] = '/';
        }
        if (out_index + 5U + 1U > out_capacity) {
            return CFG_STATUS_TRUNCATED;
        }
        memcpy(out_text + out_index, "@bare", 5U);
        out_index += 5U;
    }

    out_text[out_index] = '\0';
    return CFG_STATUS_OK;
}
