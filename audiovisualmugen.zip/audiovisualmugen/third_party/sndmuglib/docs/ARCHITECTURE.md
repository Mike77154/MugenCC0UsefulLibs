# Architecture

## `wavc89`

`wavc89` is a standalone RIFF/WAVE container library:

- callback-based I/O
- memory and stdio backends
- parser for RIFF/WAVE
- metadata reader for `fmt`, `data`, optional `fact`, and ADPCM extra format fields
- PCM 8-bit / 16-bit conversion helpers
- Microsoft ADPCM sample-level encoder and decoder for mono and stereo WAV payloads
- IMA/DVI ADPCM sample-level encoder and decoder for mono and stereo WAV payloads
- Q15 fixed-point helpers for gain and downmix

### `wavc89` module split

- `wavc89_reader.c` : RIFF/WAVE parsing and metadata extraction
- `wavc89_writer.c` : generic WAV writer helpers
- `wavc89_pcm.c` : PCM sample conversion and generic decode dispatch
- `wavc89_msadpcm.c` : Microsoft ADPCM sample codec and WAV ADPCM writer
- `wavc89_imaadpcm.c` : IMA/DVI ADPCM sample codec and WAV ADPCM writer
- `wavc89_io_mem.c` / `wavc89_io_stdio.c` : embeddable backends

## `sndmug`

`sndmug` sits above `wavc89`:

- parses `.snd` header and linked subfile chain
- indexes entries into caller-supplied memory
- optional sorted pair index `(group,sound) -> entry_index`
- validates payload WAVs through `wavc89`
- writes deterministic output
- builds without heap allocation

## No heap rule

All long-lived storage is caller-owned:

- entry index arrays
- in-memory buffers
- manifest arrays in CLI/tests
- PCM and ADPCM work buffers owned by the caller

No module calls `malloc`, `calloc`, `realloc`, or `free`.
