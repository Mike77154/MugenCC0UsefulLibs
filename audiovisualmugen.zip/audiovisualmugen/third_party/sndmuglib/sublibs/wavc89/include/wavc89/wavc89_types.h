#ifndef WAVC89_TYPES_H
#define WAVC89_TYPES_H

#include <limits.h>

#if CHAR_BIT != 8
#error "wavc89 requires 8-bit bytes"
#endif

typedef unsigned char wavc89_u8;

#if USHRT_MAX == 0xFFFFu
typedef unsigned short wavc89_u16;
#elif UINT_MAX == 0xFFFFu
typedef unsigned int wavc89_u16;
#else
#error "wavc89 requires a 16-bit unsigned type"
#endif

#if UINT_MAX == 0xFFFFFFFFUL
typedef unsigned int wavc89_u32;
#elif ULONG_MAX == 0xFFFFFFFFUL
typedef unsigned long wavc89_u32;
#else
#error "wavc89 requires a 32-bit unsigned type"
#endif

#if SCHAR_MAX == 0x7F
typedef signed char wavc89_s8;
#else
#error "wavc89 requires an 8-bit signed type"
#endif

#if SHRT_MAX == 0x7FFF
typedef signed short wavc89_s16;
#elif INT_MAX == 0x7FFF
typedef signed int wavc89_s16;
#else
#error "wavc89 requires a 16-bit signed type"
#endif

#if INT_MAX == 0x7FFFFFFFL
typedef signed int wavc89_s32;
#elif LONG_MAX == 0x7FFFFFFFL
typedef signed long wavc89_s32;
#else
#error "wavc89 requires a 32-bit signed type"
#endif

#endif
