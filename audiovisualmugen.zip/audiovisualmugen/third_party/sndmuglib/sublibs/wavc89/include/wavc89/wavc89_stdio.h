#ifndef WAVC89_STDIO_H
#define WAVC89_STDIO_H

#include <stdio.h>
#include "wavc89_io.h"

int wavc89_io_stdio_reader_init(wavc89_io *io, FILE *fp);
int wavc89_io_stdio_writer_init(wavc89_io *io, FILE *fp);

#endif
