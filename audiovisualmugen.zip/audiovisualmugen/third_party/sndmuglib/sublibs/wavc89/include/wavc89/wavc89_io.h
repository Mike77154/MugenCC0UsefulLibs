#ifndef WAVC89_IO_H
#define WAVC89_IO_H

#include "wavc89_types.h"

typedef int (*wavc89_read_fn)(void *user, void *dst, wavc89_u32 size, wavc89_u32 *out_read);
typedef int (*wavc89_write_fn)(void *user, const void *src, wavc89_u32 size, wavc89_u32 *out_written);
typedef int (*wavc89_seek_fn)(void *user, wavc89_u32 absolute_offset);
typedef int (*wavc89_tell_fn)(void *user, wavc89_u32 *out_offset);
typedef int (*wavc89_size_fn)(void *user, wavc89_u32 *out_size);

typedef struct wavc89_io_t
{
    wavc89_read_fn read;
    wavc89_write_fn write;
    wavc89_seek_fn seek;
    wavc89_tell_fn tell;
    wavc89_size_fn size;
    void *user;
} wavc89_io;

typedef struct wavc89_mem_reader_t
{
    const wavc89_u8 *data;
    wavc89_u32 size;
    wavc89_u32 pos;
} wavc89_mem_reader;

typedef struct wavc89_mem_writer_t
{
    wavc89_u8 *data;
    wavc89_u32 capacity;
    wavc89_u32 pos;
    wavc89_u32 size;
} wavc89_mem_writer;

int wavc89_io_mem_reader_init(wavc89_io *io, wavc89_mem_reader *ctx, const void *data, wavc89_u32 size);
int wavc89_io_mem_writer_init(wavc89_io *io, wavc89_mem_writer *ctx, void *data, wavc89_u32 capacity);

#endif
