#ifndef WAVC89_FIXED_H
#define WAVC89_FIXED_H

#include "wavc89_types.h"

#define WAVC89_Q15_ONE ((wavc89_s32)32768L)
#define WAVC89_Q16_ONE ((wavc89_s32)65536L)

wavc89_s32 wavc89_q15_mul(wavc89_s32 a, wavc89_s32 b);
wavc89_s32 wavc89_q15_from_ratio(wavc89_s32 num, wavc89_s32 den);
wavc89_s32 wavc89_q16_from_ratio(wavc89_s32 num, wavc89_s32 den);

#endif
