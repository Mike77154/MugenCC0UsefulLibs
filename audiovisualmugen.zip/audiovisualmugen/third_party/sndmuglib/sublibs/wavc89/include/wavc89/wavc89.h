#ifndef WAVC89_H
#define WAVC89_H

#include "wavc89_types.h"
#include "wavc89_status.h"
#include "wavc89_fixed.h"
#include "wavc89_io.h"

#define WAVC89_FORMAT_PCM        ((wavc89_u16)0x0001u)
#define WAVC89_FORMAT_ADPCM      ((wavc89_u16)0x0002u)
#define WAVC89_FORMAT_MS_ADPCM   WAVC89_FORMAT_ADPCM
#define WAVC89_FORMAT_DVI_ADPCM  ((wavc89_u16)0x0011u)
#define WAVC89_FORMAT_IMA_ADPCM  WAVC89_FORMAT_DVI_ADPCM

#define WAVC89_MSADPCM_COEF_COUNT        7u
#define WAVC89_MSADPCM_MAX_COEFFICIENTS 16u

typedef struct wavc89_info_t
{
    wavc89_u32 container_offset;
    wavc89_u32 container_size;
    wavc89_u32 riff_size_field;

    wavc89_u32 fmt_offset;
    wavc89_u32 fmt_size;
    wavc89_u32 data_offset;
    wavc89_u32 data_size;
    wavc89_u32 fact_offset;
    wavc89_u32 fact_size;

    wavc89_u16 format_tag;
    wavc89_u16 channels;
    wavc89_u32 sample_rate;
    wavc89_u32 avg_bytes_per_sec;
    wavc89_u16 block_align;
    wavc89_u16 bits_per_sample;
    wavc89_u16 cb_size;

    wavc89_u32 extra_format_offset;
    wavc89_u32 extra_format_size;

    wavc89_u16 adpcm_samples_per_block;
    wavc89_u16 adpcm_num_coef;
    wavc89_s16 adpcm_coef1[WAVC89_MSADPCM_MAX_COEFFICIENTS];
    wavc89_s16 adpcm_coef2[WAVC89_MSADPCM_MAX_COEFFICIENTS];

    int has_fact;
    wavc89_u32 fact_sample_length;
} wavc89_info;

typedef struct wavc89_reader_t
{
    wavc89_io io;
    wavc89_u32 base_offset;
    wavc89_u32 span_size;
    wavc89_info info;
} wavc89_reader;

typedef struct wavc89_writer_format_t
{
    wavc89_u16 format_tag;
    wavc89_u16 channels;
    wavc89_u32 sample_rate;
    wavc89_u32 avg_bytes_per_sec;
    wavc89_u16 block_align;
    wavc89_u16 bits_per_sample;
    const wavc89_u8 *extra_format;
    wavc89_u16 extra_format_size;
    int write_fact;
    wavc89_u32 fact_sample_length;
} wavc89_writer_format;

int wavc89_reader_open(wavc89_reader *reader, const wavc89_io *io, wavc89_u32 base_offset, wavc89_u32 span_size);
int wavc89_reader_read_data(const wavc89_reader *reader, wavc89_u32 data_offset, void *dst, wavc89_u32 size, wavc89_u32 *out_read);
int wavc89_reader_copy_data(const wavc89_reader *reader, wavc89_io *dst);
int wavc89_reader_copy_file(const wavc89_reader *reader, wavc89_io *dst);

int wavc89_is_pcm(const wavc89_info *info);
int wavc89_is_adpcm(const wavc89_info *info);
int wavc89_is_ms_adpcm(const wavc89_info *info);
int wavc89_is_ima_adpcm(const wavc89_info *info);
int wavc89_is_mugen_compatible(const wavc89_info *info);

int wavc89_writer_write_from_io(const wavc89_io *dst, const wavc89_writer_format *fmt, const wavc89_io *data_io, wavc89_u32 data_offset, wavc89_u32 data_size);
int wavc89_writer_write_pcm_from_memory(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, wavc89_u16 bits_per_sample, const void *pcm_data, wavc89_u32 pcm_size);
int wavc89_writer_write_msadpcm_from_s16(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align);
int wavc89_writer_write_imaadpcm_from_s16(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align);

int wavc89_pcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count);
int wavc89_pcm_encode_from_s16(wavc89_u16 bits_per_sample, const wavc89_s16 *src_samples, wavc89_u32 sample_count, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size);
void wavc89_pcm_apply_gain_q15(wavc89_s16 *samples, wavc89_u32 sample_count, wavc89_s32 gain_q15);
void wavc89_pcm_downmix_stereo_to_mono_q15(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_s16 *dst_mono, wavc89_s32 left_q15, wavc89_s32 right_q15);

int wavc89_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count);
int wavc89_msadpcm_samples_per_block(wavc89_u16 channels, wavc89_u16 block_align, wavc89_u16 *out_samples_per_block);
int wavc89_msadpcm_block_align(wavc89_u16 channels, wavc89_u16 samples_per_block, wavc89_u16 *out_block_align);
int wavc89_msadpcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count);
int wavc89_msadpcm_encode_from_s16(wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size, wavc89_u16 *out_samples_per_block);
int wavc89_imaadpcm_samples_per_block(wavc89_u16 channels, wavc89_u16 block_align, wavc89_u16 *out_samples_per_block);
int wavc89_imaadpcm_block_align(wavc89_u16 channels, wavc89_u16 samples_per_block, wavc89_u16 *out_block_align);
int wavc89_imaadpcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count);
int wavc89_imaadpcm_encode_from_s16(wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size, wavc89_u16 *out_samples_per_block);

#endif
