#include "wavc89/wavc89_status.h"

const char *wavc89_status_string(int code)
{
    switch (code)
    {
    case WAVC89_OK: return "WAVC89_OK";
    case WAVC89_E_INVALID_ARG: return "WAVC89_E_INVALID_ARG";
    case WAVC89_E_IO: return "WAVC89_E_IO";
    case WAVC89_E_SHORT_READ: return "WAVC89_E_SHORT_READ";
    case WAVC89_E_SHORT_WRITE: return "WAVC89_E_SHORT_WRITE";
    case WAVC89_E_SEEK: return "WAVC89_E_SEEK";
    case WAVC89_E_BAD_SIGNATURE: return "WAVC89_E_BAD_SIGNATURE";
    case WAVC89_E_BAD_RIFF: return "WAVC89_E_BAD_RIFF";
    case WAVC89_E_BAD_WAVE: return "WAVC89_E_BAD_WAVE";
    case WAVC89_E_BAD_CHUNK: return "WAVC89_E_BAD_CHUNK";
    case WAVC89_E_OVERFLOW: return "WAVC89_E_OVERFLOW";
    case WAVC89_E_LIMIT: return "WAVC89_E_LIMIT";
    case WAVC89_E_MISSING_FMT: return "WAVC89_E_MISSING_FMT";
    case WAVC89_E_MISSING_DATA: return "WAVC89_E_MISSING_DATA";
    case WAVC89_E_UNSUPPORTED: return "WAVC89_E_UNSUPPORTED";
    case WAVC89_E_CORRUPT: return "WAVC89_E_CORRUPT";
    default: return "WAVC89_E_UNKNOWN";
    }
}
