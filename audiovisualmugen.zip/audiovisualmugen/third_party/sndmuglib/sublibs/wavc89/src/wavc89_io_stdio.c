#include <stdio.h>
#include "wavc89/wavc89_stdio.h"
#include "wavc89/wavc89_status.h"

static int wavc89_stdio_read(void *user, void *dst, wavc89_u32 size, wavc89_u32 *out_read)
{
    FILE *fp;
    size_t n;
    if (user == 0 || dst == 0 || out_read == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    n = fread(dst, 1u, (size_t)size, fp);
    *out_read = (wavc89_u32)n;
    return (n == (size_t)size) ? WAVC89_OK : WAVC89_E_SHORT_READ;
}

static int wavc89_stdio_write(void *user, const void *src, wavc89_u32 size, wavc89_u32 *out_written)
{
    FILE *fp;
    size_t n;
    if (user == 0 || src == 0 || out_written == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    n = fwrite(src, 1u, (size_t)size, fp);
    *out_written = (wavc89_u32)n;
    return (n == (size_t)size) ? WAVC89_OK : WAVC89_E_SHORT_WRITE;
}

static int wavc89_stdio_seek(void *user, wavc89_u32 absolute_offset)
{
    FILE *fp;
    if (user == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    return (fseek(fp, (long)absolute_offset, SEEK_SET) == 0) ? WAVC89_OK : WAVC89_E_SEEK;
}

static int wavc89_stdio_tell(void *user, wavc89_u32 *out_offset)
{
    FILE *fp;
    long p;
    if (user == 0 || out_offset == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    p = ftell(fp);
    if (p < 0)
    {
        return WAVC89_E_IO;
    }
    *out_offset = (wavc89_u32)p;
    return WAVC89_OK;
}

static int wavc89_stdio_size(void *user, wavc89_u32 *out_size)
{
    FILE *fp;
    long saved;
    long endp;
    if (user == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    saved = ftell(fp);
    if (saved < 0)
    {
        return WAVC89_E_IO;
    }
    if (fseek(fp, 0L, SEEK_END) != 0)
    {
        return WAVC89_E_SEEK;
    }
    endp = ftell(fp);
    if (endp < 0)
    {
        return WAVC89_E_IO;
    }
    if (fseek(fp, saved, SEEK_SET) != 0)
    {
        return WAVC89_E_SEEK;
    }
    *out_size = (wavc89_u32)endp;
    return WAVC89_OK;
}

int wavc89_io_stdio_reader_init(wavc89_io *io, FILE *fp)
{
    if (io == 0 || fp == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    io->read = wavc89_stdio_read;
    io->write = 0;
    io->seek = wavc89_stdio_seek;
    io->tell = wavc89_stdio_tell;
    io->size = wavc89_stdio_size;
    io->user = fp;
    return WAVC89_OK;
}

int wavc89_io_stdio_writer_init(wavc89_io *io, FILE *fp)
{
    if (io == 0 || fp == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    io->read = 0;
    io->write = wavc89_stdio_write;
    io->seek = wavc89_stdio_seek;
    io->tell = wavc89_stdio_tell;
    io->size = wavc89_stdio_size;
    io->user = fp;
    return WAVC89_OK;
}
