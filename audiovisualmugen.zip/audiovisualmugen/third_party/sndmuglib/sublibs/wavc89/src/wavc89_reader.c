#include <string.h>
#include "wavc89/wavc89.h"

static wavc89_u16 wavc89_le16(const wavc89_u8 *p)
{
    return (wavc89_u16)((wavc89_u16)p[0] | ((wavc89_u16)p[1] << 8));
}

static wavc89_s16 wavc89_les16(const wavc89_u8 *p)
{
    wavc89_u16 u;
    u = wavc89_le16(p);
    return (wavc89_s16)u;
}

static wavc89_u32 wavc89_le32(const wavc89_u8 *p)
{
    return (wavc89_u32)((wavc89_u32)p[0]
        | ((wavc89_u32)p[1] << 8)
        | ((wavc89_u32)p[2] << 16)
        | ((wavc89_u32)p[3] << 24));
}

static int wavc89_read_exact(const wavc89_io *io, wavc89_u32 offset, void *dst, wavc89_u32 size)
{
    wavc89_u32 n;
    int rc;
    if (io == 0 || io->read == 0 || io->seek == 0 || dst == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    rc = io->seek(io->user, offset);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = io->read(io->user, dst, size, &n);
    if (rc != WAVC89_OK && rc != WAVC89_E_SHORT_READ)
    {
        return rc;
    }
    return (n == size) ? WAVC89_OK : WAVC89_E_SHORT_READ;
}

static int wavc89_copy_exact(const wavc89_io *src, wavc89_u32 src_offset, wavc89_io *dst, wavc89_u32 size)
{
    wavc89_u8 buf[256];
    wavc89_u32 remain;
    wavc89_u32 take;
    wavc89_u32 nread;
    wavc89_u32 nwritten;
    int rc;

    if (src == 0 || dst == 0 || src->read == 0 || src->seek == 0 || dst->write == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = src->seek(src->user, src_offset);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    remain = size;
    while (remain != 0)
    {
        take = (remain > (wavc89_u32)sizeof(buf)) ? (wavc89_u32)sizeof(buf) : remain;
        rc = src->read(src->user, buf, take, &nread);
        if ((rc != WAVC89_OK && rc != WAVC89_E_SHORT_READ) || nread != take)
        {
            return WAVC89_E_SHORT_READ;
        }
        rc = dst->write(dst->user, buf, take, &nwritten);
        if ((rc != WAVC89_OK && rc != WAVC89_E_SHORT_WRITE) || nwritten != take)
        {
            return WAVC89_E_SHORT_WRITE;
        }
        remain -= take;
    }
    return WAVC89_OK;
}

static int wavc89_parse_msadpcm_format(wavc89_reader *reader, const wavc89_io *io)
{
    wavc89_u8 head[4];
    wavc89_u8 pair[4];
    wavc89_u32 need;
    wavc89_u32 i;
    int rc;

    if (reader->info.extra_format_size < 4u)
    {
        return WAVC89_OK;
    }

    rc = wavc89_read_exact(io, reader->info.extra_format_offset, head, 4u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    reader->info.adpcm_samples_per_block = wavc89_le16(head + 0);
    reader->info.adpcm_num_coef = wavc89_le16(head + 2);

    if (reader->info.adpcm_num_coef > WAVC89_MSADPCM_MAX_COEFFICIENTS)
    {
        return WAVC89_E_LIMIT;
    }

    need = 4u + ((wavc89_u32)reader->info.adpcm_num_coef * 4u);
    if (reader->info.extra_format_size < need)
    {
        return WAVC89_E_BAD_CHUNK;
    }

    for (i = 0u; i < (wavc89_u32)reader->info.adpcm_num_coef; ++i)
    {
        rc = wavc89_read_exact(io, reader->info.extra_format_offset + 4u + (i * 4u), pair, 4u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        reader->info.adpcm_coef1[i] = wavc89_les16(pair + 0);
        reader->info.adpcm_coef2[i] = wavc89_les16(pair + 2);
    }

    return WAVC89_OK;
}

static int wavc89_parse_imaadpcm_format(wavc89_reader *reader, const wavc89_io *io)
{
    wavc89_u8 head[2];
    int rc;

    if (reader->info.extra_format_size < 2u)
    {
        return WAVC89_OK;
    }

    rc = wavc89_read_exact(io, reader->info.extra_format_offset, head, 2u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    reader->info.adpcm_samples_per_block = wavc89_le16(head + 0);
    reader->info.adpcm_num_coef = 0u;
    return WAVC89_OK;
}

int wavc89_reader_open(wavc89_reader *reader, const wavc89_io *io, wavc89_u32 base_offset, wavc89_u32 span_size)
{
    wavc89_u8 hdr[12];
    wavc89_u8 chunk_hdr[8];
    wavc89_u8 fmt16[18];
    wavc89_u32 total_size;
    wavc89_u32 pos;
    wavc89_u32 endp;
    wavc89_u32 chunk_size;
    wavc89_u32 padded_size;
    int rc;

    if (reader == 0 || io == 0 || io->read == 0 || io->seek == 0 || io->size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    memset(reader, 0, sizeof(*reader));
    reader->io = *io;
    reader->base_offset = base_offset;

    rc = io->size(io->user, &total_size);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (base_offset > total_size)
    {
        return WAVC89_E_SEEK;
    }

    if (span_size == 0)
    {
        span_size = total_size - base_offset;
    }

    if (span_size < 12u)
    {
        return WAVC89_E_BAD_RIFF;
    }

    if (base_offset + span_size < base_offset || base_offset + span_size > total_size)
    {
        return WAVC89_E_OVERFLOW;
    }

    reader->span_size = span_size;

    rc = wavc89_read_exact(io, base_offset, hdr, 12u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (memcmp(hdr + 0, "RIFF", 4u) != 0)
    {
        return WAVC89_E_BAD_RIFF;
    }
    if (memcmp(hdr + 8, "WAVE", 4u) != 0)
    {
        return WAVC89_E_BAD_WAVE;
    }

    reader->info.container_offset = base_offset;
    reader->info.container_size = span_size;
    reader->info.riff_size_field = wavc89_le32(hdr + 4);

    pos = base_offset + 12u;
    endp = base_offset + span_size;

    while (pos + 8u <= endp)
    {
        rc = wavc89_read_exact(io, pos, chunk_hdr, 8u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }

        chunk_size = wavc89_le32(chunk_hdr + 4);
        padded_size = chunk_size + (chunk_size & 1u);

        if (pos + 8u + chunk_size < pos || pos + 8u + chunk_size > endp)
        {
            return WAVC89_E_BAD_CHUNK;
        }
        /*
         * RIFF normally pads odd-sized chunks to an even boundary.  Some
         * WAV payloads in Elecbyte's reference KFM SND omit the final pad
         * byte while keeping the RIFF size consistent with the unpadded
         * payload.  Accept that only for the terminal chunk; interior
         * chunks still require their alignment byte.
         */
        if (pos + 8u + padded_size > endp)
        {
            if (pos + 8u + chunk_size == endp)
            {
                padded_size = chunk_size;
            }
            else
            {
                return WAVC89_E_BAD_CHUNK;
            }
        }

        if (memcmp(chunk_hdr + 0, "fmt ", 4u) == 0)
        {
            if (chunk_size < 16u)
            {
                return WAVC89_E_BAD_CHUNK;
            }
            rc = wavc89_read_exact(io, pos + 8u, fmt16, (chunk_size >= 18u) ? 18u : 16u);
            if (rc != WAVC89_OK)
            {
                return rc;
            }
            reader->info.fmt_offset = pos + 8u;
            reader->info.fmt_size = chunk_size;
            reader->info.format_tag = wavc89_le16(fmt16 + 0);
            reader->info.channels = wavc89_le16(fmt16 + 2);
            reader->info.sample_rate = wavc89_le32(fmt16 + 4);
            reader->info.avg_bytes_per_sec = wavc89_le32(fmt16 + 8);
            reader->info.block_align = wavc89_le16(fmt16 + 12);
            reader->info.bits_per_sample = wavc89_le16(fmt16 + 14);
            if (chunk_size >= 18u)
            {
                reader->info.cb_size = wavc89_le16(fmt16 + 16);
                reader->info.extra_format_offset = pos + 8u + 18u;
                reader->info.extra_format_size = (chunk_size > 18u) ? (chunk_size - 18u) : 0u;
            }
            else
            {
                reader->info.cb_size = 0u;
                reader->info.extra_format_offset = 0u;
                reader->info.extra_format_size = 0u;
            }
        }
        else if (memcmp(chunk_hdr + 0, "data", 4u) == 0)
        {
            reader->info.data_offset = pos + 8u;
            reader->info.data_size = chunk_size;
        }
        else if (memcmp(chunk_hdr + 0, "fact", 4u) == 0)
        {
            wavc89_u8 fact_buf[4];
            reader->info.has_fact = 1;
            reader->info.fact_offset = pos + 8u;
            reader->info.fact_size = chunk_size;
            if (chunk_size >= 4u)
            {
                rc = wavc89_read_exact(io, pos + 8u, fact_buf, 4u);
                if (rc != WAVC89_OK)
                {
                    return rc;
                }
                reader->info.fact_sample_length = wavc89_le32(fact_buf);
            }
        }

        pos += 8u + padded_size;
    }

    if (reader->info.fmt_offset == 0u)
    {
        return WAVC89_E_MISSING_FMT;
    }
    if (reader->info.data_offset == 0u && reader->info.data_size == 0u)
    {
        return WAVC89_E_MISSING_DATA;
    }

    if (reader->info.format_tag == WAVC89_FORMAT_MS_ADPCM)
    {
        rc = wavc89_parse_msadpcm_format(reader, io);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }
    else if (reader->info.format_tag == WAVC89_FORMAT_IMA_ADPCM)
    {
        rc = wavc89_parse_imaadpcm_format(reader, io);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}

int wavc89_reader_read_data(const wavc89_reader *reader, wavc89_u32 data_offset, void *dst, wavc89_u32 size, wavc89_u32 *out_read)
{
    wavc89_u32 available;
    wavc89_u32 n;
    int rc;

    if (reader == 0 || dst == 0 || out_read == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    if (data_offset > reader->info.data_size)
    {
        return WAVC89_E_INVALID_ARG;
    }

    available = reader->info.data_size - data_offset;
    n = (size <= available) ? size : available;
    rc = wavc89_read_exact(&reader->io, reader->info.data_offset + data_offset, dst, n);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    *out_read = n;
    return (n == size) ? WAVC89_OK : WAVC89_E_SHORT_READ;
}

int wavc89_reader_copy_data(const wavc89_reader *reader, wavc89_io *dst)
{
    if (reader == 0 || dst == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    return wavc89_copy_exact(&reader->io, reader->info.data_offset, dst, reader->info.data_size);
}

int wavc89_reader_copy_file(const wavc89_reader *reader, wavc89_io *dst)
{
    if (reader == 0 || dst == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    return wavc89_copy_exact(&reader->io, reader->base_offset, dst, reader->span_size);
}

int wavc89_is_pcm(const wavc89_info *info)
{
    return (info != 0 && info->format_tag == WAVC89_FORMAT_PCM) ? 1 : 0;
}

int wavc89_is_adpcm(const wavc89_info *info)
{
    return (info != 0 && (info->format_tag == WAVC89_FORMAT_MS_ADPCM || info->format_tag == WAVC89_FORMAT_IMA_ADPCM)) ? 1 : 0;
}

int wavc89_is_ms_adpcm(const wavc89_info *info)
{
    return (info != 0 && info->format_tag == WAVC89_FORMAT_MS_ADPCM) ? 1 : 0;
}

int wavc89_is_ima_adpcm(const wavc89_info *info)
{
    return (info != 0 && info->format_tag == WAVC89_FORMAT_IMA_ADPCM) ? 1 : 0;
}

int wavc89_is_mugen_compatible(const wavc89_info *info)
{
    wavc89_u16 samples_per_block;
    int rc;

    if (info == 0)
    {
        return 0;
    }

    if (info->format_tag == WAVC89_FORMAT_PCM)
    {
        return (info->channels >= 1u && info->block_align != 0u &&
                (info->bits_per_sample == 8u || info->bits_per_sample == 16u)) ? 1 : 0;
    }

    if (!(info->channels == 1u || info->channels == 2u))
    {
        return 0;
    }
    if (info->bits_per_sample != 4u)
    {
        return 0;
    }
    if (info->block_align == 0u)
    {
        return 0;
    }

    if (info->format_tag == WAVC89_FORMAT_MS_ADPCM)
    {
        if (info->adpcm_num_coef == 0u)
        {
            return 0;
        }
        if (info->adpcm_samples_per_block < 2u)
        {
            return 0;
        }
        rc = wavc89_msadpcm_samples_per_block(info->channels, info->block_align, &samples_per_block);
        if (rc != WAVC89_OK)
        {
            return 0;
        }
        if (samples_per_block != info->adpcm_samples_per_block)
        {
            return 0;
        }
        return 1;
    }

    if (info->format_tag == WAVC89_FORMAT_IMA_ADPCM)
    {
        if (info->adpcm_samples_per_block == 0u)
        {
            return 0;
        }
        rc = wavc89_imaadpcm_samples_per_block(info->channels, info->block_align, &samples_per_block);
        if (rc != WAVC89_OK)
        {
            return 0;
        }
        if (samples_per_block != info->adpcm_samples_per_block)
        {
            return 0;
        }
        return 1;
    }

    return 0;
}
