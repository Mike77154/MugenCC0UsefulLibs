#include <string.h>
#include "wavc89/wavc89.h"

typedef struct wavc89_imaadpcm_state_t
{
    wavc89_s32 predictor;
    int step_index;
} wavc89_imaadpcm_state;

static const wavc89_s16 wavc89_imaadpcm_step_table[89] =
{
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17,
    19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
    50, 55, 60, 66, 73, 80, 88, 97, 107, 118,
    130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
    337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
    876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
    2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
    5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
};

static const wavc89_s8 wavc89_imaadpcm_index_table[16] =
{
    -1, -1, -1, -1, 2, 4, 6, 8,
    -1, -1, -1, -1, 2, 4, 6, 8
};

static wavc89_s16 wavc89_clip_s16(long v)
{
    if (v > 32767L)
    {
        return (wavc89_s16)32767;
    }
    if (v < -32768L)
    {
        return (wavc89_s16)-32768;
    }
    return (wavc89_s16)v;
}

static wavc89_s32 wavc89_abs_s32(wavc89_s32 v)
{
    return (v < 0) ? -v : v;
}

static wavc89_u16 wavc89_le16(const wavc89_u8 *p)
{
    return (wavc89_u16)((wavc89_u16)p[0] | ((wavc89_u16)p[1] << 8));
}

static wavc89_s16 wavc89_les16(const wavc89_u8 *p)
{
    return (wavc89_s16)wavc89_le16(p);
}

static void wavc89_store_le16(wavc89_u8 *p, wavc89_u16 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
}

static void wavc89_store_le32(wavc89_u8 *p, wavc89_u32 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
    p[2] = (wavc89_u8)((v >> 16) & 0xFFu);
    p[3] = (wavc89_u8)((v >> 24) & 0xFFu);
}

static int wavc89_write_exact(const wavc89_io *io, const void *src, wavc89_u32 size)
{
    wavc89_u32 n;
    int rc;
    if (io == 0 || io->write == 0 || src == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    rc = io->write(io->user, src, size, &n);
    if (rc != WAVC89_OK && rc != WAVC89_E_SHORT_WRITE)
    {
        return rc;
    }
    return (n == size) ? WAVC89_OK : WAVC89_E_SHORT_WRITE;
}

static int wavc89_imaadpcm_clamp_index(int v)
{
    if (v < 0)
    {
        return 0;
    }
    if (v > 88)
    {
        return 88;
    }
    return v;
}

static wavc89_s16 wavc89_imaadpcm_decode_nibble(wavc89_imaadpcm_state *st, wavc89_u8 nibble)
{
    long step;
    long diff;
    long pred;

    step = (long)wavc89_imaadpcm_step_table[st->step_index];
    diff = step >> 3;
    if ((nibble & 1u) != 0u)
    {
        diff += step >> 2;
    }
    if ((nibble & 2u) != 0u)
    {
        diff += step >> 1;
    }
    if ((nibble & 4u) != 0u)
    {
        diff += step;
    }

    pred = (long)st->predictor;
    if ((nibble & 8u) != 0u)
    {
        pred -= diff;
    }
    else
    {
        pred += diff;
    }

    st->predictor = (wavc89_s32)wavc89_clip_s16(pred);
    st->step_index = wavc89_imaadpcm_clamp_index(st->step_index + (int)wavc89_imaadpcm_index_table[nibble & 0x0Fu]);
    return (wavc89_s16)st->predictor;
}

static wavc89_u8 wavc89_imaadpcm_encode_nibble(wavc89_imaadpcm_state *st, wavc89_s16 sample)
{
    long step;
    long diff;
    long mag;
    long vpdiff;
    wavc89_u8 nibble;
    long pred;

    step = (long)wavc89_imaadpcm_step_table[st->step_index];
    diff = (long)sample - (long)st->predictor;
    nibble = 0u;
    mag = diff;
    if (mag < 0L)
    {
        nibble = 8u;
        mag = -mag;
    }

    vpdiff = step >> 3;
    if (mag >= step)
    {
        nibble |= 4u;
        mag -= step;
        vpdiff += step;
    }
    if (mag >= (step >> 1))
    {
        nibble |= 2u;
        mag -= (step >> 1);
        vpdiff += step >> 1;
    }
    if (mag >= (step >> 2))
    {
        nibble |= 1u;
        vpdiff += step >> 2;
    }

    pred = (long)st->predictor;
    if ((nibble & 8u) != 0u)
    {
        pred -= vpdiff;
    }
    else
    {
        pred += vpdiff;
    }

    st->predictor = (wavc89_s32)wavc89_clip_s16(pred);
    st->step_index = wavc89_imaadpcm_clamp_index(st->step_index + (int)wavc89_imaadpcm_index_table[nibble & 0x0Fu]);
    return nibble;
}

static wavc89_s16 wavc89_imaadpcm_channel_sample(const wavc89_s16 *src_interleaved, wavc89_u16 channels, wavc89_u32 frame_index, wavc89_u16 channel_index)
{
    return src_interleaved[((wavc89_u32)channels * frame_index) + channel_index];
}

static int wavc89_imaadpcm_initial_index_guess(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index)
{
    wavc89_s32 diff;
    wavc89_s32 best_dist;
    wavc89_s32 dist;
    int best_index;
    int i;

    if (frame_count < 2u)
    {
        return 0;
    }

    diff = wavc89_abs_s32((wavc89_s32)wavc89_imaadpcm_channel_sample(src_interleaved, channels, 1u, channel_index)
        - (wavc89_s32)wavc89_imaadpcm_channel_sample(src_interleaved, channels, 0u, channel_index));

    best_index = 0;
    best_dist = wavc89_abs_s32((wavc89_s32)wavc89_imaadpcm_step_table[0] - diff);
    for (i = 1; i < 89; ++i)
    {
        dist = wavc89_abs_s32((wavc89_s32)wavc89_imaadpcm_step_table[i] - diff);
        if (dist < best_dist)
        {
            best_dist = dist;
            best_index = i;
        }
    }

    return best_index;
}

static wavc89_u32 wavc89_imaadpcm_simulate_channel(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, int initial_index, wavc89_u32 frame_limit)
{
    wavc89_imaadpcm_state st;
    wavc89_u32 frame;
    wavc89_u32 err_sum;
    wavc89_s32 diff;

    st.predictor = (wavc89_s32)wavc89_imaadpcm_channel_sample(src_interleaved, channels, 0u, channel_index);
    st.step_index = wavc89_imaadpcm_clamp_index(initial_index);

    err_sum = 0u;
    for (frame = 1u; frame < frame_count && frame < frame_limit; ++frame)
    {
        (void)wavc89_imaadpcm_encode_nibble(&st, wavc89_imaadpcm_channel_sample(src_interleaved, channels, frame, channel_index));
        diff = (wavc89_s32)wavc89_imaadpcm_channel_sample(src_interleaved, channels, frame, channel_index) - st.predictor;
        err_sum += (wavc89_u32)wavc89_abs_s32(diff);
    }

    return err_sum;
}

static int wavc89_imaadpcm_choose_initial_index(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index)
{
    wavc89_u32 frame_limit;
    wavc89_u32 best_error;
    wavc89_u32 error_sum;
    int base_index;
    int best_index;
    int start;
    int end;
    int i;

    if (frame_count < 2u)
    {
        return 0;
    }

    base_index = wavc89_imaadpcm_initial_index_guess(src_interleaved, frame_count, channels, channel_index);
    start = base_index - 12;
    end = base_index + 12;
    if (start < 0)
    {
        start = 0;
    }
    if (end > 88)
    {
        end = 88;
    }

    frame_limit = frame_count;
    if (frame_limit > 33u)
    {
        frame_limit = 33u;
    }

    best_index = base_index;
    best_error = 0xFFFFFFFFUL;
    for (i = start; i <= end; ++i)
    {
        error_sum = wavc89_imaadpcm_simulate_channel(src_interleaved, frame_count, channels, channel_index, i, frame_limit);
        if (error_sum < best_error)
        {
            best_error = error_sum;
            best_index = i;
        }
    }

    return best_index;
}

static wavc89_u16 wavc89_imaadpcm_block_bytes_for_frames(wavc89_u16 channels, wavc89_u32 frame_count, wavc89_u16 block_align, wavc89_u16 samples_per_block)
{
    wavc89_u32 block_bytes;
    wavc89_u32 word_groups;
    wavc89_u32 header_size;

    if (frame_count == 0u)
    {
        return 0u;
    }
    if (frame_count >= (wavc89_u32)samples_per_block)
    {
        return block_align;
    }

    header_size = (wavc89_u32)channels * 4u;
    word_groups = 0u;
    if (frame_count > 1u)
    {
        word_groups = ((frame_count - 1u) + 7u) / 8u;
    }
    block_bytes = header_size + (word_groups * 4u * (wavc89_u32)channels);
    if (block_bytes > (wavc89_u32)block_align)
    {
        block_bytes = (wavc89_u32)block_align;
    }
    return (wavc89_u16)block_bytes;
}

static wavc89_u8 wavc89_imaadpcm_encode_or_pad(wavc89_imaadpcm_state *st, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, wavc89_u32 frame_index)
{
    wavc89_s16 s;
    if (frame_index < frame_count)
    {
        s = wavc89_imaadpcm_channel_sample(src_interleaved, channels, frame_index, channel_index);
    }
    else
    {
        s = (wavc89_s16)st->predictor;
    }
    return wavc89_imaadpcm_encode_nibble(st, s);
}

static int wavc89_imaadpcm_write_mono_block(const wavc89_io *dst, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_bytes)
{
    wavc89_u8 header[4];
    wavc89_u8 word[4];
    wavc89_imaadpcm_state st;
    wavc89_u32 word_groups;
    wavc89_u32 g;
    wavc89_u32 frame_index;
    int rc;

    st.predictor = (wavc89_s32)src_interleaved[0];
    st.step_index = wavc89_imaadpcm_choose_initial_index(src_interleaved, frame_count, 1u, 0u);

    wavc89_store_le16(header + 0, (wavc89_u16)src_interleaved[0]);
    header[2] = (wavc89_u8)st.step_index;
    header[3] = 0u;

    rc = wavc89_write_exact(dst, header, 4u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (block_bytes < 4u)
    {
        return WAVC89_E_CORRUPT;
    }

    word_groups = ((wavc89_u32)block_bytes - 4u) / 4u;
    frame_index = 1u;
    for (g = 0u; g < word_groups; ++g)
    {
        wavc89_u32 i;
        for (i = 0u; i < 4u; ++i)
        {
            wavc89_u8 low;
            wavc89_u8 high;
            low = wavc89_imaadpcm_encode_or_pad(&st, src_interleaved, frame_count, 1u, 0u, frame_index);
            frame_index += 1u;
            high = wavc89_imaadpcm_encode_or_pad(&st, src_interleaved, frame_count, 1u, 0u, frame_index);
            frame_index += 1u;
            word[i] = (wavc89_u8)((low & 0x0Fu) | ((high & 0x0Fu) << 4));
        }
        rc = wavc89_write_exact(dst, word, 4u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}

static int wavc89_imaadpcm_write_stereo_block(const wavc89_io *dst, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_bytes)
{
    wavc89_u8 header[8];
    wavc89_u8 word_l[4];
    wavc89_u8 word_r[4];
    wavc89_imaadpcm_state st[2];
    wavc89_u32 word_groups;
    wavc89_u32 g;
    int rc;

    st[0].predictor = (wavc89_s32)src_interleaved[0];
    st[1].predictor = (wavc89_s32)src_interleaved[1];
    st[0].step_index = wavc89_imaadpcm_choose_initial_index(src_interleaved, frame_count, 2u, 0u);
    st[1].step_index = wavc89_imaadpcm_choose_initial_index(src_interleaved, frame_count, 2u, 1u);

    wavc89_store_le16(header + 0, (wavc89_u16)src_interleaved[0]);
    header[2] = (wavc89_u8)st[0].step_index;
    header[3] = 0u;
    wavc89_store_le16(header + 4, (wavc89_u16)src_interleaved[1]);
    header[6] = (wavc89_u8)st[1].step_index;
    header[7] = 0u;

    rc = wavc89_write_exact(dst, header, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (block_bytes < 8u)
    {
        return WAVC89_E_CORRUPT;
    }

    word_groups = ((wavc89_u32)block_bytes - 8u) / 8u;
    for (g = 0u; g < word_groups; ++g)
    {
        wavc89_u32 base_frame;
        wavc89_u32 i;

        base_frame = 1u + (g * 8u);
        for (i = 0u; i < 4u; ++i)
        {
            wavc89_u32 frame_a;
            wavc89_u32 frame_b;
            wavc89_u8 low_l;
            wavc89_u8 high_l;
            wavc89_u8 low_r;
            wavc89_u8 high_r;

            frame_a = base_frame + (i * 2u);
            frame_b = frame_a + 1u;

            low_l = wavc89_imaadpcm_encode_or_pad(&st[0], src_interleaved, frame_count, 2u, 0u, frame_a);
            high_l = wavc89_imaadpcm_encode_or_pad(&st[0], src_interleaved, frame_count, 2u, 0u, frame_b);
            low_r = wavc89_imaadpcm_encode_or_pad(&st[1], src_interleaved, frame_count, 2u, 1u, frame_a);
            high_r = wavc89_imaadpcm_encode_or_pad(&st[1], src_interleaved, frame_count, 2u, 1u, frame_b);

            word_l[i] = (wavc89_u8)((low_l & 0x0Fu) | ((high_l & 0x0Fu) << 4));
            word_r[i] = (wavc89_u8)((low_r & 0x0Fu) | ((high_r & 0x0Fu) << 4));
        }

        rc = wavc89_write_exact(dst, word_l, 4u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        rc = wavc89_write_exact(dst, word_r, 4u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}

static int wavc89_imaadpcm_write_raw_blocks(const wavc89_io *dst, wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, wavc89_u16 samples_per_block)
{
    wavc89_u32 frames_done;
    wavc89_u32 block_frames;
    const wavc89_s16 *block_src;
    wavc89_u16 block_bytes;
    int rc;

    if (dst == 0 || src_interleaved == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    frames_done = 0u;
    while (frames_done < frame_count)
    {
        block_frames = frame_count - frames_done;
        if (block_frames > (wavc89_u32)samples_per_block)
        {
            block_frames = (wavc89_u32)samples_per_block;
        }
        block_src = src_interleaved + ((wavc89_u32)channels * frames_done);
        block_bytes = wavc89_imaadpcm_block_bytes_for_frames(channels, block_frames, block_align, samples_per_block);

        if (channels == 1u)
        {
            rc = wavc89_imaadpcm_write_mono_block(dst, block_src, block_frames, block_bytes);
        }
        else
        {
            rc = wavc89_imaadpcm_write_stereo_block(dst, block_src, block_frames, block_bytes);
        }
        if (rc != WAVC89_OK)
        {
            return rc;
        }

        frames_done += block_frames;
    }

    return WAVC89_OK;
}

static int wavc89_imaadpcm_write_wav_header(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, wavc89_u16 block_align, wavc89_u16 samples_per_block, wavc89_u32 frame_count, wavc89_u32 data_size)
{
    wavc89_u8 header[12];
    wavc89_u8 fmt_head[8];
    wavc89_u8 fact_head[8];
    wavc89_u8 data_head[8];
    wavc89_u8 fmt_data[18];
    wavc89_u8 extra[2];
    wavc89_u8 fact_data[4];
    wavc89_u32 avg_bytes_per_sec;
    wavc89_u32 riff_size;
    int rc;

    avg_bytes_per_sec = 0u;
    if (samples_per_block != 0u)
    {
        avg_bytes_per_sec = (sample_rate * (wavc89_u32)block_align) / (wavc89_u32)samples_per_block;
    }

    riff_size = 4u + (8u + 20u) + (8u + 4u) + 8u + data_size + (data_size & 1u);

    memcpy(header + 0, "RIFF", 4u);
    wavc89_store_le32(header + 4, riff_size);
    memcpy(header + 8, "WAVE", 4u);

    memcpy(fmt_head + 0, "fmt ", 4u);
    wavc89_store_le32(fmt_head + 4, 20u);
    wavc89_store_le16(fmt_data + 0, WAVC89_FORMAT_IMA_ADPCM);
    wavc89_store_le16(fmt_data + 2, channels);
    wavc89_store_le32(fmt_data + 4, sample_rate);
    wavc89_store_le32(fmt_data + 8, avg_bytes_per_sec);
    wavc89_store_le16(fmt_data + 12, block_align);
    wavc89_store_le16(fmt_data + 14, 4u);
    wavc89_store_le16(fmt_data + 16, 2u);
    wavc89_store_le16(extra + 0, samples_per_block);

    memcpy(fact_head + 0, "fact", 4u);
    wavc89_store_le32(fact_head + 4, 4u);
    wavc89_store_le32(fact_data + 0, frame_count);

    memcpy(data_head + 0, "data", 4u);
    wavc89_store_le32(data_head + 4, data_size);

    rc = wavc89_write_exact(dst, header, 12u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fmt_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fmt_data, 18u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, extra, 2u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fact_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fact_data, 4u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, data_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    return WAVC89_OK;
}

int wavc89_imaadpcm_samples_per_block(wavc89_u16 channels, wavc89_u16 block_align, wavc89_u16 *out_samples_per_block)
{
    wavc89_u32 header_bytes;
    wavc89_u32 group_bytes;
    wavc89_u32 samples_per_block;

    if (out_samples_per_block == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (!(channels == 1u || channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }

    header_bytes = (wavc89_u32)channels * 4u;
    group_bytes = (wavc89_u32)channels * 4u;
    if ((wavc89_u32)block_align < header_bytes)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if ((((wavc89_u32)block_align - header_bytes) % group_bytes) != 0u)
    {
        return WAVC89_E_INVALID_ARG;
    }

    samples_per_block = 1u + ((((wavc89_u32)block_align - header_bytes) / group_bytes) * 8u);
    if (samples_per_block > 0xFFFFu)
    {
        return WAVC89_E_LIMIT;
    }

    *out_samples_per_block = (wavc89_u16)samples_per_block;
    return WAVC89_OK;
}

int wavc89_imaadpcm_block_align(wavc89_u16 channels, wavc89_u16 samples_per_block, wavc89_u16 *out_block_align)
{
    wavc89_u32 block_align;
    wavc89_u32 groups;

    if (out_block_align == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (!(channels == 1u || channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (samples_per_block == 0u)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (((samples_per_block - 1u) & 7u) != 0u)
    {
        return WAVC89_E_INVALID_ARG;
    }

    groups = ((wavc89_u32)samples_per_block - 1u) / 8u;
    block_align = ((wavc89_u32)channels * 4u) + (groups * (wavc89_u32)channels * 4u);
    if (block_align > 0xFFFFu)
    {
        return WAVC89_E_LIMIT;
    }

    *out_block_align = (wavc89_u16)block_align;
    return WAVC89_OK;
}

int wavc89_imaadpcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count)
{
    const wavc89_u8 *src;
    wavc89_u32 pos;
    wavc89_u32 out_pos;
    wavc89_u32 remaining_frames;
    wavc89_u32 block_size;
    wavc89_u32 header_size;
    wavc89_u32 group_bytes;
    wavc89_u32 group_count;
    wavc89_u32 frames_target;
    wavc89_u32 frames_written;
    wavc89_u32 g;
    wavc89_imaadpcm_state st[2];

    if (info == 0 || src_bytes == 0 || dst_samples == 0 || out_sample_count == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (info->format_tag != WAVC89_FORMAT_IMA_ADPCM)
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (!(info->channels == 1u || info->channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (info->bits_per_sample != 4u)
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (info->block_align == 0u)
    {
        return WAVC89_E_CORRUPT;
    }

    src = (const wavc89_u8 *)src_bytes;
    pos = 0u;
    out_pos = 0u;
    remaining_frames = info->has_fact ? info->fact_sample_length : 0xFFFFFFFFUL;
    header_size = (wavc89_u32)info->channels * 4u;
    group_bytes = (wavc89_u32)info->channels * 4u;

    while (pos < src_size && remaining_frames != 0u)
    {
        block_size = src_size - pos;
        if (block_size > (wavc89_u32)info->block_align)
        {
            block_size = (wavc89_u32)info->block_align;
        }
        if (block_size < header_size)
        {
            return WAVC89_E_CORRUPT;
        }
        if (((block_size - header_size) % group_bytes) != 0u)
        {
            return WAVC89_E_CORRUPT;
        }

        group_count = (block_size - header_size) / group_bytes;
        frames_target = 1u + (group_count * 8u);
        if (info->adpcm_samples_per_block != 0u && frames_target > (wavc89_u32)info->adpcm_samples_per_block)
        {
            frames_target = (wavc89_u32)info->adpcm_samples_per_block;
        }
        if (frames_target > remaining_frames)
        {
            frames_target = remaining_frames;
        }

        if (info->channels == 1u)
        {
            if (out_pos + frames_target > dst_sample_capacity)
            {
                return WAVC89_E_LIMIT;
            }

            st[0].predictor = (wavc89_s32)wavc89_les16(src + pos + 0u);
            st[0].step_index = wavc89_imaadpcm_clamp_index((int)src[pos + 2u]);

            frames_written = 0u;
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = (wavc89_s16)st[0].predictor;
                frames_written += 1u;
            }

            for (g = 0u; g < group_count && frames_written < frames_target; ++g)
            {
                wavc89_u32 byte_index;
                wavc89_u32 base;
                base = pos + 4u + (g * 4u);
                for (byte_index = 0u; byte_index < 4u && frames_written < frames_target; ++byte_index)
                {
                    wavc89_u8 b;
                    b = src[base + byte_index];
                    dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[0], (wavc89_u8)(b & 0x0Fu));
                    frames_written += 1u;
                    if (frames_written < frames_target)
                    {
                        dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[0], (wavc89_u8)(b >> 4));
                        frames_written += 1u;
                    }
                }
            }
        }
        else
        {
            if (out_pos + (frames_target * 2u) > dst_sample_capacity)
            {
                return WAVC89_E_LIMIT;
            }

            st[0].predictor = (wavc89_s32)wavc89_les16(src + pos + 0u);
            st[0].step_index = wavc89_imaadpcm_clamp_index((int)src[pos + 2u]);
            st[1].predictor = (wavc89_s32)wavc89_les16(src + pos + 4u);
            st[1].step_index = wavc89_imaadpcm_clamp_index((int)src[pos + 6u]);

            frames_written = 0u;
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = (wavc89_s16)st[0].predictor;
                dst_samples[out_pos++] = (wavc89_s16)st[1].predictor;
                frames_written += 1u;
            }

            for (g = 0u; g < group_count && frames_written < frames_target; ++g)
            {
                wavc89_u32 byte_index;
                wavc89_u32 base;
                base = pos + 8u + (g * 8u);
                for (byte_index = 0u; byte_index < 4u && frames_written < frames_target; ++byte_index)
                {
                    wavc89_u8 bl;
                    wavc89_u8 br;
                    bl = src[base + byte_index];
                    br = src[base + 4u + byte_index];
                    dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[0], (wavc89_u8)(bl & 0x0Fu));
                    dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[1], (wavc89_u8)(br & 0x0Fu));
                    frames_written += 1u;
                    if (frames_written < frames_target)
                    {
                        dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[0], (wavc89_u8)(bl >> 4));
                        dst_samples[out_pos++] = wavc89_imaadpcm_decode_nibble(&st[1], (wavc89_u8)(br >> 4));
                        frames_written += 1u;
                    }
                }
            }
        }

        remaining_frames -= frames_target;
        pos += block_size;
    }

    *out_sample_count = out_pos;
    return WAVC89_OK;
}

int wavc89_imaadpcm_encode_from_s16(wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size, wavc89_u16 *out_samples_per_block)
{
    wavc89_io io;
    wavc89_mem_writer mem;
    wavc89_u16 samples_per_block;
    int rc;

    if (src_interleaved == 0 || dst_bytes == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = wavc89_imaadpcm_samples_per_block(channels, block_align, &samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_io_mem_writer_init(&io, &mem, dst_bytes, dst_capacity);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_imaadpcm_write_raw_blocks(&io, channels, src_interleaved, frame_count, block_align, samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    *out_size = mem.size;
    if (out_samples_per_block != 0)
    {
        *out_samples_per_block = samples_per_block;
    }
    return WAVC89_OK;
}

int wavc89_writer_write_imaadpcm_from_s16(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align)
{
    wavc89_u16 samples_per_block;
    wavc89_u32 data_size;
    wavc89_u8 pad;
    int rc;

    if (dst == 0 || src_interleaved == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = wavc89_imaadpcm_samples_per_block(channels, block_align, &samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    data_size = 0u;
    if (frame_count != 0u)
    {
        wavc89_u32 full_blocks;
        wavc89_u32 tail_frames;
        wavc89_u16 tail_bytes;

        full_blocks = frame_count / (wavc89_u32)samples_per_block;
        tail_frames = frame_count % (wavc89_u32)samples_per_block;
        if (full_blocks != 0u && ((0xFFFFFFFFUL / full_blocks) < (wavc89_u32)block_align))
        {
            return WAVC89_E_OVERFLOW;
        }
        data_size = full_blocks * (wavc89_u32)block_align;
        if (tail_frames != 0u)
        {
            tail_bytes = wavc89_imaadpcm_block_bytes_for_frames(channels, tail_frames, block_align, samples_per_block);
            if (data_size > 0xFFFFFFFFUL - (wavc89_u32)tail_bytes)
            {
                return WAVC89_E_OVERFLOW;
            }
            data_size += (wavc89_u32)tail_bytes;
        }
    }

    rc = wavc89_imaadpcm_write_wav_header(dst, channels, sample_rate, block_align, samples_per_block, frame_count, data_size);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_imaadpcm_write_raw_blocks(dst, channels, src_interleaved, frame_count, block_align, samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if ((data_size & 1u) != 0u)
    {
        pad = 0u;
        rc = wavc89_write_exact(dst, &pad, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}
