#include "wavc89/wavc89.h"

static wavc89_s16 wavc89_clip_s16(long v)
{
    if (v > 32767L)
    {
        return (wavc89_s16)32767;
    }
    if (v < -32768L)
    {
        return (wavc89_s16)-32768;
    }
    return (wavc89_s16)v;
}

int wavc89_pcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count)
{
    const wavc89_u8 *src;
    wavc89_u32 sample_count;
    wavc89_u32 i;

    if (info == 0 || src_bytes == 0 || dst_samples == 0 || out_sample_count == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (info->format_tag != WAVC89_FORMAT_PCM)
    {
        return WAVC89_E_UNSUPPORTED;
    }

    if (info->bits_per_sample == 8u)
    {
        sample_count = src_size;
        if (sample_count > dst_sample_capacity)
        {
            return WAVC89_E_LIMIT;
        }
        src = (const wavc89_u8 *)src_bytes;
        for (i = 0; i < sample_count; ++i)
        {
            dst_samples[i] = (wavc89_s16)(((wavc89_s32)src[i] - 128) << 8);
        }
        *out_sample_count = sample_count;
        return WAVC89_OK;
    }

    if (info->bits_per_sample == 16u)
    {
        if ((src_size & 1u) != 0u)
        {
            return WAVC89_E_CORRUPT;
        }
        sample_count = src_size / 2u;
        if (sample_count > dst_sample_capacity)
        {
            return WAVC89_E_LIMIT;
        }
        src = (const wavc89_u8 *)src_bytes;
        for (i = 0; i < sample_count; ++i)
        {
            wavc89_u16 lo;
            wavc89_u16 hi;
            wavc89_u16 u;
            lo = src[(i * 2u) + 0u];
            hi = src[(i * 2u) + 1u];
            u = (wavc89_u16)(lo | (wavc89_u16)(hi << 8));
            dst_samples[i] = (wavc89_s16)u;
        }
        *out_sample_count = sample_count;
        return WAVC89_OK;
    }

    return WAVC89_E_UNSUPPORTED;
}

int wavc89_pcm_encode_from_s16(wavc89_u16 bits_per_sample, const wavc89_s16 *src_samples, wavc89_u32 sample_count, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size)
{
    wavc89_u8 *dst;
    wavc89_u32 need;
    wavc89_u32 i;

    if (src_samples == 0 || dst_bytes == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    if (bits_per_sample == 8u)
    {
        need = sample_count;
        if (need > dst_capacity)
        {
            return WAVC89_E_LIMIT;
        }
        dst = (wavc89_u8 *)dst_bytes;
        for (i = 0; i < sample_count; ++i)
        {
            long v;
            v = ((long)src_samples[i] >> 8) + 128L;
            if (v < 0L)
            {
                v = 0L;
            }
            if (v > 255L)
            {
                v = 255L;
            }
            dst[i] = (wavc89_u8)v;
        }
        *out_size = need;
        return WAVC89_OK;
    }

    if (bits_per_sample == 16u)
    {
        need = sample_count * 2u;
        if (need > dst_capacity)
        {
            return WAVC89_E_LIMIT;
        }
        dst = (wavc89_u8 *)dst_bytes;
        for (i = 0; i < sample_count; ++i)
        {
            wavc89_u16 u;
            u = (wavc89_u16)src_samples[i];
            dst[(i * 2u) + 0u] = (wavc89_u8)(u & 0xFFu);
            dst[(i * 2u) + 1u] = (wavc89_u8)((u >> 8) & 0xFFu);
        }
        *out_size = need;
        return WAVC89_OK;
    }

    return WAVC89_E_UNSUPPORTED;
}

void wavc89_pcm_apply_gain_q15(wavc89_s16 *samples, wavc89_u32 sample_count, wavc89_s32 gain_q15)
{
    wavc89_u32 i;
    long v;
    if (samples == 0)
    {
        return;
    }
    for (i = 0; i < sample_count; ++i)
    {
        v = (long)samples[i] * (long)gain_q15;
        v /= 32768L;
        samples[i] = wavc89_clip_s16(v);
    }
}

void wavc89_pcm_downmix_stereo_to_mono_q15(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_s16 *dst_mono, wavc89_s32 left_q15, wavc89_s32 right_q15)
{
    wavc89_u32 i;
    long l;
    long r;
    long mix;
    if (src_interleaved == 0 || dst_mono == 0)
    {
        return;
    }
    for (i = 0; i < frame_count; ++i)
    {
        l = (long)src_interleaved[i * 2u];
        r = (long)src_interleaved[i * 2u + 1u];
        mix = (l * (long)left_q15 + r * (long)right_q15) / 32768L;
        dst_mono[i] = wavc89_clip_s16(mix);
    }
}

int wavc89_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count)
{
    if (info == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (info->format_tag == WAVC89_FORMAT_PCM)
    {
        return wavc89_pcm_decode_to_s16(info, src_bytes, src_size, dst_samples, dst_sample_capacity, out_sample_count);
    }
    if (info->format_tag == WAVC89_FORMAT_MS_ADPCM)
    {
        return wavc89_msadpcm_decode_to_s16(info, src_bytes, src_size, dst_samples, dst_sample_capacity, out_sample_count);
    }
    if (info->format_tag == WAVC89_FORMAT_IMA_ADPCM)
    {
        return wavc89_imaadpcm_decode_to_s16(info, src_bytes, src_size, dst_samples, dst_sample_capacity, out_sample_count);
    }
    return WAVC89_E_UNSUPPORTED;
}
