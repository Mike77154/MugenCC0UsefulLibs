#include <string.h>
#include "wavc89/wavc89.h"

#define WAVC89_MSADPCM_MIN_DELTA 16L

static const wavc89_s16 wavc89_msadpcm_default_coef1[WAVC89_MSADPCM_COEF_COUNT] =
{
    256, 512, 0, 192, 240, 460, 392
};

static const wavc89_s16 wavc89_msadpcm_default_coef2[WAVC89_MSADPCM_COEF_COUNT] =
{
    0, -256, 0, 64, 0, -208, -232
};

static const wavc89_u16 wavc89_msadpcm_adapt_table[16] =
{
    230, 230, 230, 230, 307, 409, 512, 614,
    768, 614, 512, 409, 307, 230, 230, 230
};

typedef struct wavc89_msadpcm_state_t
{
    wavc89_s16 sample1;
    wavc89_s16 sample2;
    wavc89_s32 delta;
    wavc89_s16 coeff1;
    wavc89_s16 coeff2;
} wavc89_msadpcm_state;

static wavc89_s16 wavc89_clip_s16(long v)
{
    if (v > 32767L)
    {
        return (wavc89_s16)32767;
    }
    if (v < -32768L)
    {
        return (wavc89_s16)-32768;
    }
    return (wavc89_s16)v;
}

static wavc89_s32 wavc89_abs_s32(wavc89_s32 v)
{
    return (v < 0) ? -v : v;
}

static wavc89_u16 wavc89_le16(const wavc89_u8 *p)
{
    return (wavc89_u16)((wavc89_u16)p[0] | ((wavc89_u16)p[1] << 8));
}

static wavc89_s16 wavc89_les16(const wavc89_u8 *p)
{
    return (wavc89_s16)wavc89_le16(p);
}

static void wavc89_store_le16(wavc89_u8 *p, wavc89_u16 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
}

static void wavc89_store_le32(wavc89_u8 *p, wavc89_u32 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
    p[2] = (wavc89_u8)((v >> 16) & 0xFFu);
    p[3] = (wavc89_u8)((v >> 24) & 0xFFu);
}

static int wavc89_write_exact(const wavc89_io *io, const void *src, wavc89_u32 size)
{
    wavc89_u32 n;
    int rc;
    if (io == 0 || io->write == 0 || src == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    rc = io->write(io->user, src, size, &n);
    if (rc != WAVC89_OK && rc != WAVC89_E_SHORT_WRITE)
    {
        return rc;
    }
    return (n == size) ? WAVC89_OK : WAVC89_E_SHORT_WRITE;
}

static long wavc89_msadpcm_predict(const wavc89_msadpcm_state *st)
{
    long v;
    v = ((long)st->sample1 * (long)st->coeff1) + ((long)st->sample2 * (long)st->coeff2);
    return v / 256L;
}

static void wavc89_msadpcm_step_delta(wavc89_msadpcm_state *st, wavc89_u8 nibble)
{
    long d;
    d = ((long)wavc89_msadpcm_adapt_table[nibble & 0x0Fu] * (long)st->delta) / 256L;
    if (d < WAVC89_MSADPCM_MIN_DELTA)
    {
        d = WAVC89_MSADPCM_MIN_DELTA;
    }
    st->delta = (wavc89_s32)d;
}

static wavc89_s16 wavc89_msadpcm_decode_nibble(wavc89_msadpcm_state *st, wavc89_u8 nibble)
{
    long pred;
    long sample;
    long signed_nib;
    wavc89_s16 out;

    pred = wavc89_msadpcm_predict(st);
    signed_nib = (nibble < 8u) ? (long)nibble : ((long)nibble - 16L);
    sample = pred + (signed_nib * (long)st->delta);
    out = wavc89_clip_s16(sample);

    st->sample2 = st->sample1;
    st->sample1 = out;
    wavc89_msadpcm_step_delta(st, nibble);
    return out;
}

static wavc89_u8 wavc89_msadpcm_quantize_sample(wavc89_msadpcm_state *st, wavc89_s16 target)
{
    long pred;
    long diff;
    long mag;
    long q;
    long recon;
    wavc89_s16 out;
    wavc89_u8 nibble;

    pred = wavc89_msadpcm_predict(st);
    diff = (long)target - pred;

    if (diff >= 0L)
    {
        q = (diff + ((long)st->delta / 2L)) / (long)st->delta;
    }
    else
    {
        mag = -diff;
        q = -((mag + ((long)st->delta / 2L)) / (long)st->delta);
    }

    if (q > 7L)
    {
        q = 7L;
    }
    if (q < -8L)
    {
        q = -8L;
    }

    nibble = (wavc89_u8)(q & 0x0Fu);
    recon = pred + (q * (long)st->delta);
    out = wavc89_clip_s16(recon);

    st->sample2 = st->sample1;
    st->sample1 = out;
    wavc89_msadpcm_step_delta(st, nibble);
    return nibble;
}

static void wavc89_msadpcm_seed_channel(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, wavc89_s16 *out_sample1, wavc89_s16 *out_sample2)
{
    wavc89_s16 s2;
    wavc89_s16 s1;

    s2 = 0;
    s1 = 0;
    if (frame_count != 0u)
    {
        s2 = src_interleaved[channel_index];
        s1 = s2;
    }
    if (frame_count > 1u)
    {
        s1 = src_interleaved[(wavc89_u32)channels + channel_index];
    }

    *out_sample1 = s1;
    *out_sample2 = s2;
}

static wavc89_s32 wavc89_msadpcm_initial_delta(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, wavc89_s16 coeff1, wavc89_s16 coeff2)
{
    wavc89_s16 sample1;
    wavc89_s16 sample2;
    wavc89_s32 delta;
    long pred;
    wavc89_s32 err;

    wavc89_msadpcm_seed_channel(src_interleaved, frame_count, channels, channel_index, &sample1, &sample2);
    delta = wavc89_abs_s32((wavc89_s32)sample1 - (wavc89_s32)sample2);
    if (frame_count > 2u)
    {
        pred = (((long)sample1 * (long)coeff1) + ((long)sample2 * (long)coeff2)) / 256L;
        err = wavc89_abs_s32((wavc89_s32)src_interleaved[((wavc89_u32)channels * 2u) + channel_index] - (wavc89_s32)pred);
        if (err > delta)
        {
            delta = err;
        }
    }
    if (delta < WAVC89_MSADPCM_MIN_DELTA)
    {
        delta = WAVC89_MSADPCM_MIN_DELTA;
    }
    return delta;
}

static wavc89_u32 wavc89_msadpcm_simulate_channel(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, wavc89_s16 coeff1, wavc89_s16 coeff2, wavc89_s32 delta)
{
    wavc89_msadpcm_state st;
    wavc89_u32 frame;
    wavc89_u32 error_sum;
    wavc89_u8 nibble;
    wavc89_s16 recon;
    wavc89_s32 diff;

    wavc89_msadpcm_seed_channel(src_interleaved, frame_count, channels, channel_index, &st.sample1, &st.sample2);
    st.delta = delta;
    st.coeff1 = coeff1;
    st.coeff2 = coeff2;
    error_sum = 0u;

    for (frame = 2u; frame < frame_count; ++frame)
    {
        nibble = wavc89_msadpcm_quantize_sample(&st, src_interleaved[((wavc89_u32)channels * frame) + channel_index]);
        (void)nibble;
        recon = st.sample1;
        diff = (wavc89_s32)src_interleaved[((wavc89_u32)channels * frame) + channel_index] - (wavc89_s32)recon;
        error_sum += (wavc89_u32)wavc89_abs_s32(diff);
    }

    return error_sum;
}

static void wavc89_msadpcm_choose_predictor(const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 channels, wavc89_u16 channel_index, wavc89_u8 *out_predictor, wavc89_s32 *out_delta)
{
    wavc89_u32 i;
    wavc89_u32 best_error;
    wavc89_u8 best_predictor;
    wavc89_s32 best_delta;
    wavc89_s32 delta;
    wavc89_u32 error_sum;

    best_error = 0xFFFFFFFFUL;
    best_predictor = 0u;
    best_delta = WAVC89_MSADPCM_MIN_DELTA;

    for (i = 0u; i < WAVC89_MSADPCM_COEF_COUNT; ++i)
    {
        delta = wavc89_msadpcm_initial_delta(src_interleaved, frame_count, channels, channel_index, wavc89_msadpcm_default_coef1[i], wavc89_msadpcm_default_coef2[i]);
        error_sum = wavc89_msadpcm_simulate_channel(src_interleaved, frame_count, channels, channel_index, wavc89_msadpcm_default_coef1[i], wavc89_msadpcm_default_coef2[i], delta);
        if (error_sum < best_error)
        {
            best_error = error_sum;
            best_predictor = (wavc89_u8)i;
            best_delta = delta;
        }
    }

    *out_predictor = best_predictor;
    *out_delta = best_delta;
}

static wavc89_u16 wavc89_msadpcm_block_bytes_for_frames(wavc89_u16 channels, wavc89_u32 frame_count, wavc89_u16 block_align, wavc89_u16 samples_per_block)
{
    wavc89_u32 block_bytes;

    if (frame_count == 0u)
    {
        return 0u;
    }
    if (frame_count >= (wavc89_u32)samples_per_block)
    {
        return block_align;
    }

    if (channels == 1u)
    {
        block_bytes = 7u;
        if (frame_count > 2u)
        {
            block_bytes += ((frame_count - 2u) + 1u) / 2u;
        }
    }
    else
    {
        block_bytes = 14u;
        if (frame_count > 2u)
        {
            block_bytes += (frame_count - 2u);
        }
    }

    if (block_bytes > (wavc89_u32)block_align)
    {
        block_bytes = (wavc89_u32)block_align;
    }

    return (wavc89_u16)block_bytes;
}

static int wavc89_msadpcm_write_mono_block(const wavc89_io *dst, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_bytes)
{
    wavc89_u8 header[7];
    wavc89_u8 predictor;
    wavc89_s32 delta;
    wavc89_s16 sample1;
    wavc89_s16 sample2;
    wavc89_msadpcm_state st;
    wavc89_u32 bytes_after_header;
    wavc89_u32 frame_index;
    wavc89_u8 b;
    int rc;

    wavc89_msadpcm_seed_channel(src_interleaved, frame_count, 1u, 0u, &sample1, &sample2);
    wavc89_msadpcm_choose_predictor(src_interleaved, frame_count, 1u, 0u, &predictor, &delta);

    st.sample1 = sample1;
    st.sample2 = sample2;
    st.delta = delta;
    st.coeff1 = wavc89_msadpcm_default_coef1[predictor];
    st.coeff2 = wavc89_msadpcm_default_coef2[predictor];

    header[0] = predictor;
    wavc89_store_le16(header + 1, (wavc89_u16)delta);
    wavc89_store_le16(header + 3, (wavc89_u16)sample1);
    wavc89_store_le16(header + 5, (wavc89_u16)sample2);

    rc = wavc89_write_exact(dst, header, 7u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    bytes_after_header = (wavc89_u32)block_bytes - 7u;
    frame_index = 2u;
    while (bytes_after_header != 0u)
    {
        wavc89_u8 hi;
        wavc89_u8 lo;

        hi = 0u;
        lo = 0u;
        if (frame_index < frame_count)
        {
            hi = wavc89_msadpcm_quantize_sample(&st, src_interleaved[frame_index]);
            frame_index += 1u;
        }
        if (frame_index < frame_count)
        {
            lo = wavc89_msadpcm_quantize_sample(&st, src_interleaved[frame_index]);
            frame_index += 1u;
        }
        b = (wavc89_u8)((hi << 4) | (lo & 0x0Fu));
        rc = wavc89_write_exact(dst, &b, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        bytes_after_header -= 1u;
    }

    return WAVC89_OK;
}

static int wavc89_msadpcm_write_stereo_block(const wavc89_io *dst, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_bytes)
{
    wavc89_u8 header[14];
    wavc89_u8 predictor[2];
    wavc89_s32 delta[2];
    wavc89_s16 sample1[2];
    wavc89_s16 sample2[2];
    wavc89_msadpcm_state st[2];
    wavc89_u32 bytes_after_header;
    wavc89_u32 frame_index;
    wavc89_u8 b;
    int rc;

    wavc89_msadpcm_seed_channel(src_interleaved, frame_count, 2u, 0u, &sample1[0], &sample2[0]);
    wavc89_msadpcm_seed_channel(src_interleaved, frame_count, 2u, 1u, &sample1[1], &sample2[1]);
    wavc89_msadpcm_choose_predictor(src_interleaved, frame_count, 2u, 0u, &predictor[0], &delta[0]);
    wavc89_msadpcm_choose_predictor(src_interleaved, frame_count, 2u, 1u, &predictor[1], &delta[1]);

    st[0].sample1 = sample1[0];
    st[0].sample2 = sample2[0];
    st[0].delta = delta[0];
    st[0].coeff1 = wavc89_msadpcm_default_coef1[predictor[0]];
    st[0].coeff2 = wavc89_msadpcm_default_coef2[predictor[0]];

    st[1].sample1 = sample1[1];
    st[1].sample2 = sample2[1];
    st[1].delta = delta[1];
    st[1].coeff1 = wavc89_msadpcm_default_coef1[predictor[1]];
    st[1].coeff2 = wavc89_msadpcm_default_coef2[predictor[1]];

    header[0] = predictor[0];
    header[1] = predictor[1];
    wavc89_store_le16(header + 2, (wavc89_u16)delta[0]);
    wavc89_store_le16(header + 4, (wavc89_u16)delta[1]);
    wavc89_store_le16(header + 6, (wavc89_u16)sample1[0]);
    wavc89_store_le16(header + 8, (wavc89_u16)sample1[1]);
    wavc89_store_le16(header + 10, (wavc89_u16)sample2[0]);
    wavc89_store_le16(header + 12, (wavc89_u16)sample2[1]);

    rc = wavc89_write_exact(dst, header, 14u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    bytes_after_header = (wavc89_u32)block_bytes - 14u;
    frame_index = 2u;
    while (bytes_after_header != 0u)
    {
        wavc89_u8 hi;
        wavc89_u8 lo;

        hi = 0u;
        lo = 0u;
        if (frame_index < frame_count)
        {
            hi = wavc89_msadpcm_quantize_sample(&st[0], src_interleaved[(frame_index * 2u) + 0u]);
            lo = wavc89_msadpcm_quantize_sample(&st[1], src_interleaved[(frame_index * 2u) + 1u]);
            frame_index += 1u;
        }
        b = (wavc89_u8)((hi << 4) | (lo & 0x0Fu));
        rc = wavc89_write_exact(dst, &b, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        bytes_after_header -= 1u;
    }

    return WAVC89_OK;
}

static int wavc89_msadpcm_write_raw_blocks(const wavc89_io *dst, wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, wavc89_u16 samples_per_block)
{
    wavc89_u32 frames_done;
    wavc89_u32 block_frames;
    const wavc89_s16 *block_src;
    wavc89_u16 block_bytes;
    int rc;

    if (dst == 0 || src_interleaved == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    frames_done = 0u;
    while (frames_done < frame_count)
    {
        block_frames = frame_count - frames_done;
        if (block_frames > (wavc89_u32)samples_per_block)
        {
            block_frames = (wavc89_u32)samples_per_block;
        }
        block_src = src_interleaved + ((wavc89_u32)channels * frames_done);
        block_bytes = wavc89_msadpcm_block_bytes_for_frames(channels, block_frames, block_align, samples_per_block);

        if (channels == 1u)
        {
            rc = wavc89_msadpcm_write_mono_block(dst, block_src, block_frames, block_bytes);
        }
        else
        {
            rc = wavc89_msadpcm_write_stereo_block(dst, block_src, block_frames, block_bytes);
        }
        if (rc != WAVC89_OK)
        {
            return rc;
        }

        frames_done += block_frames;
    }

    return WAVC89_OK;
}

static int wavc89_msadpcm_write_wav_header(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, wavc89_u16 block_align, wavc89_u16 samples_per_block, wavc89_u32 frame_count, wavc89_u32 data_size)
{
    wavc89_u8 header[12];
    wavc89_u8 fmt_head[8];
    wavc89_u8 fact_head[8];
    wavc89_u8 data_head[8];
    wavc89_u8 fmt_data[18];
    wavc89_u8 extra[32];
    wavc89_u8 fact_data[4];
    wavc89_u32 avg_bytes_per_sec;
    wavc89_u32 riff_size;
    wavc89_u32 i;
    int rc;

    avg_bytes_per_sec = 0u;
    if (samples_per_block != 0u)
    {
        avg_bytes_per_sec = (sample_rate * (wavc89_u32)block_align) / (wavc89_u32)samples_per_block;
    }

    riff_size = 4u + (8u + 50u) + (8u + 4u) + 8u + data_size + (data_size & 1u);

    memcpy(header + 0, "RIFF", 4u);
    wavc89_store_le32(header + 4, riff_size);
    memcpy(header + 8, "WAVE", 4u);

    memcpy(fmt_head + 0, "fmt ", 4u);
    wavc89_store_le32(fmt_head + 4, 50u);
    wavc89_store_le16(fmt_data + 0, WAVC89_FORMAT_ADPCM);
    wavc89_store_le16(fmt_data + 2, channels);
    wavc89_store_le32(fmt_data + 4, sample_rate);
    wavc89_store_le32(fmt_data + 8, avg_bytes_per_sec);
    wavc89_store_le16(fmt_data + 12, block_align);
    wavc89_store_le16(fmt_data + 14, 4u);
    wavc89_store_le16(fmt_data + 16, 32u);

    wavc89_store_le16(extra + 0, samples_per_block);
    wavc89_store_le16(extra + 2, WAVC89_MSADPCM_COEF_COUNT);
    for (i = 0u; i < WAVC89_MSADPCM_COEF_COUNT; ++i)
    {
        wavc89_store_le16(extra + 4u + (i * 4u), (wavc89_u16)wavc89_msadpcm_default_coef1[i]);
        wavc89_store_le16(extra + 6u + (i * 4u), (wavc89_u16)wavc89_msadpcm_default_coef2[i]);
    }

    memcpy(fact_head + 0, "fact", 4u);
    wavc89_store_le32(fact_head + 4, 4u);
    wavc89_store_le32(fact_data + 0, frame_count);

    memcpy(data_head + 0, "data", 4u);
    wavc89_store_le32(data_head + 4, data_size);

    rc = wavc89_write_exact(dst, header, 12u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fmt_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fmt_data, 18u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, extra, 32u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fact_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fact_data, 4u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, data_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }


    return WAVC89_OK;
}

int wavc89_msadpcm_samples_per_block(wavc89_u16 channels, wavc89_u16 block_align, wavc89_u16 *out_samples_per_block)
{
    wavc89_u32 header_bytes;
    wavc89_u32 samples_per_block;

    if (out_samples_per_block == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (!(channels == 1u || channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }

    header_bytes = (wavc89_u32)channels * 7u;
    if ((wavc89_u32)block_align <= header_bytes)
    {
        return WAVC89_E_INVALID_ARG;
    }

    samples_per_block = 2u + ((((wavc89_u32)block_align - header_bytes) * 2u) / (wavc89_u32)channels);
    if (samples_per_block > 0xFFFFu)
    {
        return WAVC89_E_LIMIT;
    }

    *out_samples_per_block = (wavc89_u16)samples_per_block;
    return WAVC89_OK;
}

int wavc89_msadpcm_block_align(wavc89_u16 channels, wavc89_u16 samples_per_block, wavc89_u16 *out_block_align)
{
    wavc89_u32 block_align;

    if (out_block_align == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (!(channels == 1u || channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (samples_per_block < 2u)
    {
        return WAVC89_E_INVALID_ARG;
    }

    block_align = ((wavc89_u32)channels * 7u) + ((((wavc89_u32)samples_per_block - 2u) * (wavc89_u32)channels + 1u) / 2u);
    if (block_align > 0xFFFFu)
    {
        return WAVC89_E_LIMIT;
    }

    *out_block_align = (wavc89_u16)block_align;
    return WAVC89_OK;
}

int wavc89_msadpcm_decode_to_s16(const wavc89_info *info, const void *src_bytes, wavc89_u32 src_size, wavc89_s16 *dst_samples, wavc89_u32 dst_sample_capacity, wavc89_u32 *out_sample_count)
{
    const wavc89_u8 *src;
    wavc89_u32 pos;
    wavc89_u32 out_pos;
    wavc89_u32 block_size;
    wavc89_u32 remaining_frames;
    wavc89_u32 frames_target;
    wavc89_u32 frames_written;
    wavc89_u32 bytes_after_header;
    wavc89_u8 predictor;
    wavc89_msadpcm_state st[2];
    wavc89_u32 min_block;

    if (info == 0 || src_bytes == 0 || dst_samples == 0 || out_sample_count == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    if (info->format_tag != WAVC89_FORMAT_ADPCM)
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (!(info->channels == 1u || info->channels == 2u))
    {
        return WAVC89_E_UNSUPPORTED;
    }
    if (info->adpcm_num_coef == 0u)
    {
        return WAVC89_E_CORRUPT;
    }
    if (info->block_align == 0u)
    {
        return WAVC89_E_CORRUPT;
    }

    src = (const wavc89_u8 *)src_bytes;
    pos = 0u;
    out_pos = 0u;
    remaining_frames = info->has_fact ? info->fact_sample_length : 0xFFFFFFFFUL;
    min_block = (info->channels == 1u) ? 7u : 14u;

    while (pos < src_size && remaining_frames != 0u)
    {
        block_size = src_size - pos;
        if (block_size > (wavc89_u32)info->block_align)
        {
            block_size = (wavc89_u32)info->block_align;
        }
        if (block_size < min_block)
        {
            return WAVC89_E_CORRUPT;
        }

        if (info->channels == 1u)
        {
            frames_target = 2u + ((block_size - 7u) * 2u);
            if (info->adpcm_samples_per_block != 0u && frames_target > (wavc89_u32)info->adpcm_samples_per_block)
            {
                frames_target = (wavc89_u32)info->adpcm_samples_per_block;
            }
            if (frames_target > remaining_frames)
            {
                frames_target = remaining_frames;
            }
            if (out_pos + frames_target > dst_sample_capacity)
            {
                return WAVC89_E_LIMIT;
            }

            predictor = src[pos + 0u];
            if ((wavc89_u32)predictor >= (wavc89_u32)info->adpcm_num_coef)
            {
                return WAVC89_E_CORRUPT;
            }
            st[0].delta = (wavc89_s32)wavc89_le16(src + pos + 1u);
            if (st[0].delta < WAVC89_MSADPCM_MIN_DELTA)
            {
                st[0].delta = WAVC89_MSADPCM_MIN_DELTA;
            }
            st[0].sample1 = wavc89_les16(src + pos + 3u);
            st[0].sample2 = wavc89_les16(src + pos + 5u);
            st[0].coeff1 = info->adpcm_coef1[predictor];
            st[0].coeff2 = info->adpcm_coef2[predictor];

            frames_written = 0u;
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = st[0].sample2;
                frames_written += 1u;
            }
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = st[0].sample1;
                frames_written += 1u;
            }

            bytes_after_header = block_size - 7u;
            while (bytes_after_header != 0u && frames_written < frames_target)
            {
                wavc89_u8 b;
                b = src[pos + 7u + ((block_size - 7u) - bytes_after_header)];
                dst_samples[out_pos++] = wavc89_msadpcm_decode_nibble(&st[0], (wavc89_u8)(b >> 4));
                frames_written += 1u;
                if (frames_written < frames_target)
                {
                    dst_samples[out_pos++] = wavc89_msadpcm_decode_nibble(&st[0], (wavc89_u8)(b & 0x0Fu));
                    frames_written += 1u;
                }
                bytes_after_header -= 1u;
            }

            remaining_frames -= frames_target;
        }
        else
        {
            frames_target = 2u + (block_size - 14u);
            if (info->adpcm_samples_per_block != 0u && frames_target > (wavc89_u32)info->adpcm_samples_per_block)
            {
                frames_target = (wavc89_u32)info->adpcm_samples_per_block;
            }
            if (frames_target > remaining_frames)
            {
                frames_target = remaining_frames;
            }
            if (out_pos + (frames_target * 2u) > dst_sample_capacity)
            {
                return WAVC89_E_LIMIT;
            }

            predictor = src[pos + 0u];
            if ((wavc89_u32)predictor >= (wavc89_u32)info->adpcm_num_coef)
            {
                return WAVC89_E_CORRUPT;
            }
            st[0].delta = (wavc89_s32)wavc89_le16(src + pos + 2u);
            if (st[0].delta < WAVC89_MSADPCM_MIN_DELTA)
            {
                st[0].delta = WAVC89_MSADPCM_MIN_DELTA;
            }
            st[0].sample1 = wavc89_les16(src + pos + 6u);
            st[0].sample2 = wavc89_les16(src + pos + 10u);
            st[0].coeff1 = info->adpcm_coef1[predictor];
            st[0].coeff2 = info->adpcm_coef2[predictor];

            predictor = src[pos + 1u];
            if ((wavc89_u32)predictor >= (wavc89_u32)info->adpcm_num_coef)
            {
                return WAVC89_E_CORRUPT;
            }
            st[1].delta = (wavc89_s32)wavc89_le16(src + pos + 4u);
            if (st[1].delta < WAVC89_MSADPCM_MIN_DELTA)
            {
                st[1].delta = WAVC89_MSADPCM_MIN_DELTA;
            }
            st[1].sample1 = wavc89_les16(src + pos + 8u);
            st[1].sample2 = wavc89_les16(src + pos + 12u);
            st[1].coeff1 = info->adpcm_coef1[predictor];
            st[1].coeff2 = info->adpcm_coef2[predictor];

            frames_written = 0u;
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = st[0].sample2;
                dst_samples[out_pos++] = st[1].sample2;
                frames_written += 1u;
            }
            if (frames_written < frames_target)
            {
                dst_samples[out_pos++] = st[0].sample1;
                dst_samples[out_pos++] = st[1].sample1;
                frames_written += 1u;
            }

            bytes_after_header = block_size - 14u;
            while (bytes_after_header != 0u && frames_written < frames_target)
            {
                wavc89_u8 b;
                b = src[pos + 14u + ((block_size - 14u) - bytes_after_header)];
                dst_samples[out_pos++] = wavc89_msadpcm_decode_nibble(&st[0], (wavc89_u8)(b >> 4));
                dst_samples[out_pos++] = wavc89_msadpcm_decode_nibble(&st[1], (wavc89_u8)(b & 0x0Fu));
                frames_written += 1u;
                bytes_after_header -= 1u;
            }

            remaining_frames -= frames_target;
        }

        pos += block_size;
    }

    *out_sample_count = out_pos;
    return WAVC89_OK;
}

int wavc89_msadpcm_encode_from_s16(wavc89_u16 channels, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align, void *dst_bytes, wavc89_u32 dst_capacity, wavc89_u32 *out_size, wavc89_u16 *out_samples_per_block)
{
    wavc89_io io;
    wavc89_mem_writer mem;
    wavc89_u16 samples_per_block;
    int rc;

    if (src_interleaved == 0 || dst_bytes == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = wavc89_msadpcm_samples_per_block(channels, block_align, &samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_io_mem_writer_init(&io, &mem, dst_bytes, dst_capacity);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_msadpcm_write_raw_blocks(&io, channels, src_interleaved, frame_count, block_align, samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    *out_size = mem.size;
    if (out_samples_per_block != 0)
    {
        *out_samples_per_block = samples_per_block;
    }
    return WAVC89_OK;
}

int wavc89_writer_write_msadpcm_from_s16(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, const wavc89_s16 *src_interleaved, wavc89_u32 frame_count, wavc89_u16 block_align)
{
    wavc89_u16 samples_per_block;
    wavc89_u32 data_size;
    wavc89_u8 pad;
    int rc;

    if (dst == 0 || src_interleaved == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = wavc89_msadpcm_samples_per_block(channels, block_align, &samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    data_size = 0u;
    if (frame_count != 0u)
    {
        wavc89_u32 full_blocks;
        wavc89_u32 tail_frames;
        wavc89_u16 tail_bytes;

        full_blocks = frame_count / (wavc89_u32)samples_per_block;
        tail_frames = frame_count % (wavc89_u32)samples_per_block;
        if (full_blocks != 0u && ((0xFFFFFFFFUL / full_blocks) < (wavc89_u32)block_align))
        {
            return WAVC89_E_OVERFLOW;
        }
        data_size = full_blocks * (wavc89_u32)block_align;
        if (tail_frames != 0u)
        {
            tail_bytes = wavc89_msadpcm_block_bytes_for_frames(channels, tail_frames, block_align, samples_per_block);
            if (data_size > 0xFFFFFFFFUL - (wavc89_u32)tail_bytes)
            {
                return WAVC89_E_OVERFLOW;
            }
            data_size += (wavc89_u32)tail_bytes;
        }
    }

    rc = wavc89_msadpcm_write_wav_header(dst, channels, sample_rate, block_align, samples_per_block, frame_count, data_size);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_msadpcm_write_raw_blocks(dst, channels, src_interleaved, frame_count, block_align, samples_per_block);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if ((data_size & 1u) != 0u)
    {
        pad = 0u;
        rc = wavc89_write_exact(dst, &pad, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}
