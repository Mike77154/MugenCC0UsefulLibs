#include <string.h>
#include "wavc89/wavc89.h"

static void wavc89_store_le16(wavc89_u8 *p, wavc89_u16 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
}

static void wavc89_store_le32(wavc89_u8 *p, wavc89_u32 v)
{
    p[0] = (wavc89_u8)(v & 0xFFu);
    p[1] = (wavc89_u8)((v >> 8) & 0xFFu);
    p[2] = (wavc89_u8)((v >> 16) & 0xFFu);
    p[3] = (wavc89_u8)((v >> 24) & 0xFFu);
}

static int wavc89_write_exact(const wavc89_io *io, const void *src, wavc89_u32 size)
{
    wavc89_u32 n;
    int rc;
    if (io == 0 || io->write == 0 || src == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    rc = io->write(io->user, src, size, &n);
    if (rc != WAVC89_OK && rc != WAVC89_E_SHORT_WRITE)
    {
        return rc;
    }
    return (n == size) ? WAVC89_OK : WAVC89_E_SHORT_WRITE;
}

static int wavc89_copy_exact(const wavc89_io *src, wavc89_u32 src_offset, const wavc89_io *dst, wavc89_u32 size)
{
    wavc89_u8 buf[256];
    wavc89_u32 remain;
    wavc89_u32 take;
    wavc89_u32 nread;
    wavc89_u32 nwritten;
    int rc;

    if (src == 0 || dst == 0 || src->read == 0 || src->seek == 0 || dst->write == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    rc = src->seek(src->user, src_offset);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    remain = size;
    while (remain != 0)
    {
        take = (remain > (wavc89_u32)sizeof(buf)) ? (wavc89_u32)sizeof(buf) : remain;
        rc = src->read(src->user, buf, take, &nread);
        if ((rc != WAVC89_OK && rc != WAVC89_E_SHORT_READ) || nread != take)
        {
            return WAVC89_E_SHORT_READ;
        }
        rc = dst->write(dst->user, buf, take, &nwritten);
        if ((rc != WAVC89_OK && rc != WAVC89_E_SHORT_WRITE) || nwritten != take)
        {
            return WAVC89_E_SHORT_WRITE;
        }
        remain -= take;
    }
    return WAVC89_OK;
}

int wavc89_writer_write_from_io(const wavc89_io *dst, const wavc89_writer_format *fmt, const wavc89_io *data_io, wavc89_u32 data_offset, wavc89_u32 data_size)
{
    wavc89_u8 header[12];
    wavc89_u8 fmt_head[8];
    wavc89_u8 fact_head[8];
    wavc89_u8 data_head[8];
    wavc89_u8 fmt_data[18];
    wavc89_u8 fact_data[4];
    wavc89_u8 pad;
    wavc89_u32 fmt_chunk_size;
    wavc89_u32 fact_chunk_size;
    wavc89_u32 total_riff_size;
    int rc;

    if (dst == 0 || fmt == 0 || data_io == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    fmt_chunk_size = 16u + ((fmt->format_tag == WAVC89_FORMAT_PCM) ? 0u : (2u + (wavc89_u32)fmt->extra_format_size));
    fact_chunk_size = fmt->write_fact ? 4u : 0u;

    if (fmt->format_tag == WAVC89_FORMAT_PCM)
    {
        if (!(fmt->bits_per_sample == 8u || fmt->bits_per_sample == 16u))
        {
            return WAVC89_E_UNSUPPORTED;
        }
    }

    total_riff_size = 4u + (8u + fmt_chunk_size) + (fmt_chunk_size & 1u)
                    + (fmt->write_fact ? (8u + fact_chunk_size + (fact_chunk_size & 1u)) : 0u)
                    + 8u + data_size + (data_size & 1u);

    memcpy(header + 0, "RIFF", 4u);
    wavc89_store_le32(header + 4, total_riff_size);
    memcpy(header + 8, "WAVE", 4u);

    memcpy(fmt_head + 0, "fmt ", 4u);
    wavc89_store_le32(fmt_head + 4, fmt_chunk_size);

    wavc89_store_le16(fmt_data + 0, fmt->format_tag);
    wavc89_store_le16(fmt_data + 2, fmt->channels);
    wavc89_store_le32(fmt_data + 4, fmt->sample_rate);
    wavc89_store_le32(fmt_data + 8, fmt->avg_bytes_per_sec);
    wavc89_store_le16(fmt_data + 12, fmt->block_align);
    wavc89_store_le16(fmt_data + 14, fmt->bits_per_sample);
    wavc89_store_le16(fmt_data + 16, (fmt->format_tag == WAVC89_FORMAT_PCM) ? 0u : fmt->extra_format_size);

    rc = wavc89_write_exact(dst, header, 12u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_write_exact(dst, fmt_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    rc = wavc89_write_exact(dst, fmt_data, (fmt->format_tag == WAVC89_FORMAT_PCM) ? 16u : 18u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }
    if (fmt->format_tag != WAVC89_FORMAT_PCM && fmt->extra_format_size != 0u)
    {
        rc = wavc89_write_exact(dst, fmt->extra_format, fmt->extra_format_size);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }
    if (fmt_chunk_size & 1u)
    {
        pad = 0u;
        rc = wavc89_write_exact(dst, &pad, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    if (fmt->write_fact)
    {
        memcpy(fact_head + 0, "fact", 4u);
        wavc89_store_le32(fact_head + 4, fact_chunk_size);
        wavc89_store_le32(fact_data + 0, fmt->fact_sample_length);
        rc = wavc89_write_exact(dst, fact_head, 8u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        rc = wavc89_write_exact(dst, fact_data, 4u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        if (fact_chunk_size & 1u)
        {
            pad = 0u;
            rc = wavc89_write_exact(dst, &pad, 1u);
            if (rc != WAVC89_OK)
            {
                return rc;
            }
        }
    }

    memcpy(data_head + 0, "data", 4u);
    wavc89_store_le32(data_head + 4, data_size);
    rc = wavc89_write_exact(dst, data_head, 8u);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    rc = wavc89_copy_exact(data_io, data_offset, dst, data_size);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (data_size & 1u)
    {
        pad = 0u;
        rc = wavc89_write_exact(dst, &pad, 1u);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
    }

    return WAVC89_OK;
}

int wavc89_writer_write_pcm_from_memory(const wavc89_io *dst, wavc89_u16 channels, wavc89_u32 sample_rate, wavc89_u16 bits_per_sample, const void *pcm_data, wavc89_u32 pcm_size)
{
    wavc89_writer_format fmt;
    wavc89_io data_io;
    wavc89_mem_reader ctx;
    int rc;

    if (dst == 0 || pcm_data == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    memset(&fmt, 0, sizeof(fmt));
    fmt.format_tag = WAVC89_FORMAT_PCM;
    fmt.channels = channels;
    fmt.sample_rate = sample_rate;
    fmt.bits_per_sample = bits_per_sample;
    fmt.block_align = (wavc89_u16)((channels * bits_per_sample) / 8u);
    fmt.avg_bytes_per_sec = sample_rate * (wavc89_u32)fmt.block_align;
    fmt.extra_format = 0;
    fmt.extra_format_size = 0;
    fmt.write_fact = 0;
    fmt.fact_sample_length = 0u;

    rc = wavc89_io_mem_reader_init(&data_io, &ctx, pcm_data, pcm_size);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    return wavc89_writer_write_from_io(dst, &fmt, &data_io, 0u, pcm_size);
}
