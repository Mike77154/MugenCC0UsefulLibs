#include "wavc89/wavc89_fixed.h"

wavc89_s32 wavc89_q15_mul(wavc89_s32 a, wavc89_s32 b)
{
    long v;
    v = (long)a * (long)b;
    return (wavc89_s32)(v / 32768L);
}

wavc89_s32 wavc89_q15_from_ratio(wavc89_s32 num, wavc89_s32 den)
{
    if (den == 0)
    {
        return 0;
    }
    return (wavc89_s32)(((long)num * 32768L) / (long)den);
}

wavc89_s32 wavc89_q16_from_ratio(wavc89_s32 num, wavc89_s32 den)
{
    if (den == 0)
    {
        return 0;
    }
    return (wavc89_s32)(((long)num * 65536L) / (long)den);
}
