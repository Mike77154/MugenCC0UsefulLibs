#include "wavc89/wavc89_io.h"
#include "wavc89/wavc89_status.h"

static int wavc89_mem_read(void *user, void *dst, wavc89_u32 size, wavc89_u32 *out_read)
{
    wavc89_mem_reader *ctx;
    wavc89_u32 remain;
    wavc89_u32 take;
    wavc89_u32 i;
    wavc89_u8 *d;
    const wavc89_u8 *s;

    if (user == 0 || dst == 0 || out_read == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    ctx = (wavc89_mem_reader *)user;
    if (ctx->pos > ctx->size)
    {
        return WAVC89_E_CORRUPT;
    }

    remain = ctx->size - ctx->pos;
    take = (size <= remain) ? size : remain;
    d = (wavc89_u8 *)dst;
    s = ctx->data + ctx->pos;
    for (i = 0; i < take; ++i)
    {
        d[i] = s[i];
    }
    ctx->pos += take;
    *out_read = take;
    return (take == size) ? WAVC89_OK : WAVC89_E_SHORT_READ;
}

static int wavc89_mem_write(void *user, const void *src, wavc89_u32 size, wavc89_u32 *out_written)
{
    wavc89_mem_writer *ctx;
    wavc89_u32 remain;
    wavc89_u32 take;
    wavc89_u32 i;
    const wavc89_u8 *s;
    wavc89_u8 *d;

    if (user == 0 || src == 0 || out_written == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }

    ctx = (wavc89_mem_writer *)user;
    if (ctx->pos > ctx->capacity)
    {
        return WAVC89_E_CORRUPT;
    }

    remain = ctx->capacity - ctx->pos;
    take = (size <= remain) ? size : remain;
    s = (const wavc89_u8 *)src;
    d = ctx->data + ctx->pos;

    for (i = 0; i < take; ++i)
    {
        d[i] = s[i];
    }

    ctx->pos += take;
    if (ctx->size < ctx->pos)
    {
        ctx->size = ctx->pos;
    }

    *out_written = take;
    return (take == size) ? WAVC89_OK : WAVC89_E_SHORT_WRITE;
}

static int wavc89_mem_seek_reader(void *user, wavc89_u32 absolute_offset)
{
    wavc89_mem_reader *ctx;
    if (user == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_reader *)user;
    if (absolute_offset > ctx->size)
    {
        return WAVC89_E_SEEK;
    }
    ctx->pos = absolute_offset;
    return WAVC89_OK;
}

static int wavc89_mem_tell_reader(void *user, wavc89_u32 *out_offset)
{
    wavc89_mem_reader *ctx;
    if (user == 0 || out_offset == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_reader *)user;
    *out_offset = ctx->pos;
    return WAVC89_OK;
}

static int wavc89_mem_size_reader(void *user, wavc89_u32 *out_size)
{
    wavc89_mem_reader *ctx;
    if (user == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_reader *)user;
    *out_size = ctx->size;
    return WAVC89_OK;
}

static int wavc89_mem_seek_writer(void *user, wavc89_u32 absolute_offset)
{
    wavc89_mem_writer *ctx;
    if (user == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_writer *)user;
    if (absolute_offset > ctx->capacity)
    {
        return WAVC89_E_SEEK;
    }
    ctx->pos = absolute_offset;
    if (ctx->size < ctx->pos)
    {
        ctx->size = ctx->pos;
    }
    return WAVC89_OK;
}

static int wavc89_mem_tell_writer(void *user, wavc89_u32 *out_offset)
{
    wavc89_mem_writer *ctx;
    if (user == 0 || out_offset == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_writer *)user;
    *out_offset = ctx->pos;
    return WAVC89_OK;
}

static int wavc89_mem_size_writer(void *user, wavc89_u32 *out_size)
{
    wavc89_mem_writer *ctx;
    if (user == 0 || out_size == 0)
    {
        return WAVC89_E_INVALID_ARG;
    }
    ctx = (wavc89_mem_writer *)user;
    *out_size = ctx->size;
    return WAVC89_OK;
}

int wavc89_io_mem_reader_init(wavc89_io *io, wavc89_mem_reader *ctx, const void *data, wavc89_u32 size)
{
    if (io == 0 || ctx == 0 || (data == 0 && size != 0))
    {
        return WAVC89_E_INVALID_ARG;
    }

    ctx->data = (const wavc89_u8 *)data;
    ctx->size = size;
    ctx->pos = 0;

    io->read = wavc89_mem_read;
    io->write = 0;
    io->seek = wavc89_mem_seek_reader;
    io->tell = wavc89_mem_tell_reader;
    io->size = wavc89_mem_size_reader;
    io->user = ctx;
    return WAVC89_OK;
}

int wavc89_io_mem_writer_init(wavc89_io *io, wavc89_mem_writer *ctx, void *data, wavc89_u32 capacity)
{
    if (io == 0 || ctx == 0 || (data == 0 && capacity != 0))
    {
        return WAVC89_E_INVALID_ARG;
    }

    ctx->data = (wavc89_u8 *)data;
    ctx->capacity = capacity;
    ctx->pos = 0;
    ctx->size = 0;

    io->read = 0;
    io->write = wavc89_mem_write;
    io->seek = wavc89_mem_seek_writer;
    io->tell = wavc89_mem_tell_writer;
    io->size = wavc89_mem_size_writer;
    io->user = ctx;
    return WAVC89_OK;
}
