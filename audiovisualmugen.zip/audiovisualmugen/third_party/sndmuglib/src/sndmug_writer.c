#include <string.h>
#include "sndmug/sndmug.h"

typedef struct sndmug_wav_bridge_t
{
    const sndmug_io *io;
} sndmug_wav_bridge;

static int sndmug_wav_read(void *user, void *dst, wavc89_u32 size, wavc89_u32 *out_read)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->read(b->io->user, dst, (sndmug_u32)size, (sndmug_u32 *)out_read);
}

static int sndmug_wav_seek(void *user, wavc89_u32 absolute_offset)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->seek(b->io->user, (sndmug_u32)absolute_offset);
}

static int sndmug_wav_tell(void *user, wavc89_u32 *out_offset)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->tell(b->io->user, (sndmug_u32 *)out_offset);
}

static int sndmug_wav_size(void *user, wavc89_u32 *out_size)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->size(b->io->user, (sndmug_u32 *)out_size);
}

static void sndmug_wav_bridge_init(wavc89_io *dst, sndmug_wav_bridge *ctx, const sndmug_io *src)
{
    ctx->io = src;
    dst->read = sndmug_wav_read;
    dst->write = 0;
    dst->seek = sndmug_wav_seek;
    dst->tell = sndmug_wav_tell;
    dst->size = sndmug_wav_size;
    dst->user = ctx;
}


static void sndmug_store_le32(sndmug_u8 *p, sndmug_u32 v)
{
    p[0] = (sndmug_u8)(v & 0xFFu);
    p[1] = (sndmug_u8)((v >> 8) & 0xFFu);
    p[2] = (sndmug_u8)((v >> 16) & 0xFFu);
    p[3] = (sndmug_u8)((v >> 24) & 0xFFu);
}

static int sndmug_write_exact(const sndmug_io *io, const void *src, sndmug_u32 size)
{
    sndmug_u32 n;
    int rc;
    if (io == 0 || io->write == 0 || src == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    rc = io->write(io->user, src, size, &n);
    if (rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_WRITE)
    {
        return rc;
    }
    return (n == size) ? SNDMUG_OK : SNDMUG_E_SHORT_WRITE;
}

static int sndmug_copy_exact(const sndmug_io *src, sndmug_u32 src_offset, const sndmug_io *dst, sndmug_u32 size)
{
    sndmug_u8 buf[256];
    sndmug_u32 remain;
    sndmug_u32 take;
    sndmug_u32 nread;
    sndmug_u32 nwritten;
    int rc;

    if (src == 0 || dst == 0 || src->read == 0 || src->seek == 0 || dst->write == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    rc = src->seek(src->user, src_offset);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    remain = size;
    while (remain != 0u)
    {
        take = (remain > (sndmug_u32)sizeof(buf)) ? (sndmug_u32)sizeof(buf) : remain;
        rc = src->read(src->user, buf, take, &nread);
        if ((rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_READ) || nread != take)
        {
            return SNDMUG_E_SHORT_READ;
        }
        rc = dst->write(dst->user, buf, take, &nwritten);
        if ((rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_WRITE) || nwritten != take)
        {
            return SNDMUG_E_SHORT_WRITE;
        }
        remain -= take;
    }
    return SNDMUG_OK;
}

static int sndmug_patch_u32(const sndmug_io *io, sndmug_u32 offset, sndmug_u32 value)
{
    sndmug_u8 buf[4];
    int rc;
    if (io == 0 || io->write == 0 || io->seek == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    sndmug_store_le32(buf, value);
    rc = io->seek(io->user, offset);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }
    return sndmug_write_exact(io, buf, 4u);
}

static int sndmug_validate_wav_payload(const sndmug_io *payload_io, sndmug_u32 payload_offset, sndmug_u32 payload_size)
{
    sndmug_wav_bridge bridge;
    wavc89_io io;
    wavc89_reader wr;
    int rc;

    if (payload_io == 0 || payload_io->read == 0 || payload_io->seek == 0 || payload_io->size == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    if (payload_size == 0u)
    {
        sndmug_u32 total;
        rc = payload_io->size(payload_io->user, &total);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }
        if (payload_offset > total)
        {
            return SNDMUG_E_BAD_OFFSET;
        }
        payload_size = total - payload_offset;
    }

    sndmug_wav_bridge_init(&io, &bridge, payload_io);
    rc = wavc89_reader_open(&wr, &io, payload_offset, payload_size);
    if (rc != WAVC89_OK)
    {
        return SNDMUG_E_WAV_INVALID;
    }
    if (!wavc89_is_mugen_compatible(&wr.info))
    {
        return SNDMUG_E_UNSUPPORTED;
    }
    return SNDMUG_OK;
}

static int sndmug_write_header(const sndmug_io *io, const sndmug_u8 version[4], const sndmug_u8 comment[SNDMUG_COMMENT_SIZE], sndmug_u32 sound_count, sndmug_u32 first_offset)
{
    sndmug_u8 raw[SNDMUG_HEADER_SIZE];
    static const sndmug_u8 sig[SNDMUG_SIGNATURE_SIZE] = {
        'E','l','e','c','b','y','t','e','S','n','d','\0'
    };
    sndmug_u32 i;
    for (i = 0u; i < SNDMUG_HEADER_SIZE; ++i)
    {
        raw[i] = 0u;
    }
    for (i = 0u; i < SNDMUG_SIGNATURE_SIZE; ++i)
    {
        raw[i] = sig[i];
    }
    raw[12] = version ? version[0] : 1u;
    raw[13] = version ? version[1] : 0u;
    raw[14] = version ? version[2] : 0u;
    raw[15] = version ? version[3] : 0u;
    sndmug_store_le32(raw + 16, sound_count);
    sndmug_store_le32(raw + 20, first_offset);
    if (comment != 0)
    {
        for (i = 0u; i < SNDMUG_COMMENT_SIZE; ++i)
        {
            raw[24u + i] = comment[i];
        }
    }
    if (io->seek(io->user, 0u) != SNDMUG_OK)
    {
        return SNDMUG_E_SEEK;
    }
    return sndmug_write_exact(io, raw, SNDMUG_HEADER_SIZE);
}

int sndmug_writer_begin(sndmug_writer *writer, const sndmug_io *io, const sndmug_u8 version[4], const sndmug_u8 comment[SNDMUG_COMMENT_SIZE])
{
    sndmug_u32 i;
    int rc;

    if (writer == 0 || io == 0 || io->write == 0 || io->seek == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    memset(writer, 0, sizeof(*writer));
    writer->io = *io;
    writer->started = 1;
    writer->first_entry_offset = 0u;
    writer->last_entry_offset = 0u;
    writer->sound_count = 0u;

    writer->version[0] = version ? version[0] : 1u;
    writer->version[1] = version ? version[1] : 0u;
    writer->version[2] = version ? version[2] : 0u;
    writer->version[3] = version ? version[3] : 0u;
    for (i = 0u; i < SNDMUG_COMMENT_SIZE; ++i)
    {
        writer->comment[i] = (comment != 0) ? comment[i] : 0u;
    }

    rc = sndmug_write_header(&writer->io, writer->version, writer->comment, 0u, 0u);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    return writer->io.seek(writer->io.user, SNDMUG_HEADER_SIZE);
}

int sndmug_writer_add_from_io(sndmug_writer *writer, sndmug_u32 group_no, sndmug_u32 sound_no, const sndmug_io *payload_io, sndmug_u32 payload_offset, sndmug_u32 payload_size)
{
    sndmug_u8 sub[16];
    sndmug_u32 cur_offset;
    sndmug_u32 total_size;
    int rc;

    if (writer == 0 || payload_io == 0 || !writer->started)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    rc = sndmug_validate_wav_payload(payload_io, payload_offset, payload_size);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    if (payload_size == 0u)
    {
        rc = payload_io->size(payload_io->user, &total_size);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }
        if (payload_offset > total_size)
        {
            return SNDMUG_E_BAD_OFFSET;
        }
        payload_size = total_size - payload_offset;
    }

    rc = writer->io.tell(writer->io.user, &cur_offset);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    if (writer->sound_count == 0u)
    {
        writer->first_entry_offset = cur_offset;
    }
    else
    {
        rc = sndmug_patch_u32(&writer->io, writer->last_entry_offset, cur_offset);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }
        rc = writer->io.seek(writer->io.user, cur_offset);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }
    }

    sndmug_store_le32(sub + 0, 0u);
    sndmug_store_le32(sub + 4, payload_size);
    sndmug_store_le32(sub + 8, group_no);
    sndmug_store_le32(sub + 12, sound_no);

    rc = sndmug_write_exact(&writer->io, sub, 16u);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    rc = sndmug_copy_exact(payload_io, payload_offset, &writer->io, payload_size);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    writer->last_entry_offset = cur_offset;
    writer->sound_count += 1u;
    return SNDMUG_OK;
}

int sndmug_writer_add_from_memory(sndmug_writer *writer, sndmug_u32 group_no, sndmug_u32 sound_no, const void *wav_bytes, sndmug_u32 wav_size)
{
    sndmug_io io;
    sndmug_mem_reader mem;
    int rc;
    rc = sndmug_io_mem_reader_init(&io, &mem, wav_bytes, wav_size);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }
    return sndmug_writer_add_from_io(writer, group_no, sound_no, &io, 0u, wav_size);
}

int sndmug_writer_finish(sndmug_writer *writer)
{
    if (writer == 0 || !writer->started)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    writer->started = 0;
    return sndmug_write_header(&writer->io, writer->version, writer->comment, writer->sound_count, writer->first_entry_offset);
}

int sndmug_build_from_descs(const sndmug_io *dst, const sndmug_u8 version[4], const sndmug_u8 comment[SNDMUG_COMMENT_SIZE], sndmug_desc *descs, sndmug_u32 count)
{
    sndmug_writer writer;
    sndmug_u32 i;
    int rc;

    if (dst == 0 || descs == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    rc = sndmug_desc_sort(descs, count);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }
    rc = sndmug_desc_validate_unique(descs, count);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    rc = sndmug_writer_begin(&writer, dst, version, comment);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    for (i = 0u; i < count; ++i)
    {
        rc = sndmug_writer_add_from_io(&writer, descs[i].group_no, descs[i].sound_no, descs[i].payload_io, descs[i].payload_offset, descs[i].payload_size);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }
    }

    return sndmug_writer_finish(&writer);
}
