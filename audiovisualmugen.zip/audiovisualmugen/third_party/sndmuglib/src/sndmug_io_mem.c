#include "sndmug/sndmug_io.h"
#include "sndmug/sndmug_status.h"

static int sndmug_mem_read(void *user, void *dst, sndmug_u32 size, sndmug_u32 *out_read)
{
    sndmug_mem_reader *ctx;
    sndmug_u32 remain;
    sndmug_u32 take;
    sndmug_u32 i;
    sndmug_u8 *d;
    const sndmug_u8 *s;

    if (user == 0 || dst == 0 || out_read == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    ctx = (sndmug_mem_reader *)user;
    if (ctx->pos > ctx->size)
    {
        return SNDMUG_E_CORRUPT;
    }

    remain = ctx->size - ctx->pos;
    take = (size <= remain) ? size : remain;
    d = (sndmug_u8 *)dst;
    s = ctx->data + ctx->pos;
    for (i = 0; i < take; ++i)
    {
        d[i] = s[i];
    }
    ctx->pos += take;
    *out_read = take;
    return (take == size) ? SNDMUG_OK : SNDMUG_E_SHORT_READ;
}

static int sndmug_mem_write(void *user, const void *src, sndmug_u32 size, sndmug_u32 *out_written)
{
    sndmug_mem_writer *ctx;
    sndmug_u32 remain;
    sndmug_u32 take;
    sndmug_u32 i;
    const sndmug_u8 *s;
    sndmug_u8 *d;

    if (user == 0 || src == 0 || out_written == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    ctx = (sndmug_mem_writer *)user;
    if (ctx->pos > ctx->capacity)
    {
        return SNDMUG_E_CORRUPT;
    }

    remain = ctx->capacity - ctx->pos;
    take = (size <= remain) ? size : remain;
    s = (const sndmug_u8 *)src;
    d = ctx->data + ctx->pos;

    for (i = 0; i < take; ++i)
    {
        d[i] = s[i];
    }

    ctx->pos += take;
    if (ctx->size < ctx->pos)
    {
        ctx->size = ctx->pos;
    }

    *out_written = take;
    return (take == size) ? SNDMUG_OK : SNDMUG_E_SHORT_WRITE;
}

static int sndmug_mem_seek_reader(void *user, sndmug_u32 absolute_offset)
{
    sndmug_mem_reader *ctx;
    if (user == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_reader *)user;
    if (absolute_offset > ctx->size)
    {
        return SNDMUG_E_SEEK;
    }
    ctx->pos = absolute_offset;
    return SNDMUG_OK;
}

static int sndmug_mem_tell_reader(void *user, sndmug_u32 *out_offset)
{
    sndmug_mem_reader *ctx;
    if (user == 0 || out_offset == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_reader *)user;
    *out_offset = ctx->pos;
    return SNDMUG_OK;
}

static int sndmug_mem_size_reader(void *user, sndmug_u32 *out_size)
{
    sndmug_mem_reader *ctx;
    if (user == 0 || out_size == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_reader *)user;
    *out_size = ctx->size;
    return SNDMUG_OK;
}

static int sndmug_mem_seek_writer(void *user, sndmug_u32 absolute_offset)
{
    sndmug_mem_writer *ctx;
    if (user == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_writer *)user;
    if (absolute_offset > ctx->capacity)
    {
        return SNDMUG_E_SEEK;
    }
    ctx->pos = absolute_offset;
    if (ctx->size < ctx->pos)
    {
        ctx->size = ctx->pos;
    }
    return SNDMUG_OK;
}

static int sndmug_mem_tell_writer(void *user, sndmug_u32 *out_offset)
{
    sndmug_mem_writer *ctx;
    if (user == 0 || out_offset == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_writer *)user;
    *out_offset = ctx->pos;
    return SNDMUG_OK;
}

static int sndmug_mem_size_writer(void *user, sndmug_u32 *out_size)
{
    sndmug_mem_writer *ctx;
    if (user == 0 || out_size == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    ctx = (sndmug_mem_writer *)user;
    *out_size = ctx->size;
    return SNDMUG_OK;
}

int sndmug_io_mem_reader_init(sndmug_io *io, sndmug_mem_reader *ctx, const void *data, sndmug_u32 size)
{
    if (io == 0 || ctx == 0 || (data == 0 && size != 0))
    {
        return SNDMUG_E_INVALID_ARG;
    }

    ctx->data = (const sndmug_u8 *)data;
    ctx->size = size;
    ctx->pos = 0;

    io->read = sndmug_mem_read;
    io->write = 0;
    io->seek = sndmug_mem_seek_reader;
    io->tell = sndmug_mem_tell_reader;
    io->size = sndmug_mem_size_reader;
    io->user = ctx;
    return SNDMUG_OK;
}

int sndmug_io_mem_writer_init(sndmug_io *io, sndmug_mem_writer *ctx, void *data, sndmug_u32 capacity)
{
    if (io == 0 || ctx == 0 || (data == 0 && capacity != 0))
    {
        return SNDMUG_E_INVALID_ARG;
    }

    ctx->data = (sndmug_u8 *)data;
    ctx->capacity = capacity;
    ctx->pos = 0;
    ctx->size = 0;

    io->read = 0;
    io->write = sndmug_mem_write;
    io->seek = sndmug_mem_seek_writer;
    io->tell = sndmug_mem_tell_writer;
    io->size = sndmug_mem_size_writer;
    io->user = ctx;
    return SNDMUG_OK;
}
