#include "sndmug/sndmug.h"

int sndmug_pair_index_build(const sndmug_reader *reader, sndmug_pair_index *index, sndmug_u32 capacity)
{
    sndmug_u32 i;
    sndmug_u32 j;
    sndmug_pair_index key;

    if (reader == 0 || index == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    if (capacity < reader->entry_count)
    {
        return SNDMUG_E_LIMIT;
    }

    for (i = 0u; i < reader->entry_count; ++i)
    {
        index[i].group_no = reader->entries[i].group_no;
        index[i].sound_no = reader->entries[i].sound_no;
        index[i].entry_index = i;
    }

    for (i = 1u; i < reader->entry_count; ++i)
    {
        key = index[i];
        j = i;
        while (j > 0u)
        {
            if (index[j - 1u].group_no < key.group_no)
            {
                break;
            }
            if (index[j - 1u].group_no == key.group_no &&
                index[j - 1u].sound_no <= key.sound_no)
            {
                break;
            }
            index[j] = index[j - 1u];
            --j;
        }
        index[j] = key;
    }

    for (i = 1u; i < reader->entry_count; ++i)
    {
        if (index[i - 1u].group_no == index[i].group_no &&
            index[i - 1u].sound_no == index[i].sound_no)
        {
            return SNDMUG_E_DUPLICATE;
        }
    }

    return SNDMUG_OK;
}

int sndmug_pair_index_find(const sndmug_pair_index *index, sndmug_u32 count, sndmug_u32 group_no, sndmug_u32 sound_no, sndmug_u32 *out_entry_index)
{
    sndmug_u32 lo;
    sndmug_u32 hi;

    if (index == 0 || out_entry_index == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    lo = 0u;
    hi = count;
    while (lo < hi)
    {
        sndmug_u32 mid;
        mid = lo + ((hi - lo) / 2u);
        if (index[mid].group_no < group_no ||
            (index[mid].group_no == group_no && index[mid].sound_no < sound_no))
        {
            lo = mid + 1u;
        }
        else
        {
            hi = mid;
        }
    }

    if (lo < count && index[lo].group_no == group_no && index[lo].sound_no == sound_no)
    {
        *out_entry_index = index[lo].entry_index;
        return SNDMUG_OK;
    }

    return SNDMUG_E_NOT_FOUND;
}
