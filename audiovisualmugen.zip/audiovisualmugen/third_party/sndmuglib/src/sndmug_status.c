#include "sndmug/sndmug_status.h"

const char *sndmug_status_string(int code)
{
    switch (code)
    {
    case SNDMUG_OK: return "SNDMUG_OK";
    case SNDMUG_E_INVALID_ARG: return "SNDMUG_E_INVALID_ARG";
    case SNDMUG_E_IO: return "SNDMUG_E_IO";
    case SNDMUG_E_SHORT_READ: return "SNDMUG_E_SHORT_READ";
    case SNDMUG_E_SHORT_WRITE: return "SNDMUG_E_SHORT_WRITE";
    case SNDMUG_E_SEEK: return "SNDMUG_E_SEEK";
    case SNDMUG_E_BAD_SIGNATURE: return "SNDMUG_E_BAD_SIGNATURE";
    case SNDMUG_E_BAD_HEADER: return "SNDMUG_E_BAD_HEADER";
    case SNDMUG_E_BAD_OFFSET: return "SNDMUG_E_BAD_OFFSET";
    case SNDMUG_E_BAD_LENGTH: return "SNDMUG_E_BAD_LENGTH";
    case SNDMUG_E_LIMIT: return "SNDMUG_E_LIMIT";
    case SNDMUG_E_DUPLICATE: return "SNDMUG_E_DUPLICATE";
    case SNDMUG_E_NOT_FOUND: return "SNDMUG_E_NOT_FOUND";
    case SNDMUG_E_CORRUPT: return "SNDMUG_E_CORRUPT";
    case SNDMUG_E_LOOP: return "SNDMUG_E_LOOP";
    case SNDMUG_E_WAV_INVALID: return "SNDMUG_E_WAV_INVALID";
    case SNDMUG_E_OVERFLOW: return "SNDMUG_E_OVERFLOW";
    case SNDMUG_E_UNSUPPORTED: return "SNDMUG_E_UNSUPPORTED";
    default: return "SNDMUG_E_UNKNOWN";
    }
}
