#include "sndmug/sndmug.h"

typedef struct sndmug_wav_bridge_t
{
    const sndmug_io *io;
} sndmug_wav_bridge;

static int sndmug_wav_read(void *user, void *dst, wavc89_u32 size, wavc89_u32 *out_read)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->read(b->io->user, dst, (sndmug_u32)size, (sndmug_u32 *)out_read);
}

static int sndmug_wav_write(void *user, const void *src, wavc89_u32 size, wavc89_u32 *out_written)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->write(b->io->user, src, (sndmug_u32)size, (sndmug_u32 *)out_written);
}

static int sndmug_wav_seek(void *user, wavc89_u32 absolute_offset)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->seek(b->io->user, (sndmug_u32)absolute_offset);
}

static int sndmug_wav_tell(void *user, wavc89_u32 *out_offset)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->tell(b->io->user, (sndmug_u32 *)out_offset);
}

static int sndmug_wav_size(void *user, wavc89_u32 *out_size)
{
    sndmug_wav_bridge *b;
    b = (sndmug_wav_bridge *)user;
    return b->io->size(b->io->user, (sndmug_u32 *)out_size);
}

static void sndmug_wav_bridge_init(wavc89_io *dst, sndmug_wav_bridge *ctx, const sndmug_io *src)
{
    ctx->io = src;
    dst->read = sndmug_wav_read;
    dst->write = sndmug_wav_write;
    dst->seek = sndmug_wav_seek;
    dst->tell = sndmug_wav_tell;
    dst->size = sndmug_wav_size;
    dst->user = ctx;
}

int sndmug_reader_get_wav_info(const sndmug_reader *reader, sndmug_u32 index, wavc89_info *out_info)
{
    sndmug_wav_bridge bridge;
    wavc89_io io;
    wavc89_reader wr;
    int rc;

    if (reader == 0 || out_info == 0 || index >= reader->entry_count)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    sndmug_wav_bridge_init(&io, &bridge, &reader->io);
    rc = wavc89_reader_open(&wr, &io, reader->entries[index].data_offset, reader->entries[index].data_length);
    if (rc != WAVC89_OK)
    {
        return SNDMUG_E_WAV_INVALID;
    }
    *out_info = wr.info;
    return SNDMUG_OK;
}

int sndmug_desc_sort(sndmug_desc *descs, sndmug_u32 count)
{
    sndmug_u32 i;
    sndmug_u32 j;
    sndmug_desc key;

    if (descs == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    for (i = 1u; i < count; ++i)
    {
        key = descs[i];
        j = i;
        while (j > 0u)
        {
            if (descs[j - 1u].group_no < key.group_no)
            {
                break;
            }
            if (descs[j - 1u].group_no == key.group_no && descs[j - 1u].sound_no <= key.sound_no)
            {
                break;
            }
            descs[j] = descs[j - 1u];
            --j;
        }
        descs[j] = key;
    }
    return SNDMUG_OK;
}

int sndmug_desc_validate_unique(const sndmug_desc *descs, sndmug_u32 count)
{
    sndmug_u32 i;
    if (descs == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    for (i = 1u; i < count; ++i)
    {
        if (descs[i - 1u].group_no == descs[i].group_no &&
            descs[i - 1u].sound_no == descs[i].sound_no)
        {
            return SNDMUG_E_DUPLICATE;
        }
    }
    return SNDMUG_OK;
}
