#include <stdio.h>
#include "sndmug/sndmug_stdio.h"
#include "sndmug/sndmug_status.h"

static int sndmug_stdio_read(void *user, void *dst, sndmug_u32 size, sndmug_u32 *out_read)
{
    FILE *fp;
    size_t n;
    if (user == 0 || dst == 0 || out_read == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    n = fread(dst, 1u, (size_t)size, fp);
    *out_read = (sndmug_u32)n;
    return (n == (size_t)size) ? SNDMUG_OK : SNDMUG_E_SHORT_READ;
}

static int sndmug_stdio_write(void *user, const void *src, sndmug_u32 size, sndmug_u32 *out_written)
{
    FILE *fp;
    size_t n;
    if (user == 0 || src == 0 || out_written == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    n = fwrite(src, 1u, (size_t)size, fp);
    *out_written = (sndmug_u32)n;
    return (n == (size_t)size) ? SNDMUG_OK : SNDMUG_E_SHORT_WRITE;
}

static int sndmug_stdio_seek(void *user, sndmug_u32 absolute_offset)
{
    FILE *fp;
    if (user == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    return (fseek(fp, (long)absolute_offset, SEEK_SET) == 0) ? SNDMUG_OK : SNDMUG_E_SEEK;
}

static int sndmug_stdio_tell(void *user, sndmug_u32 *out_offset)
{
    FILE *fp;
    long p;
    if (user == 0 || out_offset == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    p = ftell(fp);
    if (p < 0)
    {
        return SNDMUG_E_IO;
    }
    *out_offset = (sndmug_u32)p;
    return SNDMUG_OK;
}

static int sndmug_stdio_size(void *user, sndmug_u32 *out_size)
{
    FILE *fp;
    long saved;
    long endp;
    if (user == 0 || out_size == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    fp = (FILE *)user;
    saved = ftell(fp);
    if (saved < 0)
    {
        return SNDMUG_E_IO;
    }
    if (fseek(fp, 0L, SEEK_END) != 0)
    {
        return SNDMUG_E_SEEK;
    }
    endp = ftell(fp);
    if (endp < 0)
    {
        return SNDMUG_E_IO;
    }
    if (fseek(fp, saved, SEEK_SET) != 0)
    {
        return SNDMUG_E_SEEK;
    }
    *out_size = (sndmug_u32)endp;
    return SNDMUG_OK;
}

int sndmug_io_stdio_reader_init(sndmug_io *io, FILE *fp)
{
    if (io == 0 || fp == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    io->read = sndmug_stdio_read;
    io->write = 0;
    io->seek = sndmug_stdio_seek;
    io->tell = sndmug_stdio_tell;
    io->size = sndmug_stdio_size;
    io->user = fp;
    return SNDMUG_OK;
}

int sndmug_io_stdio_writer_init(sndmug_io *io, FILE *fp)
{
    if (io == 0 || fp == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    io->read = 0;
    io->write = sndmug_stdio_write;
    io->seek = sndmug_stdio_seek;
    io->tell = sndmug_stdio_tell;
    io->size = sndmug_stdio_size;
    io->user = fp;
    return SNDMUG_OK;
}
