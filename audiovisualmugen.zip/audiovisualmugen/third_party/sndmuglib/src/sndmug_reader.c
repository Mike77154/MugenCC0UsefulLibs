#include <string.h>
#include "sndmug/sndmug.h"

static sndmug_u32 sndmug_le32(const sndmug_u8 *p)
{
    return (sndmug_u32)((sndmug_u32)p[0]
        | ((sndmug_u32)p[1] << 8)
        | ((sndmug_u32)p[2] << 16)
        | ((sndmug_u32)p[3] << 24));
}

static int sndmug_read_exact(const sndmug_io *io, sndmug_u32 offset, void *dst, sndmug_u32 size)
{
    sndmug_u32 n;
    int rc;
    if (io == 0 || io->read == 0 || io->seek == 0 || dst == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    rc = io->seek(io->user, offset);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }
    rc = io->read(io->user, dst, size, &n);
    if (rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_READ)
    {
        return rc;
    }
    return (n == size) ? SNDMUG_OK : SNDMUG_E_SHORT_READ;
}

int sndmug_reader_open(sndmug_reader *reader, const sndmug_io *io, sndmug_entry *entries, sndmug_u32 entry_capacity)
{
    static const sndmug_u8 sig[SNDMUG_SIGNATURE_SIZE] = {
        'E','l','e','c','b','y','t','e','S','n','d','\0'
    };
    sndmug_u8 raw[SNDMUG_HEADER_SIZE];
    sndmug_u8 sub[16];
    sndmug_u32 offset;
    sndmug_u32 i;
    sndmug_u32 next_offset;
    sndmug_u32 data_length;
    sndmug_u32 group_no;
    sndmug_u32 sound_no;
    int rc;

    if (reader == 0 || io == 0 || entries == 0 || entry_capacity == 0u || io->read == 0 || io->seek == 0 || io->size == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    memset(reader, 0, sizeof(*reader));
    reader->io = *io;
    reader->entries = entries;
    reader->entry_capacity = entry_capacity;

    rc = io->size(io->user, &reader->file_size);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }
    if (reader->file_size < SNDMUG_HEADER_SIZE)
    {
        return SNDMUG_E_BAD_HEADER;
    }

    rc = sndmug_read_exact(io, 0u, raw, SNDMUG_HEADER_SIZE);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    if (memcmp(raw + 0, sig, SNDMUG_SIGNATURE_SIZE) != 0)
    {
        return SNDMUG_E_BAD_SIGNATURE;
    }

    memcpy(reader->header.signature, raw + 0, SNDMUG_SIGNATURE_SIZE);
    memcpy(reader->header.version, raw + 12, 4u);
    reader->header.sound_count = sndmug_le32(raw + 16);
    reader->header.first_subfile_offset = sndmug_le32(raw + 20);
    memcpy(reader->header.comment, raw + 24, SNDMUG_COMMENT_SIZE);

    if (reader->header.first_subfile_offset == 0u)
    {
        reader->entry_count = 0u;
        reader->header_count_mismatch = (reader->header.sound_count != 0u) ? 1 : 0;
        return SNDMUG_OK;
    }

    if (reader->header.first_subfile_offset < SNDMUG_HEADER_SIZE || reader->header.first_subfile_offset > reader->file_size - 16u)
    {
        return SNDMUG_E_BAD_OFFSET;
    }

    offset = reader->header.first_subfile_offset;

    while (offset != 0u)
    {
        if (reader->entry_count >= reader->entry_capacity)
        {
            return SNDMUG_E_LIMIT;
        }

        for (i = 0u; i < reader->entry_count; ++i)
        {
            if (reader->entries[i].entry_offset == offset)
            {
                return SNDMUG_E_LOOP;
            }
        }

        rc = sndmug_read_exact(io, offset, sub, 16u);
        if (rc != SNDMUG_OK)
        {
            return rc;
        }

        next_offset = sndmug_le32(sub + 0);
        data_length = sndmug_le32(sub + 4);
        group_no = sndmug_le32(sub + 8);
        sound_no = sndmug_le32(sub + 12);

        if (offset + 16u < offset)
        {
            return SNDMUG_E_OVERFLOW;
        }
        if (offset + 16u + data_length < offset + 16u)
        {
            return SNDMUG_E_OVERFLOW;
        }
        if (offset + 16u + data_length > reader->file_size)
        {
            return SNDMUG_E_BAD_LENGTH;
        }

        reader->entries[reader->entry_count].entry_offset = offset;
        reader->entries[reader->entry_count].next_offset = next_offset;
        reader->entries[reader->entry_count].data_length = data_length;
        reader->entries[reader->entry_count].group_no = group_no;
        reader->entries[reader->entry_count].sound_no = sound_no;
        reader->entries[reader->entry_count].data_offset = offset + 16u;
        reader->entry_count += 1u;

        /*
         * Elecbyte's reference KFM archive terminates the linked list by
         * pointing one byte past the last payload, i.e. exactly at EOF,
         * instead of writing zero.  Accept both terminators.  Offsets in
         * the middle of the final 16-byte header area remain invalid.
         */
        if (next_offset == 0u || next_offset == reader->file_size)
        {
            break;
        }

        if (next_offset < SNDMUG_HEADER_SIZE || next_offset > reader->file_size - 16u)
        {
            return SNDMUG_E_BAD_OFFSET;
        }

        offset = next_offset;
    }

    reader->header_count_mismatch = (reader->header.sound_count != reader->entry_count) ? 1 : 0;
    return SNDMUG_OK;
}

int sndmug_reader_find(const sndmug_reader *reader, sndmug_u32 group_no, sndmug_u32 sound_no, sndmug_u32 *out_index)
{
    sndmug_u32 i;
    if (reader == 0 || out_index == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    for (i = 0u; i < reader->entry_count; ++i)
    {
        if (reader->entries[i].group_no == group_no && reader->entries[i].sound_no == sound_no)
        {
            *out_index = i;
            return SNDMUG_OK;
        }
    }
    return SNDMUG_E_NOT_FOUND;
}

int sndmug_reader_read_payload(const sndmug_reader *reader, sndmug_u32 index, void *dst, sndmug_u32 capacity, sndmug_u32 *out_size)
{
    sndmug_u32 size;
    int rc;
    if (reader == 0 || dst == 0 || out_size == 0 || index >= reader->entry_count)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    size = reader->entries[index].data_length;
    *out_size = size;
    if (capacity < size)
    {
        return SNDMUG_E_LIMIT;
    }
    rc = sndmug_read_exact(&reader->io, reader->entries[index].data_offset, dst, size);
    return rc;
}

int sndmug_reader_copy_payload(const sndmug_reader *reader, sndmug_u32 index, sndmug_io *dst)
{
    sndmug_u8 buf[256];
    sndmug_u32 remain;
    sndmug_u32 take;
    sndmug_u32 nread;
    sndmug_u32 nwritten;
    int rc;

    if (reader == 0 || dst == 0 || index >= reader->entry_count)
    {
        return SNDMUG_E_INVALID_ARG;
    }
    if (dst->write == 0 || dst->seek == 0)
    {
        return SNDMUG_E_INVALID_ARG;
    }

    rc = reader->io.seek(reader->io.user, reader->entries[index].data_offset);
    if (rc != SNDMUG_OK)
    {
        return rc;
    }

    remain = reader->entries[index].data_length;
    while (remain != 0u)
    {
        take = (remain > (sndmug_u32)sizeof(buf)) ? (sndmug_u32)sizeof(buf) : remain;
        rc = reader->io.read(reader->io.user, buf, take, &nread);
        if ((rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_READ) || nread != take)
        {
            return SNDMUG_E_SHORT_READ;
        }
        rc = dst->write(dst->user, buf, take, &nwritten);
        if ((rc != SNDMUG_OK && rc != SNDMUG_E_SHORT_WRITE) || nwritten != take)
        {
            return SNDMUG_E_SHORT_WRITE;
        }
        remain -= take;
    }
    return SNDMUG_OK;
}
