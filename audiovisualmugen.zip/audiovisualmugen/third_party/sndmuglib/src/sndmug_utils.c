#include <string.h>
#include "sndmug/sndmug.h"

sndmug_s32 sndmug_q15_mul(sndmug_s32 a, sndmug_s32 b)
{
    long v;
    v = (long)a * (long)b;
    return (sndmug_s32)(v / 32768L);
}

sndmug_s32 sndmug_q15_from_ratio(sndmug_s32 num, sndmug_s32 den)
{
    if (den == 0)
    {
        return 0;
    }
    return (sndmug_s32)(((long)num * 32768L) / (long)den);
}

void sndmug_header_init(sndmug_snd_header *header)
{
    static const sndmug_u8 sig[SNDMUG_SIGNATURE_SIZE] = {
        'E','l','e','c','b','y','t','e','S','n','d','\0'
    };
    sndmug_u32 i;
    if (header == 0)
    {
        return;
    }
    memset(header, 0, sizeof(*header));
    for (i = 0; i < SNDMUG_SIGNATURE_SIZE; ++i)
    {
        header->signature[i] = sig[i];
    }
    header->version[0] = 1u;
    header->version[1] = 0u;
    header->version[2] = 0u;
    header->version[3] = 0u;
    header->sound_count = 0u;
    header->first_subfile_offset = 0u;
}
