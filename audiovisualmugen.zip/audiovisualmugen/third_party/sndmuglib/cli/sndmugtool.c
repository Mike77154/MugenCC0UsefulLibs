#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sndmug/sndmug.h"
#include "sndmug/sndmug_stdio.h"
#include "wavc89/wavc89_stdio.h"

#define SNDMUGTOOL_MAX_ENTRIES 1024u
#define SNDMUGTOOL_MAX_PATH 512u
#define SNDMUGTOOL_MAX_LINE 1024u

typedef struct manifest_item_t
{
    sndmug_desc desc;
    char path[SNDMUGTOOL_MAX_PATH];
} manifest_item;

static void print_usage(void)
{
    printf("sndmugtool list <in.snd>\n");
    printf("sndmugtool extract <in.snd> <out_dir>\n");
    printf("sndmugtool extract-one <in.snd> <group> <sound> <out.wav>\n");
    printf("sndmugtool build <out.snd> <manifest.txt>\n");
    printf("sndmugtool wavinfo <in.wav>\n");
}

static int command_list(const char *path)
{
    FILE *fp;
    sndmug_io io;
    sndmug_reader rd;
    sndmug_entry entries[SNDMUGTOOL_MAX_ENTRIES];
    int rc;
    sndmug_u32 i;

    fp = fopen(path, "rb");
    if (fp == 0)
    {
        perror(path);
        return 1;
    }

    rc = sndmug_io_stdio_reader_init(&io, fp);
    if (rc != SNDMUG_OK)
    {
        fclose(fp);
        return 1;
    }

    rc = sndmug_reader_open(&rd, &io, entries, SNDMUGTOOL_MAX_ENTRIES);
    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        fclose(fp);
        return 1;
    }

    printf("count=%lu header_count=%lu first_offset=%lu mismatch=%d\n",
           (unsigned long)rd.entry_count,
           (unsigned long)rd.header.sound_count,
           (unsigned long)rd.header.first_subfile_offset,
           rd.header_count_mismatch);

    for (i = 0u; i < rd.entry_count; ++i)
    {
        printf("[%lu] group=%lu sound=%lu payload=%lu entry=%lu next=%lu\n",
               (unsigned long)i,
               (unsigned long)rd.entries[i].group_no,
               (unsigned long)rd.entries[i].sound_no,
               (unsigned long)rd.entries[i].data_length,
               (unsigned long)rd.entries[i].entry_offset,
               (unsigned long)rd.entries[i].next_offset);
    }

    fclose(fp);
    return 0;
}

static int command_extract(const char *path, const char *out_dir)
{
    FILE *fp;
    sndmug_io io;
    sndmug_reader rd;
    sndmug_entry entries[SNDMUGTOOL_MAX_ENTRIES];
    int rc;
    sndmug_u32 i;

    fp = fopen(path, "rb");
    if (fp == 0)
    {
        perror(path);
        return 1;
    }

    rc = sndmug_io_stdio_reader_init(&io, fp);
    if (rc != SNDMUG_OK)
    {
        fclose(fp);
        return 1;
    }

    rc = sndmug_reader_open(&rd, &io, entries, SNDMUGTOOL_MAX_ENTRIES);
    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        fclose(fp);
        return 1;
    }

    for (i = 0u; i < rd.entry_count; ++i)
    {
        char out_path[SNDMUGTOOL_MAX_PATH];
        FILE *ofp;
        sndmug_io out_io;

        sprintf(out_path, "%s/%lu_%lu.wav", out_dir,
                (unsigned long)rd.entries[i].group_no,
                (unsigned long)rd.entries[i].sound_no);

        ofp = fopen(out_path, "wb");
        if (ofp == 0)
        {
            perror(out_path);
            fclose(fp);
            return 1;
        }

        sndmug_io_stdio_writer_init(&out_io, ofp);
        rc = sndmug_reader_copy_payload(&rd, i, &out_io);
        fclose(ofp);

        if (rc != SNDMUG_OK)
        {
            printf("error writing %s: %s\n", out_path, sndmug_status_string(rc));
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

static int command_extract_one(const char *path, sndmug_u32 group_no, sndmug_u32 sound_no, const char *out_path)
{
    FILE *fp;
    FILE *ofp;
    sndmug_io io;
    sndmug_io out_io;
    sndmug_reader rd;
    sndmug_entry entries[SNDMUGTOOL_MAX_ENTRIES];
    sndmug_u32 idx;
    int rc;

    fp = fopen(path, "rb");
    if (fp == 0)
    {
        perror(path);
        return 1;
    }

    rc = sndmug_io_stdio_reader_init(&io, fp);
    if (rc != SNDMUG_OK)
    {
        fclose(fp);
        return 1;
    }

    rc = sndmug_reader_open(&rd, &io, entries, SNDMUGTOOL_MAX_ENTRIES);
    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        fclose(fp);
        return 1;
    }

    rc = sndmug_reader_find(&rd, group_no, sound_no, &idx);
    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        fclose(fp);
        return 1;
    }

    ofp = fopen(out_path, "wb");
    if (ofp == 0)
    {
        perror(out_path);
        fclose(fp);
        return 1;
    }
    sndmug_io_stdio_writer_init(&out_io, ofp);
    rc = sndmug_reader_copy_payload(&rd, idx, &out_io);
    fclose(ofp);
    fclose(fp);

    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        return 1;
    }
    return 0;
}

static int load_manifest(const char *manifest_path, manifest_item *items, sndmug_u32 *out_count)
{
    FILE *fp;
    char line[SNDMUGTOOL_MAX_LINE];
    sndmug_u32 count;
    int group_i;
    int sound_i;
    char path[SNDMUGTOOL_MAX_PATH];

    if (manifest_path == 0 || items == 0 || out_count == 0)
    {
        return 1;
    }

    fp = fopen(manifest_path, "rb");
    if (fp == 0)
    {
        perror(manifest_path);
        return 1;
    }

    count = 0u;
    while (fgets(line, sizeof(line), fp) != 0)
    {
        char *p;
        size_t len;

        p = line;
        while (*p == ' ' || *p == '\t')
        {
            ++p;
        }
        if (*p == '#' || *p == '\n' || *p == '\r' || *p == '\0')
        {
            continue;
        }

        path[0] = '\0';
        if (sscanf(p, "%d %d %511s", &group_i, &sound_i, path) != 3)
        {
            printf("bad manifest line: %s\n", line);
            fclose(fp);
            return 1;
        }
        if (count >= SNDMUGTOOL_MAX_ENTRIES)
        {
            printf("manifest too large\n");
            fclose(fp);
            return 1;
        }

        items[count].desc.group_no = (sndmug_u32)group_i;
        items[count].desc.sound_no = (sndmug_u32)sound_i;
        items[count].desc.payload_io = 0;
        items[count].desc.payload_offset = 0u;
        items[count].desc.payload_size = 0u;

        len = strlen(path);
        if (len >= SNDMUGTOOL_MAX_PATH)
        {
            fclose(fp);
            return 1;
        }
        memcpy(items[count].path, path, len + 1u);
        count += 1u;
    }

    fclose(fp);
    *out_count = count;
    return 0;
}

static int command_build(const char *out_path, const char *manifest_path)
{
    manifest_item items[SNDMUGTOOL_MAX_ENTRIES];
    sndmug_u32 count;
    sndmug_u32 i;
    FILE *out_fp;
    sndmug_io out_io;
    sndmug_writer writer;
    int rc;

    if (load_manifest(manifest_path, items, &count) != 0)
    {
        return 1;
    }

    if (count == 0u)
    {
        printf("manifest empty\n");
        return 1;
    }

    {
        sndmug_desc sort_only[SNDMUGTOOL_MAX_ENTRIES];
        for (i = 0u; i < count; ++i)
        {
            sort_only[i].group_no = items[i].desc.group_no;
            sort_only[i].sound_no = items[i].desc.sound_no;
            sort_only[i].payload_io = 0;
            sort_only[i].payload_offset = 0u;
            sort_only[i].payload_size = 0u;
        }
        rc = sndmug_desc_sort(sort_only, count);
        if (rc != SNDMUG_OK)
        {
            printf("error: %s\n", sndmug_status_string(rc));
            return 1;
        }
        rc = sndmug_desc_validate_unique(sort_only, count);
        if (rc != SNDMUG_OK)
        {
            printf("error: %s\n", sndmug_status_string(rc));
            return 1;
        }

        for (i = 0u; i < count; ++i)
        {
            sndmug_u32 j;
            for (j = i; j < count; ++j)
            {
                if (items[j].desc.group_no == sort_only[i].group_no &&
                    items[j].desc.sound_no == sort_only[i].sound_no)
                {
                    manifest_item tmp;
                    tmp = items[i];
                    items[i] = items[j];
                    items[j] = tmp;
                    break;
                }
            }
        }
    }

    out_fp = fopen(out_path, "wb+");
    if (out_fp == 0)
    {
        perror(out_path);
        return 1;
    }

    sndmug_io_stdio_writer_init(&out_io, out_fp);
    rc = sndmug_writer_begin(&writer, &out_io, 0, 0);
    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        fclose(out_fp);
        return 1;
    }

    for (i = 0u; i < count; ++i)
    {
        FILE *wav_fp;
        sndmug_io wav_io;

        wav_fp = fopen(items[i].path, "rb");
        if (wav_fp == 0)
        {
            perror(items[i].path);
            fclose(out_fp);
            return 1;
        }

        sndmug_io_stdio_reader_init(&wav_io, wav_fp);
        rc = sndmug_writer_add_from_io(&writer, items[i].desc.group_no, items[i].desc.sound_no, &wav_io, 0u, 0u);
        fclose(wav_fp);

        if (rc != SNDMUG_OK)
        {
            printf("error adding %s: %s\n", items[i].path, sndmug_status_string(rc));
            fclose(out_fp);
            return 1;
        }
    }

    rc = sndmug_writer_finish(&writer);
    fclose(out_fp);

    if (rc != SNDMUG_OK)
    {
        printf("error: %s\n", sndmug_status_string(rc));
        return 1;
    }

    return 0;
}

static int command_wavinfo(const char *path)
{
    FILE *fp;
    wavc89_io io;
    wavc89_reader rd;
    int rc;

    fp = fopen(path, "rb");
    if (fp == 0)
    {
        perror(path);
        return 1;
    }

    rc = wavc89_io_stdio_reader_init(&io, fp);
    if (rc != WAVC89_OK)
    {
        fclose(fp);
        return 1;
    }

    rc = wavc89_reader_open(&rd, &io, 0u, 0u);
    if (rc != WAVC89_OK)
    {
        printf("error: %s\n", wavc89_status_string(rc));
        fclose(fp);
        return 1;
    }

    printf("format=%u channels=%u rate=%lu bps=%u data=%lu compatible=%d\n",
           (unsigned)rd.info.format_tag,
           (unsigned)rd.info.channels,
           (unsigned long)rd.info.sample_rate,
           (unsigned)rd.info.bits_per_sample,
           (unsigned long)rd.info.data_size,
           wavc89_is_mugen_compatible(&rd.info));

    fclose(fp);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 3)
    {
        print_usage();
        return 1;
    }

    if (strcmp(argv[1], "list") == 0 && argc == 3)
    {
        return command_list(argv[2]);
    }
    if (strcmp(argv[1], "extract") == 0 && argc == 4)
    {
        return command_extract(argv[2], argv[3]);
    }
    if (strcmp(argv[1], "extract-one") == 0 && argc == 6)
    {
        return command_extract_one(argv[2], (sndmug_u32)strtoul(argv[3], 0, 10), (sndmug_u32)strtoul(argv[4], 0, 10), argv[5]);
    }
    if (strcmp(argv[1], "build") == 0 && argc == 4)
    {
        return command_build(argv[2], argv[3]);
    }
    if (strcmp(argv[1], "wavinfo") == 0 && argc == 3)
    {
        return command_wavinfo(argv[2]);
    }

    print_usage();
    return 1;
}
