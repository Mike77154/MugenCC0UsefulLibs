#ifndef SNDMUG_H
#define SNDMUG_H

#include "sndmug_types.h"
#include "sndmug_status.h"
#include "sndmug_fixed.h"
#include "sndmug_io.h"
#include "wavc89/wavc89.h"

#define SNDMUG_SIGNATURE_SIZE 12u
#define SNDMUG_HEADER_SIZE 512u
#define SNDMUG_COMMENT_SIZE 488u

typedef struct sndmug_snd_header_t
{
    sndmug_u8 signature[SNDMUG_SIGNATURE_SIZE];
    sndmug_u8 version[4];
    sndmug_u32 sound_count;
    sndmug_u32 first_subfile_offset;
    sndmug_u8 comment[SNDMUG_COMMENT_SIZE];
} sndmug_snd_header;

typedef struct sndmug_entry_t
{
    sndmug_u32 entry_offset;
    sndmug_u32 next_offset;
    sndmug_u32 data_length;
    sndmug_u32 group_no;
    sndmug_u32 sound_no;
    sndmug_u32 data_offset;
} sndmug_entry;

typedef struct sndmug_reader_t
{
    sndmug_io io;
    sndmug_snd_header header;
    sndmug_entry *entries;
    sndmug_u32 entry_capacity;
    sndmug_u32 entry_count;
    sndmug_u32 file_size;
    int header_count_mismatch;
} sndmug_reader;


typedef struct sndmug_pair_index_t
{
    sndmug_u32 group_no;
    sndmug_u32 sound_no;
    sndmug_u32 entry_index;
} sndmug_pair_index;

typedef struct sndmug_writer_t
{
    sndmug_io io;
    sndmug_u8 version[4];
    sndmug_u8 comment[SNDMUG_COMMENT_SIZE];
    sndmug_u32 first_entry_offset;
    sndmug_u32 last_entry_offset;
    sndmug_u32 sound_count;
    int started;
} sndmug_writer;

typedef struct sndmug_desc_t
{
    sndmug_u32 group_no;
    sndmug_u32 sound_no;
    const sndmug_io *payload_io;
    sndmug_u32 payload_offset;
    sndmug_u32 payload_size;
} sndmug_desc;

void sndmug_header_init(sndmug_snd_header *header);
int sndmug_reader_open(sndmug_reader *reader, const sndmug_io *io, sndmug_entry *entries, sndmug_u32 entry_capacity);
int sndmug_reader_find(const sndmug_reader *reader, sndmug_u32 group_no, sndmug_u32 sound_no, sndmug_u32 *out_index);
int sndmug_reader_read_payload(const sndmug_reader *reader, sndmug_u32 index, void *dst, sndmug_u32 capacity, sndmug_u32 *out_size);
int sndmug_reader_copy_payload(const sndmug_reader *reader, sndmug_u32 index, sndmug_io *dst);
int sndmug_reader_get_wav_info(const sndmug_reader *reader, sndmug_u32 index, wavc89_info *out_info);

int sndmug_writer_begin(sndmug_writer *writer, const sndmug_io *io, const sndmug_u8 version[4], const sndmug_u8 comment[SNDMUG_COMMENT_SIZE]);
int sndmug_writer_add_from_io(sndmug_writer *writer, sndmug_u32 group_no, sndmug_u32 sound_no, const sndmug_io *payload_io, sndmug_u32 payload_offset, sndmug_u32 payload_size);
int sndmug_writer_add_from_memory(sndmug_writer *writer, sndmug_u32 group_no, sndmug_u32 sound_no, const void *wav_bytes, sndmug_u32 wav_size);
int sndmug_writer_finish(sndmug_writer *writer);

int sndmug_desc_sort(sndmug_desc *descs, sndmug_u32 count);
int sndmug_desc_validate_unique(const sndmug_desc *descs, sndmug_u32 count);
int sndmug_build_from_descs(const sndmug_io *dst, const sndmug_u8 version[4], const sndmug_u8 comment[SNDMUG_COMMENT_SIZE], sndmug_desc *descs, sndmug_u32 count);
int sndmug_pair_index_build(const sndmug_reader *reader, sndmug_pair_index *index, sndmug_u32 capacity);
int sndmug_pair_index_find(const sndmug_pair_index *index, sndmug_u32 count, sndmug_u32 group_no, sndmug_u32 sound_no, sndmug_u32 *out_entry_index);

#endif
