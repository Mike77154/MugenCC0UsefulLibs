#ifndef SNDMUG_TYPES_H
#define SNDMUG_TYPES_H

#include <limits.h>

#if CHAR_BIT != 8
#error "sndmug requires 8-bit bytes"
#endif

typedef unsigned char sndmug_u8;

#if USHRT_MAX == 0xFFFFu
typedef unsigned short sndmug_u16;
#elif UINT_MAX == 0xFFFFu
typedef unsigned int sndmug_u16;
#else
#error "sndmug requires a 16-bit unsigned type"
#endif

#if UINT_MAX == 0xFFFFFFFFUL
typedef unsigned int sndmug_u32;
#elif ULONG_MAX == 0xFFFFFFFFUL
typedef unsigned long sndmug_u32;
#else
#error "sndmug requires a 32-bit unsigned type"
#endif

#if SCHAR_MAX == 0x7F
typedef signed char sndmug_s8;
#else
#error "sndmug requires an 8-bit signed type"
#endif

#if SHRT_MAX == 0x7FFF
typedef signed short sndmug_s16;
#elif INT_MAX == 0x7FFF
typedef signed int sndmug_s16;
#else
#error "sndmug requires a 16-bit signed type"
#endif

#if INT_MAX == 0x7FFFFFFFL
typedef signed int sndmug_s32;
#elif LONG_MAX == 0x7FFFFFFFL
typedef signed long sndmug_s32;
#else
#error "sndmug requires a 32-bit signed type"
#endif

#endif
