#ifndef SNDMUG_IO_H
#define SNDMUG_IO_H

#include "sndmug_types.h"

typedef int (*sndmug_read_fn)(void *user, void *dst, sndmug_u32 size, sndmug_u32 *out_read);
typedef int (*sndmug_write_fn)(void *user, const void *src, sndmug_u32 size, sndmug_u32 *out_written);
typedef int (*sndmug_seek_fn)(void *user, sndmug_u32 absolute_offset);
typedef int (*sndmug_tell_fn)(void *user, sndmug_u32 *out_offset);
typedef int (*sndmug_size_fn)(void *user, sndmug_u32 *out_size);

typedef struct sndmug_io_t
{
    sndmug_read_fn read;
    sndmug_write_fn write;
    sndmug_seek_fn seek;
    sndmug_tell_fn tell;
    sndmug_size_fn size;
    void *user;
} sndmug_io;

typedef struct sndmug_mem_reader_t
{
    const sndmug_u8 *data;
    sndmug_u32 size;
    sndmug_u32 pos;
} sndmug_mem_reader;

typedef struct sndmug_mem_writer_t
{
    sndmug_u8 *data;
    sndmug_u32 capacity;
    sndmug_u32 pos;
    sndmug_u32 size;
} sndmug_mem_writer;

int sndmug_io_mem_reader_init(sndmug_io *io, sndmug_mem_reader *ctx, const void *data, sndmug_u32 size);
int sndmug_io_mem_writer_init(sndmug_io *io, sndmug_mem_writer *ctx, void *data, sndmug_u32 capacity);

#endif
