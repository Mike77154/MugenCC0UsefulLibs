#ifndef SNDMUG_STDIO_H
#define SNDMUG_STDIO_H

#include <stdio.h>
#include "sndmug_io.h"

int sndmug_io_stdio_reader_init(sndmug_io *io, FILE *fp);
int sndmug_io_stdio_writer_init(sndmug_io *io, FILE *fp);

#endif
