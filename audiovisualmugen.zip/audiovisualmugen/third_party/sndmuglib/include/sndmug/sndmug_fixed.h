#ifndef SNDMUG_FIXED_H
#define SNDMUG_FIXED_H

#include "sndmug_types.h"

#define SNDMUG_Q15_ONE ((sndmug_s32)32768L)
#define SNDMUG_Q16_ONE ((sndmug_s32)65536L)

sndmug_s32 sndmug_q15_mul(sndmug_s32 a, sndmug_s32 b);
sndmug_s32 sndmug_q15_from_ratio(sndmug_s32 num, sndmug_s32 den);

#endif
