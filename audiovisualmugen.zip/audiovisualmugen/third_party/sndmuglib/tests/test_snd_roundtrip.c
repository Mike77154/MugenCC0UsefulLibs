#include <stdio.h>
#include <string.h>
#include "sndmug/sndmug.h"

#define TEST_ASSERT(x) do { if (!(x)) { printf("assert fail: %s line %d\n", #x, __LINE__); return 1; } } while (0)

static int build_test_wav(sndmug_u8 *dst, sndmug_u32 capacity, sndmug_u32 *out_size, int seed, int adpcm_mode)
{
    wavc89_s16 pcm[257];
    wavc89_io io;
    wavc89_mem_writer mem;
    wavc89_u16 block_align;
    int i;
    int rc;

    for (i = 0; i < 257; ++i)
    {
        pcm[i] = (wavc89_s16)((((i * 700) + (seed * 333)) & 0x7FFF) - 16384);
    }

    rc = wavc89_io_mem_writer_init(&io, &mem, dst, capacity);
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    if (adpcm_mode == 0)
    {
        rc = wavc89_writer_write_pcm_from_memory(&io, 1u, 11025u, 16u, pcm, (wavc89_u32)sizeof(pcm));
    }
    else if (adpcm_mode == 1)
    {
        rc = wavc89_msadpcm_block_align(1u, 62u, &block_align);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        rc = wavc89_writer_write_msadpcm_from_s16(&io, 1u, 11025u, pcm, 257u, block_align);
    }
    else
    {
        rc = wavc89_imaadpcm_block_align(1u, 249u, &block_align);
        if (rc != WAVC89_OK)
        {
            return rc;
        }
        rc = wavc89_writer_write_imaadpcm_from_s16(&io, 1u, 11025u, pcm, 257u, block_align);
    }
    if (rc != WAVC89_OK)
    {
        return rc;
    }

    *out_size = mem.size;
    return 0;
}

int main(void)
{
    sndmug_u8 wav1[1024];
    sndmug_u8 wav2[1024];
    sndmug_u8 wav3[1024];
    sndmug_u32 wav1_size;
    sndmug_u32 wav2_size;
    sndmug_u32 wav3_size;

    sndmug_u8 snd_buf[8192];
    sndmug_io snd_out_io;
    sndmug_mem_writer snd_out_mem;
    sndmug_writer wr;

    sndmug_io snd_in_io;
    sndmug_mem_reader snd_in_mem;
    sndmug_reader rd;
    sndmug_entry entries[16];

    sndmug_u8 out_payload[1024];
    sndmug_u32 out_size;
    sndmug_u32 idx;
    int rc;

    rc = build_test_wav(wav1, (sndmug_u32)sizeof(wav1), &wav1_size, 1, 0);
    TEST_ASSERT(rc == 0);
    rc = build_test_wav(wav2, (sndmug_u32)sizeof(wav2), &wav2_size, 2, 1);
    TEST_ASSERT(rc == 0);
    rc = build_test_wav(wav3, (sndmug_u32)sizeof(wav3), &wav3_size, 3, 2);
    TEST_ASSERT(rc == 0);

    rc = sndmug_io_mem_writer_init(&snd_out_io, &snd_out_mem, snd_buf, (sndmug_u32)sizeof(snd_buf));
    TEST_ASSERT(rc == SNDMUG_OK);

    rc = sndmug_writer_begin(&wr, &snd_out_io, 0, 0);
    TEST_ASSERT(rc == SNDMUG_OK);
    rc = sndmug_writer_add_from_memory(&wr, 1u, 0u, wav1, wav1_size);
    TEST_ASSERT(rc == SNDMUG_OK);
    rc = sndmug_writer_add_from_memory(&wr, 2u, 3u, wav2, wav2_size);
    TEST_ASSERT(rc == SNDMUG_OK);
    rc = sndmug_writer_add_from_memory(&wr, 4u, 5u, wav3, wav3_size);
    TEST_ASSERT(rc == SNDMUG_OK);
    rc = sndmug_writer_finish(&wr);
    TEST_ASSERT(rc == SNDMUG_OK);

    rc = sndmug_io_mem_reader_init(&snd_in_io, &snd_in_mem, snd_buf, snd_out_mem.size);
    TEST_ASSERT(rc == SNDMUG_OK);

    rc = sndmug_reader_open(&rd, &snd_in_io, entries, 16u);
    TEST_ASSERT(rc == SNDMUG_OK);
    TEST_ASSERT(rd.entry_count == 3u);

    rc = sndmug_reader_find(&rd, 4u, 5u, &idx);
    TEST_ASSERT(rc == SNDMUG_OK);
    rc = sndmug_reader_read_payload(&rd, idx, out_payload, (sndmug_u32)sizeof(out_payload), &out_size);
    TEST_ASSERT(rc == SNDMUG_OK);
    TEST_ASSERT(out_size == wav3_size);
    TEST_ASSERT(memcmp(out_payload, wav3, wav3_size) == 0);

    {
        wavc89_info info;
        rc = sndmug_reader_get_wav_info(&rd, idx, &info);
        TEST_ASSERT(rc == SNDMUG_OK);
        TEST_ASSERT(info.format_tag == WAVC89_FORMAT_IMA_ADPCM);
        TEST_ASSERT(info.sample_rate == 11025u);
        TEST_ASSERT(info.adpcm_samples_per_block == 249u);
    }

    rc = sndmug_reader_find(&rd, 2u, 3u, &idx);
    TEST_ASSERT(rc == SNDMUG_OK);
    {
        wavc89_info info;
        rc = sndmug_reader_get_wav_info(&rd, idx, &info);
        TEST_ASSERT(rc == SNDMUG_OK);
        TEST_ASSERT(info.format_tag == WAVC89_FORMAT_MS_ADPCM);
        TEST_ASSERT(info.sample_rate == 11025u);
        TEST_ASSERT(info.adpcm_num_coef == WAVC89_MSADPCM_COEF_COUNT);
    }

    printf("test_snd_roundtrip: ok\n");
    return 0;
}
