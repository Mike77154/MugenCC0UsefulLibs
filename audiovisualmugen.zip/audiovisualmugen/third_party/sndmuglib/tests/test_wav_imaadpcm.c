#include <stdio.h>
#include "wavc89/wavc89.h"

#define TEST_ASSERT(x) do { if (!(x)) { printf("assert fail: %s line %d\n", #x, __LINE__); return 1; } } while (0)

static wavc89_s32 abs_s32(wavc89_s32 v)
{
    return (v < 0) ? -v : v;
}

int main(void)
{
    wavc89_s16 pcm[257u * 2u];
    wavc89_u8 wav_buf[4096];
    wavc89_u8 raw_adpcm[2048];
    wavc89_io out_io;
    wavc89_mem_writer out_mem;
    wavc89_io in_io;
    wavc89_mem_reader in_mem;
    wavc89_reader rd;
    wavc89_u8 data_buf[2048];
    wavc89_u32 data_size;
    wavc89_s16 decoded[257u * 2u];
    wavc89_u32 sample_count;
    wavc89_u32 raw_size;
    wavc89_u16 samples_per_block;
    wavc89_u16 block_align;
    wavc89_u32 i;
    wavc89_s32 max_err;
    int rc;

    for (i = 0u; i < 257u; ++i)
    {
        wavc89_s32 phase_l;
        wavc89_s32 phase_r;
        wavc89_s32 lv;
        wavc89_s32 rv;

        phase_l = (wavc89_s32)(i & 63u);
        phase_r = (wavc89_s32)((i + 16u) & 63u);

        if (phase_l < 32L)
        {
            lv = -14000L + (phase_l * 900L);
        }
        else
        {
            lv = 14800L - ((phase_l - 32L) * 900L);
        }

        if (phase_r < 32L)
        {
            rv = -10000L + (phase_r * 700L);
        }
        else
        {
            rv = 11800L - ((phase_r - 32L) * 700L);
        }

        pcm[i * 2u + 0u] = (wavc89_s16)lv;
        pcm[i * 2u + 1u] = (wavc89_s16)rv;
    }

    rc = wavc89_imaadpcm_block_align(2u, 249u, &block_align);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(block_align == 256u);

    rc = wavc89_imaadpcm_encode_from_s16(2u, pcm, 257u, block_align, raw_adpcm, (wavc89_u32)sizeof(raw_adpcm), &raw_size, &samples_per_block);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(samples_per_block == 249u);
    TEST_ASSERT(raw_size == (wavc89_u32)(256u + 16u));

    rc = wavc89_io_mem_writer_init(&out_io, &out_mem, wav_buf, (wavc89_u32)sizeof(wav_buf));
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_writer_write_imaadpcm_from_s16(&out_io, 2u, 22050u, pcm, 257u, block_align);
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_io_mem_reader_init(&in_io, &in_mem, wav_buf, out_mem.size);
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_reader_open(&rd, &in_io, 0u, 0u);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(rd.info.format_tag == WAVC89_FORMAT_IMA_ADPCM);
    TEST_ASSERT(rd.info.channels == 2u);
    TEST_ASSERT(rd.info.bits_per_sample == 4u);
    TEST_ASSERT(rd.info.adpcm_samples_per_block == samples_per_block);
    TEST_ASSERT(rd.info.fact_sample_length == 257u);
    TEST_ASSERT(wavc89_is_mugen_compatible(&rd.info) == 1);

    rc = wavc89_reader_read_data(&rd, 0u, data_buf, (wavc89_u32)sizeof(data_buf), &data_size);
    TEST_ASSERT(rc == WAVC89_E_SHORT_READ || rc == WAVC89_OK);
    TEST_ASSERT(data_size == rd.info.data_size);
    TEST_ASSERT(data_size == raw_size);

    rc = wavc89_decode_to_s16(&rd.info, data_buf, data_size, decoded, (wavc89_u32)(257u * 2u), &sample_count);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(sample_count == (wavc89_u32)(257u * 2u));

    max_err = 0;
    for (i = 0u; i < (wavc89_u32)(257u * 2u); ++i)
    {
        wavc89_s32 diff;
        diff = abs_s32((wavc89_s32)pcm[i] - (wavc89_s32)decoded[i]);
        if (diff > max_err)
        {
            max_err = diff;
        }
    }

    TEST_ASSERT(max_err < 8000L);

    printf("test_wav_imaadpcm: ok\n");
    return 0;
}
