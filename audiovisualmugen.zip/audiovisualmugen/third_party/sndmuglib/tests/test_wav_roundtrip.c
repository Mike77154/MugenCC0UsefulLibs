#include <stdio.h>
#include <string.h>
#include "wavc89/wavc89.h"

#define TEST_ASSERT(x) do { if (!(x)) { printf("assert fail: %s line %d\n", #x, __LINE__); return 1; } } while (0)

int main(void)
{
    static const wavc89_s16 pcm_samples[16] = {
        0, 1000, -1000, 2000, -2000, 3000, -3000, 4000,
        -4000, 5000, -5000, 6000, -6000, 7000, -7000, 8000
    };
    wavc89_u8 wav_buf[2048];
    wavc89_io out_io;
    wavc89_mem_writer out_mem;
    wavc89_io in_io;
    wavc89_mem_reader in_mem;
    wavc89_reader rd;
    wavc89_u8 raw_pcm[sizeof(pcm_samples)];
    wavc89_s16 decoded[16];
    wavc89_u32 got_size;
    wavc89_u32 samples_out;
    int rc;

    rc = wavc89_io_mem_writer_init(&out_io, &out_mem, wav_buf, (wavc89_u32)sizeof(wav_buf));
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_writer_write_pcm_from_memory(&out_io, 1u, 22050u, 16u, pcm_samples, (wavc89_u32)sizeof(pcm_samples));
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_io_mem_reader_init(&in_io, &in_mem, wav_buf, out_mem.size);
    TEST_ASSERT(rc == WAVC89_OK);

    rc = wavc89_reader_open(&rd, &in_io, 0u, 0u);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(rd.info.format_tag == WAVC89_FORMAT_PCM);
    TEST_ASSERT(rd.info.channels == 1u);
    TEST_ASSERT(rd.info.sample_rate == 22050u);
    TEST_ASSERT(rd.info.bits_per_sample == 16u);

    rc = wavc89_reader_read_data(&rd, 0u, raw_pcm, (wavc89_u32)sizeof(raw_pcm), &got_size);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(got_size == (wavc89_u32)sizeof(raw_pcm));

    rc = wavc89_pcm_decode_to_s16(&rd.info, raw_pcm, got_size, decoded, 16u, &samples_out);
    TEST_ASSERT(rc == WAVC89_OK);
    TEST_ASSERT(samples_out == 16u);
    TEST_ASSERT(memcmp(decoded, pcm_samples, sizeof(pcm_samples)) == 0);

    printf("test_wav_roundtrip: ok\n");
    return 0;
}
