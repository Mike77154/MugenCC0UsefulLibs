# sndmuglib

`sndmuglib` is a C89, no-heap, no-malloc, integer-only toolkit for M.U.G.E.N `.snd`
files plus a separate `wavc89` sublibrary for RIFF/WAVE parsing, writing, and
sample-level audio conversion.

## Design goals

- C89
- no `malloc`, no heap allocation
- no `float`, no `double`
- integer-only / fixed-point friendly
- embeddable I/O callback layer
- separate `wavc89/` sublibrary consumed by `sndmug`
- deterministic writer and pair-index builder
- file and memory backends
- tests and CLI

## Tree

```text
sndmuglib/
├── include/sndmug/
│   ├── sndmug.h
│   ├── sndmug_fixed.h
│   ├── sndmug_io.h
│   ├── sndmug_status.h
│   ├── sndmug_stdio.h
│   └── sndmug_types.h
├── src/
│   ├── sndmug_io_mem.c
│   ├── sndmug_io_stdio.c
│   ├── sndmug_status.c
│   ├── sndmug_utils.c
│   ├── sndmug_reader.c
│   ├── sndmug_writer.c
│   ├── sndmug_index.c
│   └── sndmug_wav_bridge.c
├── sublibs/wavc89/
│   ├── include/wavc89/
│   └── src/
├── cli/
│   └── sndmugtool.c
├── tests/
│   ├── test_wav_roundtrip.c
│   ├── test_wav_msadpcm.c
│   ├── test_wav_imaadpcm.c
│   └── test_snd_roundtrip.c
└── Makefile
```

## Build

```sh
make
make test
```

## CLI

```sh
./bin/sndmugtool list some.snd
./bin/sndmugtool extract some.snd out_dir
./bin/sndmugtool extract-one some.snd 1 0 out.wav
./bin/sndmugtool build out.snd manifest.txt
./bin/sndmugtool wavinfo hit.wav
```

Manifest format for `build`:

```text
# group sound path
0 0 intro.wav
1 0 punch.wav
1 1 kick.wav
```

Paths are parsed as a single token without spaces.

## `wavc89` capabilities

- RIFF/WAVE parser for `fmt`, `data`, and optional `fact`
- PCM 8-bit / 16-bit sample decode and encode helpers
- Microsoft ADPCM (`WAVE_FORMAT_ADPCM`, tag `0x0002`) sample-level decode
- Microsoft ADPCM sample-level encode with real nibble quantization
- IMA/DVI ADPCM (`WAVE_FORMAT_IMA_ADPCM`, tag `0x0011`) sample-level decode
- IMA/DVI ADPCM sample-level encode with real nibble quantization
- WAV writer helpers for PCM, Microsoft ADPCM, and IMA/DVI ADPCM
- Q15 fixed-point helpers for gain and downmix

## Important ADPCM notes

`wavc89` now implements both ADPCM variants commonly seen in WAV payloads for MUGEN work:

- **Microsoft ADPCM** (`0x0002`)
- **IMA/DVI ADPCM** (`0x0011`)

For IMA/DVI ADPCM, blocks are emitted on the format's 32-bit word boundaries with
`wSamplesPerBlock` stored in the `fmt` extra data and the exact frame count stored in the
`fact` chunk. A tail block that is not an exact `1 + 8N` frame count is rounded to the
next channel-word boundary inside the compressed data, so decoders that ignore `fact` may
expose padded tail samples. `wavc89`'s own decoder respects the `fact` length when present.

The Microsoft ADPCM encoder writes a partial last block so decoders that honor RIFF chunk
lengths can stop cleanly at the real tail.

## Example: encode PCM samples to WAV ADPCM

```c
wavc89_s16 pcm[1024];
wavc89_io out_io;
wavc89_mem_writer out_mem;
int rc;

rc = wavc89_io_mem_writer_init(&out_io, &out_mem, wav_buf, wav_buf_capacity);
rc = wavc89_writer_write_msadpcm_from_s16(&out_io, 1u, 22050u, pcm, 1024u, 256u);
```

## Example: encode PCM samples to WAV IMA ADPCM

```c
wavc89_s16 pcm[1024];
wavc89_io out_io;
wavc89_mem_writer out_mem;
wavc89_u16 block_align;
int rc;

rc = wavc89_imaadpcm_block_align(1u, 505u, &block_align);
rc = wavc89_io_mem_writer_init(&out_io, &out_mem, wav_buf, wav_buf_capacity);
rc = wavc89_writer_write_imaadpcm_from_s16(&out_io, 1u, 22050u, pcm, 1024u, block_align);
```

## Example: decode WAV payload samples

```c
wavc89_reader rd;
wavc89_u8 raw_data[2048];
wavc89_u32 raw_size;
wavc89_s16 samples[4096];
wavc89_u32 sample_count;

rc = wavc89_reader_open(&rd, &io, 0u, 0u);
rc = wavc89_reader_read_data(&rd, 0u, raw_data, sizeof(raw_data), &raw_size);
rc = wavc89_decode_to_s16(&rd.info, raw_data, raw_size, samples, 4096u, &sample_count);
```

## Notes

- `sndmug` validates SND structure and validates that payloads are RIFF/WAVE before writing.
- `sndmug` accepts PCM, Microsoft ADPCM, or IMA/DVI ADPCM WAV payloads when they pass `wavc89_is_mugen_compatible`.
- Writer version bytes default to `{1,0,0,0}` unless you provide your own 4 raw bytes.

## License

MIT / CC0 friendly. See `LICENSE`.

## Pair index API

You can build a sorted `(group,sound) -> entry_index` side index into caller-owned memory with:

```c
sndmug_pair_index index[256];
rc = sndmug_pair_index_build(&reader, index, 256u);
rc = sndmug_pair_index_find(index, reader.entry_count, 1u, 0u, &entry_index);
```
