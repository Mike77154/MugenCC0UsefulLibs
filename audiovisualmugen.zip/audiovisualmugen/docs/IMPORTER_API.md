# API del importador

Header público:

```c
#include "audiovisualmugen/audiovisualmugen.h"
```

## Inicialización mínima

```c
static char def_text[65535u];
static char air_text[2u * 1024u * 1024u];
static unsigned char air_assets[12u * 1024u * 1024u];
static unsigned char air_scratch[64u * 1024u * 1024u];
static sndmug_entry sound_entries[4096u];

static avm_character character;
avm_memory memory;
avm_report report;
avm_file_api files;
avm_status status;

avm_character_init(&character);
avm_memory_init(&memory);

memory.def_text = def_text;
memory.def_text_capacity = sizeof(def_text);
memory.air_text = air_text;
memory.air_text_capacity = sizeof(air_text);
memory.air_asset_memory = air_assets;
memory.air_asset_capacity = sizeof(air_assets);
memory.air_scratch_memory = air_scratch;
memory.air_scratch_capacity = sizeof(air_scratch);
memory.snd_entries = sound_entries;
memory.snd_entry_capacity = 4096u;

/* Rellenar files con el VFS del host. */
status = avm_character_open(&character,
                            "chars/kfm/kfm.def",
                            &files,
                            &memory,
                            &report);

if (status == AVM_STATUS_OK &&
    (report.warning_flags & AVM_WARNING_AIR_RECOVERED) != 0u) {
    /* El AIR se cargó aplicando compatibilidad tolerante. */
}
```

## Sprites

```c
avm_u32 count;
avm_u16 width;
avm_u16 height;
avm_status status;

count = avm_character_sprite_count(&character);
status = avm_character_decode_sprite_rgba(&character,
                                           0u,
                                           rgba,
                                           rgba_capacity,
                                           &width,
                                           &height,
                                           work,
                                           work_capacity);
```

El decode es bajo demanda. `rgba` y `work` pertenecen al caller.

Para leer metadatos o resolver lo que referencia un frame AIR:

```c
SffSpriteInfo info;
avm_u32 sprite_index;

status = avm_character_sprite_info(&character, 0u, &info);
status = avm_character_find_sprite(&character,
                                   (avm_u16)group_no,
                                   (avm_u16)image_no,
                                   &sprite_index);
```

## Acciones AIR

```c
const air_action *action;
action = avm_character_action_at(&character, action_index);
```

También se puede buscar por el número escrito en `[Begin Action n]`:

```c
avm_u32 action_index;
status = avm_character_find_action(&character, 200, &action_index);
```

El objeto público expone `air_program_data` y `air_runtime_data` para consumidores que necesiten playback o cajas transformadas.

## Sonidos

```c
const sndmug_entry *entry;
avm_u32 payload_size;

entry = avm_character_sound_at(&character, sound_index);
status = avm_character_read_sound_payload(&character,
                                          sound_index,
                                          payload,
                                          payload_capacity,
                                          &payload_size);
```

La biblioteca devuelve el RIFF/WAVE contenido por el SND. También puede buscar una entrada por pareja:

```c
avm_u32 sound_index;
status = avm_character_find_sound(&character, 0u, 1u, &sound_index);
```

Decodificarlo o reproducirlo corresponde al consumidor.

## Cierre

```c
avm_character_close(&character);
```

El cierre libera recursos del host mediante `file_api.close`; no libera memoria porque los buffers siguen siendo del caller.

## Estados importantes

| Estado | Significado |
|---|---|
| `AVM_STATUS_OK` | Personaje importado |
| `AVM_STATUS_DEF_*` | Fallo en definición o rutas |
| `AVM_STATUS_SFF_*` | SFF obligatorio ausente o inválido |
| `AVM_STATUS_AIR_*` | AIR obligatorio ausente, grande o inválido |
| `AVM_STATUS_CAPACITY` | Buffer del caller insuficiente |
| `AVM_STATUS_NOT_FOUND` | Referencia `group,image` inexistente |
| `AVM_STATUS_DECODE_FAILED` | Recurso corrupto o no soportado |

## Warnings

| Flag | Significado |
|---|---|
| `AVM_WARNING_AIR_RECOVERED` | Se corrigió una inconsistencia AIR tolerable sin perder la carga |
| `AVM_WARNING_SND_OPEN_FAILED` | No se pudo abrir el SND opcional |
| `AVM_WARNING_SND_PARSE_FAILED` | El SND opcional abrió pero no pudo indexarse |
