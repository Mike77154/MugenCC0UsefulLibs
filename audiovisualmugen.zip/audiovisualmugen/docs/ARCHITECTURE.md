# Arquitectura de audiovisualmugen

## Objetivo de separación

El visor no debe convertirse en la única forma de usar el parser. Por eso hay dos productos:

1. `libaudiovisualmugen.a`: importador audiovisual independiente de plataforma.
2. `audiovisualmugen.exe`: front-end Win32 que dibuja y reproduce lo importado.

## Flujo de carga

```text
character.def
    │
    ├─ parse DEF/INI ────────────────► metadatos [Info]
    │
    └─ resolver [Files]
         ├─ sprite = character.sff ──► índice SFF + decode bajo demanda
         ├─ anim   = character.air ──► texto → AST → IR → VM/runtime
         └─ sound  = character.snd ──► índice de entradas WAV
```

`avm_character_open()` realiza una transacción: si falla un recurso obligatorio,
cierra los handles que ya abrió y deja `loaded == 0`. El SND es opcional; su
fallo queda en `warning_flags`. Una recuperación AIR compatible con archivos
reales de Elecbyte no invalida el personaje y activa
`AVM_WARNING_AIR_RECOVERED`.

## Propiedad de memoria

```text
HOST
 ├─ avm_memory.def_text
 ├─ avm_memory.air_text
 ├─ avm_memory.air_asset_memory
 ├─ avm_memory.air_scratch_memory
 └─ avm_memory.snd_entries

IMPORTER
 ├─ sólo conserva punteros/capacidades
 ├─ construye índices dentro de los buffers del host
 └─ conserva handles SFF/SND hasta avm_character_close()
```

No hay asignador interno ni callback de asignación. La única política posible ante falta de espacio es devolver `AVM_STATUS_CAPACITY` o el error específico del recurso.

## Adaptadores de I/O

La API `avm_file_api` necesita cuatro operaciones:

```c
open_read(user, path)
close(user, file)
read_at(user, file, offset, dst, size, out_read)
get_size(user, file, out_size)
```

Esto permite usar Win32, stdio de prueba, un archivo empaquetado, memoria mapeada, ROM o el VFS del engine sin modificar los parsers.

## AIR y frame stepping

La capa AIR se compila a un programa inmutable. Hay dos rutas de inspección:

- `air_runtime`: reproducción temporal a ticks.
- `air_vm_step_elem`: avance exacto por elemento para inspección frame a frame.

El visor no intenta inferir una animación desde el orden del SFF; siempre respeta las referencias `group,image` escritas en AIR.

## SFF v1, PCX y paletas compartidas

El SFF permanece abierto como una fuente aleatoria de 32 bits; no se copia el
archivo completo. En SFF v1, `same_palette` determina el propietario de paleta.
Para fuentes por callbacks, el decoder lee únicamente los 769 bytes finales del
PCX propietario cuando necesita la paleta VGA.

La presencia de paleta no se decide sólo por el byte `0x0C` en `size-769`.
Primero se recorre el RLE hasta producir todas las scanlines declaradas; el
marcador sólo es válido si queda después del final real de la imagen. Esto evita
truncar PCX sin paleta creados por Fighter Factory/VirtualTek.

En modo permisivo, la declaración `Clsn1: N` o `Clsn2: N` es dueña de los N
rectángulos siguientes. Esto permite cargar los KFM de referencia, donde hay
algunas etiquetas de rectángulo copiadas con el tipo equivocado, sin perder la
intención de la declaración.

## Cajas

Las cajas se obtienen del `air_pose_sample` actual y se transforman con:

- offset X/Y del elemento;
- escala Q16.16;
- facing/flip horizontal;
- política visual sin rotación de cajas.

`Clsn1` se dibuja roja y `Clsn2` azul.

## Audio

Cada entrada SND se lee a un buffer estático. El WAV embebido se decodifica a
PCM16 en otro buffer estático y el front-end lo entrega a `waveOut`. El lector
acepta tanto `next_offset == 0` como `next_offset == file_size` para terminar la
lista, y tolera un chunk WAV terminal impar sin padding. El importador no
reproduce audio: sólo indexa y expone payloads.

## Capas reusables

```text
Engine futuro
  ├─ su VFS implementa avm_file_api
  ├─ su arena estática rellena avm_memory
  ├─ usa avm_character para importar
  ├─ su renderer consume SFF/AIR
  └─ su mixer consume payloads SND
```
