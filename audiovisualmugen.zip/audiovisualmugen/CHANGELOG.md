# Changelog

## 0.1.4 - 2026-08-02

- Elevado el límite SFF v1/v2 a 8192 sprites y el mapa a 16384 slots; Hokuto
  contiene 4787 sprites y ya no falla al abrir por capacidad.
- Corregida la detección de paleta VGA en PCX: un byte `0x0C` situado por azar
  769 bytes antes del final ya no hace que el decoder recorte 769 bytes de RLE.
- Las paletas compartidas SFF v1 funcionan igual con archivos en memoria y con
  I/O por callbacks; el propietario se deriva de `same_palette` y la cola de
  769 bytes se lee directamente.
- Límites AIR ampliados para archivos reales grandes: 65535 líneas, 1048576
  tokens, 131072 instrucciones y archivo de 2 MiB.
- Reducido el almacenamiento por línea AIR a 32 tokens, suficiente para los 16
  campos CSV soportados, y ampliado el scratch Win32 a 64 MiB.
- El campo flip AIR acepta el valor numérico `0` como `AIR_FLIP_NONE`.
- Nuevas regresiones autocontenidas para falso marcador PCX, paleta compartida
  por streaming y flip `0`.
- Corpus exhaustivo ampliado a KFM, KFM720, Hokuto, ShadowGeist y Chonshu:
  8111 sprites, 794 acciones y 200 sonidos decodificados sin fallos.

## 0.1.3 - 2026-08-02

- Backbuffer GDI persistente para toda la ventana; cada `WM_PAINT` se compone fuera de pantalla y se presenta con un solo `BitBlt`.
- Suprimido el borrado de fondo de clase y de `WM_SIZE`, evitando parpadeo entre el checkerboard, los sprites y las cajas.
- El playback ya no invalida el caché RGBA en cada tick AIR: sólo se decodifica cuando el `group,image` resuelve a otro índice SFF.
- Timeline Win32 estabilizado a 60 ticks por segundo con acumulador entero basado en `GetTickCount`; no usa `float` ni `double`.
- Checkerboard optimizado: reutiliza dos brushes por frame en vez de crear y destruir un brush por celda.
- Fallback a pintado directo si Windows no puede crear el bitmap compatible.

## 0.1.2 - 2026-08-02

- Compatibilidad verificada con los KFM y KFM720 oficiales incluidos en la
  distribución de M.U.G.E.N usada como corpus.
- El lexer AIR acepta BOM UTF-8 únicamente al inicio del primer renglón.
- El parser AIR permisivo ahora convierte recuperaciones reales en warnings,
  no en errores que bloquean toda la carga.
- Compatibilidad con declaraciones `Clsn1` cuyos rectángulos vienen
  accidentalmente etiquetados `Clsn2`: manda el tipo declarado y el orden.
- El lector SND acepta el sentinel de fin de lista igual al tamaño del archivo.
- El lector WAV acepta un chunk terminal impar sin byte de padding, como en
  algunos sonidos de KFM.
- Nuevo warning `AVM_WARNING_AIR_RECOVERED`.
- Mensajes AIR fallidos ahora conservan línea, columna y acción en el reporte.
- Prueba autocontenida de compatibilidad y prueba exhaustiva opcional para
  personajes de referencia.

## 0.1.1 - 2026-08-02

- Build corregido para MSYS2 Portable MINGW32.
- Detección independiente de compilador y archivador.
- Prioridad a `gcc`/`ar` nativos del shell MINGW32.
- El EXE se enlaza antes del archivado, por lo que la ausencia de `ar` ya no
  impide obtener `audiovisualmugen.exe`.

## 0.1.0 - 2026-08-02

- Importador reutilizable para character DEF + SFF + AIR + SND.
- Callbacks de I/O y memoria completamente provista por el host.
- Visor Win32 de sprites, acciones AIR y sonidos.
- Avance por elemento y playback a timeline de 60 ticks.
- Overlay de Clsn1/Clsn2 con offset, escala y flip.
- Decode y playback de PCM, Microsoft ADPCM e IMA ADPCM.
- Personaje mínimo de prueba e integration smoke.
- Auditoría automática de heap y tipos de coma flotante.
