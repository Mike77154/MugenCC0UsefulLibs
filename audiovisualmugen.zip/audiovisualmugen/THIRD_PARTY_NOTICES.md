# Avisos de terceros

`third_party/` proviene de la base `mugencharbase.zip` entregada para construir este proyecto.

| Componente | Uso | Aviso encontrado en la base |
|---|---|---|
| `airdsl_irvm` | Parser, compilador, VM, runtime y cajas AIR | Licencia permisiva tipo MIT en `third_party/airdsl_irvm/LICENSE` |
| `sndmuglib` + `wavc89` | Índice SND y decode WAV | MIT en `third_party/sndmuglib/LICENSE` |
| `defroute89` | Parser DEF/INI y loader de character DEF | La base no incluía un archivo LICENSE separado; se conserva sin sustituir su autoría ni condiciones |
| `sff_fixed` + `pcx89/png89/zlib89` | Lectura y decode SFF | La base no incluía un archivo LICENSE separado; se conserva sin sustituir su autoría ni condiciones |

Los archivos de licencia originales presentes se distribuyen intactos. El CC0 de la raíz sólo cubre el código nuevo de integración, front-end, pruebas, scripts y documentación creados para `audiovisualmugen`; no relicencia componentes de `third_party/`.
