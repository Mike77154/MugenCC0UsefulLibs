# Test report

Fecha: 2026-08-02  
Versión: 0.1.4

## Fallos reproducidos con el corpus adicional

Los tres personajes entregados eran válidos. Los defectos estaban en la capa
vendorizada:

1. **Hokuto excedía el índice SFF estático anterior.** Su SFF v1 declara 4787
   sprites; el límite era 4096 y `sff_open_*()` terminaba antes del decode.
2. **Falso positivo de paleta PCX.** El decoder consideraba suficiente encontrar
   `0x0C` en `data_len - 769`. En PCX sin paleta y con `same_palette = 1`, ese
   byte puede aparecer dentro del RLE por coincidencia. Se descontaban 769 bytes
   válidos y la imagen terminaba como `SFF_ERR_CORRUPT`.
3. **Paletas compartidas incorrectas con I/O por callbacks.** El índice de
   paletas intentaba detectar la cola VGA leyendo sólo el prefijo del PCX. El
   sprite podía decodificar, pero quedaba en escala de grises al no recuperar la
   paleta del propietario.
4. **AIR grande fuera de los límites iniciales.** `Hokuto.air` tiene 1 445 650
   bytes y 51 065 líneas; supera los límites originales de líneas/tokens y su
   programa compilado requiere más de 65 536 instrucciones.
5. **Flip numérico válido para esos archivos.** Varias líneas usan `0` como
   sexto campo AIR. El parser lo rechazaba, descartaba los elementos en modo
   permisivo y posteriormente informaba falsamente “action has no elements”.

Antes de la reparación, la prueba directa del decoder encontró:

```text
Hokuto:      35 sprites PCX fallidos + apertura bloqueada a 4096 sprites
ShadowGeist:  1 sprite PCX fallido
Chonshu:     67 sprites PCX fallidos
```

Todos los fallos PCX tenían el mismo patrón: `same_palette = 1`, PCX válido y
un `0x0C` accidental en la posición que el detector confundía con paleta.

## Reparaciones verificadas

- `SFF_MAX_SPRITES = 8192` y `SFF_MAP_CAPACITY = 16384`.
- El detector PCX recorre el stream RLE hasta producir la imagen completa antes
  de aceptar la cola VGA de 769 bytes.
- El propietario de paleta SFF v1 se resuelve por `same_palette`.
- La paleta de una fuente streamed se obtiene leyendo directamente la cola del
  PCX propietario; memoria e I/O producen RGBA idéntico.
- AIR: 65535 líneas, 1048576 tokens, 131072 instrucciones y 2 MiB de archivo.
- `AIR_MAX_TOKENS_PER_LINE = 32`; cubre los 16 campos CSV admitidos y reduce el
  costo del token stream.
- Scratch del visor y prueba exhaustiva ampliado a 64 MiB.
- Flip AIR `0` convertido a `AIR_FLIP_NONE`.

## Pruebas autocontenidas

```text
./scripts/build_core_smoke.sh
audiovisualmugen integration smoke: ok
audiovisualmugen compatibility smoke: ok

./scripts/audit_constraints.sh
constraint audit: ok (no heap calls, float, or double in shipped runtime sources)
```

La prueba de compatibilidad verifica ahora:

- BOM UTF-8 al comienzo del AIR;
- declaración `Clsn1` seguida por rectángulo etiquetado `Clsn2`;
- flip AIR numérico `0`;
- terminación SND con `next_offset == file_size`;
- WAV terminal impar sin byte de padding;
- PCX sin paleta con un falso `0x0C` exactamente 769 bytes antes del final;
- PCX con paleta real;
- SFF v1 de dos sprites con paleta compartida, abierto tanto desde memoria como
  mediante `SffIo.read_at`, comparando los ocho bytes RGBA finales.

## Corpus exhaustivo

Se ejecutó:

```text
./scripts/test_reference_mugen.sh \
  .../chars/kfm/kfm.def \
  .../chars/kfm720/kfm720.def \
  .../Hokuto/Hokuto.def \
  .../ShadowGeist/ShadowGeist.def \
  .../Chonshu/Chonshu.def
```

Resultado:

```text
KFM:         sprites=281  actions=117 sounds=12 warnings=0x00000004
KFM720:      sprites=281  actions=117 sounds=12 warnings=0x00000004
Hokuto:      sprites=4787 actions=195 sounds=50 warnings=0x00000000
ShadowGeist: sprites=2100 actions=164 sounds=43 warnings=0x00000004
Chonshu:     sprites=662  actions=201 sounds=83 warnings=0x00000000
```

Total recorrido:

```text
8111 sprites RGBA
794 acciones AIR
200 sonidos WAV/ADPCM
```

Para cada personaje la prueba:

- abrió DEF, SFF, AIR y SND mediante callbacks de archivo;
- decodificó todos los sprites a RGBA;
- enlazó y recorrió cada elemento de cada acción AIR;
- comprobó los rangos Clsn1/Clsn2;
- ejercitó 240 ticks del runtime;
- leyó todos los payloads SND y los decodificó a PCM16.

Además se compararon hashes RGBA entre el camino SFF en memoria y el camino
streamed para sprites con `same_palette = 1`. Después del arreglo son idénticos.
Se renderizaron visualmente sprites representativos de Hokuto, ShadowGeist y
Chonshu; conservaron paleta, transparencia y dimensiones.

## Win32

El front-end conserva el backbuffer GDI persistente y el caché de sprite de
0.1.3. La 0.1.4 sólo amplía los buffers AIR estáticos y consume el decoder SFF
corregido; no añade bibliotecas ni APIs Win32 nuevas.

Este entorno no dispone del toolchain `i686-w64-mingw32`, así que aquí no se
pudo enlazar ni ejecutar el EXE. El script para MSYS2 Portable MINGW32 mantiene:

- comprobación del target `i686-w64-mingw32`;
- selección independiente de `gcc` y `ar`;
- enlace del EXE antes del archivado;
- conservación del EXE aunque `ar` no esté disponible.
