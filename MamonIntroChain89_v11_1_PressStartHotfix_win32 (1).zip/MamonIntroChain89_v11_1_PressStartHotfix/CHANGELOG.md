# v11.1 Press Start Hotfix

- Fixed Storyboard89 indefinite-scene semantics.
- A layer with `endtime = -1` now inherits the scene end only when `scene end.time > 0`.
- Scenes with `end.time = 0` and `wait.input = 1` keep their layers active indefinitely.
- Restores visible `PUSH START` and `MENU / EXIT` screens.
- Added regression coverage for scene IDs 3000 and 3001 at tick 0 and tick 60000.

# Changelog

## v11 — Storyboard Text Layers

- Sustituye los wordmarks C prehechos por `layerX.text` dentro del storyboard.
- Elimina del proyecto los catálogos específicos de estilos, wordmarks, copy y recetas completas de logo.
- Conserva únicamente shells visuales agnósticos: fondos, emblemas, máscaras y efectos frontales.
- Añade renderer vendorizado `story89_ic89_render` para mezclar capas visuales y texto en orden.
- Añade `layerX.outlines`, `layerX.glow` y `layerX.shadow`.
- Conserva `layerX.font`, `offset`, `starttime`, `endtime` y `textdelay` con semántica MUGEN-like.
- Añade movimientos declarativos `bob`, `jitter`, `step` y `slide` para texto.
- Separa runtime Storyboard89 del compilador para que el EXE no arrastre parser ni stdio.
- Añade pruebas de CAPCOM amarillo con borde azul, sílabas de Maseca, glow de Caricachupas y ausencia de capas tipográficas precompiladas.

## v10 — Storyboard89 + AIRLite89

- Sustituye la tabla manual de 17 escenas por `storyboards/mamon_intro.def`.
- Añade AIRLite89 para acciones, frames, loop, flips, blending, escala, ángulo e interpolación.
- Añade Storyboard89, capas clásicas y extendidas, fondos y BGCtrl.
- Añade `timebase`, codegen C89 estático y bridge hacia IC89.
