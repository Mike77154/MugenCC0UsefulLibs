# Mamon Intro Chain 89 v11.1 — Storyboard Text Layers

Presentación Win32 PE32 de 32 bits cuyo timeline, nombres de logo y copy se escriben en un storyboard `.def` inspirado en MUGEN. Los wordmarks ya no se cargan como presets C prehechos: `CAPCOM`, `INBAL`, `CARICACHUPAS` o cualquier otro nombre son datos de una capa `text`.

```text
storyboards/mamon_intro.def
        ↓
cut89 + Storyboard89 + AIRLite89
        ↓
generated/mamon_storyboard_generated.c/.h
        ↓
Storyboard89 text renderer + IC89 visual shells
        ↓
EXE Win32
```

## Modelo visual

```text
shell visual de fondo
        ↓
capa text declarativa
        ↓
forma/emblema opcional
        ↓
efecto frontal opcional
```

El shell no conoce el nombre de la marca. Cambiar:

```ini
layer1.text = "CAPCOM"
```

por:

```ini
layer1.text = "MI ESTUDIO"
```

no requiere recompilar una receta tipográfica manual; basta regenerar las tablas del storyboard.

## Texto estilo MUGEN

```ini
layer1.text = "CAPCOM"
layer1.font = 4,0,0,255,205,25
layer1.offset = 320,112
layer1.starttime = 0
layer1.endtime = 2500
layer1.textdelay = 0
```

`layerX.font` conserva la forma mental de MUGEN:

```text
font_id, bank, align, red, green, blue
```

Alineación:

```text
 1 = izquierda
 0 = centro
-1 = derecha
```

## Decoración estilo Ren'Py

Storyboard89 añade propiedades declarativas que crean el efecto, no sólo lo recolorean:

```ini
layer1.outlines = 3,22,69,166,0,0
layer1.glow = 2,255,36,36
layer1.shadow = 3,4,0,0,0
```

Formatos:

```text
outlines = grosor,r,g,b
outlines = grosor,r,g,b,offset_x,offset_y
glow     = radio,r,g,b
shadow   = offset_x,offset_y,r,g,b
```

Cada capa admite un decorador principal. Si una identidad requiere varias decoraciones, se apilan varias capas `text` con el mismo contenido y distintos estilos.

## Movimiento de palabras

```ini
layer1.motion = bob,y,4,4
layer1.motion = jitter,x,4,65
layer1.motion = step,y,216,96,7
layer1.motion = slide,x,-200,0,400
```

Todos los cálculos son enteros o Q16.16.

## Secuencia conservada

```text
CAPCOM → MASECA → FONCA → FIDECINE → IMCINE → CONACULTA
→ INAH → INBAL → CINETECA → CULTURA → FOPROCINE
→ CARICACHUPAS PRESENTA
→ INTRO 1 → INTRO 2 → INTRO 3
→ PRESS START → MENU → EXIT
```

Rutas:

```text
LOGO       --Start--> primera INTRO posterior
INTRO      --Start--> PUSH START posterior
PUSH START --Start--> MENU posterior
```

## AIRLite89

Minilib agnóstica para el subconjunto AIR útil en storyboards, fondos y stages:

- `[Begin Action n]` y frames;
- `Loopstart`;
- flips `H`, `V`, `HV`;
- blend `A`, `A1`, `S`, `ASxxxDxxx`;
- escala y ángulo;
- interpolación de offset, blend, escala y ángulo;
- sampleo por tick sin heap ni tipos flotantes.

## Compilación offline

```bash
./generate_storyboard.sh
./build_clang_lld.sh
```

MSYS2/MinGW32:

```bat
generate_storyboard_msys2_mingw32.bat
build_msys2_mingw32.bat
```

El EXE final incorpora tablas C89 estáticas y el runtime pequeño. No incorpora lexer, parser, AST, `FILE` I/O ni codegen.

## Pruebas

```bash
./run_core_tests.sh
./run_storyboard_tests.sh
./run_project_tests.sh
```

Cubren:

- parser AIR y Storyboard89;
- texto MUGEN-like;
- `outlines`, `glow` y `shadow`;
- movimiento textual;
- ausencia de wordmarks precompilados en las doce escenas de logo;
- orden de 17 escenas y saltos semánticos;
- visual shells y efectos frontales;
- codegen C89.

## Restricciones

- C89 estricto;
- PE32 Intel i386;
- sin `malloc`, `calloc`, `realloc`, `free` ni heap de aplicación;
- sin `float` ni `double`;
- sin CRT;
- doble buffer GDI;
- imports: KERNEL32, USER32 y GDI32.

Consulta `docs/STORYBOARD89_DIALECT.md`, `docs/ADDING_LOGOS.md`, `docs/FONT_VS_TYPOGRAPHY.md` y `docs/WEB_RESEARCH.md`.


## v11.1 hotfix

`end.time = 0` on a `wait.input = 1` scene means the scene is open-ended. Its inherited layers remain visible until input changes the route. This fixes the black screen that previously hid Push Start and the Exit menu.
