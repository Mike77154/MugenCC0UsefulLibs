#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
COMMON=(-std=c89 -pedantic-errors -Wall -Wextra -Werror -Iinclude -Ivendor/ic89/include -Ivendor/airlite89/include -Ivendor/storyboard89/include -Ivendor/storyboard89_ic89/include -Igenerated)

cc "${COMMON[@]}" \
  tests/test_project_packs.c \
  vendor/ic89/src/ic89_sequence.c \
  vendor/ic89/src/ic89_visual_registry.c \
  vendor/ic89/src/ic89_hit_region.c \
  vendor/ic89/src/ic89_string.c \
  generated/mamon_storyboard_generated.c \
  src/app/bridges/story89_ic89_adapter.c \
  src/app/mamon_project.c \
  src/app/packs/mamon_pack_commercial.c \
  src/app/packs/mamon_pack_funds.c \
  src/app/packs/mamon_pack_institutions.c \
  src/app/packs/mamon_pack_parody.c \
  src/app/packs/mamon_pack_intros.c \
  src/app/packs/mamon_pack_system.c \
  -o build/test_project_packs
./build/test_project_packs

cc "${COMMON[@]}" \
  tests/test_storyboard_text_model.c \
  generated/mamon_storyboard_generated.c \
  vendor/storyboard89/src/story89_runtime.c \
  -o build/test_storyboard_text_model
./build/test_storyboard_text_model

cc "${COMMON[@]}" \
  tests/test_storyboard_text_render.c \
  generated/mamon_storyboard_generated.c \
  vendor/storyboard89/src/story89_runtime.c \
  vendor/storyboard89_ic89/src/story89_ic89_render.c \
  vendor/ic89/src/ic89_font_bank.c \
  vendor/ic89/src/ic89_text_style.c \
  vendor/ic89/src/ic89_text_painter.c \
  vendor/ic89/src/ic89_color.c \
  vendor/ic89/src/ic89_draw2d.c \
  vendor/ic89/src/ic89_motion_wave.c \
  vendor/ic89/src/ic89_trig.c \
  vendor/ic89/src/ic89_string.c \
  vendor/ic89/src/ic89_visual_registry.c \
  vendor/ic89/src/ic89_sequence.c \
  vendor/ic89/src/ic89_player.c \
  vendor/ic89/src/ic89_route_policy.c \
  vendor/ic89/src/ic89_fade.c \
  vendor/ic89/src/ic89_fixed.c \
  -o build/test_storyboard_text_render
./build/test_storyboard_text_render

cc "${COMMON[@]}" \
  tests/test_press_start_flow.c \
  generated/mamon_storyboard_generated.c \
  src/app/bridges/story89_ic89_adapter.c \
  vendor/storyboard89/src/story89_runtime.c \
  vendor/ic89/src/ic89_string.c \
  vendor/ic89/src/ic89_sequence.c \
  vendor/ic89/src/ic89_player.c \
  vendor/ic89/src/ic89_route_policy.c \
  vendor/ic89/src/ic89_fade.c \
  vendor/ic89/src/ic89_fixed.c \
  vendor/ic89/src/ic89_tween.c \
  vendor/ic89/src/ic89_int_math.c \
  -o build/test_press_start_flow
./build/test_press_start_flow
