@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
if exist build\mingw32 rmdir /s /q build\mingw32
mkdir build\mingw32
set CC=i686-w64-mingw32-gcc
set CFLAGS=-std=c89 -pedantic-errors -Os -Wall -Wextra -Werror -ffreestanding -fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables -Iinclude -Ivendor\ic89\include -Ivendor\airlite89\include -Ivendor\storyboard89\include -Igenerated
set OBJECTS=
for /f "usebackq delims=" %%F in ("sources_win32.txt") do (
  set NAME=%%~nF
  %CC% %CFLAGS% -c %%F -o build\mingw32\!NAME!.o || goto :fail
  set OBJECTS=!OBJECTS! build\mingw32\!NAME!.o
)
%CC% -nostdlib -mwindows -Wl,--entry=_WinMainCRTStartup -Wl,--subsystem,windows:5.01 -Wl,--gc-sections -o MamonIntroChain89.exe %OBJECTS% -lkernel32 -luser32 -lgdi32 || goto :fail
echo.
echo OK: MamonIntroChain89.exe
exit /b 0
:fail
echo.
echo ERROR DE COMPILACION
exit /b 1
