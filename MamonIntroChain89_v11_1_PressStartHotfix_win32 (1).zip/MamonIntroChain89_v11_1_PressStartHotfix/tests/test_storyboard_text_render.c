#include <stdio.h>
#include "mamon_storyboard_generated.h"
#include "story89_ic89_render.h"
#include "ic89_font_bank.h"
#include "ic89_draw2d.h"
#include "ic89_string.h"

#define MAX_CALLS 256
#define FONT_COUNT 6U

typedef struct draw_call {
    int x;
    int y;
    ic89_color color;
    char text[64];
} draw_call;

static char g_handles[FONT_COUNT];
static draw_call g_calls[MAX_CALLS];
static int g_call_count;

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

static void *mock_create(void *context, const ic89_font_face_spec *spec)
{
    static unsigned short next;
    (void)context;
    (void)spec;
    if (next >= FONT_COUNT) return (void *)0;
    return &g_handles[next++];
}

static void mock_destroy(void *context, void *handle)
{
    (void)context;
    (void)handle;
}

static void mock_draw(void *context, ic89_canvas *canvas, void *font_handle,
    int x, int y, const char *text, ic89_color color, unsigned short alignment)
{
    int i;
    (void)context;
    (void)canvas;
    (void)font_handle;
    (void)alignment;
    if (g_call_count >= MAX_CALLS) return;
    g_calls[g_call_count].x = x;
    g_calls[g_call_count].y = y;
    g_calls[g_call_count].color = color;
    i = 0;
    while (text[i] && i < 63) { g_calls[g_call_count].text[i] = text[i]; ++i; }
    g_calls[g_call_count].text[i] = '\0';
    ++g_call_count;
}

static unsigned char mock_measure(void *context, ic89_canvas *canvas,
    void *font_handle, const char *text, ic89_text_metrics *metrics)
{
    (void)context;
    (void)canvas;
    (void)font_handle;
    metrics->width = ic89_cstr_len(text) * 8;
    metrics->height = 16;
    return 1U;
}

static const ic89_font_factory g_factory = {mock_create, mock_destroy};
static const ic89_text_renderer g_renderer = {mock_draw, mock_measure};

int main(void)
{
    ic89_font_face_spec specs[FONT_COUNT];
    ic89_font_bank bank;
    ic89_canvas canvas;
    ic89_player player;
    ic89_sequence sequence;
    ic89_scene scene;
    const ic89_scene_pack *pack_ref;
    ic89_visual_registry empty_visuals;
    ic89_scene_pack pack;
    unsigned short i;
    for (i = 0U; i < FONT_COUNT; ++i) {
        specs[i].height = -16; specs[i].width = 0; specs[i].weight = 700;
        specs[i].italic = 0UL; specs[i].quality = 0UL; specs[i].pitch_family = 0UL;
        specs[i].face_name = "mock";
    }
    if (!ic89_font_bank_create(&bank, &g_factory, (void *)0, &g_renderer, (void *)0, specs, FONT_COUNT)) return fail("font bank");
    ic89_canvas_bind(&canvas, (const ic89_draw2d_ops *)0, (void *)0, 640, 360);
    scene.id = 1000U; scene.visual_id = 1000U; scene.kind = IC89_KIND_LOGO;
    scene.flags = 0U; scene.start_target_kind = IC89_KIND_INTRO;
    scene.duration_ms = 2500UL; scene.fade_in_ms = 0UL; scene.fade_out_ms = 0UL;
    pack.scenes = &scene; pack.count = 1U; pack.name = "test";
    pack_ref = &pack;
    ic89_sequence_bind(&sequence, &pack_ref, 1U);
    ic89_init(&player, &sequence, 0UL);
    player.local_ms = 0UL;
    player.visibility = IC89_FX_ONE;
    empty_visuals.packs = (const ic89_visual_pack *const *)0;
    empty_visuals.pack_count = 0U;
    g_call_count = 0;
    story89_ic89_render_current(&g_mamon_storyboard, &player,
        &empty_visuals, &bank, &canvas, (const ic89_render_input *)0);
    if (g_call_count < 49) return fail("CAPCOM outline passes");
    if (g_calls[48].x != 320 || g_calls[48].y != 112) return fail("CAPCOM final fill position");
    if (g_calls[48].color != IC89_RGB(255,205,25)) return fail("CAPCOM yellow fill");
    ic89_font_bank_destroy(&bank);
    printf("PASS: storyboard text renderer draws MUGEN text plus declarative outline\n");
    return 0;
}
