#include <stdio.h>
#include "mamon_project.h"
#include "mamon_visuals.h"
#include "logo_presets/mamon_logo_shells.h"
#include "ic89_logo_recipe.h"
#include "packs/mamon_pack_commercial.h"
#include "packs/mamon_pack_funds.h"
#include "packs/mamon_pack_institutions.h"
#include "packs/mamon_pack_parody.h"
#include "packs/mamon_pack_intros.h"
#include "packs/mamon_pack_system.h"

#define DUMMY_RECIPE(symbol_) \
    const ic89_logo_recipe symbol_ = {(const ic89_logo_layer *const *)0, 0U, #symbol_}

DUMMY_RECIPE(g_mamon_shell_capcom);
DUMMY_RECIPE(g_mamon_shell_capcom_shine);
DUMMY_RECIPE(g_mamon_shell_maseca);
DUMMY_RECIPE(g_mamon_shell_maseca_corn);
DUMMY_RECIPE(g_mamon_shell_fonca);
DUMMY_RECIPE(g_mamon_shell_fonca_sweep);
DUMMY_RECIPE(g_mamon_shell_fidecine);
DUMMY_RECIPE(g_mamon_shell_imcine);
DUMMY_RECIPE(g_mamon_shell_imcine_cutouts);
DUMMY_RECIPE(g_mamon_shell_imcine_strip);
DUMMY_RECIPE(g_mamon_shell_foprocine);
DUMMY_RECIPE(g_mamon_shell_conaculta);
DUMMY_RECIPE(g_mamon_shell_conaculta_reveal);
DUMMY_RECIPE(g_mamon_shell_inah);
DUMMY_RECIPE(g_mamon_shell_inbal);
DUMMY_RECIPE(g_mamon_shell_cineteca);
DUMMY_RECIPE(g_mamon_shell_cultura);
DUMMY_RECIPE(g_mamon_shell_caricachupas);
DUMMY_RECIPE(g_mamon_shell_caricachupas_glitch);

#undef DUMMY_RECIPE

void ic89_logo_recipe_draw_scene(const ic89_render_context *context, const void *user_data)
{
    (void)context;
    (void)user_data;
}

#define DUMMY_DRAW(name) \
void name(const ic89_render_context *context, const void *user_data) \
{ \
    (void)context; \
    (void)user_data; \
}

DUMMY_DRAW(mamon_draw_intro_one)
DUMMY_DRAW(mamon_draw_intro_two)
DUMMY_DRAW(mamon_draw_intro_three)
DUMMY_DRAW(mamon_draw_press_start)
DUMMY_DRAW(mamon_draw_menu)

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

int main(void)
{
    static const unsigned short expected[17] = {
        MAMON_VIS_CAPCOM, MAMON_VIS_MASECA, MAMON_VIS_FONCA,
        MAMON_VIS_FIDECINE, MAMON_VIS_IMCINE, MAMON_VIS_CONACULTA,
        MAMON_VIS_INAH, MAMON_VIS_INBAL, MAMON_VIS_CINETECA,
        MAMON_VIS_CULTURA, MAMON_VIS_FOPROCINE, MAMON_VIS_CARICACHUPAS,
        MAMON_VIS_INTRO_ONE, MAMON_VIS_INTRO_TWO, MAMON_VIS_INTRO_THREE,
        MAMON_VIS_PRESS_START, MAMON_VIS_MENU
    };
    const ic89_sequence *sequence;
    const ic89_visual_registry *visuals;
    const ic89_scene *scene;
    unsigned short index;
    sequence = mamon_project_sequence();
    visuals = mamon_project_visuals();
    if (!sequence || sequence->pack_count != 1U) return fail("generated storyboard pack");
    if (sequence->scene_count != 17U) return fail("seventeen nodes");
    if (!visuals || visuals->pack_count != 6U) return fail("six visual packs");
    for (index = 0U; index < 17U; ++index) {
        scene = ic89_sequence_at(sequence, index);
        if (!scene || scene->visual_id != expected[index]) return fail("scene order changed");
        if (!ic89_visual_find(visuals, expected[index])) return fail("base scene visual missing");
    }
    if (!ic89_visual_find(visuals, MAMON_VIS_CAPCOM_SHINE)) return fail("CAPCOM shine atom");
    if (!ic89_visual_find(visuals, MAMON_VIS_MASECA_CORN)) return fail("Maseca corn atom");
    if (!ic89_visual_find(visuals, MAMON_VIS_IMCINE_CUTOUTS)) return fail("IMCINE cutout atom");
    if (!ic89_visual_find(visuals, MAMON_VIS_CARICACHUPAS_GLITCH)) return fail("Caricachupas glitch atom");
    printf("PASS: generated sequence and atomic visual shells are registered\n");
    return 0;
}
