#include <stdio.h>
#include "mamon_storyboard_generated.h"
#include "bridges/story89_ic89_adapter.h"
#include "ic89_player.h"

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

int main(void)
{
    story89_ic89_adapter adapter;
    const ic89_sequence *sequence;
    ic89_player player;
    ic89_input input;
    const ic89_scene *scene;
    const story89_scene *story_scene;
    const story89_layer *layer;

    if (!story89_ic89_bind(&adapter, &g_mamon_storyboard, "press-start-flow"))
        return fail("adapter bind");
    sequence = story89_ic89_sequence(&adapter);
    if (!sequence || sequence->scene_count != 17U) return fail("generated sequence");

    ic89_init(&player, sequence, 0UL);
    if (!ic89_jump_to_index(&player, 14U, 0UL)) return fail("jump to final intro");
    input.start_pressed = 0U;
    input.skip_pressed = 0U;
    ic89_update(&player, &input, 4400UL);
    scene = ic89_current(&player);
    if (!scene || scene->kind != IC89_KIND_PUSH_START || scene->id != 3000U)
        return fail("final intro must auto-advance to Push Start");

    story_scene = story89_find_scene_id(&g_mamon_storyboard, 3000L);
    if (!story_scene) return fail("Push Start storyboard scene");
    layer = story89_scene_layer(&g_mamon_storyboard, story_scene, 0U);
    if (!layer || !story89_layer_active(layer, 60000L, story_scene->end_time))
        return fail("Push Start visual layer must stay active");

    input.start_pressed = 1U;
    ic89_update(&player, &input, 5000UL);
    scene = ic89_current(&player);
    if (!scene || scene->kind != IC89_KIND_MENU || scene->id != 3001U)
        return fail("Start on Push Start must enter menu");

    story_scene = story89_find_scene_id(&g_mamon_storyboard, 3001L);
    if (!story_scene) return fail("Menu storyboard scene");
    layer = story89_scene_layer(&g_mamon_storyboard, story_scene, 0U);
    if (!layer || !story89_layer_active(layer, 60000L, story_scene->end_time))
        return fail("Menu visual layer must stay active");

    printf("PASS: final intro -> Push Start -> Menu remains visible\n");
    return 0;
}
