#include <stdio.h>
#include <string.h>
#include "air89.h"
#include "story89_cut.h"

static cut_context g_cut;
static story89_document g_story;

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

int main(void)
{
    static const char air_text[] =
        "[Begin Action 1]\n"
        "Clsn2Default: 1\n"
        "Clsn2[0] = -10,-10,10,10\n"
        "0,0,0,0,10\n"
        "Interpolate Offset\n"
        "0,1,10,0,10,H,AS128D128,1.5,2,45\n"
        "Loopstart\n"
        "0,2,20,0,10,,A1,1,1,90\n";
    air89_document air;
    air89_sample sample;
    story89_program program;
    const story89_scene *scene;
    const story89_layer *layer;
    int rc;

    rc = air89_parse_buffer(&air, air_text, (long)strlen(air_text));
    if (rc != AIR89_OK) return fail("AIR parser rejected valid action");
    if (air.action_count != 1U || air.frame_count != 3U) return fail("AIR counts");
    if (!air.actions[0].has_loop_start || air.actions[0].loop_start != 2U) return fail("AIR loopstart");
    if (air.frames[1].flip != AIR89_FLIP_H) return fail("AIR horizontal flip");
    if (air.frames[1].blend != AIR89_BLEND_ALPHA || air.frames[1].source_alpha != 128U || air.frames[1].dest_alpha != 128U) return fail("AIR alpha blend");
    if (air.frames[1].scale_x != 98304L || air.frames[1].scale_y != 131072L) return fail("AIR fixed scale");
    if (air.frames[1].angle != 2949120L) return fail("AIR angle");
    if (air89_sample_action(&air, 1L, 5L, &sample) != AIR89_OK) return fail("AIR sample");
    if (air89_fixed_to_int(sample.offset_x) != 5) return fail("AIR offset interpolation");
    if (air89_sample_action(&air, 1L, 25L, &sample) != AIR89_OK) return fail("AIR loop sample");
    if (sample.frame_index != 2U) return fail("AIR loop segment selection");

    rc = story89_load_compile(&g_story, &g_cut, "storyboards/logo_steroids_example.def");
    if (rc != STORY89_OK) return fail("Storyboard89 compile");
    if (g_story.scene_count != 1U || g_story.layer_count != 6U) return fail("Storyboard scene/layer counts");
    if (g_story.air.action_count != 1U || g_story.bg_element_count != 1U || g_story.bgctrl_count != 1U) return fail("Storyboard AIR/BG counts");
    story89_program_view(&g_story, &program);
    scene = story89_find_scene_id(&program, 9000L);
    if (!scene || scene->kind != STORY89_KIND_LOGO || scene->start_target_kind != STORY89_KIND_INTRO) return fail("Storyboard scene semantics");
    layer = story89_scene_layer(&program, scene, 0U);
    if (!layer || layer->kind != STORY89_LAYER_ANIM || layer->action_no != 100L) return fail("Storyboard classic anim layer");
    layer = story89_scene_layer(&program, scene, 2U);
    if (!layer || layer->kind != STORY89_LAYER_TEXT || layer->text_effect != STORY89_TEXT_OUTLINE || layer->decor_size != 3L) return fail("Storyboard outlined text layer");
    if (story89_time_to_ms(&program, 60L) != 1000L) return fail("Storyboard 60 Hz timebase");

    printf("PASS: AIR actions, interpolation, storyboard layers, BG and controllers\n");
    return 0;
}
