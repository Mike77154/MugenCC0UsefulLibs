#include <stdio.h>
#include "introchain89.h"
#include "ic89_motion.h"
#include "ic89_viewport.h"
#include "ic89_visual_registry.h"
#include "ic89_hit_region.h"
#include "ic89_typography.h"
#include "ic89_logo_recipe.h"

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

static void no_input(ic89_input *input)
{
    input->start_pressed = 0U;
    input->skip_pressed = 0U;
}


static int g_text_x;
static int g_text_y;
static int g_text_calls;
static char g_mock_font;

static void *mock_font_create(void *driver_context, const ic89_font_face_spec *spec)
{
    (void)driver_context;
    (void)spec;
    return &g_mock_font;
}

static void mock_font_destroy(void *driver_context, void *font_handle)
{
    (void)driver_context;
    (void)font_handle;
}

static void mock_text_draw(void *driver_context, ic89_canvas *canvas, void *font_handle, int x, int y, const char *text, ic89_color color, unsigned short alignment)
{
    (void)driver_context;
    (void)canvas;
    (void)font_handle;
    (void)text;
    (void)color;
    (void)alignment;
    g_text_x = x;
    g_text_y = y;
    g_text_calls++;
}

static unsigned char mock_text_measure(void *driver_context, ic89_canvas *canvas, void *font_handle, const char *text, ic89_text_metrics *out_metrics)
{
    (void)driver_context;
    (void)canvas;
    (void)font_handle;
    (void)text;
    out_metrics->width = 42;
    out_metrics->height = 12;
    return 1U;
}

static const ic89_font_factory g_mock_font_factory = {
    mock_font_create,
    mock_font_destroy
};

static const ic89_text_renderer g_mock_text_renderer = {
    mock_text_draw,
    mock_text_measure
};

static void dummy_draw(const ic89_render_context *context, const void *user_data)
{
    (void)context;
    (void)user_data;
}

static int g_logo_order[4];
static int g_logo_order_count;

static void logo_layer_one(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)context;
    (void)layer_data;
    (void)scene_user_data;
    g_logo_order[g_logo_order_count++] = 1;
}

static void logo_layer_two(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)context;
    (void)layer_data;
    (void)scene_user_data;
    g_logo_order[g_logo_order_count++] = 2;
}

static void logo_layer_three(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)context;
    (void)layer_data;
    (void)scene_user_data;
    g_logo_order[g_logo_order_count++] = 3;
}

static void logo_layer_four(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)context;
    (void)layer_data;
    (void)scene_user_data;
    g_logo_order[g_logo_order_count++] = 4;
}

int main(void)
{
    static const ic89_scene logo_scenes[] = {
        {1U, 101U, IC89_KIND_LOGO, 0U, IC89_KIND_INTRO, 1000UL, 200UL, 200UL},
        {2U, 102U, IC89_KIND_LOGO, 0U, IC89_KIND_INTRO, 1000UL, 100UL, 100UL}
    };
    static const ic89_scene later_scenes[] = {
        {3U, 103U, IC89_KIND_INTRO, 0U, IC89_KIND_PUSH_START, 1000UL, 100UL, 100UL},
        {4U, 104U, IC89_KIND_INTRO, 0U, IC89_KIND_PUSH_START, 1000UL, 100UL, 100UL},
        {5U, 105U, IC89_KIND_PUSH_START, IC89_SCENE_WAIT_INPUT, IC89_KIND_MENU, 0UL, 100UL, 0UL},
        {6U, 106U, IC89_KIND_MENU, IC89_SCENE_MENU | IC89_SCENE_WAIT_INPUT, IC89_KIND_NONE, 0UL, 0UL, 0UL}
    };
    static const ic89_scene_pack logo_pack = {
        logo_scenes,
        (unsigned short)(sizeof(logo_scenes) / sizeof(logo_scenes[0])),
        "logos"
    };
    static const ic89_scene_pack later_pack = {
        later_scenes,
        (unsigned short)(sizeof(later_scenes) / sizeof(later_scenes[0])),
        "later"
    };
    static const ic89_scene_pack *const packs[] = {&logo_pack, &later_pack};
    static const ic89_visual_entry visual_entries[] = {
        {101U, dummy_draw, ic89_hit_none, (const void *)0},
        {106U, dummy_draw, ic89_hit_none, (const void *)0}
    };
    static const ic89_visual_pack visual_pack = {
        visual_entries,
        (unsigned short)(sizeof(visual_entries) / sizeof(visual_entries[0])),
        "test"
    };
    static const ic89_visual_pack *const visual_packs[] = {&visual_pack};
    static const ic89_visual_registry registry = {visual_packs, 1U};
    static const ic89_logo_layer logo_primitive = {IC89_LOGO_LAYER_PRIMITIVE, logo_layer_one, (const void *)0, "primitive"};
    static const ic89_logo_layer logo_shape = {IC89_LOGO_LAYER_SHAPE, logo_layer_two, (const void *)0, "shape"};
    static const ic89_logo_layer logo_type = {IC89_LOGO_LAYER_TYPOGRAPHY, logo_layer_three, (const void *)0, "type"};
    static const ic89_logo_layer logo_foreground = {IC89_LOGO_LAYER_PRIMITIVE, logo_layer_four, (const void *)0, "foreground"};
    static const ic89_logo_layer *const logo_layers[] = {&logo_primitive, &logo_shape, &logo_type, &logo_foreground};
    static const ic89_logo_recipe logo_recipe = {logo_layers, 4U, "test_recipe"};
    ic89_sequence sequence;
    ic89_player player;
    ic89_input input;
    ic89_point_i point;
    ic89_anim_value animation;
    ic89_viewport viewport;
    int x;
    int y;
    ic89_font_bank bank;
    ic89_font_face_spec font_spec;
    ic89_text_preset text_preset;
    ic89_text_actor text_actor;
    ic89_canvas canvas;
    ic89_render_context logo_context;

    ic89_sequence_bind(&sequence, packs, 2U);
    if (sequence.scene_count != 6U) return fail("scene packs must flatten to six nodes");
    if (ic89_sequence_at(&sequence, 2U)->visual_id != 103U) return fail("pack boundary indexing");

    no_input(&input);
    ic89_init(&player, &sequence, 100UL);
    ic89_update(&player, &input, 200UL);
    if (player.scene_index != 0U) return fail("logo zero should remain active");
    if (player.visibility <= 0L || player.visibility >= IC89_FX_ONE) return fail("fade-in should be partial");

    input.start_pressed = 1U;
    ic89_update(&player, &input, 450UL);
    if (player.scene_index != 2U) return fail("START on logo must cross packs to first intro");

    no_input(&input);
    input.start_pressed = 1U;
    ic89_update(&player, &input, 801UL);
    if (player.scene_index != 4U) return fail("START on intro must jump to push-start");

    no_input(&input);
    input.start_pressed = 1U;
    ic89_update(&player, &input, 1201UL);
    if (player.scene_index != 5U) return fail("START on push-start must jump to menu");

    ic89_motion_orbit(&point, 100, 100, 20, 10, 0U);
    if (point.x != 100 || point.y < 109 || point.y > 111) return fail("fixed-point orbit");
    if (ic89_motion_jitter(0UL, 50UL, 4) != -4) return fail("jitter phase zero");
    if (ic89_motion_jitter(50UL, 50UL, 4) != 4) return fail("jitter phase one");

    ic89_anim_track(&animation, 0, 0, 100, 0UL, 1000UL, IC89_EASE_LINEAR, 0U);
    if (ic89_anim_eval_i(&animation, 500UL) < 49 || ic89_anim_eval_i(&animation, 500UL) > 50) return fail("track midpoint");
    ic89_anim_jitter(&animation, 320, -4, 65UL);
    if (ic89_anim_eval_i(&animation, 0UL) != 324) return fail("negative amplitude jitter actor");
    ic89_anim_step_ramp(&animation, 0, 216, 96, 7UL);
    if (ic89_anim_eval_i(&animation, 6UL) != 216) return fail("step ramp must hold before boundary");
    if (ic89_anim_eval_i(&animation, 7UL) != 215) return fail("step ramp first boundary");
    if (ic89_anim_eval_i(&animation, 840UL) != 96) return fail("step ramp clamp");

    ic89_viewport_fit(&viewport, 640, 360, 1000, 1000);
    if (!ic89_viewport_client_to_virtual(&viewport, 500, 500, &x, &y)) return fail("viewport center should map");
    if (x < 319 || x > 321 || y < 179 || y > 181) return fail("viewport center mapping");

    if (ic89_visual_find(&registry, 106U) == (const ic89_visual_entry *)0) return fail("visual lookup through pack");
    if (ic89_visual_find(&registry, 999U) != (const ic89_visual_entry *)0) return fail("missing visual lookup");

    font_spec.height = -20;
    font_spec.width = 0;
    font_spec.weight = 400;
    font_spec.italic = 0UL;
    font_spec.quality = 0UL;
    font_spec.pitch_family = 0UL;
    font_spec.face_name = "mock";
    if (!ic89_font_bank_create(&bank, &g_mock_font_factory, (void *)0, &g_mock_text_renderer, (void *)0, &font_spec, 1U)) return fail("mock font bank");
    ic89_text_preset_set(&text_preset, 0U, IC89_TEXT_PLAIN, IC89_TEXT_ALIGN_CENTER, 0, 0, 0, IC89_RGB(255, 255, 255), IC89_RGB(0, 0, 0));
    text_actor.text = "ACTOR";
    text_actor.preset = &text_preset;
    ic89_anim_jitter(&text_actor.x, 320, 4, 65UL);
    ic89_anim_constant(&text_actor.y, 108);
    text_actor.starts_at_ms = 0UL;
    text_actor.reveal_ms_per_character = 0UL;
    ic89_canvas_bind(&canvas, (const ic89_draw2d_ops *)0, (void *)0, 640, 360);
    g_text_calls = 0;
    ic89_text_actor_draw(&bank, &canvas, &text_actor, 0UL, IC89_FX_ONE);
    if (g_text_calls != 1 || g_text_x != 316 || g_text_y != 108) return fail("text actor must evaluate motion before draw");
    ic89_font_bank_destroy(&bank);

    logo_context.canvas = &canvas;
    logo_context.fonts = (const ic89_font_bank *)0;
    logo_context.local_ms = 0UL;
    logo_context.visibility = IC89_FX_ONE;
    logo_context.input = (const ic89_render_input *)0;
    g_logo_order_count = 0;
    ic89_logo_recipe_draw(&logo_recipe, &logo_context, (const void *)0);
    if (g_logo_order_count != 4) return fail("logo recipe must draw every layer");
    if (g_logo_order[0] != 1 || g_logo_order[1] != 2 || g_logo_order[2] != 3 || g_logo_order[3] != 4) return fail("logo recipe must preserve declared layer order");
    if (ic89_logo_recipe_count_kind(&logo_recipe, IC89_LOGO_LAYER_PRIMITIVE) != 2U) return fail("logo primitive layer count");
    if (ic89_logo_recipe_count_kind(&logo_recipe, IC89_LOGO_LAYER_SHAPE) != 1U) return fail("logo shape layer count");
    if (ic89_logo_recipe_count_kind(&logo_recipe, IC89_LOGO_LAYER_TYPOGRAPHY) != 1U) return fail("logo typography layer count");

    printf("PASS: packs, routes, animation, viewport, visual packs, text actors and logo recipes\n");
    return 0;
}
