#include <stdio.h>
#include <string.h>
#include "mamon_storyboard_generated.h"

static int fail(const char *message)
{
    printf("FAIL: %s\n", message);
    return 1;
}

static const story89_layer *find_text(const story89_scene *scene, const char *text)
{
    unsigned short i;
    for (i = 0U; i < scene->layer_count; ++i) {
        const story89_layer *layer;
        layer = story89_scene_layer(&g_mamon_storyboard, scene, i);
        if (layer && layer->kind == STORY89_LAYER_TEXT &&
            strcmp(story89_string(&g_mamon_storyboard, layer->text_off), text) == 0) return layer;
    }
    return (const story89_layer *)0;
}

int main(void)
{
    const story89_scene *capcom;
    const story89_scene *maseca;
    const story89_scene *caricachupas;
    const story89_scene *push_start;
    const story89_scene *menu;
    const story89_layer *layer;
    unsigned short s;
    capcom = story89_find_scene_id(&g_mamon_storyboard, 1000L);
    maseca = story89_find_scene_id(&g_mamon_storyboard, 1001L);
    caricachupas = story89_find_scene_id(&g_mamon_storyboard, 1300L);
    push_start = story89_find_scene_id(&g_mamon_storyboard, 3000L);
    menu = story89_find_scene_id(&g_mamon_storyboard, 3001L);
    if (!capcom || !maseca || !caricachupas) return fail("logo scenes");
    if (!push_start || !menu) return fail("system scenes");
    layer = find_text(capcom, "CAPCOM");
    if (!layer) return fail("CAPCOM comes from layer.text");
    if (layer->font_no != 4L || layer->text_effect != STORY89_TEXT_OUTLINE) return fail("CAPCOM font and outline");
    if (layer->decor_size != 3L || layer->decor_r != 22L || layer->decor_g != 69L || layer->decor_b != 166L) return fail("CAPCOM outline color");
    if (!find_text(maseca, "MA") || !find_text(maseca, "SE") || !find_text(maseca, "CA")) return fail("Maseca syllables are text layers");
    layer = find_text(caricachupas, "CARICACHUPAS");
    if (!layer || layer->text_effect != STORY89_TEXT_GLOW) return fail("Caricachupas glow text");
    layer = story89_scene_layer(&g_mamon_storyboard, push_start, 0U);
    if (!layer || !story89_layer_active(layer, 0L, push_start->end_time) ||
        !story89_layer_active(layer, 60000L, push_start->end_time))
        return fail("Push Start indefinite layer must remain active");
    layer = story89_scene_layer(&g_mamon_storyboard, menu, 0U);
    if (!layer || !story89_layer_active(layer, 0L, menu->end_time) ||
        !story89_layer_active(layer, 60000L, menu->end_time))
        return fail("Menu indefinite layer must remain active");
    for (s = 0U; s < 12U; ++s) {
        const story89_scene *scene;
        unsigned short i;
        scene = &g_mamon_storyboard.scenes[s];
        for (i = 0U; i < scene->layer_count; ++i) {
            const story89_layer *item;
            item = story89_scene_layer(&g_mamon_storyboard, scene, i);
            if (item && item->kind == STORY89_LAYER_TYPOGRAPHY) return fail("prebuilt typography layer remains in logo chain");
        }
    }
    printf("PASS: declarative text and indefinite Push Start/Menu layers\n");
    return 0;
}
