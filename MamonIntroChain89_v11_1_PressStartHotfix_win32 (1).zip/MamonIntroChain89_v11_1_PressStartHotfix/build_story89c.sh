#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
CC="${CC:-cc}"
"$CC" -std=c89 -pedantic-errors -Wall -Wextra -Werror \
  -Ivendor/airlite89/include -Ivendor/storyboard89/include -Ivendor/cut89/include \
  tools/story89c/main.c \
  vendor/airlite89/src/air89.c \
  vendor/storyboard89/src/story89.c vendor/storyboard89/src/story89_runtime.c \
  vendor/cut89/src/cut_base.c vendor/cut89/src/cut_lex.c vendor/cut89/src/cut_parse.c \
  vendor/cut89/src/cut_compile.c vendor/cut89/src/cut_vm.c vendor/cut89/src/cut_catalog.c \
  -o build/story89c
./build/story89c validate storyboards/mamon_intro.def
