#include "mamon_text_helpers.h"

static void mamon_preset(ic89_text_preset *preset, unsigned short font_id, unsigned short effect, ic89_color primary, ic89_color secondary, int thickness)
{
    ic89_text_preset_set(preset, font_id, effect, IC89_TEXT_ALIGN_CENTER, thickness, 0, 0, primary, secondary);
}


static void mamon_draw_text(const ic89_render_context *context, unsigned short font_id, unsigned short effect, int x, int y, const char *text, ic89_color primary, ic89_color secondary, int thickness)
{
    ic89_text_preset preset;
    mamon_preset(&preset, font_id, effect, primary, secondary, thickness);
    ic89_text_draw(context->fonts, context->canvas, &preset, x, y, text, IC89_FX_ONE);
}

void mamon_text_plain(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color color)
{
    mamon_draw_text(context, font_id, IC89_TEXT_PLAIN, x, y, text, color, color, 0);
}

void mamon_text_glow(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color glow, ic89_color main_color)
{
    mamon_draw_text(context, font_id, IC89_TEXT_GLOW, x, y, text, main_color, glow, 2);
}

void mamon_text_outline(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color edge, ic89_color fill, int thickness)
{
    mamon_draw_text(context, font_id, IC89_TEXT_OUTLINE, x, y, text, fill, edge, thickness);
}

void mamon_text_reveal_glow(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, unsigned long milliseconds_per_character, ic89_color glow, ic89_color main_color)
{
    ic89_text_preset preset;
    mamon_preset(&preset, font_id, IC89_TEXT_GLOW, main_color, glow, 2);
    ic89_text_draw_reveal(context->fonts, context->canvas, &preset, x, y, text, context->local_ms, milliseconds_per_character, IC89_FX_ONE);
}
