#include "bridges/story89_ic89_adapter.h"

#include "ic89_string.h"

static unsigned short story89_ic89_kind(unsigned short kind)
{
    switch (kind) {
    case STORY89_KIND_LOGO: return IC89_KIND_LOGO;
    case STORY89_KIND_INTRO: return IC89_KIND_INTRO;
    case STORY89_KIND_PUSH_START: return IC89_KIND_PUSH_START;
    case STORY89_KIND_MENU: return IC89_KIND_MENU;
    case STORY89_KIND_CUTSCENE: return IC89_KIND_OTHER;
    default: return IC89_KIND_NONE;
    }
}

static unsigned long story89_ic89_ms(const story89_program *program, long value)
{
    unsigned long whole;
    unsigned long remainder;
    if (value <= 0L) return 0UL;
    if (!program || program->timebase == 0U) return (unsigned long)value;
    whole = (unsigned long)value / (unsigned long)program->timebase;
    remainder = (unsigned long)value % (unsigned long)program->timebase;
    return whole * 1000UL + (remainder * 1000UL) / (unsigned long)program->timebase;
}

int story89_ic89_bind(story89_ic89_adapter *adapter, const story89_program *program, const char *pack_name)
{
    unsigned short i;
    if (!adapter || !program || program->scene_count > STORY89_IC89_MAX_SCENES) return 0;
    ic89_mem_zero(adapter, (unsigned long)sizeof(*adapter));
    for (i = 0U; i < program->scene_count; ++i) {
        const story89_scene *source;
        ic89_scene *target;
        source = &program->scenes[i];
        target = &adapter->scenes[i];
        if (source->scene_id < 0L || source->scene_id > 65535L ||
            source->visual_id < 0L || source->visual_id > 65535L) return 0;
        target->id = (unsigned short)source->scene_id;
        target->visual_id = (unsigned short)source->visual_id;
        target->kind = story89_ic89_kind(source->kind);
        target->start_target_kind = story89_ic89_kind(source->start_target_kind);
        target->flags = 0U;
        if (source->flags & STORY89_SCENE_WAIT_INPUT) target->flags |= IC89_SCENE_WAIT_INPUT;
        if (source->flags & STORY89_SCENE_MENU) target->flags |= IC89_SCENE_MENU;
        target->duration_ms = story89_ic89_ms(program, source->end_time);
        target->fade_in_ms = story89_ic89_ms(program, source->fade_in_time);
        target->fade_out_ms = story89_ic89_ms(program, source->fade_out_time);
    }
    adapter->pack.scenes = adapter->scenes;
    adapter->pack.count = program->scene_count;
    adapter->pack.name = pack_name;
    adapter->pack_refs[0] = &adapter->pack;
    ic89_sequence_bind(&adapter->sequence, adapter->pack_refs, 1U);
    return 1;
}

const ic89_sequence *story89_ic89_sequence(const story89_ic89_adapter *adapter)
{
    return adapter ? &adapter->sequence : (const ic89_sequence *)0;
}
