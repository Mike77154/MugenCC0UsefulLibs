#include "win32_min.h"
#include "mamon_font_faces.h"

/* These are physical font resource requests, not typography presets. */
static const ic89_font_face_spec g_mamon_font_faces[MAMON_FONT_COUNT] = {
    {-13, 0, FW_BOLD, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas"},
    {-18, 0, FW_BOLD, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Segoe UI"},
    {-28, 0, FW_HEAVY, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial Black"},
    {-42, 0, FW_HEAVY, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial Black"},
    {-64, 0, FW_HEAVY, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial Black"},
    {-20, 0, FW_BOLD, 0UL, ANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas"}
};

const ic89_font_face_spec *mamon_project_font_faces(void)
{
    return g_mamon_font_faces;
}

unsigned short mamon_project_font_face_count(void)
{
    return MAMON_FONT_COUNT;
}
