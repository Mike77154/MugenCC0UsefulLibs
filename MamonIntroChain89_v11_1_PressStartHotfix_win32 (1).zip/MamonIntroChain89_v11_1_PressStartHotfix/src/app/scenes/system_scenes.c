#include "mamon_visuals.h"
#include "mamon_typography_presets.h"
#include "ic89_effects.h"
#include "ic89_motion.h"

#define canvas (context->canvas)
#define t (context->local_ms)
#define v (context->visibility + ((user_data != (const void *)0) ? 0L : 0L))

void mamon_draw_press_start(const ic89_render_context *context, const void *user_data)
{
    int pulse;
    int y;
    ic89_color cyan;
    ic89_color white;
    ic89_color dim;
    cyan = ic89_color_scale(IC89_RGB(70, 230, 255), v);
    white = ic89_color_scale(IC89_RGB(250, 250, 255), v);
    dim = ic89_color_scale(IC89_RGB(20, 72, 88), v);
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, ic89_color_scale(IC89_RGB(0, 12, 18), v));
    ic89_fx_starfield(canvas, t * 2UL, dim, 96, 0x13579BDFUL);
    for (y = 0; y < MAMON_APP_HEIGHT; y += 24) {
        ic89_draw_line(canvas, 0, y + ic89_motion_bob(t + (unsigned long)(y * 5), 5U, 4), MAMON_APP_WIDTH, y, dim);
    }
    mamon_text_glow(context, MAMON_FONT_HUGE, MAMON_APP_WIDTH / 2, 80, "MAMON", dim, white);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 156, "INTRO CHAIN 89", cyan, white);
    pulse = (ic89_sin_q14((unsigned int)((t >> 3) & 255UL)) + 16493) >> 7;
    if (pulse > 70) {
        mamon_text_glow(context, MAMON_FONT_MEDIUM, MAMON_APP_WIDTH / 2, 258, "PRESS START", dim, white);
    }
    mamon_text_plain(context, MAMON_FONT_TINY, MAMON_APP_WIDTH / 2, 318, "ENTER / ESPACIO / CLICK", cyan);
    ic89_fx_scanlines(canvas, ic89_color_scale(IC89_RGB(0, 20, 24), v), 4);
}

void mamon_draw_menu(const ic89_render_context *context, const void *user_data)
{
    int hover;
    int pulse;
    ic89_color cyan;
    ic89_color white;
    ic89_color panel;
    ic89_color edge;
    cyan = ic89_color_scale(IC89_RGB(53, 228, 255), v);
    white = ic89_color_scale(IC89_RGB(248, 252, 255), v);
    panel = ic89_color_scale(IC89_RGB(7, 31, 42), v);
    edge = ic89_color_scale(IC89_RGB(22, 112, 135), v);
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, ic89_color_scale(IC89_RGB(0, 9, 14), v));
    ic89_fx_starfield(canvas, t / 2UL, edge, 48, 0x13579BDFUL);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 52, "EXPERIMENTO COMPLETADO", edge, white);
    mamon_text_plain(context, MAMON_FONT_SMALL, MAMON_APP_WIDTH / 2, 126, "EL MENU MAS EXCLUSIVO DEL PLANETA", cyan);
    hover = context->input->mouse_valid && ic89_hit_rect(user_data, context->input->mouse_x, context->input->mouse_y);
    pulse = ic89_motion_bob(t, 3U, 5);
    ic89_draw_round_rect(canvas, 238 - pulse, 215 - pulse, 402 + pulse, 269 + pulse, 18, 18, hover ? white : cyan, panel);
    ic89_draw_outline_rect(canvas, 244, 221, 396, 263, hover ? white : edge);
    mamon_text_glow(context, MAMON_FONT_MEDIUM, MAMON_APP_WIDTH / 2, 225, "EXIT", edge, hover ? cyan : white);
    mamon_text_plain(context, MAMON_FONT_TINY, MAMON_APP_WIDTH / 2, 308, "ENTER O CLICK PARA SALIR CON DIGNIDAD", edge);
    ic89_fx_scanlines(canvas, ic89_color_scale(IC89_RGB(0, 18, 22), v), 4);
}



#undef canvas
#undef t
#undef v
