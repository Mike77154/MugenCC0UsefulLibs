#include "mamon_visuals.h"
#include "mamon_typography_presets.h"
#include "ic89_effects.h"
#include "ic89_motion.h"

#define canvas (context->canvas)
#define t (context->local_ms)
#define v (context->visibility + ((user_data != (const void *)0) ? 0L : 0L))

void mamon_draw_intro_one(const ic89_render_context *context, const void *user_data)
{
    ic89_color white;
    ic89_color blue;
    white = ic89_color_scale(IC89_RGB(230, 240, 255), v);
    blue = ic89_color_scale(IC89_RGB(90, 168, 255), v);
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, ic89_color_scale(IC89_RGB(0, 5, 18), v));
    ic89_fx_starfield(canvas, t, ic89_color_scale(IC89_RGB(100, 145, 210), v), 74, 0x13579BDFUL);
    mamon_text_plain(context, MAMON_FONT_SMALL, MAMON_APP_WIDTH / 2, 84, "EN UNA COMPUTADORA LEJANA, MUY LEJANA...", blue);
    mamon_text_reveal_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 150, "UNA PRODUCCION QUE NADIE SOLICITO", 80UL, blue, white);
    ic89_draw_line(canvas, 120, 237, 520, 237, blue);
    mamon_text_plain(context, MAMON_FONT_TINY, MAMON_APP_WIDTH / 2, 252, "C89. SIN HEAP. SIN VERGUENZA.", white);
}

void mamon_draw_intro_two(const ic89_render_context *context, const void *user_data)
{
    ic89_color purple;
    ic89_color cyan;
    ic89_color white;
    purple = ic89_color_scale(IC89_RGB(155, 55, 255), v);
    cyan = ic89_color_scale(IC89_RGB(20, 220, 255), v);
    white = ic89_color_scale(IC89_RGB(250, 250, 255), v);
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, ic89_color_scale(IC89_RGB(8, 0, 20), v));
    ic89_fx_tunnel_rects(canvas, t, 12, 46, cyan, purple);
    mamon_text_plain(context, MAMON_FONT_MEDIUM, MAMON_APP_WIDTH / 2, 74, "EN UN MUNDO...", cyan);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 132, "DONDE CABEN ONCE LOGOS", purple, white);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 188, "CABEN OTROS ONCE MAS", cyan, white);
    mamon_text_plain(context, MAMON_FONT_TINY, MAMON_APP_WIDTH / 2, 278, "SECUENCIAS ENCADENADAS. TRANSICIONES. DRAMA CORPORATIVO.", purple);
}

void mamon_draw_intro_three(const ic89_render_context *context, const void *user_data)
{
    int i;
    int r;
    int flash;
    ic89_point_i tri[3];
    ic89_color orange;
    ic89_color red;
    ic89_color white;
    orange = ic89_color_scale(IC89_RGB(255, 160, 24), v);
    red = ic89_color_scale(IC89_RGB(255, 42, 24), v);
    white = ic89_color_scale(IC89_RGB(255, 248, 214), v);
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, ic89_color_scale(IC89_RGB(22, 4, 0), v));
    r = ic89_i_clamp((int)(t / 7UL), 0, 240);
    for (i = 0; i < 9; i++) {
        int ring_radius;
        ring_radius = r - i * 18;
        if (ring_radius > 2) {
            ic89_draw_circle(canvas, MAMON_APP_WIDTH / 2, MAMON_APP_HEIGHT / 2, ring_radius, (i & 1) ? orange : red, IC89_RGB(0, 0, 0));
        }
    }
    for (i = 0; i < 18; i++) {
        tri[0].x = MAMON_APP_WIDTH / 2;
        tri[0].y = MAMON_APP_HEIGHT / 2;
        tri[1].x = MAMON_APP_WIDTH / 2 + ((ic89_sin_q14((unsigned int)(i * 14)) * 310) >> 14);
        tri[1].y = MAMON_APP_HEIGHT / 2 + ((ic89_sin_q14((unsigned int)(i * 14 + 64)) * 210) >> 14);
        tri[2].x = MAMON_APP_WIDTH / 2 + ((ic89_sin_q14((unsigned int)(i * 14 + 7)) * 310) >> 14);
        tri[2].y = MAMON_APP_HEIGHT / 2 + ((ic89_sin_q14((unsigned int)(i * 14 + 71)) * 210) >> 14);
        ic89_draw_polygon(canvas, tri, 3, red, (i & 1) ? orange : red);
    }
    flash = (((t / 120UL) % 10UL) == 0UL);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 94, "TODO EL PRESUPUESTO", red, white);
    mamon_text_glow(context, MAMON_FONT_LARGE, MAMON_APP_WIDTH / 2, 151, "SE GASTO EN LOGOS", orange, flash ? red : white);
    mamon_text_plain(context, MAMON_FONT_MEDIUM, MAMON_APP_WIDTH / 2, 235, "Y AHORA... PRESS START.", white);
}


#undef canvas
#undef t
#undef v
