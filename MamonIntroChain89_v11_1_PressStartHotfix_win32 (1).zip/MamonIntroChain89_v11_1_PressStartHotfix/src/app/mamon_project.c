#include "mamon_project.h"
#include "packs/mamon_pack_commercial.h"
#include "packs/mamon_pack_funds.h"
#include "packs/mamon_pack_institutions.h"
#include "packs/mamon_pack_parody.h"
#include "packs/mamon_pack_intros.h"
#include "packs/mamon_pack_system.h"
#include "bridges/story89_ic89_adapter.h"
#include "mamon_storyboard_generated.h"

static const ic89_visual_pack *const g_mamon_visual_packs[] = {
    &g_mamon_visual_pack_commercial,
    &g_mamon_visual_pack_funds,
    &g_mamon_visual_pack_institutions,
    &g_mamon_visual_pack_parody,
    &g_mamon_visual_pack_intros,
    &g_mamon_visual_pack_system
};

static story89_ic89_adapter g_mamon_story_adapter;
static unsigned char g_mamon_story_bound;

static const ic89_visual_registry g_mamon_visual_registry = {
    g_mamon_visual_packs,
    (unsigned short)(sizeof(g_mamon_visual_packs) / sizeof(g_mamon_visual_packs[0]))
};

const ic89_sequence *mamon_project_sequence(void)
{
    if (!g_mamon_story_bound) {
        if (!story89_ic89_bind(&g_mamon_story_adapter, &g_mamon_storyboard, "mamon_storyboard89")) {
            return (const ic89_sequence *)0;
        }
        g_mamon_story_bound = 1U;
    }
    return story89_ic89_sequence(&g_mamon_story_adapter);
}

const ic89_visual_registry *mamon_project_visuals(void)
{
    return &g_mamon_visual_registry;
}

const story89_program *mamon_project_storyboard(void)
{
    return &g_mamon_storyboard;
}
