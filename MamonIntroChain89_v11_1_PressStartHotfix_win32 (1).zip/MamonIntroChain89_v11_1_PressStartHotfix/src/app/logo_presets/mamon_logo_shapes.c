#include "logo_presets/mamon_logo_shapes.h"
#include "mamon_config.h"
#include "ic89_draw2d.h"
#include "ic89_motion.h"
#include "ic89_trig.h"
#include "ic89_int_math.h"
#include "ic89_color.h"

#define CANVAS (context->canvas)
#define T (context->local_ms)
#define V (context->visibility)

static void shape_maseca_corn(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int bob;
    ic89_point_i leaf[5];
    ic89_color green;
    ic89_color yellow;
    (void)layer_data;
    (void)scene_user_data;
    green = ic89_color_scale(IC89_RGB(35, 145, 68), V);
    yellow = ic89_color_scale(IC89_RGB(255, 234, 36), V);
    bob = ic89_motion_bob(T, 4U, 4);
    leaf[0].x = 410; leaf[0].y = 202 + bob;
    leaf[1].x = 438; leaf[1].y = 186 + bob;
    leaf[2].x = 458; leaf[2].y = 208 + bob;
    leaf[3].x = 450; leaf[3].y = 247 + bob;
    leaf[4].x = 420; leaf[4].y = 241 + bob;
    ic89_draw_polygon(CANVAS, leaf, 5, green, green);
    for (i = 0; i < 6; i++) {
        ic89_draw_circle(CANVAS, 419 + (i % 2) * 15, 205 + (i / 2) * 13 + bob, 5, yellow, yellow);
    }
}

static void shape_fonca_bars(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    ic89_color blackc;
    ic89_color red;
    ic89_color green;
    ic89_color blue;
    ic89_color yellow;
    (void)layer_data;
    (void)scene_user_data;
    blackc = ic89_color_scale(IC89_RGB(20, 20, 20), V);
    red = ic89_color_scale(IC89_RGB(206, 45, 54), V);
    green = ic89_color_scale(IC89_RGB(54, 150, 92), V);
    blue = ic89_color_scale(IC89_RGB(40, 118, 176), V);
    yellow = ic89_color_scale(IC89_RGB(235, 171, 37), V);
    for (i = 0; i < 5; i++) {
        ic89_color cc;
        cc = (i == 0) ? red : ((i == 1) ? yellow : ((i == 2) ? green : ((i == 3) ? blue : blackc)));
        ic89_draw_fill_rect(CANVAS, 86 + i * 18, 101, 96 + i * 18, 239, cc);
    }
    ic89_draw_line(CANVAS, 209, 206, 536, 206, ic89_color_scale(IC89_RGB(118, 118, 118), V));
}

static void shape_fidecine_film(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int offset;
    ic89_color blackc;
    ic89_color green;
    ic89_color red;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    blackc = ic89_color_scale(IC89_RGB(18, 18, 18), V);
    green = ic89_color_scale(IC89_RGB(0, 116, 80), V);
    red = ic89_color_scale(IC89_RGB(171, 29, 57), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    offset = ic89_motion_bob(T, 4U, 5);
    ic89_draw_fill_rect(CANVAS, 74, 91 + offset, 210, 228 + offset, blackc);
    ic89_draw_fill_rect(CANVAS, 88, 108 + offset, 196, 211 + offset, white);
    for (i = 0; i < 5; i++) {
        ic89_draw_fill_rect(CANVAS, 78 + i * 27, 96 + offset, 88 + i * 27, 105 + offset, white);
        ic89_draw_fill_rect(CANVAS, 78 + i * 27, 214 + offset, 88 + i * 27, 223 + offset, white);
    }
    ic89_draw_fill_rect(CANVAS, 88, 108 + offset, 142, 211 + offset, green);
    ic89_draw_fill_rect(CANVAS, 142, 108 + offset, 196, 211 + offset, red);
    ic89_draw_line(CANVAS, 265, 232, 552, 232, red);
}

static void shape_imcine_cutouts(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int slide;
    ic89_point_i cut[3];
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    slide = ic89_i_clamp((int)(T / 7UL), 0, 120);
    cut[0].x = 239; cut[0].y = 107 + (120 - slide);
    cut[1].x = 269; cut[1].y = 107 + (120 - slide);
    cut[2].x = 254; cut[2].y = 143 + (120 - slide);
    ic89_draw_polygon(CANVAS, cut, 3, white, white);
    cut[0].x = 395; cut[0].y = 107 + (120 - slide);
    cut[1].x = 425; cut[1].y = 107 + (120 - slide);
    cut[2].x = 425; cut[2].y = 143 + (120 - slide);
    ic89_draw_polygon(CANVAS, cut, 3, white, white);
}

static void shape_foprocine_film(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int frame;
    ic89_color red;
    ic89_color blackc;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    red = ic89_color_scale(IC89_RGB(167, 28, 53), V);
    blackc = ic89_color_scale(IC89_RGB(22, 22, 22), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    frame = (int)((T / 100UL) % 6UL);
    for (i = 0; i < 6; i++) {
        int yy;
        yy = 91 + i * 29;
        ic89_draw_fill_rect(CANVAS, 71, yy, 208, yy + 18, (i == frame) ? red : blackc);
        ic89_draw_fill_rect(CANVAS, 80, yy + 4, 99, yy + 14, white);
        ic89_draw_fill_rect(CANVAS, 180, yy + 4, 199, yy + 14, white);
    }
}

static void shape_conaculta_mark(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    ic89_point_i tri[3];
    ic89_color blackc;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    blackc = ic89_color_scale(IC89_RGB(0, 0, 0), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    ic89_draw_circle(CANVAS, 94, 155, 28, blackc, blackc);
    ic89_draw_fill_rect(CANVAS, 94, 126, 123, 184, white);
    tri[0].x = 124; tri[0].y = 126;
    tri[1].x = 156; tri[1].y = 184;
    tri[2].x = 93; tri[2].y = 184;
    ic89_draw_polygon(CANVAS, tri, 3, blackc, blackc);
}

static void shape_conaculta_reveal(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int reveal;
    ic89_color white;
    ic89_color gray;
    (void)layer_data;
    (void)scene_user_data;
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    gray = ic89_color_scale(IC89_RGB(150, 150, 150), V);
    reveal = ic89_i_clamp((int)(T / 5UL), 0, 340);
    if (reveal < 340) {
        ic89_draw_fill_rect(CANVAS, 156 + reveal, 121, 520, 192, white);
        ic89_draw_line(CANVAS, 156 + reveal, 121, 156 + reveal, 192, gray);
    }
}

static void shape_inah_sun(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int ring;
    ic89_color red;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    red = ic89_color_scale(IC89_RGB(151, 25, 45), V);
    white = ic89_color_scale(IC89_RGB(252, 250, 247), V);
    ring = 62 + ic89_motion_bob(T, 4U, 4);
    ic89_draw_circle(CANVAS, 151, 164, ring, red, white);
    ic89_draw_circle(CANVAS, 151, 164, ring - 9, red, white);
    for (i = 0; i < 8; i++) {
        ic89_draw_line(CANVAS, 151, 164,
            151 + ((ic89_sin_q14((unsigned int)(i * 32)) * 55) >> 14),
            164 + ((ic89_sin_q14((unsigned int)(i * 32 + 64)) * 55) >> 14), red);
    }
    ic89_draw_circle(CANVAS, 151, 164, 18, red, red);
}

static void shape_inbal_bars(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int x;
    ic89_color blue;
    ic89_color gray;
    (void)layer_data;
    (void)scene_user_data;
    blue = ic89_color_scale(IC89_RGB(35, 94, 145), V);
    gray = ic89_color_scale(IC89_RGB(207, 216, 224), V);
    x = 80 + ic89_i_clamp((int)(T / 8UL), 0, 70);
    for (i = 0; i < 5; i++) {
        ic89_draw_fill_rect(CANVAS, x + i * 22, 111 + i * 8,
            x + 14 + i * 22, 227 - i * 8, (i & 1) ? blue : gray);
    }
}

static void shape_cineteca_reel(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    ic89_color blackc;
    ic89_color white;
    ic89_color red;
    ic89_color gray;
    (void)layer_data;
    (void)scene_user_data;
    blackc = ic89_color_scale(IC89_RGB(17, 17, 17), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    red = ic89_color_scale(IC89_RGB(173, 34, 48), V);
    gray = ic89_color_scale(IC89_RGB(155, 155, 155), V);
    ic89_draw_circle(CANVAS, 155, 179, 75, white, blackc);
    ic89_draw_circle(CANVAS, 155, 179, 47, white, blackc);
    ic89_draw_circle(CANVAS, 155, 179, 12, red, red);
    ic89_draw_line(CANVAS, 155, 104, 155, 254, gray);
    ic89_draw_line(CANVAS, 80, 179, 230, 179, gray);
}

static void shape_cultura_seal(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int phase;
    ic89_color gold;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    gold = ic89_color_scale(IC89_RGB(171, 134, 26), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    phase = (int)((T / 16UL) & 255UL);
    ic89_draw_circle(CANVAS, 124, 164, 52, gold, white);
    for (i = 0; i < 12; i++) {
        int x0;
        int y0;
        x0 = 124 + ((ic89_sin_q14((unsigned int)(phase + i * 21)) * 39) >> 14);
        y0 = 164 + ((ic89_sin_q14((unsigned int)(phase + i * 21 + 64)) * 39) >> 14);
        ic89_draw_circle(CANVAS, x0, y0, 5, gold, gold);
    }
    ic89_draw_line(CANVAS, 236, 221, 552, 221, gold);
}

const ic89_logo_layer g_mamon_shape_maseca_corn = {IC89_LOGO_LAYER_SHAPE, shape_maseca_corn, (const void *)0, "maseca_corn_mark"};
const ic89_logo_layer g_mamon_shape_fonca_bars = {IC89_LOGO_LAYER_SHAPE, shape_fonca_bars, (const void *)0, "fonca_color_bars"};
const ic89_logo_layer g_mamon_shape_fidecine_film = {IC89_LOGO_LAYER_SHAPE, shape_fidecine_film, (const void *)0, "fidecine_film_mark"};
const ic89_logo_layer g_mamon_shape_imcine_cutouts = {IC89_LOGO_LAYER_SHAPE, shape_imcine_cutouts, (const void *)0, "imcine_wordmark_cutouts"};
const ic89_logo_layer g_mamon_shape_foprocine_film = {IC89_LOGO_LAYER_SHAPE, shape_foprocine_film, (const void *)0, "foprocine_film_column"};
const ic89_logo_layer g_mamon_shape_conaculta_mark = {IC89_LOGO_LAYER_SHAPE, shape_conaculta_mark, (const void *)0, "conaculta_symbol"};
const ic89_logo_layer g_mamon_shape_conaculta_reveal = {IC89_LOGO_LAYER_SHAPE, shape_conaculta_reveal, (const void *)0, "conaculta_reveal_mask"};
const ic89_logo_layer g_mamon_shape_inah_sun = {IC89_LOGO_LAYER_SHAPE, shape_inah_sun, (const void *)0, "inah_radial_seal"};
const ic89_logo_layer g_mamon_shape_inbal_bars = {IC89_LOGO_LAYER_SHAPE, shape_inbal_bars, (const void *)0, "inbal_vertical_mark"};
const ic89_logo_layer g_mamon_shape_cineteca_reel = {IC89_LOGO_LAYER_SHAPE, shape_cineteca_reel, (const void *)0, "cineteca_reel"};
const ic89_logo_layer g_mamon_shape_cultura_seal = {IC89_LOGO_LAYER_SHAPE, shape_cultura_seal, (const void *)0, "cultura_orbit_seal"};

#undef CANVAS
#undef T
#undef V

const ic89_logo_layer *const g_mamon_logo_shape_presets[] = {
    &g_mamon_shape_maseca_corn,
    &g_mamon_shape_fonca_bars,
    &g_mamon_shape_fidecine_film,
    &g_mamon_shape_imcine_cutouts,
    &g_mamon_shape_foprocine_film,
    &g_mamon_shape_conaculta_mark,
    &g_mamon_shape_conaculta_reveal,
    &g_mamon_shape_inah_sun,
    &g_mamon_shape_inbal_bars,
    &g_mamon_shape_cineteca_reel,
    &g_mamon_shape_cultura_seal
};

const unsigned short g_mamon_logo_shape_preset_count =
    (unsigned short)(sizeof(g_mamon_logo_shape_presets) /
    sizeof(g_mamon_logo_shape_presets[0]));
