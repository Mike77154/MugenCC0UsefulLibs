#include "logo_presets/mamon_logo_primitives.h"
#include "mamon_config.h"
#include "ic89_draw2d.h"
#include "ic89_motion.h"
#include "ic89_trig.h"
#include "ic89_int_math.h"
#include "ic89_color.h"

#define CANVAS (context->canvas)
#define T (context->local_ms)
#define V (context->visibility)

static void primitive_capcom_background(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int radius;
    ic89_color blue;
    ic89_color gold;
    ic89_color dark;
    (void)layer_data;
    (void)scene_user_data;
    blue = ic89_color_scale(IC89_RGB(22, 69, 166), V);
    gold = ic89_color_scale(IC89_RGB(255, 205, 25), V);
    dark = ic89_color_scale(IC89_RGB(3, 12, 34), V);
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, dark);
    radius = 85 + ic89_i_clamp((int)(T / 12UL), 0, 90);
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, MAMON_APP_HEIGHT / 2 - 12, radius, blue, IC89_RGB(0, 0, 0));
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, MAMON_APP_HEIGHT / 2 - 12, radius - 6, gold, IC89_RGB(0, 0, 0));
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, MAMON_APP_HEIGHT / 2 - 12, radius - 13, dark, IC89_RGB(0, 0, 0));
}

static void primitive_capcom_shine(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int x;
    int y;
    int shine;
    ic89_color gold;
    (void)layer_data;
    (void)scene_user_data;
    gold = ic89_color_scale(IC89_RGB(255, 205, 25), V);
    shine = (int)((T / 5UL) % 900UL) - 130;
    for (x = 0; x < 34; x += 5) {
        y = 104 + x;
        ic89_draw_line(CANVAS, shine + x, y, shine + 120 + x, y, gold);
    }
}

static void primitive_maseca(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int bob;
    int i;
    int angle;
    int x;
    int y;
    ic89_color green;
    ic89_color deep_green;
    ic89_color cream;
    ic89_color orange;
    (void)layer_data;
    (void)scene_user_data;
    green = ic89_color_scale(IC89_RGB(35, 145, 68), V);
    deep_green = ic89_color_scale(IC89_RGB(8, 34, 17), V);
    cream = ic89_color_scale(IC89_RGB(255, 242, 196), V);
    orange = ic89_color_scale(IC89_RGB(244, 147, 31), V);
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, deep_green);
    bob = ic89_motion_bob(T, 4U, 4);
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, 166 + bob, 112, orange, orange);
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, 166 + bob, 102, green, green);
    ic89_draw_circle(CANVAS, MAMON_APP_WIDTH / 2, 166 + bob, 91, cream, cream);
    for (i = 0; i < 12; i++) {
        angle = (i * 21 + (int)(T >> 4)) & 255;
        x = MAMON_APP_WIDTH / 2 + ((ic89_sin_q14((unsigned int)angle) * 142) >> 14);
        y = 166 + ((ic89_sin_q14((unsigned int)(angle + 64)) * 102) >> 14);
        ic89_draw_circle(CANVAS, x, y, 5, orange, orange);
    }
}

static void primitive_fonca_background(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)layer_data;
    (void)scene_user_data;
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT,
        ic89_color_scale(IC89_RGB(255, 255, 255), V));
}

static void primitive_fonca_sweep(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int sweep;
    (void)layer_data;
    (void)scene_user_data;
    sweep = (int)((T / 7UL) % 760UL) - 80;
    for (i = 0; i < 4; i++) {
        ic89_draw_line(CANVAS, sweep + i * 4, 79, sweep + 132 + i * 4, 270,
            ic89_color_scale(IC89_RGB(220, 220, 220), V));
    }
}

static void primitive_white(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)layer_data;
    (void)scene_user_data;
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT,
        ic89_color_scale(IC89_RGB(255, 255, 255), V));
}

static void primitive_inah(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    (void)layer_data;
    (void)scene_user_data;
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT,
        ic89_color_scale(IC89_RGB(252, 250, 247), V));
}

static void primitive_cineteca(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int shift;
    ic89_color blackc;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    blackc = ic89_color_scale(IC89_RGB(17, 17, 17), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, blackc);
    shift = (int)((T / 12UL) % 44UL);
    for (i = -2; i < 18; i++) {
        ic89_draw_fill_rect(CANVAS, i * 44 + shift, 42, i * 44 + shift + 22, 64, white);
        ic89_draw_fill_rect(CANVAS, i * 44 + shift, 296, i * 44 + shift + 22, 318, white);
    }
}

static void primitive_imcine_strip(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    ic89_color gray;
    ic89_color light;
    (void)layer_data;
    (void)scene_user_data;
    gray = ic89_color_scale(IC89_RGB(112, 116, 116), V);
    light = ic89_color_scale(IC89_RGB(210, 214, 214), V);
    for (i = 0; i < 12; i++) {
        ic89_draw_fill_rect(CANVAS, 98 + i * 40, 257, 119 + i * 40, 269, (i & 1) ? gray : light);
    }
}

static void primitive_caricachupas(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    int i;
    int y;
    ic89_color red;
    ic89_color yellow;
    (void)layer_data;
    (void)scene_user_data;
    red = ic89_color_scale(IC89_RGB(255, 36, 36), V);
    yellow = ic89_color_scale(IC89_RGB(255, 230, 48), V);
    ic89_draw_fill_rect(CANVAS, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT,
        ic89_color_scale(IC89_RGB(34, 0, 0), V));
    for (i = 0; i < 22; i++) {
        y = (i * 19 + (int)(T / 9UL)) % MAMON_APP_HEIGHT;
        ic89_draw_line(CANVAS, 0, y, MAMON_APP_WIDTH, y, (i & 1) ? red : yellow);
    }
}

static void primitive_caricachupas_glitch(const ic89_render_context *context, const void *layer_data, const void *scene_user_data)
{
    ic89_color red;
    ic89_color white;
    (void)layer_data;
    (void)scene_user_data;
    red = ic89_color_scale(IC89_RGB(255, 36, 36), V);
    white = ic89_color_scale(IC89_RGB(255, 255, 255), V);
    if (((T / 90UL) % 7UL) == 0UL) {
        ic89_draw_fill_rect(CANVAS, 0, 150, MAMON_APP_WIDTH, 160, white);
        ic89_draw_fill_rect(CANVAS, 0, 223, MAMON_APP_WIDTH, 229, red);
    }
}

const ic89_logo_layer g_mamon_primitive_capcom = {IC89_LOGO_LAYER_PRIMITIVE, primitive_capcom_background, (const void *)0, "capcom_background_rings"};
const ic89_logo_layer g_mamon_primitive_capcom_shine = {IC89_LOGO_LAYER_PRIMITIVE, primitive_capcom_shine, (const void *)0, "capcom_foreground_shine"};
const ic89_logo_layer g_mamon_primitive_maseca = {IC89_LOGO_LAYER_PRIMITIVE, primitive_maseca, (const void *)0, "maseca_orbit_background"};
const ic89_logo_layer g_mamon_primitive_fonca = {IC89_LOGO_LAYER_PRIMITIVE, primitive_fonca_background, (const void *)0, "fonca_white_background"};
const ic89_logo_layer g_mamon_primitive_fonca_sweep = {IC89_LOGO_LAYER_PRIMITIVE, primitive_fonca_sweep, (const void *)0, "fonca_foreground_sweep"};
const ic89_logo_layer g_mamon_primitive_fidecine = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "fidecine_white_background"};
const ic89_logo_layer g_mamon_primitive_imcine = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "imcine_white_background"};
const ic89_logo_layer g_mamon_primitive_imcine_strip = {IC89_LOGO_LAYER_PRIMITIVE, primitive_imcine_strip, (const void *)0, "imcine_foreground_strip"};
const ic89_logo_layer g_mamon_primitive_foprocine = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "foprocine_white_background"};
const ic89_logo_layer g_mamon_primitive_conaculta = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "conaculta_white_background"};
const ic89_logo_layer g_mamon_primitive_inah = {IC89_LOGO_LAYER_PRIMITIVE, primitive_inah, (const void *)0, "inah_warm_background"};
const ic89_logo_layer g_mamon_primitive_inbal = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "inbal_white_background"};
const ic89_logo_layer g_mamon_primitive_cineteca = {IC89_LOGO_LAYER_PRIMITIVE, primitive_cineteca, (const void *)0, "cineteca_moving_perforations"};
const ic89_logo_layer g_mamon_primitive_cultura = {IC89_LOGO_LAYER_PRIMITIVE, primitive_white, (const void *)0, "cultura_white_background"};
const ic89_logo_layer g_mamon_primitive_caricachupas = {IC89_LOGO_LAYER_PRIMITIVE, primitive_caricachupas, (const void *)0, "caricachupas_scan_background"};
const ic89_logo_layer g_mamon_primitive_caricachupas_glitch = {IC89_LOGO_LAYER_PRIMITIVE, primitive_caricachupas_glitch, (const void *)0, "caricachupas_foreground_glitch"};

#undef CANVAS
#undef T
#undef V

const ic89_logo_layer *const g_mamon_logo_primitive_presets[] = {
    &g_mamon_primitive_capcom,
    &g_mamon_primitive_capcom_shine,
    &g_mamon_primitive_maseca,
    &g_mamon_primitive_fonca,
    &g_mamon_primitive_fonca_sweep,
    &g_mamon_primitive_fidecine,
    &g_mamon_primitive_imcine,
    &g_mamon_primitive_imcine_strip,
    &g_mamon_primitive_foprocine,
    &g_mamon_primitive_conaculta,
    &g_mamon_primitive_inah,
    &g_mamon_primitive_inbal,
    &g_mamon_primitive_cineteca,
    &g_mamon_primitive_cultura,
    &g_mamon_primitive_caricachupas,
    &g_mamon_primitive_caricachupas_glitch
};

const unsigned short g_mamon_logo_primitive_preset_count =
    (unsigned short)(sizeof(g_mamon_logo_primitive_presets) /
    sizeof(g_mamon_logo_primitive_presets[0]));
