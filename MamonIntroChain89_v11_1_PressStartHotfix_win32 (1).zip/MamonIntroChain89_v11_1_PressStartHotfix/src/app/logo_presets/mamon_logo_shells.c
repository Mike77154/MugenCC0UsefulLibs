#include "logo_presets/mamon_logo_shells.h"
#include "logo_presets/mamon_logo_primitives.h"
#include "logo_presets/mamon_logo_shapes.h"

#define RECIPE(symbol_, array_) \
    const ic89_logo_recipe symbol_ = {array_, (unsigned short)(sizeof(array_) / sizeof((array_)[0])), #symbol_}

static const ic89_logo_layer *const g_capcom[] = {&g_mamon_primitive_capcom};
static const ic89_logo_layer *const g_capcom_shine[] = {&g_mamon_primitive_capcom_shine};
static const ic89_logo_layer *const g_maseca[] = {&g_mamon_primitive_maseca};
static const ic89_logo_layer *const g_maseca_corn[] = {&g_mamon_shape_maseca_corn};
static const ic89_logo_layer *const g_fonca[] = {&g_mamon_primitive_fonca, &g_mamon_shape_fonca_bars};
static const ic89_logo_layer *const g_fonca_sweep[] = {&g_mamon_primitive_fonca_sweep};
static const ic89_logo_layer *const g_fidecine[] = {&g_mamon_primitive_fidecine, &g_mamon_shape_fidecine_film};
static const ic89_logo_layer *const g_imcine[] = {&g_mamon_primitive_imcine};
static const ic89_logo_layer *const g_imcine_cutouts[] = {&g_mamon_shape_imcine_cutouts};
static const ic89_logo_layer *const g_imcine_strip[] = {&g_mamon_primitive_imcine_strip};
static const ic89_logo_layer *const g_foprocine[] = {&g_mamon_primitive_foprocine, &g_mamon_shape_foprocine_film};
static const ic89_logo_layer *const g_conaculta[] = {&g_mamon_primitive_conaculta, &g_mamon_shape_conaculta_mark};
static const ic89_logo_layer *const g_conaculta_reveal[] = {&g_mamon_shape_conaculta_reveal};
static const ic89_logo_layer *const g_inah[] = {&g_mamon_primitive_inah, &g_mamon_shape_inah_sun};
static const ic89_logo_layer *const g_inbal[] = {&g_mamon_primitive_inbal, &g_mamon_shape_inbal_bars};
static const ic89_logo_layer *const g_cineteca[] = {&g_mamon_primitive_cineteca, &g_mamon_shape_cineteca_reel};
static const ic89_logo_layer *const g_cultura[] = {&g_mamon_primitive_cultura, &g_mamon_shape_cultura_seal};
static const ic89_logo_layer *const g_caricachupas[] = {&g_mamon_primitive_caricachupas};
static const ic89_logo_layer *const g_caricachupas_glitch[] = {&g_mamon_primitive_caricachupas_glitch};

RECIPE(g_mamon_shell_capcom, g_capcom);
RECIPE(g_mamon_shell_capcom_shine, g_capcom_shine);
RECIPE(g_mamon_shell_maseca, g_maseca);
RECIPE(g_mamon_shell_maseca_corn, g_maseca_corn);
RECIPE(g_mamon_shell_fonca, g_fonca);
RECIPE(g_mamon_shell_fonca_sweep, g_fonca_sweep);
RECIPE(g_mamon_shell_fidecine, g_fidecine);
RECIPE(g_mamon_shell_imcine, g_imcine);
RECIPE(g_mamon_shell_imcine_cutouts, g_imcine_cutouts);
RECIPE(g_mamon_shell_imcine_strip, g_imcine_strip);
RECIPE(g_mamon_shell_foprocine, g_foprocine);
RECIPE(g_mamon_shell_conaculta, g_conaculta);
RECIPE(g_mamon_shell_conaculta_reveal, g_conaculta_reveal);
RECIPE(g_mamon_shell_inah, g_inah);
RECIPE(g_mamon_shell_inbal, g_inbal);
RECIPE(g_mamon_shell_cineteca, g_cineteca);
RECIPE(g_mamon_shell_cultura, g_cultura);
RECIPE(g_mamon_shell_caricachupas, g_caricachupas);
RECIPE(g_mamon_shell_caricachupas_glitch, g_caricachupas_glitch);

#undef RECIPE
