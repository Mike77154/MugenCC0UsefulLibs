#include "packs/mamon_pack_institutions.h"
#include "mamon_visuals.h"
#include "logo_presets/mamon_logo_shells.h"
#include "ic89_logo_recipe.h"
#include "ic89_hit_region.h"

static const ic89_scene g_mamon_institution_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_CONACULTA, MAMON_VIS_CONACULTA, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_INAH, MAMON_VIS_INAH, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_INBAL, MAMON_VIS_INBAL, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_CINETECA, MAMON_VIS_CINETECA, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_CULTURA, MAMON_VIS_CULTURA, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL)
};

static const ic89_visual_entry g_mamon_institution_visuals[] = {
    {MAMON_VIS_CONACULTA, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_conaculta},
    {MAMON_VIS_CONACULTA_REVEAL, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_conaculta_reveal},
    {MAMON_VIS_INAH, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_inah},
    {MAMON_VIS_INBAL, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_inbal},
    {MAMON_VIS_CINETECA, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_cineteca},
    {MAMON_VIS_CULTURA, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_cultura}
};

const ic89_scene_pack g_mamon_scene_pack_institutions = {
    g_mamon_institution_scenes,
    (unsigned short)(sizeof(g_mamon_institution_scenes) / sizeof(g_mamon_institution_scenes[0])),
    "cultural_institutions"
};

const ic89_visual_pack g_mamon_visual_pack_institutions = {
    g_mamon_institution_visuals,
    (unsigned short)(sizeof(g_mamon_institution_visuals) / sizeof(g_mamon_institution_visuals[0])),
    "cultural_institution_visuals"
};
