#include "packs/mamon_pack_system.h"
#include "mamon_visuals.h"
#include "ic89_hit_region.h"

static const ic89_rect_i g_mamon_exit_rect = {238, 215, 402, 269};

static const ic89_scene g_mamon_system_scenes[] = {
    MAMON_NODE_WAIT(MAMON_VIS_PRESS_START, MAMON_VIS_PRESS_START, IC89_KIND_PUSH_START, IC89_SCENE_WAIT_INPUT, IC89_KIND_MENU, 700UL),
    MAMON_NODE_WAIT(MAMON_VIS_MENU, MAMON_VIS_MENU, IC89_KIND_MENU, IC89_SCENE_MENU | IC89_SCENE_WAIT_INPUT, IC89_KIND_NONE, 400UL)
};

static const ic89_visual_entry g_mamon_system_visuals[] = {
    {MAMON_VIS_PRESS_START, mamon_draw_press_start, ic89_hit_none, (const void *)0},
    {MAMON_VIS_MENU, mamon_draw_menu, ic89_hit_rect, &g_mamon_exit_rect}
};

const ic89_scene_pack g_mamon_scene_pack_system = {
    g_mamon_system_scenes,
    (unsigned short)(sizeof(g_mamon_system_scenes) / sizeof(g_mamon_system_scenes[0])),
    "push_start_and_menu"
};

const ic89_visual_pack g_mamon_visual_pack_system = {
    g_mamon_system_visuals,
    (unsigned short)(sizeof(g_mamon_system_visuals) / sizeof(g_mamon_system_visuals[0])),
    "system_visuals"
};
