#include "packs/mamon_pack_funds.h"
#include "mamon_visuals.h"
#include "logo_presets/mamon_logo_shells.h"
#include "ic89_logo_recipe.h"
#include "ic89_hit_region.h"

static const ic89_scene g_mamon_funds_a_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_FONCA, MAMON_VIS_FONCA, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_FIDECINE, MAMON_VIS_FIDECINE, IC89_KIND_LOGO, IC89_KIND_INTRO, 2400UL, 320UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_IMCINE, MAMON_VIS_IMCINE, IC89_KIND_LOGO, IC89_KIND_INTRO, 2300UL, 320UL, 420UL)
};

static const ic89_scene g_mamon_funds_b_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_FOPROCINE, MAMON_VIS_FOPROCINE, IC89_KIND_LOGO, IC89_KIND_INTRO, 2400UL, 320UL, 500UL)
};

static const ic89_visual_entry g_mamon_funds_visuals[] = {
    {MAMON_VIS_FONCA, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_fonca},
    {MAMON_VIS_FONCA_SWEEP, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_fonca_sweep},
    {MAMON_VIS_FIDECINE, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_fidecine},
    {MAMON_VIS_IMCINE, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_imcine},
    {MAMON_VIS_IMCINE_CUTOUTS, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_imcine_cutouts},
    {MAMON_VIS_IMCINE_STRIP, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_imcine_strip},
    {MAMON_VIS_FOPROCINE, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_foprocine}
};

const ic89_scene_pack g_mamon_scene_pack_funds_a = {
    g_mamon_funds_a_scenes,
    (unsigned short)(sizeof(g_mamon_funds_a_scenes) / sizeof(g_mamon_funds_a_scenes[0])),
    "film_funds_a"
};

const ic89_scene_pack g_mamon_scene_pack_funds_b = {
    g_mamon_funds_b_scenes,
    (unsigned short)(sizeof(g_mamon_funds_b_scenes) / sizeof(g_mamon_funds_b_scenes[0])),
    "film_funds_b"
};

const ic89_visual_pack g_mamon_visual_pack_funds = {
    g_mamon_funds_visuals,
    (unsigned short)(sizeof(g_mamon_funds_visuals) / sizeof(g_mamon_funds_visuals[0])),
    "film_fund_visuals"
};
