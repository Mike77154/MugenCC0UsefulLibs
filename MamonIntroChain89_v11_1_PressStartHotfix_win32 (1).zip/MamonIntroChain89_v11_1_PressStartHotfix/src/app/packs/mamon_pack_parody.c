#include "packs/mamon_pack_parody.h"
#include "mamon_visuals.h"
#include "logo_presets/mamon_logo_shells.h"
#include "ic89_logo_recipe.h"
#include "ic89_hit_region.h"

static const ic89_scene g_mamon_parody_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_CARICACHUPAS, MAMON_VIS_CARICACHUPAS, IC89_KIND_LOGO, IC89_KIND_INTRO, 2600UL, 280UL, 650UL)
};

static const ic89_visual_entry g_mamon_parody_visuals[] = {
    {MAMON_VIS_CARICACHUPAS, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_caricachupas},
    {MAMON_VIS_CARICACHUPAS_GLITCH, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_caricachupas_glitch}
};

const ic89_scene_pack g_mamon_scene_pack_parody = {
    g_mamon_parody_scenes,
    (unsigned short)(sizeof(g_mamon_parody_scenes) / sizeof(g_mamon_parody_scenes[0])),
    "parody_logo"
};

const ic89_visual_pack g_mamon_visual_pack_parody = {
    g_mamon_parody_visuals,
    (unsigned short)(sizeof(g_mamon_parody_visuals) / sizeof(g_mamon_parody_visuals[0])),
    "parody_visual"
};
