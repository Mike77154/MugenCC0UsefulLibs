#include "packs/mamon_pack_intros.h"
#include "mamon_visuals.h"
#include "ic89_hit_region.h"

static const ic89_scene g_mamon_intro_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_INTRO_ONE, MAMON_VIS_INTRO_ONE, IC89_KIND_INTRO, IC89_KIND_PUSH_START, 4100UL, 500UL, 700UL),
    MAMON_NODE_TIMED(MAMON_VIS_INTRO_TWO, MAMON_VIS_INTRO_TWO, IC89_KIND_INTRO, IC89_KIND_PUSH_START, 4300UL, 500UL, 700UL),
    MAMON_NODE_TIMED(MAMON_VIS_INTRO_THREE, MAMON_VIS_INTRO_THREE, IC89_KIND_INTRO, IC89_KIND_PUSH_START, 4400UL, 500UL, 800UL)
};

static const ic89_visual_entry g_mamon_intro_visuals[] = {
    {MAMON_VIS_INTRO_ONE, mamon_draw_intro_one, ic89_hit_none, (const void *)0},
    {MAMON_VIS_INTRO_TWO, mamon_draw_intro_two, ic89_hit_none, (const void *)0},
    {MAMON_VIS_INTRO_THREE, mamon_draw_intro_three, ic89_hit_none, (const void *)0}
};

const ic89_scene_pack g_mamon_scene_pack_intros = {
    g_mamon_intro_scenes,
    (unsigned short)(sizeof(g_mamon_intro_scenes) / sizeof(g_mamon_intro_scenes[0])),
    "intro_chain"
};

const ic89_visual_pack g_mamon_visual_pack_intros = {
    g_mamon_intro_visuals,
    (unsigned short)(sizeof(g_mamon_intro_visuals) / sizeof(g_mamon_intro_visuals[0])),
    "intro_visuals"
};
