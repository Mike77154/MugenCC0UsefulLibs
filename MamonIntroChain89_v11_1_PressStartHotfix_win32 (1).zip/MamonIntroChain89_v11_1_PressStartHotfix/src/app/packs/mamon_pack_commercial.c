#include "packs/mamon_pack_commercial.h"
#include "mamon_visuals.h"
#include "logo_presets/mamon_logo_shells.h"
#include "ic89_logo_recipe.h"
#include "ic89_hit_region.h"

static const ic89_scene g_mamon_commercial_scenes[] = {
    MAMON_NODE_TIMED(MAMON_VIS_CAPCOM, MAMON_VIS_CAPCOM, IC89_KIND_LOGO, IC89_KIND_INTRO, 2500UL, 360UL, 420UL),
    MAMON_NODE_TIMED(MAMON_VIS_MASECA, MAMON_VIS_MASECA, IC89_KIND_LOGO, IC89_KIND_INTRO, 2500UL, 360UL, 420UL)
};

static const ic89_visual_entry g_mamon_commercial_visuals[] = {
    {MAMON_VIS_CAPCOM, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_capcom},
    {MAMON_VIS_CAPCOM_SHINE, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_capcom_shine},
    {MAMON_VIS_MASECA, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_maseca},
    {MAMON_VIS_MASECA_CORN, ic89_logo_recipe_draw_scene, ic89_hit_none, &g_mamon_shell_maseca_corn}
};

const ic89_scene_pack g_mamon_scene_pack_commercial = {
    g_mamon_commercial_scenes,
    (unsigned short)(sizeof(g_mamon_commercial_scenes) / sizeof(g_mamon_commercial_scenes[0])),
    "commercial_logos"
};

const ic89_visual_pack g_mamon_visual_pack_commercial = {
    g_mamon_commercial_visuals,
    (unsigned short)(sizeof(g_mamon_commercial_visuals) / sizeof(g_mamon_commercial_visuals[0])),
    "commercial_visuals"
};
