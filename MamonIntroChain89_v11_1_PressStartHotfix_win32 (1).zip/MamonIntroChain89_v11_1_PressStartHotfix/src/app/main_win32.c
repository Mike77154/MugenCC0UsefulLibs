#include "win32_min.h"
#include "mamon_project.h"
#include "ic89_gdi_presenter.h"
#include "ic89_gdi_font_factory.h"
#include "ic89_gdi_text_renderer.h"
#include "ic89_input_edges.h"
#include "ic89_scene_runtime.h"
#include "story89_ic89_render.h"
#include "ic89_win32_host.h"
#include "ic89_string.h"

typedef struct mamon_app {
    HWND window;
    ic89_gdi_presenter presenter;
    ic89_font_bank fonts;
    ic89_player player;
    ic89_input_edges input;
} mamon_app;

static mamon_app g_app;

static void mamon_render_frame(HWND window)
{
    ic89_canvas *canvas;
    ic89_render_input render_input;
    canvas = ic89_gdi_presenter_begin(&g_app.presenter, window);
    if (canvas == (ic89_canvas *)0) {
        return;
    }
    ic89_draw_fill_rect(canvas, 0, 0, MAMON_APP_WIDTH, MAMON_APP_HEIGHT, IC89_RGB(0, 0, 0));
    render_input.mouse_x = g_app.input.pointer_x;
    render_input.mouse_y = g_app.input.pointer_y;
    render_input.mouse_valid = g_app.input.pointer_valid;
    story89_ic89_render_current(
        mamon_project_storyboard(),
        &g_app.player,
        mamon_project_visuals(),
        &g_app.fonts,
        canvas,
        &render_input);
    ic89_gdi_presenter_compose(&g_app.presenter, window, IC89_RGB(0, 0, 0));
}

static void mamon_update_mouse(HWND window, int client_x, int client_y)
{
    int virtual_x;
    int virtual_y;
    unsigned char valid;
    virtual_x = 0;
    virtual_y = 0;
    valid = ic89_gdi_presenter_client_to_virtual(
        &g_app.presenter,
        window,
        client_x,
        client_y,
        &virtual_x,
        &virtual_y);
    ic89_input_edges_pointer(&g_app.input, virtual_x, virtual_y, valid);
}

static void mamon_tick(HWND window, unsigned long now_ms)
{
    ic89_input input;
    const ic89_scene *scene;
    unsigned char menu_clicked;
    input.start_pressed = (unsigned char)(g_app.input.start || g_app.input.activate);
    input.skip_pressed = g_app.input.skip;
    scene = ic89_current(&g_app.player);
    menu_clicked = 0U;
    if (scene != (const ic89_scene *)0 && scene->kind == IC89_KIND_MENU) {
        if (g_app.input.activate && g_app.input.pointer_valid) {
            menu_clicked = ic89_scene_runtime_hit_current(
                &g_app.player,
                mamon_project_visuals(),
                g_app.input.pointer_x,
                g_app.input.pointer_y);
        }
        if (g_app.input.exit_request || g_app.input.start || menu_clicked) {
            ic89_input_edges_clear_actions(&g_app.input);
            ic89_win32_host_close(window);
            return;
        }
    }
    ic89_update(&g_app.player, &input, now_ms);
    ic89_input_edges_clear_actions(&g_app.input);
    mamon_render_frame(window);
    InvalidateRect(window, (const RECT *)0, FALSE);
}

static int mamon_on_create(HWND window, void *user_data)
{
    unsigned long now_ms;
    (void)user_data;
    g_app.window = window;
    if (!ic89_font_bank_create(
            &g_app.fonts,
            ic89_gdi_font_factory(),
            (void *)0,
            ic89_gdi_text_renderer(),
            (void *)0,
            mamon_project_font_faces(),
            mamon_project_font_face_count())) {
        return 0;
    }
    now_ms = GetTickCount();
    ic89_init(&g_app.player, mamon_project_sequence(), now_ms);
    mamon_render_frame(window);
    return 1;
}

static void mamon_on_resize(HWND window, void *user_data)
{
    (void)user_data;
    ic89_gdi_presenter_resize(&g_app.presenter, window);
    mamon_render_frame(window);
    InvalidateRect(window, (const RECT *)0, FALSE);
}

static void mamon_on_paint(HWND window, HDC target_dc, void *user_data)
{
    (void)user_data;
    if (!ic89_gdi_presenter_has_frame(&g_app.presenter)) {
        mamon_render_frame(window);
    }
    ic89_gdi_presenter_paint(&g_app.presenter, target_dc);
}

static void mamon_on_pointer(HWND window, int client_x, int client_y, unsigned char pressed, void *user_data)
{
    (void)user_data;
    mamon_update_mouse(window, client_x, client_y);
    if (pressed) {
        g_app.input.activate = 1U;
    }
}

static void mamon_on_key_down(HWND window, unsigned long key, unsigned char repeated, void *user_data)
{
    (void)user_data;
    if (key == VK_ESCAPE) {
        g_app.input.exit_request = 1U;
        ic89_win32_host_close(window);
        return;
    }
    if (repeated) {
        return;
    }
    if (key == VK_RETURN || key == VK_SPACE) {
        g_app.input.start = 1U;
    } else if (key == 'Z' || key == 'X') {
        g_app.input.skip = 1U;
    }
}

static void mamon_on_frame(HWND window, unsigned long now_ms, void *user_data)
{
    (void)user_data;
    mamon_tick(window, now_ms);
}

static void mamon_on_destroy(HWND window, void *user_data)
{
    (void)window;
    (void)user_data;
    ic89_font_bank_destroy(&g_app.fonts);
    ic89_gdi_presenter_destroy(&g_app.presenter);
}

static int mamon_app_main(HINSTANCE instance)
{
    ic89_win32_host_config config;
    ic89_win32_host_callbacks callbacks;
    ic89_mem_zero(&g_app, (unsigned long)sizeof(g_app));
    ic89_input_edges_zero(&g_app.input);
    ic89_gdi_presenter_zero(&g_app.presenter, MAMON_APP_WIDTH, MAMON_APP_HEIGHT);
    config.class_name = MAMON_APP_CLASS;
    config.window_title = MAMON_APP_TITLE;
    config.client_width = 960;
    config.client_height = 540;
    config.frame_ms = MAMON_FRAME_MS;
    callbacks.on_create = mamon_on_create;
    callbacks.on_resize = mamon_on_resize;
    callbacks.on_paint = mamon_on_paint;
    callbacks.on_pointer = mamon_on_pointer;
    callbacks.on_key_down = mamon_on_key_down;
    callbacks.on_frame = mamon_on_frame;
    callbacks.on_destroy = mamon_on_destroy;
    return ic89_win32_host_run(instance, &config, &callbacks, (void *)0);
}

void WinMainCRTStartup(void)
{
    HINSTANCE instance;
    int code;
    instance = (HINSTANCE)GetModuleHandleA((LPCSTR)0);
    code = mamon_app_main(instance);
    ExitProcess((UINT)code);
}
