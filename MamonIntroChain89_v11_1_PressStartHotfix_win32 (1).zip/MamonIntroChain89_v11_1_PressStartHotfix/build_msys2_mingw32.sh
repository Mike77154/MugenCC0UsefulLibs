#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CC="${CC:-i686-w64-mingw32-gcc}"
rm -rf build/mingw32
mkdir -p build/mingw32
CFLAGS=(-std=c89 -pedantic-errors -Os -Wall -Wextra -Werror -ffreestanding -fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables -Iinclude -Ivendor/ic89/include -Ivendor/airlite89/include -Ivendor/storyboard89/include -Ivendor/storyboard89_ic89/include -Igenerated)
OBJECTS=()
while IFS= read -r source; do
  object="build/mingw32/${source//\//_}"
  object="${object%.c}.o"
  "$CC" "${CFLAGS[@]}" -c "$source" -o "$object"
  OBJECTS+=("$object")
done < sources_win32.txt
"$CC" -nostdlib -mwindows -Wl,--entry=_WinMainCRTStartup -Wl,--subsystem,windows:5.01 -Wl,--gc-sections \
  -o MamonIntroChain89.exe "${OBJECTS[@]}" -lkernel32 -luser32 -lgdi32
file MamonIntroChain89.exe
