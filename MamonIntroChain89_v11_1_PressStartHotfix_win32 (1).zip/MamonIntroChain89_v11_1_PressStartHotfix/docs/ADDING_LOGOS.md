# Añadir un logo nuevo

## 1. Añade la escena al `.def`

```ini
[Scene MiLogo]
id = 1400
visual.id = 1400
kind = logo
start.target = intro
end.time = 2400
fadein.time = 300
fadeout.time = 400
```

## 2. Escribe el nombre como texto

```ini
layer1.text = "MI ESTUDIO"
layer1.font = 4,0,0,255,220,40
layer1.outlines = 3,20,70,160
layer1.offset = 320,120
```

No necesitas un archivo C para registrar el wordmark.

## 3. Añade copy opcional

```ini
layer2.text = "PRESENTA"
layer2.font = 1,0,0,230,230,230
layer2.offset = 320,220
```

## 4. Añade movimiento

```ini
layer1.motion = bob,y,4,4
```

## 5. Añade un shell sólo cuando haga falta

Un logo puramente textual puede no tener `visual`. Para un fondo procedural, emblema o efecto frontal:

```ini
layer0.visual = 1400
layer3.visual = 4400
```

Registra esos IDs en un visual pack. El shell no debe contener el nombre del logo.

## 6. Regenera

```bash
./generate_storyboard.sh
./build_clang_lld.sh
```

## Cuándo usar cada tipo

```text
text        → nombre, subtítulo o copy con una fuente
letterform  → letras realmente dibujadas como geometría
visual      → shell compuesto, fondo o efecto registrado
primitive   → operación procedural pequeña
shape       → emblema o símbolo
anim        → acción AIR
```
