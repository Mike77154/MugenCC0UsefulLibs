# Añadir logos e intros

La arquitectura usa una tabla de timeline y otra de renderizadores. Los tamaños se calculan automáticamente con `sizeof`.

## Ejemplo: añadir otro logo

### 1. Declara un ID

En `include/mamon_project.h`:

```c
#define MAMON_SC_NUEVO_LOGO 17U
```

Usa un valor único.

### 2. Declara el renderizador

En `include/mamon_visuals.h`:

```c
void mamon_draw_nuevo_logo(
    const ic89_render_context *context,
    const void *user_data);
```

### 3. Implementa la composición

Agrégala a `src/app/scenes/logos_mexicanos.c` o crea otro paquete de escenas:

```c
void mamon_draw_nuevo_logo(
    const ic89_render_context *context,
    const void *user_data)
{
    COLORREF fondo;
    COLORREF texto;
    fondo = ic89_color_scale(RGB(8, 8, 24), v);
    texto = ic89_color_scale(RGB(255, 220, 32), v);
    ic89_draw_fill_rect(canvas, 0, 0,
        MAMON_APP_WIDTH, MAMON_APP_HEIGHT, fondo);
    mamon_text_glow(context, MAMON_FONT_LARGE,
        MAMON_APP_WIDTH / 2, 140,
        "NUEVO LOGO", fondo, texto);
}
```

Los macros `canvas`, `t` y `v` ya están definidos en los paquetes actuales. En un archivo nuevo puedes usar directamente `context->canvas`, `context->local_ms` y `context->visibility`.

### 4. Regístralo

En `src/app/mamon_visual_registry.c`:

```c
{MAMON_SC_NUEVO_LOGO,
 mamon_draw_nuevo_logo,
 (ic89_visual_hit_fn)0,
 (const void *)0},
```

### 5. Encadénalo

En `src/app/mamon_project.c`, coloca la fila donde deba reproducirse:

```c
MAMON_NODE_TIMED(
    MAMON_SC_NUEVO_LOGO,
    MAMON_SC_NUEVO_LOGO,
    IC89_KIND_LOGO,
    IC89_KIND_INTRO,
    2400UL,
    320UL,
    420UL),
```

Al ser `IC89_KIND_LOGO`, `Start` saltará desde él a la primera intro posterior.

## Añadir una intro

El procedimiento es idéntico, pero la fila usa:

```c
IC89_KIND_INTRO
IC89_KIND_PUSH_START
```

Ejemplo:

```c
MAMON_NODE_TIMED(
    MAMON_SC_INTRO_CUATRO,
    MAMON_SC_INTRO_CUATRO,
    IC89_KIND_INTRO,
    IC89_KIND_PUSH_START,
    4200UL,
    500UL,
    700UL),
```

## Reutilizar una animación con otro contenido

`scene_id` y `visual_id` no tienen que coincidir. Dos nodos pueden usar el mismo `visual_id` con duraciones o categorías diferentes. Para variaciones, coloca un descriptor estático en `user_data` dentro de la entrada visual.
