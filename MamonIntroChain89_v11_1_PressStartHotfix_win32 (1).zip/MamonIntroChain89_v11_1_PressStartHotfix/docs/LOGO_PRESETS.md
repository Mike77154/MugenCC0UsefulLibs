# Presets y shells de logo v11

## Regla central

El nombre del logo ya no es un preset C. Es una capa `text` del storyboard.

```text
logo scene
├── visual shell opcional
├── text wordmark
├── text copy opcional
├── shape/emblem opcional
└── visual/effect frontal opcional
```

## Qué sigue vendorizado

```text
primitives
├── fondos
├── anillos
├── barridos
├── scanlines
└── glitches

shapes
├── símbolos
├── sellos
├── cintas
├── mazorca
└── máscaras

text runtime
├── font face
├── renderer
├── fill
├── outlines
├── glow
├── shadow
├── reveal
└── motion
```

## Organización

```text
src/app/logo_presets/
├── mamon_logo_primitives.c
├── mamon_logo_shapes.c
└── mamon_logo_shells.c

vendor/storyboard89_ic89/
└── renderer agnóstico de capas Storyboard89

storyboards/mamon_intro.def
└── nombres, colores, contornos, copy y movimiento
```

## Ejemplos

```text
CAPCOM
shell de anillos → text CAPCOM → copy → shine

MASECA
shell orbital → text MA/SE/CA → copy → mazorca

IMCINE
shell → text IMCINE → máscara → copy → franja

CARICACHUPAS
shell → text con glow/jitter → copy → glitch
```
