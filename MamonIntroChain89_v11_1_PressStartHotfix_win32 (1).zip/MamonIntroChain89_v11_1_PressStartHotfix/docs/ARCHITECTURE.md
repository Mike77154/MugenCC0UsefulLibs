# Arquitectura v11

```text
storyboard .def
├── scene order and timing
├── text strings
├── font/color/alignment
├── outline/glow/shadow
└── text motion
        ↓ offline compile
story89_program (static C89 tables)
        ↓
story89_ic89_render
├── visual layer ── visual registry ── shell/primitive/shape/effect
├── text layer ─── font bank + text painter
└── anim layer ─── AIRLite89 sample
        ↓
IC89 canvas
        ↓
GDI draw/text plugins
        ↓
scene surface → present surface → one final BitBlt
```

## División de responsabilidades

```text
cut89
└── lexer/parser/AST offline

Storyboard89 compiler
└── valida y genera tablas C

Storyboard89 runtime
└── consulta escenas/capas/strings sin stdio

AIRLite89
└── acciones y sampleo por tick

story89_ic89_render
└── adapta capas a interfaces IC89

visual shells
└── fondos, emblemas, máscaras y efectos; nunca nombres de marca

font bank
└── recursos físicos de fuente

storyboard text layer
└── contenido, color, alineación, decoración, tiempos y movimiento
```

## Logo sin preset de wordmark

```text
layer0.visual = shell de fondo
layer1.text   = "CAPCOM"
layer1.outlines = ...
layer2.text   = "PRESENTA"
layer3.visual = brillo frontal
```

El compositor no conoce marcas. El mismo shell puede reutilizarse con otro texto.

## Límite de plataforma

Sólo los plugins GDI y el host Win32 conocen tipos Windows. Storyboard89, AIRLite89, rutas, timeline, fixed-point y recetas visuales permanecen agnósticos.
