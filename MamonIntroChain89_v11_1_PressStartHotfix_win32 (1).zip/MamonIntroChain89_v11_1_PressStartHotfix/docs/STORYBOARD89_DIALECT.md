# Storyboard89 Dialect v2

## Filosofía

El archivo conserva el flujo mental de un storyboard MUGEN:

```text
SceneDef + Scene + layers + Begin Action + BG/BGCtrl
```

Las extensiones permiten usar primitivas, formas, efectos y texto decorado sin convertir el compilador en un motor gráfico.

## Texto clásico

```ini
layer1.text = "CAPCOM"
layer1.font = 4,0,0,255,205,25
layer1.offset = 320,112
layer1.starttime = 0
layer1.endtime = 180
layer1.textdelay = 2
```

Formato de `font`:

```text
font_id, bank, align, r, g, b
```

Una capa tiene un solo contenido principal. No mezcles `text`, `anim`, `visual`, `primitive`, `shape`, `letterform` o `effect` en la misma capa.

## Decoradores de texto

```ini
layer1.outlines = 3,22,69,166
layer2.outlines = 4,0,0,0,2,2
layer3.glow = 2,255,36,36
layer4.shadow = 3,4,0,0,0
```

```text
outlines = size,r,g,b[,offset_x,offset_y]
glow     = size,r,g,b
shadow   = offset_x,offset_y,r,g,b
```

`outlines` crea el contorno. No requiere que exista un preset tipográfico previo.

## Movimiento

```ini
layer1.motion = bob,y,4,4
layer2.motion = jitter,x,4,65
layer3.motion = step,y,216,96,7
layer4.motion = slide,x,-200,0,400
```

Los movimientos se interpretan en el bridge runtime y usan enteros/Q16.16.

## Capas visuales

```ini
layer0.visual = 1000
layer1.primitive = expanding_rings
layer2.shape = vector_emblem
layer3.letterform = custom_vector_letters
layer4.effect = shine_sweep
```

Un `visual` puede ser un shell compuesto sin texto. El wordmark se añade después mediante `layerX.text`.

## Acciones AIR

```ini
[Begin Action 100]
0,0,0,0,12
Interpolate Offset
0,1,20,0,12,H,AS192D128,1.25,1.25,15
Loopstart
0,2,0,0,8
```

## Escenas semánticas

```ini
kind = logo
start.target = intro
```

Kinds:

```text
logo
intro
push_start
menu
cutscene
```

## Codegen

```text
.def → cut89 AST → Storyboard89 document → C arrays
```

El EXE usa `story89_program` y `story89_runtime.c`; no enlaza el compilador.
