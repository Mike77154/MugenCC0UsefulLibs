# Fuentes técnicas consultadas

## MUGEN / Elecbyte

- Storyboard Documentation:
  https://www.elecbyte.com/mugendocs-11b1/storyboard.html
- AIR format and standard:
  https://www.elecbyte.com/mugendocs-11b1/air.html
- Backgrounds and stages:
  https://www.elecbyte.com/mugendocs-11b1/bgs.html

Conceptos adoptados:

- `SceneDef`, escenas y capas;
- `layerX.text` emparejado con `layerX.font`;
- `offset`, `starttime`, `endtime` y `textdelay`;
- una clase de contenido principal por capa;
- `[Begin Action n]`, frames, `Loopstart`, flips y blend;
- fondos y BGCtrl temporizados;
- 60 ticks por segundo como timebase por defecto.

## Ren'Py

- Text documentation:
  https://www.renpy.org/doc/html/text.html
- Text style properties:
  https://www.renpy.org/doc/html/style_properties.html

Conceptos adoptados:

- separar el string de sus propiedades de estilo;
- representar outlines mediante tamaño, color y offsets;
- usar un outline de tamaño cero con offset como base conceptual de una sombra;
- distinguir entre crear outlines y sólo recolorear outlines existentes.

## Adaptación propia

La sintaxis `layerX.outlines`, `layerX.glow` y `layerX.shadow` no pretende ser sintaxis exacta de Ren'Py. Es una extensión Storyboard89 con forma de propiedad MUGEN y semántica inspirada en las propiedades tipográficas de Ren'Py.
