# Auditoría de vendorization v9

## Separaciones nuevas

| Antes | Ahora |
|---|---|
| `ic89_font_driver` | `ic89_font_factory` + `ic89_text_renderer` |
| `ic89_font_spec` mezclado con bank | `ic89_font_face_spec` independiente |
| `ic89_text_effects` | `ic89_text_style` + `ic89_text_painter` + facade compatible |
| callbacks tipográficos por logo | `ic89_typography_recipe` + items animados |
| “typography” para cualquier texto | `FONT_TEXT` + `TYPOGRAPHY` + `VECTOR_LETTERFORM` |
| archivo único de lettering | font faces + styles + wordmarks + copy |
| adaptadores de logo específicos | `ic89_logo_draw_typography_recipe` genérico |

## Frontera actual

```text
AGNÓSTICO
├── font face
├── font factory interface
├── font bank
├── text renderer interface
├── text style
├── text painter
├── text actor
├── typography recipe
└── logo typography adapter

BACKEND GDI
├── gdi font factory
└── gdi text renderer

CONTENIDO
├── font face pack de la aplicación
├── style catalog
├── wordmark catalog
└── font-text catalog
```

## Qué sigue siendo contenido deliberadamente

- Nombres de fuentes concretas.
- Paletas y posiciones de cada marca.
- Textos de chiste y pies institucionales.
- Orden de capas y timeline.
- Formas gráficas específicas.

## Resultado de la clasificación

```text
12 wordmarks tipográficos basados en fuentes
13 bloques de font text
34 estilos
0 letterforms vectoriales actuales
```

La ausencia de letterforms vectoriales es explícita. Ya existe el socket para añadirlas sin fingir que un wordmark con Arial Black es geometría propia.
