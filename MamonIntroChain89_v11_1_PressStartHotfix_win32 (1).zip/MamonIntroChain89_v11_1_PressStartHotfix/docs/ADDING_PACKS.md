# Añadir paquetes de logos o intros

## 1. Crea un header de paquete

```c
#define MY_VIS_LOGO 4100U
extern const ic89_scene_pack g_my_scene_pack;
extern const ic89_visual_pack g_my_visual_pack;
```

## 2. Declara escenas y visuales

```c
static const ic89_scene g_scenes[] = {
    MAMON_NODE_TIMED(
        MY_VIS_LOGO,
        MY_VIS_LOGO,
        IC89_KIND_LOGO,
        IC89_KIND_INTRO,
        2400UL,
        320UL,
        420UL)
};

static const ic89_visual_entry g_visuals[] = {
    {MY_VIS_LOGO, my_draw_logo, ic89_hit_none, (const void *)0}
};
```

Expón ambos paquetes con su nombre y tamaño calculado mediante `sizeof`.

## 3. Enchúfalos

Agrega el scene pack en la posición deseada de `g_mamon_scene_packs` y el visual pack en `g_mamon_visual_packs`.

El reproductor, los fades, el registro, el presenter y el host no cambian.

## Reutilizar una animación

Un nodo puede usar un `scene.id` nuevo y un `visual_id` existente. También puedes pasar un descriptor por `user_data` para reutilizar un callback con distintos textos, paletas o regiones de hit testing.
