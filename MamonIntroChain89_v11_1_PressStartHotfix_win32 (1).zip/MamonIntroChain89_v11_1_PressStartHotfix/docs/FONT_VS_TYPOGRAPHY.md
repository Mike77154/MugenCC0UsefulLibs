# Fuentes, texto y letterforms en v11

## Taxonomía

| Concepto | Responsabilidad | Dónde vive |
|---|---|---|
| Font face | Familia, tamaño y peso físicos | `mamon_font_specs.c` |
| Text layer | String, color, alineación y tiempo | storyboard `.def` |
| Text decoration | Outline, glow o shadow | storyboard `.def` + renderer |
| Text motion | Bob, jitter, step o slide | storyboard `.def` + bridge |
| Visual shell | Fondo, emblema, máscara, brillo | visual packs C89 |
| Vector letterform | Glifos dibujados como geometría | plugin `letterform` opcional |

## Qué cambió

Antes, `CAPCOM` o `CARICACHUPAS` eran recetas tipográficas C específicas. Ahora son datos:

```ini
layer1.text = "CARICACHUPAS"
layer1.font = 3,0,0,255,230,48
layer1.glow = 2,255,36,36
layer1.motion = jitter,x,4,65
```

La fuente crea los glifos. Storyboard89 decide contenido, color, decoración, posición y animación.

## Contratos

```text
font face specs
      ↓
font factory
      ↓
font bank
      ↓
text renderer
      ↓
text painter
      ↓
storyboard text layer
```

El renderer Storyboard89 no conoce GDI directamente; consume las interfaces IC89 de fuente y canvas.
