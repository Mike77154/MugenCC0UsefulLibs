# AIRLite89

## Propósito

AIRLite89 es una minilib de apoyo. No intenta implementar personajes, hitboxes ni el motor de combate MUGEN. Su objetivo es poder reutilizar acciones AIR dentro de storyboards, fondos, stages, logos e intros.

## Formato soportado

```ini
[Begin Action 100]
0,0, 0,0, 8
Interpolate Offset
0,1, 12,0, 8, H, AS192D128, 1.25,1.25, 15
Loopstart
Interpolate Angle
0,2, 0,0, 8, , A1, 1,1, 45
```

Campos de frame:

```text
sprite_group
sprite_image
x_offset
y_offset
duration_ticks
flip
blend
x_scale
y_scale
angle_degrees
```

## API

```c
air89_document_init(&doc);
air89_parse_buffer(&doc, text, length);
air89_find_action(&doc, 100);
air89_sample_action(&doc, 100, tick, &sample);
```

El sample es renderer-agnóstico. El consumidor decide cómo resolver `group_no,image_no` a un sprite, una primitiva, un atlas o cualquier backend.

## Deliberadamente fuera de alcance

- cargar o decodificar SFF;
- collision boxes para combate;
- paletas;
- sprites reales;
- renderizado;
- triggers de CNS;
- heap dinámico.

Las líneas `Clsn1/Clsn2` se cuentan como ignoradas y no rompen el modelo conceptual; el frontend `cut89` usado por Storyboard89 espera storyboards/stages sin colisiones.
