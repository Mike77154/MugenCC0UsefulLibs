# Portar IC89 a otro backend

## Dibujo 2D

Implementa `ic89_draw2d_ops`: rectángulos, líneas, círculos, polígonos y marcos.

## Recursos de fuente

Implementa `ic89_font_factory`:

```text
create
 destroy
```

Esta pieza sólo administra handles. No pinta texto.

## Rasterizado y medición de texto

Implementa `ic89_text_renderer`:

```text
draw
measure
```

Outline, glow, shadow, reveal, actores y recetas tipográficas viven encima de esa interfaz y no conocen la API de destino.

## Presentación

Reemplaza `ic89_gdi_surface`/`ic89_gdi_presenter` por un presenter que entregue un canvas y presente el frame terminado.

## Host

Reemplaza `ic89_win32_host` por SDL, X11, framebuffer o un host propio. Timeline, logos y tipografía permanecen intactos.
