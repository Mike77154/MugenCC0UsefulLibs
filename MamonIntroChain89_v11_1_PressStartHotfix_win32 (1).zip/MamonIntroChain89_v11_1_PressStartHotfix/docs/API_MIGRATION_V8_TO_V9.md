# Migración v8 → v9

## Font bank

Antes:

```c
ic89_font_bank_create(&bank, driver, ctx, specs, count);
```

Ahora:

```c
ic89_font_bank_create(
    &bank,
    font_factory, factory_ctx,
    text_renderer, renderer_ctx,
    faces, face_count);
```

## GDI

Antes:

```c
ic89_gdi_font_driver()
```

Ahora:

```c
ic89_gdi_font_factory()
ic89_gdi_text_renderer()
```

## Logo layers

`IC89_LOGO_LAYER_TYPOGRAPHY` significa wordmark/composición. Para copy ordinario usa `IC89_LOGO_LAYER_FONT_TEXT`. `IC89_LOGO_LAYER_VECTOR_LETTERFORM` queda reservado para glifos geométricos.
