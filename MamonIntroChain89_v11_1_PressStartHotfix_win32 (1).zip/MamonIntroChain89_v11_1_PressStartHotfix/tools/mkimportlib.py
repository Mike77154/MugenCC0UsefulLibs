#!/usr/bin/env python3
import argparse
import os
import struct
import subprocess
from pathlib import Path

MACHINE_I386 = 0x014C
IMPORT_CODE = 0
IMPORT_NAME_UNDECORATE = 3


def make_short_import(symbol: str, dll: str) -> bytes:
    payload = symbol.encode("ascii") + b"\0" + dll.encode("ascii") + b"\0"
    type_info = IMPORT_CODE | (IMPORT_NAME_UNDECORATE << 2)
    header = struct.pack(
        "<HHHHIIHH",
        0,
        0xFFFF,
        0,
        MACHINE_I386,
        0,
        len(payload),
        0,
        type_info,
    )
    return header + payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dll", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--llvm-ar", required=True)
    parser.add_argument("symbols", nargs="+")
    args = parser.parse_args()

    out = Path(args.out)
    objdir = out.parent / (out.stem + "_imports")
    objdir.mkdir(parents=True, exist_ok=True)
    members = []
    for idx, spec in enumerate(args.symbols):
        name, byte_count = spec.rsplit(":", 1)
        decorated = f"_{name}@{int(byte_count)}"
        member = objdir / f"{idx:03d}_{name}.obj"
        member.write_bytes(make_short_import(decorated, args.dll))
        members.append(str(member))

    if out.exists():
        out.unlink()
    subprocess.run([args.llvm_ar, "rcs", str(out), *members], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
