#include "story89_cut.h"

#include <stdio.h>
#include <string.h>

static cut_context g_cut;
static story89_document g_story;

static void usage(void)
{
    puts("story89c - MUGEN-style storyboard compiler with IC89 extensions");
    puts("usage:");
    puts("  story89c validate input.def");
    puts("  story89c dump input.def");
    puts("  story89c codegen input.def output.h output.c symbol");
    puts("  story89c sample-air input.def action tick");
}

static int compile_input(const char *path)
{
    int rc;
    rc = story89_load_compile(&g_story, &g_cut, path);
    if (rc != STORY89_OK) {
        fprintf(stderr, "%s:%d: %s (%s)\n", path, g_story.error_line,
            g_story.error_message[0] ? g_story.error_message : story89_error_string(rc),
            story89_error_string(rc));
        if (g_cut.error_code != CUT_OK) {
            fprintf(stderr, "cut89: line=%d col=%d %s\n", g_cut.error_line, g_cut.error_col, g_cut.error_msg);
        }
        return 1;
    }
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 3) {
        usage();
        return 2;
    }
    if (compile_input(argv[2])) return 1;
    if (strcmp(argv[1], "validate") == 0) {
        printf("OK scenes=%u layers=%u actions=%u frames=%u bg=%u ctrl=%u warnings=%u\n",
            g_story.scene_count,g_story.layer_count,g_story.air.action_count,g_story.air.frame_count,
            g_story.bg_element_count,g_story.bgctrl_count,g_story.warning_count);
        return 0;
    }
    if (strcmp(argv[1], "dump") == 0) {
        story89_dump(&g_story, stdout);
        return 0;
    }
    if (strcmp(argv[1], "codegen") == 0) {
        int rc;
        if (argc != 6) {
            usage();
            return 2;
        }
        rc = story89_write_c(&g_story, argv[3], argv[4], argv[5]);
        if (rc != STORY89_OK) {
            fprintf(stderr, "codegen failed: %s\n", story89_error_string(rc));
            return 1;
        }
        printf("generated %s and %s as %s\n", argv[3], argv[4], argv[5]);
        return 0;
    }
    if (strcmp(argv[1], "sample-air") == 0) {
        int ok;
        long action;
        long tick;
        air89_sample sample;
        if (argc != 5) {
            usage();
            return 2;
        }
        action = 0L;
        tick = 0L;
        ok = sscanf(argv[3], "%ld", &action) == 1 && sscanf(argv[4], "%ld", &tick) == 1;
        if (!ok || air89_sample_action(&g_story.air, action, tick, &sample) != AIR89_OK) {
            fprintf(stderr, "could not sample action\n");
            return 1;
        }
        printf("action=%ld tick=%ld frame=%u sprite=%d,%d offset=%ld,%ld scale=%ld,%ld angle=%ld flip=%u blend=%u alpha=%u,%u\n",
            action,tick,sample.frame_index,sample.group_no,sample.image_no,
            air89_fixed_to_int(sample.offset_x),air89_fixed_to_int(sample.offset_y),
            sample.scale_x,sample.scale_y,sample.angle,sample.flip,sample.blend,
            sample.source_alpha,sample.dest_alpha);
        return 0;
    }
    usage();
    return 2;
}
