@echo off
setlocal
cd /d "%~dp0"
if not exist build\tools mkdir build\tools

gcc -std=c89 -pedantic-errors -Wall -Wextra -Werror ^
  -Ivendor\airlite89\include -Ivendor\storyboard89\include -Ivendor\cut89\include ^
  tools\story89c\main.c ^
  vendor\airlite89\src\air89.c ^
  vendor\storyboard89\src\story89.c vendor\storyboard89\src\story89_runtime.c ^
  vendor\cut89\src\cut_base.c vendor\cut89\src\cut_lex.c vendor\cut89\src\cut_parse.c ^
  vendor\cut89\src\cut_compile.c vendor\cut89\src\cut_vm.c vendor\cut89\src\cut_catalog.c ^
  -o build\tools\story89c.exe
if errorlevel 1 exit /b 1

build\tools\story89c.exe validate storyboards\mamon_intro.def
if errorlevel 1 exit /b 1

echo story89c.exe listo en build\tools
endlocal
