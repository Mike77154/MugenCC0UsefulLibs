@echo off
setlocal
cd /d "%~dp0"
call build_story89c_msys2_mingw32.bat
if errorlevel 1 exit /b 1
build\tools\story89c.exe codegen storyboards\mamon_intro.def generated\mamon_storyboard_generated.h generated\mamon_storyboard_generated.c g_mamon_storyboard
if errorlevel 1 exit /b 1
echo Storyboard regenerado.
endlocal
