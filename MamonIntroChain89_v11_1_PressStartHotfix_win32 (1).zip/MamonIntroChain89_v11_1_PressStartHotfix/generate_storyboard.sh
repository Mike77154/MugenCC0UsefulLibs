#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./build_story89c.sh
./build/story89c codegen \
  storyboards/mamon_intro.def \
  generated/mamon_storyboard_generated.h \
  generated/mamon_storyboard_generated.c \
  g_mamon_storyboard
