#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CLANG="${CLANG:-/usr/local/swift/usr/bin/clang}"
LLD="${LLD:-/usr/local/swift/usr/bin/lld-link}"
LLVM_AR="${LLVM_AR:-/usr/local/swift/usr/bin/llvm-ar}"
rm -rf build/win32
mkdir -p build/win32
python3 tools/mkimportlib.py --dll KERNEL32.dll --out build/win32/kernel32.lib --llvm-ar "$LLVM_AR" \
  ExitProcess:4 GetModuleHandleA:4 GetTickCount:0 Sleep:4
python3 tools/mkimportlib.py --dll USER32.dll --out build/win32/user32.lib --llvm-ar "$LLVM_AR" \
  RegisterClassExA:4 CreateWindowExA:48 ShowWindow:8 UpdateWindow:4 DefWindowProcA:16 \
  PeekMessageA:20 TranslateMessage:4 DispatchMessageA:4 PostQuitMessage:4 BeginPaint:8 \
  EndPaint:8 GetClientRect:8 InvalidateRect:12 DestroyWindow:4 LoadCursorA:8 GetDC:4 \
  ReleaseDC:8 AdjustWindowRectEx:16 SetProcessDPIAware:0
python3 tools/mkimportlib.py --dll GDI32.dll --out build/win32/gdi32.lib --llvm-ar "$LLVM_AR" \
  CreateCompatibleDC:4 CreateCompatibleBitmap:12 SelectObject:8 DeleteObject:4 DeleteDC:4 \
  GetStockObject:4 SetDCBrushColor:8 SetDCPenColor:8 Rectangle:20 RoundRect:28 Ellipse:20 \
  Polygon:12 MoveToEx:16 LineTo:12 SetBkMode:8 SetTextColor:8 SetTextAlign:8 \
  CreateFontA:56 TextOutA:20 GetTextExtentPoint32A:16 BitBlt:36 StretchBlt:44 SetStretchBltMode:8
COMMON=(--target=i686-pc-windows-msvc -std=c89 -pedantic-errors -fms-extensions -ffreestanding -fno-builtin -fno-stack-protector -fno-exceptions -fno-unwind-tables -fno-asynchronous-unwind-tables -Oz -Iinclude -Ivendor/ic89/include -Ivendor/airlite89/include -Ivendor/storyboard89/include -Ivendor/storyboard89_ic89/include -Igenerated -Wall -Wextra -Werror -Wno-language-extension-token)
OBJECTS=()
while IFS= read -r source; do
  object="build/win32/${source//\//_}"
  object="${object%.c}.obj"
  "$CLANG" "${COMMON[@]}" -c "$source" -o "$object"
  OBJECTS+=("$object")
done < sources_win32.txt
"$LLD" /subsystem:windows,5.01 /machine:x86 /entry:WinMainCRTStartup /nodefaultlib /opt:ref /opt:icf \
  /out:MamonIntroChain89.exe "${OBJECTS[@]}" \
  build/win32/kernel32.lib build/win32/user32.lib build/win32/gdi32.lib
file MamonIntroChain89.exe
