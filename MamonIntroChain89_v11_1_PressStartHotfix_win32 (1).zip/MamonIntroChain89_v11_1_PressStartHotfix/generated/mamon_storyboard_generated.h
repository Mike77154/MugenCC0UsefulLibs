#ifndef G_MAMON_STORYBOARD_GENERATED_H
#define G_MAMON_STORYBOARD_GENERATED_H

#include "story89.h"

extern const story89_program g_mamon_storyboard;

#endif
