#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
cc -std=c89 -pedantic-errors -Wall -Wextra -Werror -Iinclude -Ivendor/ic89/include \
  tests/test_core.c \
  vendor/ic89/src/ic89_int_math.c \
  vendor/ic89/src/ic89_fixed.c \
  vendor/ic89/src/ic89_trig.c \
  vendor/ic89/src/ic89_tween.c \
  vendor/ic89/src/ic89_string.c \
  vendor/ic89/src/ic89_motion_wave.c \
  vendor/ic89/src/ic89_motion_path.c \
  vendor/ic89/src/ic89_anim_value.c \
  vendor/ic89/src/ic89_sequence.c \
  vendor/ic89/src/ic89_fade.c \
  vendor/ic89/src/ic89_route_policy.c \
  vendor/ic89/src/ic89_player.c \
  vendor/ic89/src/ic89_viewport.c \
  vendor/ic89/src/ic89_color.c \
  vendor/ic89/src/ic89_draw2d.c \
  vendor/ic89/src/ic89_font_bank.c \
  vendor/ic89/src/ic89_text_style.c \
  vendor/ic89/src/ic89_text_painter.c \
  vendor/ic89/src/ic89_text_effects.c \
  vendor/ic89/src/ic89_text_reveal.c \
  vendor/ic89/src/ic89_text_actor.c \
  vendor/ic89/src/ic89_visual_registry.c \
  vendor/ic89/src/ic89_hit_region.c \
  vendor/ic89/src/ic89_logo_recipe.c \
  -o build/test_core
./build/test_core
