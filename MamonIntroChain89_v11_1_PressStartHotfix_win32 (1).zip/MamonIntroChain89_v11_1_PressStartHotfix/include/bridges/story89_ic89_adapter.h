#ifndef STORY89_IC89_ADAPTER_H
#define STORY89_IC89_ADAPTER_H

#include "story89.h"
#include "ic89_sequence.h"

#define STORY89_IC89_MAX_SCENES 128

typedef struct story89_ic89_adapter {
    ic89_scene scenes[STORY89_IC89_MAX_SCENES];
    ic89_scene_pack pack;
    const ic89_scene_pack *pack_refs[1];
    ic89_sequence sequence;
} story89_ic89_adapter;

int story89_ic89_bind(story89_ic89_adapter *adapter, const story89_program *program, const char *pack_name);
const ic89_sequence *story89_ic89_sequence(const story89_ic89_adapter *adapter);

#endif
