#ifndef MAMON_FONT_FACES_H
#define MAMON_FONT_FACES_H

#include "ic89_font_face.h"

#define MAMON_FONT_TINY   0U
#define MAMON_FONT_SMALL  1U
#define MAMON_FONT_MEDIUM 2U
#define MAMON_FONT_LARGE  3U
#define MAMON_FONT_HUGE   4U
#define MAMON_FONT_MONO   5U
#define MAMON_FONT_COUNT  6U

const ic89_font_face_spec *mamon_project_font_faces(void);
unsigned short mamon_project_font_face_count(void);

#endif
