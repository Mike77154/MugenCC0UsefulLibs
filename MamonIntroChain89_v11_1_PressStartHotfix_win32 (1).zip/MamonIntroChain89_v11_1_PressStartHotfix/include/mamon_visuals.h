#ifndef MAMON_VISUALS_H
#define MAMON_VISUALS_H

#include "mamon_config.h"
#include "ic89_scene_renderer.h"

void mamon_draw_intro_one(const ic89_render_context *context, const void *user_data);
void mamon_draw_intro_two(const ic89_render_context *context, const void *user_data);
void mamon_draw_intro_three(const ic89_render_context *context, const void *user_data);
void mamon_draw_press_start(const ic89_render_context *context, const void *user_data);
void mamon_draw_menu(const ic89_render_context *context, const void *user_data);

#endif
