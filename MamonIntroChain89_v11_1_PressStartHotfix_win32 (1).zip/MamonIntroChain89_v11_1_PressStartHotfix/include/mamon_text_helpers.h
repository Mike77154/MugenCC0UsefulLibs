#ifndef MAMON_TEXT_HELPERS_H
#define MAMON_TEXT_HELPERS_H

#include "ic89_render_context.h"
#include "mamon_font_faces.h"

void mamon_text_plain(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color color);
void mamon_text_glow(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color glow, ic89_color main_color);
void mamon_text_outline(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, ic89_color edge, ic89_color fill, int thickness);
void mamon_text_reveal_glow(const ic89_render_context *context, unsigned short font_id, int x, int y, const char *text, unsigned long milliseconds_per_character, ic89_color glow, ic89_color main_color);

#endif
