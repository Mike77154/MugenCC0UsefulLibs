#ifndef MAMON_PACK_COMMERCIAL_H
#define MAMON_PACK_COMMERCIAL_H
#include "mamon_project.h"
#define MAMON_VIS_CAPCOM 1000U
#define MAMON_VIS_MASECA 1001U
extern const ic89_scene_pack g_mamon_scene_pack_commercial;
extern const ic89_visual_pack g_mamon_visual_pack_commercial;
#endif
