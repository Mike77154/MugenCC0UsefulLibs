#ifndef MAMON_PACK_SYSTEM_H
#define MAMON_PACK_SYSTEM_H
#include "mamon_project.h"
#define MAMON_VIS_PRESS_START 3000U
#define MAMON_VIS_MENU 3001U
extern const ic89_scene_pack g_mamon_scene_pack_system;
extern const ic89_visual_pack g_mamon_visual_pack_system;
#endif
