#ifndef MAMON_PACK_INSTITUTIONS_H
#define MAMON_PACK_INSTITUTIONS_H
#include "mamon_project.h"
#define MAMON_VIS_CONACULTA 1200U
#define MAMON_VIS_INAH 1201U
#define MAMON_VIS_INBAL 1202U
#define MAMON_VIS_CINETECA 1203U
#define MAMON_VIS_CULTURA 1204U
extern const ic89_scene_pack g_mamon_scene_pack_institutions;
extern const ic89_visual_pack g_mamon_visual_pack_institutions;
#endif
