#ifndef MAMON_PACK_INTROS_H
#define MAMON_PACK_INTROS_H
#include "mamon_project.h"
#define MAMON_VIS_INTRO_ONE 2000U
#define MAMON_VIS_INTRO_TWO 2001U
#define MAMON_VIS_INTRO_THREE 2002U
extern const ic89_scene_pack g_mamon_scene_pack_intros;
extern const ic89_visual_pack g_mamon_visual_pack_intros;
#endif
