#ifndef MAMON_PACK_PARODY_H
#define MAMON_PACK_PARODY_H
#include "mamon_project.h"
#define MAMON_VIS_CARICACHUPAS 1300U
extern const ic89_scene_pack g_mamon_scene_pack_parody;
extern const ic89_visual_pack g_mamon_visual_pack_parody;
#endif
