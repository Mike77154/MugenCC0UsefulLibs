#ifndef MAMON_PACK_FUNDS_H
#define MAMON_PACK_FUNDS_H
#include "mamon_project.h"
#define MAMON_VIS_FONCA 1100U
#define MAMON_VIS_FIDECINE 1101U
#define MAMON_VIS_IMCINE 1102U
#define MAMON_VIS_FOPROCINE 1103U
extern const ic89_scene_pack g_mamon_scene_pack_funds_a;
extern const ic89_scene_pack g_mamon_scene_pack_funds_b;
extern const ic89_visual_pack g_mamon_visual_pack_funds;
#endif
