#ifndef MAMON_PROJECT_H
#define MAMON_PROJECT_H

#include "mamon_config.h"
#include "introchain89.h"
#include "ic89_scene_renderer.h"
#include "ic89_typography.h"
#include "mamon_font_faces.h"
#include "story89.h"

#define MAMON_NODE_TIMED(scene_id, visual, scene_kind, start_target, duration, fade_in, fade_out) \
    {scene_id, visual, scene_kind, 0U, start_target, duration, fade_in, fade_out}

#define MAMON_NODE_WAIT(scene_id, visual, scene_kind, scene_flags, start_target, fade_in) \
    {scene_id, visual, scene_kind, scene_flags, start_target, 0UL, fade_in, 0UL}

const ic89_sequence *mamon_project_sequence(void);
const ic89_visual_registry *mamon_project_visuals(void);
const story89_program *mamon_project_storyboard(void);
const ic89_font_face_spec *mamon_project_font_faces(void);
unsigned short mamon_project_font_face_count(void);

#endif
