#ifndef MAMON_TYPOGRAPHY_PRESETS_H
#define MAMON_TYPOGRAPHY_PRESETS_H

/* Compatibility umbrella retained for existing scene code. New code should
 * include mamon_font_faces.h or mamon_text_helpers.h directly. */
#include "mamon_font_faces.h"
#include "mamon_text_helpers.h"

#endif
