#ifndef MAMON_LOGO_SHELLS_H
#define MAMON_LOGO_SHELLS_H

#include "ic89_logo_recipe.h"

#define MAMON_VIS_CAPCOM_SHINE       4100U
#define MAMON_VIS_MASECA_CORN        4101U
#define MAMON_VIS_FONCA_SWEEP        4102U
#define MAMON_VIS_IMCINE_CUTOUTS     4103U
#define MAMON_VIS_IMCINE_STRIP       4104U
#define MAMON_VIS_CONACULTA_REVEAL   4105U
#define MAMON_VIS_CARICACHUPAS_GLITCH 4106U

extern const ic89_logo_recipe g_mamon_shell_capcom;
extern const ic89_logo_recipe g_mamon_shell_capcom_shine;
extern const ic89_logo_recipe g_mamon_shell_maseca;
extern const ic89_logo_recipe g_mamon_shell_maseca_corn;
extern const ic89_logo_recipe g_mamon_shell_fonca;
extern const ic89_logo_recipe g_mamon_shell_fonca_sweep;
extern const ic89_logo_recipe g_mamon_shell_fidecine;
extern const ic89_logo_recipe g_mamon_shell_imcine;
extern const ic89_logo_recipe g_mamon_shell_imcine_cutouts;
extern const ic89_logo_recipe g_mamon_shell_imcine_strip;
extern const ic89_logo_recipe g_mamon_shell_foprocine;
extern const ic89_logo_recipe g_mamon_shell_conaculta;
extern const ic89_logo_recipe g_mamon_shell_conaculta_reveal;
extern const ic89_logo_recipe g_mamon_shell_inah;
extern const ic89_logo_recipe g_mamon_shell_inbal;
extern const ic89_logo_recipe g_mamon_shell_cineteca;
extern const ic89_logo_recipe g_mamon_shell_cultura;
extern const ic89_logo_recipe g_mamon_shell_caricachupas;
extern const ic89_logo_recipe g_mamon_shell_caricachupas_glitch;

#endif
