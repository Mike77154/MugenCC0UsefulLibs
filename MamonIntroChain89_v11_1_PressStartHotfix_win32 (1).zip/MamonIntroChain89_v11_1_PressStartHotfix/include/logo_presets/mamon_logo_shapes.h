#ifndef MAMON_LOGO_SHAPES_H
#define MAMON_LOGO_SHAPES_H

#include "ic89_logo_recipe.h"

extern const ic89_logo_layer g_mamon_shape_maseca_corn;
extern const ic89_logo_layer g_mamon_shape_fonca_bars;
extern const ic89_logo_layer g_mamon_shape_fidecine_film;
extern const ic89_logo_layer g_mamon_shape_imcine_cutouts;
extern const ic89_logo_layer g_mamon_shape_foprocine_film;
extern const ic89_logo_layer g_mamon_shape_conaculta_mark;
extern const ic89_logo_layer g_mamon_shape_conaculta_reveal;
extern const ic89_logo_layer g_mamon_shape_inah_sun;
extern const ic89_logo_layer g_mamon_shape_inbal_bars;
extern const ic89_logo_layer g_mamon_shape_cineteca_reel;
extern const ic89_logo_layer g_mamon_shape_cultura_seal;

extern const ic89_logo_layer *const g_mamon_logo_shape_presets[];
extern const unsigned short g_mamon_logo_shape_preset_count;

#endif
