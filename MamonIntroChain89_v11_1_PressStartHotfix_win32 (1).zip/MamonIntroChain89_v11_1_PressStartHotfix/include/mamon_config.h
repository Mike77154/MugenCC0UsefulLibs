#ifndef MAMON_CONFIG_H
#define MAMON_CONFIG_H

#define MAMON_APP_WIDTH 640
#define MAMON_APP_HEIGHT 360
#define MAMON_APP_TITLE "Mamon Intro Chain 89 v11.1 - Press Start Hotfix"
#define MAMON_APP_CLASS "MamonIntroChain89StoryboardTextClass"
#define MAMON_FRAME_MS 16UL

#endif
