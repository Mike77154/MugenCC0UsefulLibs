@echo off
setlocal
cd /d "%~dp0"
bash build/build_msys2_mingw32.sh
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  exit /b 1
)
echo.
echo BUILD OK
endlocal
