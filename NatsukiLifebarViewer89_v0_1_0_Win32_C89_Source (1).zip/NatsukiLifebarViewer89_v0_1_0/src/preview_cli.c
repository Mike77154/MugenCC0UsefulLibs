#include "lifebar89.h"
#include "lb89_host_sff.h"
#include <stdio.h>
#include <string.h>

static LB89FightDef g_def;
static LB89Runtime g_rt;
static LB89HostBank g_fight_bank;
static LB89HostBank g_char_bank;
static LB89HostCanvas g_canvas;
static unsigned char g_canvas_rgba[LB89_HOST_RGBA_CAP];
static unsigned char g_decode_rgba[LB89_HOST_RGBA_CAP];
static unsigned char g_work[LB89_HOST_WORK_CAP];
static unsigned char g_cache[LB89_HOST_CACHE_CAP];
static char g_text[2UL * 1024UL * 1024UL];

static char *load_text(const char *path, unsigned long *out_size)
{
    FILE *fp;
    long size;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return 0; }
    size = ftell(fp);
    if (size < 0 || (unsigned long)size + 1u > sizeof(g_text)) {
        fclose(fp);
        return 0;
    }
    rewind(fp);
    if (fread(g_text, 1u, (size_t)size, fp) != (size_t)size) {
        fclose(fp); return 0;
    }
    fclose(fp);
    g_text[size] = '\0';
    *out_size = (unsigned long)size;
    return g_text;
}

int main(int argc, char **argv)
{
    char *text;
    unsigned long text_size;
    LB89RenderSink sink;
    int rc;
    if (argc != 5) {
        fprintf(stderr, "usage: %s fight.def fight.sff character.sff output.ppm\n", argv[0]);
        return 2;
    }
    text = load_text(argv[1], &text_size);
    if (!text) { fprintf(stderr, "cannot read fight.def\n"); return 3; }
    rc = lb89_fightdef_parse(&g_def, text, text_size);
    if (rc != LB89_OK) { fprintf(stderr, "fight.def parse rc=%d\n", rc); return 4; }
    if (g_def.localcoord_x > LB89_HOST_MAX_W || g_def.localcoord_y > LB89_HOST_MAX_H) {
        fprintf(stderr, "localcoord too large: %dx%d\n", g_def.localcoord_x, g_def.localcoord_y);
        return 5;
    }
    if (!lb89_host_bank_open(&g_fight_bank, argv[2])) {
        fprintf(stderr, "cannot open fight.sff\n"); return 6;
    }
    if (!lb89_host_bank_open(&g_char_bank, argv[3])) {
        fprintf(stderr, "cannot open character.sff\n");
        lb89_host_bank_close(&g_fight_bank);
        return 7;
    }
    lb89_host_canvas_init(&g_canvas, g_def.localcoord_x, g_def.localcoord_y,
                          g_canvas_rgba, g_decode_rgba, sizeof(g_decode_rgba),
                          g_work, sizeof(g_work),
                          g_cache, sizeof(g_cache));
    g_canvas.bank[LB89_BANK_FIGHT] = &g_fight_bank;
    g_canvas.bank[LB89_BANK_P1] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P2] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P3] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P4] = &g_char_bank;
    lb89_host_canvas_clear(&g_canvas, 16, 18, 26, 255);
    lb89_runtime_init(&g_rt);
    g_rt.life[0] = 760;
    g_rt.mid_life[0] = 900;
    g_rt.life[1] = 410;
    g_rt.mid_life[1] = 650;
    g_rt.power[0] = 2350;
    g_rt.power[1] = 920;
    g_rt.combo[0] = 7;
    g_rt.combo_time[0] = 90;
    g_rt.tick = 12;
    lb89_runtime_set_cue(&g_rt, LB89_CUE_FIGHT);
    g_rt.cue_tick = 12;
    sink.user = &g_canvas;
    sink.sprite = lb89_host_sprite;
    sink.text = lb89_host_text;
    sink.rect = lb89_host_rect;
    lb89_render(&g_def, &g_rt, &sink);
    if (!lb89_host_write_ppm(&g_canvas, argv[4])) {
        fprintf(stderr, "cannot write output\n");
        lb89_host_bank_close(&g_char_bank);
        lb89_host_bank_close(&g_fight_bank);
        return 8;
    }
    printf("WROTE %s (%dx%d, fight_sprites=%lu, char_sprites=%lu)\n",
           argv[4], g_canvas.width, g_canvas.height,
           (unsigned long)sff_sprite_count(&g_fight_bank.sff),
           (unsigned long)sff_sprite_count(&g_char_bank.sff));
    lb89_host_bank_close(&g_char_bank);
    lb89_host_bank_close(&g_fight_bank);
    return 0;
}
