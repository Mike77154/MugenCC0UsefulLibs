#ifndef LB89_HOST_SFF_H
#define LB89_HOST_SFF_H

#include "lifebar89.h"
#include "sff_api.h"
#include "sff_stdio_adapter.h"
#include <stdio.h>

#define LB89_HOST_MAX_W 1280
#define LB89_HOST_MAX_H 720
#define LB89_HOST_RGBA_CAP (LB89_HOST_MAX_W * LB89_HOST_MAX_H * 4UL)
#define LB89_HOST_WORK_CAP (16UL * 1024UL * 1024UL)
#define LB89_HOST_CACHE_CAP (16UL * 1024UL * 1024UL)
#define LB89_HOST_CACHE_SLOTS 128

typedef struct LB89HostBank {
    FILE *fp;
    SffStdioSource stdio_source;
    SffFile sff;
    int opened;
} LB89HostBank;

typedef struct LB89HostCacheEntry {
    LB89HostBank *bank;
    int group;
    int item;
    unsigned long offset;
    unsigned short w;
    unsigned short h;
    short axis_x;
    short axis_y;
    int valid;
} LB89HostCacheEntry;

typedef struct LB89HostCanvas {
    int width;
    int height;
    unsigned char *rgba;
    LB89HostBank *bank[5];
    unsigned char *decode_rgba;
    unsigned long decode_cap;
    unsigned char *work;
    unsigned long work_cap;
    unsigned char *cache_pixels;
    unsigned long cache_cap;
    unsigned long cache_used;
    LB89HostCacheEntry cache[LB89_HOST_CACHE_SLOTS];
} LB89HostCanvas;

int lb89_host_bank_open(LB89HostBank *bank, const char *path);
void lb89_host_bank_close(LB89HostBank *bank);
void lb89_host_canvas_init(LB89HostCanvas *canvas, int w, int h,
                           unsigned char *rgba,
                           unsigned char *decode_rgba, unsigned long decode_cap,
                           unsigned char *work, unsigned long work_cap,
                           unsigned char *cache_pixels, unsigned long cache_cap);
void lb89_host_canvas_reset_cache(LB89HostCanvas *canvas);
void lb89_host_canvas_clear(LB89HostCanvas *canvas,
                            int r, int g, int b, int a);
void lb89_host_sprite(void *user, const LB89SpriteCommand *cmd);
void lb89_host_text(void *user, const LB89TextCommand *cmd);
void lb89_host_rect(void *user, int x1, int y1, int x2, int y2,
                    int r, int g, int b, int a, int layerno);
int lb89_host_write_ppm(const LB89HostCanvas *canvas, const char *path);

#endif
