#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <stdio.h>
#include <string.h>
#include "lifebar89.h"
#include "lb89_host_sff.h"

#define LB89_DEF_TEXT_CAP (2UL * 1024UL * 1024UL)

static HWND g_hwnd;
static LB89FightDef g_def;
static LB89Runtime g_rt;
static LB89HostBank g_fight_bank;
static LB89HostBank g_char_bank;
static LB89HostCanvas g_canvas;
static unsigned char g_def_text[LB89_DEF_TEXT_CAP];
static unsigned char g_canvas_rgba[LB89_HOST_RGBA_CAP];
static unsigned char g_display_bgra[LB89_HOST_RGBA_CAP];
static unsigned char g_decode_rgba[LB89_HOST_RGBA_CAP];
static unsigned char g_work[LB89_HOST_WORK_CAP];
static unsigned char g_cache[LB89_HOST_CACHE_CAP];
static char g_def_path[MAX_PATH];
static char g_sff_path[MAX_PATH];
static char g_char_path[MAX_PATH] = "corpus\\character\\kfm.sff";
static int g_loaded;
static int g_help = 1;
static int g_timer_accum;

static void lb89_copy_path(char *dst, int cap, const char *src)
{
    int i;
    if (!dst || cap <= 0) return;
    i = 0;
    while (src && src[i] && i + 1 < cap) {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = '\0';
}

static int lb89_read_file_static(const char *path, unsigned char *buf,
                                 unsigned long cap, unsigned long *out_size)
{
    FILE *fp;
    long size;
    if (!path || !buf || cap < 2u || !out_size) return 0;
    fp = fopen(path, "rb");
    if (!fp) return 0;
    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return 0; }
    size = ftell(fp);
    if (size < 0 || (unsigned long)size + 1u > cap) {
        fclose(fp);
        return 0;
    }
    rewind(fp);
    if (fread(buf, 1u, (size_t)size, fp) != (size_t)size) {
        fclose(fp);
        return 0;
    }
    fclose(fp);
    buf[size] = '\0';
    *out_size = (unsigned long)size;
    return 1;
}

static int lb89_is_absolute(const char *path)
{
    if (!path || !*path) return 0;
    if (path[0] == '\\' || path[0] == '/') return 1;
    return path[0] && path[1] == ':';
}

static void lb89_dirname(const char *path, char *out, int cap)
{
    int i;
    int last;
    lb89_copy_path(out, cap, path);
    last = -1;
    for (i = 0; out[i]; ++i) {
        if (out[i] == '\\' || out[i] == '/') last = i;
    }
    if (last >= 0) out[last + 1] = '\0';
    else out[0] = '\0';
}

static void lb89_join_path(char *out, int cap, const char *base,
                           const char *relative)
{
    int n;
    if (lb89_is_absolute(relative)) {
        lb89_copy_path(out, cap, relative);
        return;
    }
    lb89_copy_path(out, cap, base);
    n = (int)strlen(out);
    if (n > 0 && out[n - 1] != '\\' && out[n - 1] != '/' && n + 1 < cap) {
        out[n++] = '\\';
        out[n] = '\0';
    }
    if (n < cap - 1) lb89_copy_path(out + n, cap - n, relative);
}

static void lb89_title(void)
{
    char title[512];
    const char *mode;
    mode = g_rt.mode == LB89_MODE_SIMUL ? "SIMUL" :
           (g_rt.mode == LB89_MODE_TURNS ? "TURNS" : "SINGLE");
    if (g_loaded) {
        sprintf(title, "Natsuki Lifebar Viewer 89 - %s - %s - %dx%d",
                g_def_path, mode, g_def.localcoord_x, g_def.localcoord_y);
    } else {
        strcpy(title, "Natsuki Lifebar Viewer 89 - press F1 or O");
    }
    SetWindowTextA(g_hwnd, title);
}

static int lb89_load_character(const char *path)
{
    lb89_host_bank_close(&g_char_bank);
    if (!lb89_host_bank_open(&g_char_bank, path)) return 0;
    lb89_copy_path(g_char_path, MAX_PATH, path);
    g_canvas.bank[LB89_BANK_P1] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P2] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P3] = &g_char_bank;
    g_canvas.bank[LB89_BANK_P4] = &g_char_bank;
    lb89_host_canvas_reset_cache(&g_canvas);
    return 1;
}

static int lb89_load_fight(const char *def_path)
{
    unsigned long size;
    char base[MAX_PATH];
    char sff_path[MAX_PATH];
    LB89FightDef parsed;
    int rc;
    if (!lb89_read_file_static(def_path, g_def_text,
                               sizeof(g_def_text), &size)) return 0;
    rc = lb89_fightdef_parse(&parsed, (const char *)g_def_text, size);
    if (rc != LB89_OK) return 0;
    if (parsed.localcoord_x < 1 || parsed.localcoord_y < 1 ||
        parsed.localcoord_x > LB89_HOST_MAX_W ||
        parsed.localcoord_y > LB89_HOST_MAX_H) return 0;
    lb89_dirname(def_path, base, sizeof(base));
    lb89_join_path(sff_path, sizeof(sff_path), base,
                   parsed.sff_path[0] ? parsed.sff_path : "fight.sff");
    lb89_host_bank_close(&g_fight_bank);
    if (!lb89_host_bank_open(&g_fight_bank, sff_path)) return 0;
    g_def = parsed;
    lb89_copy_path(g_def_path, sizeof(g_def_path), def_path);
    lb89_copy_path(g_sff_path, sizeof(g_sff_path), sff_path);
    g_canvas.width = g_def.localcoord_x;
    g_canvas.height = g_def.localcoord_y;
    g_canvas.bank[LB89_BANK_FIGHT] = &g_fight_bank;
    lb89_host_canvas_reset_cache(&g_canvas);
    lb89_runtime_init(&g_rt);
    g_rt.life[0] = 760;
    g_rt.mid_life[0] = 900;
    g_rt.life[1] = 410;
    g_rt.mid_life[1] = 650;
    g_rt.combo[0] = 7;
    g_rt.combo_time[0] = 90;
    lb89_runtime_set_cue(&g_rt, LB89_CUE_FIGHT);
    g_timer_accum = 0;
    g_loaded = 1;
    lb89_title();
    return 1;
}

static void lb89_overlay_line(const char *text, int line)
{
    LB89TextCommand cmd;
    int step;
    memset(&cmd, 0, sizeof(cmd));
    step = g_canvas.width >= 640 ? 18 : 9;
    cmd.x = 4;
    cmd.y = g_canvas.height - step * (4 - line);
    cmd.align = 1;
    cmd.r = 190;
    cmd.g = 220;
    cmd.b = 255;
    cmd.scale_x = LB89_FP_ONE;
    cmd.scale_y = LB89_FP_ONE;
    strncpy(cmd.text, text, sizeof(cmd.text) - 1u);
    cmd.text[sizeof(cmd.text) - 1u] = '\0';
    lb89_host_text(&g_canvas, &cmd);
}

static void lb89_render_scene(void)
{
    LB89RenderSink sink;
    char status[96];
    if (!g_loaded) {
        g_canvas.width = 640;
        g_canvas.height = 360;
    }
    lb89_host_canvas_clear(&g_canvas, 16, 18, 26, 255);
    if (g_loaded) {
        sink.user = &g_canvas;
        sink.sprite = lb89_host_sprite;
        sink.text = lb89_host_text;
        sink.rect = lb89_host_rect;
        lb89_render(&g_def, &g_rt, &sink);
    }
    if (g_help) {
        lb89_overlay_line("F1 CLASSIC  F2 HD  O OPEN  R RELOAD", 1);
        lb89_overlay_line("1 SINGLE  2 SIMUL  3 TURNS  C CUE  SPACE PAUSE", 2);
        lb89_overlay_line("A D P1 LIFE  J L P2 LIFE  W S P1 POWER  I K P2 POWER", 3);
        sprintf(status, "P1 %d  P2 %d  POWER %d %d  H HELP",
                g_rt.life[0], g_rt.life[1], g_rt.power[0], g_rt.power[1]);
        lb89_overlay_line(status, 4);
    }
}

static void lb89_open_dialog(void)
{
    OPENFILENAMEA ofn;
    char path[MAX_PATH];
    memset(&ofn, 0, sizeof(ofn));
    path[0] = '\0';
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFilter = "MUGEN fight.def\0fight.def;*.def\0DEF files\0*.def\0All files\0*.*\0\0";
    ofn.lpstrFile = path;
    ofn.nMaxFile = sizeof(path);
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileNameA(&ofn)) {
        if (!lb89_load_fight(path))
            MessageBoxA(g_hwnd, "No pude cargar fight.def o su fight.sff asociado.",
                        "Natsuki Lifebar Viewer 89", MB_OK | MB_ICONERROR);
    }
}

static void lb89_adjust_life(int p, int delta)
{
    lb89_runtime_set_life(&g_rt, p, g_rt.life[p] + delta);
    if (delta < 0) g_rt.mid_wait[p] = 30;
}

static void lb89_adjust_power(int p, int delta)
{
    lb89_runtime_set_power(&g_rt, p, g_rt.power[p] + delta);
}

static void lb89_keydown(WPARAM key)
{
    int cue;
    if (key == VK_F1) lb89_load_fight("corpus\\default\\fight.def");
    else if (key == VK_F2) lb89_load_fight("corpus\\mugen1\\fight.def");
    else if (key == 'O') lb89_open_dialog();
    else if (key == 'R' && g_def_path[0]) lb89_load_fight(g_def_path);
    else if (key == '1') g_rt.mode = LB89_MODE_SINGLE;
    else if (key == '2') g_rt.mode = LB89_MODE_SIMUL;
    else if (key == '3') g_rt.mode = LB89_MODE_TURNS;
    else if (key == 'A') lb89_adjust_life(0, -50);
    else if (key == 'D') lb89_adjust_life(0, 50);
    else if (key == 'J') lb89_adjust_life(1, -50);
    else if (key == 'L') lb89_adjust_life(1, 50);
    else if (key == 'W') lb89_adjust_power(0, 100);
    else if (key == 'S') lb89_adjust_power(0, -100);
    else if (key == 'I') lb89_adjust_power(1, 100);
    else if (key == 'K') lb89_adjust_power(1, -100);
    else if (key == 'C') {
        cue = g_rt.cue + 1;
        if (cue > LB89_CUE_DRAW) cue = LB89_CUE_NONE;
        lb89_runtime_set_cue(&g_rt, cue);
    } else if (key == VK_SPACE) g_rt.paused = !g_rt.paused;
    else if (key == 'H') g_help = !g_help;
    else if (key == VK_ESCAPE) DestroyWindow(g_hwnd);
    lb89_title();
    lb89_render_scene();
    InvalidateRect(g_hwnd, 0, FALSE);
}

static void lb89_present(HDC dc, const RECT *client)
{
    BITMAPINFO bmi;
    unsigned long pixels;
    unsigned long i;
    int cw;
    int ch;
    int dw;
    int dh;
    int dx;
    int dy;
    const unsigned char *src;
    unsigned char *dst;
    if (!g_canvas.rgba || g_canvas.width < 1 || g_canvas.height < 1) return;
    pixels = (unsigned long)g_canvas.width * (unsigned long)g_canvas.height;
    for (i = 0u; i < pixels; ++i) {
        src = g_canvas.rgba + i * 4u;
        dst = g_display_bgra + i * 4u;
        dst[0] = src[2];
        dst[1] = src[1];
        dst[2] = src[0];
        dst[3] = 0u;
    }
    memset(&bmi, 0, sizeof(bmi));
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = g_canvas.width;
    bmi.bmiHeader.biHeight = -g_canvas.height;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;
    cw = client->right - client->left;
    ch = client->bottom - client->top;
    dw = cw;
    dh = (int)(((long)dw * g_canvas.height) / g_canvas.width);
    if (dh > ch) {
        dh = ch;
        dw = (int)(((long)dh * g_canvas.width) / g_canvas.height);
    }
    dx = (cw - dw) / 2;
    dy = (ch - dh) / 2;
    PatBlt(dc, 0, 0, cw, ch, BLACKNESS);
    SetStretchBltMode(dc, COLORONCOLOR);
    StretchDIBits(dc, dx, dy, dw, dh, 0, 0,
                  g_canvas.width, g_canvas.height,
                  g_display_bgra, &bmi, DIB_RGB_COLORS, SRCCOPY);
}

static LRESULT CALLBACK lb89_wndproc(HWND hwnd, UINT msg,
                                     WPARAM wparam, LPARAM lparam)
{
    PAINTSTRUCT ps;
    RECT client;
    int frames_per_count;
    switch (msg) {
    case WM_CREATE:
        g_hwnd = hwnd;
        SetTimer(hwnd, 1u, 16u, 0);
        return 0;
    case WM_ERASEBKGND:
        return 1;
    case WM_KEYDOWN:
        lb89_keydown(wparam);
        return 0;
    case WM_TIMER:
        if (g_loaded && !g_rt.paused) {
            lb89_runtime_tick(&g_rt);
            ++g_timer_accum;
            frames_per_count = lb89_get_int(&g_def, "Time", "framespercount", 60);
            if (frames_per_count < 1) frames_per_count = 60;
            if (g_timer_accum >= frames_per_count) {
                g_timer_accum = 0;
                if (g_rt.timer > 0) --g_rt.timer;
            }
            lb89_render_scene();
            InvalidateRect(hwnd, 0, FALSE);
        }
        return 0;
    case WM_PAINT:
        BeginPaint(hwnd, &ps);
        GetClientRect(hwnd, &client);
        lb89_present(ps.hdc, &client);
        EndPaint(hwnd, &ps);
        return 0;
    case WM_DESTROY:
        KillTimer(hwnd, 1u);
        lb89_host_bank_close(&g_char_bank);
        lb89_host_bank_close(&g_fight_bank);
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcA(hwnd, msg, wparam, lparam);
    }
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE prev,
                   LPSTR command_line, int show)
{
    WNDCLASSA wc;
    HWND hwnd;
    MSG msg;
    (void)prev;
    (void)command_line;
    memset(&wc, 0, sizeof(wc));
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = lb89_wndproc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursorA(0, IDC_ARROW);
    wc.hIcon = LoadIconA(0, IDI_APPLICATION);
    wc.lpszClassName = "NatsukiLifebarViewer89Class";
    if (!RegisterClassA(&wc)) return 1;
    lb89_host_canvas_init(&g_canvas, 640, 360,
                          g_canvas_rgba, g_decode_rgba, sizeof(g_decode_rgba),
                          g_work, sizeof(g_work), g_cache, sizeof(g_cache));
    lb89_runtime_init(&g_rt);
    hwnd = CreateWindowA(wc.lpszClassName,
                         "Natsuki Lifebar Viewer 89",
                         WS_OVERLAPPEDWINDOW,
                         CW_USEDEFAULT, CW_USEDEFAULT, 1000, 620,
                         0, 0, instance, 0);
    if (!hwnd) return 2;
    g_hwnd = hwnd;
    lb89_load_character(g_char_path);
    if (!lb89_load_fight("corpus\\default\\fight.def")) {
        g_loaded = 0;
        lb89_render_scene();
    }
    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);
    while (GetMessageA(&msg, 0, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return (int)msg.wParam;
}
