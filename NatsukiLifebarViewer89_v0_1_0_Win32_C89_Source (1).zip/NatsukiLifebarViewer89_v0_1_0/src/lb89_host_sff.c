#include "lb89_host_sff.h"
#include <string.h>

static int lb89_abs_int(int v) { return v < 0 ? -v : v; }
static int lb89_clamp_int(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

int lb89_host_bank_open(LB89HostBank *bank, const char *path)
{
    SffIo io;
    SffOpenOptions opt;
    int rc;
    if (!bank || !path) return 0;
    memset(bank, 0, sizeof(*bank));
    bank->fp = fopen(path, "rb");
    if (!bank->fp) return 0;
    if (!sff_stdio_source_init(&bank->stdio_source, bank->fp)) {
        fclose(bank->fp);
        bank->fp = 0;
        return 0;
    }
    sff_stdio_make_io(&bank->stdio_source, &io);
    opt.tolerant = 1;
    opt.codec = 0;
    sff_init(&bank->sff);
    rc = sff_open_io(&bank->sff, &io, &opt);
    if (rc != SFF_OK) {
        fclose(bank->fp);
        bank->fp = 0;
        return 0;
    }
    bank->opened = 1;
    return 1;
}

void lb89_host_bank_close(LB89HostBank *bank)
{
    if (!bank) return;
    if (bank->opened) sff_close(&bank->sff);
    if (bank->fp) fclose(bank->fp);
    memset(bank, 0, sizeof(*bank));
}

void lb89_host_canvas_init(LB89HostCanvas *canvas, int w, int h,
                           unsigned char *rgba,
                           unsigned char *decode_rgba, unsigned long decode_cap,
                           unsigned char *work, unsigned long work_cap,
                           unsigned char *cache_pixels, unsigned long cache_cap)
{
    if (!canvas) return;
    memset(canvas, 0, sizeof(*canvas));
    canvas->width = w;
    canvas->height = h;
    canvas->rgba = rgba;
    canvas->decode_rgba = decode_rgba;
    canvas->decode_cap = decode_cap;
    canvas->work = work;
    canvas->work_cap = work_cap;
    canvas->cache_pixels = cache_pixels;
    canvas->cache_cap = cache_cap;
    canvas->cache_used = 0u;
}

void lb89_host_canvas_reset_cache(LB89HostCanvas *canvas)
{
    if (!canvas) return;
    canvas->cache_used = 0u;
    memset(canvas->cache, 0, sizeof(canvas->cache));
}

void lb89_host_canvas_clear(LB89HostCanvas *canvas,
                            int r, int g, int b, int a)
{
    unsigned long i;
    unsigned long count;
    if (!canvas || !canvas->rgba) return;
    count = (unsigned long)canvas->width * (unsigned long)canvas->height;
    for (i = 0u; i < count; ++i) {
        canvas->rgba[i * 4u + 0u] = (unsigned char)r;
        canvas->rgba[i * 4u + 1u] = (unsigned char)g;
        canvas->rgba[i * 4u + 2u] = (unsigned char)b;
        canvas->rgba[i * 4u + 3u] = (unsigned char)a;
    }
}

static void lb89_blend_pixel(unsigned char *dst, const unsigned char *src,
                             const LB89SpriteCommand *cmd)
{
    int sa;
    int inv;
    int sr;
    int sg;
    int sb;
    sa = src[3];
    if (cmd->blend == LB89_BLEND_ALPHA) sa = (sa * cmd->src_alpha) / 255;
    else if (cmd->blend == LB89_BLEND_ADD1) sa /= 2;
    if (sa <= 0) return;
    sr = src[0];
    sg = src[1];
    sb = src[2];
    if (cmd->blend == LB89_BLEND_ADD || cmd->blend == LB89_BLEND_ADD1 ||
        cmd->blend == LB89_BLEND_ALPHA) {
        int dr;
        int dg;
        int db;
        dr = dst[0] + (sr * sa) / 255;
        dg = dst[1] + (sg * sa) / 255;
        db = dst[2] + (sb * sa) / 255;
        dst[0] = (unsigned char)lb89_clamp_int(dr, 0, 255);
        dst[1] = (unsigned char)lb89_clamp_int(dg, 0, 255);
        dst[2] = (unsigned char)lb89_clamp_int(db, 0, 255);
        dst[3] = 255u;
    } else {
        inv = 255 - sa;
        dst[0] = (unsigned char)((sr * sa + dst[0] * inv) / 255);
        dst[1] = (unsigned char)((sg * sa + dst[1] * inv) / 255);
        dst[2] = (unsigned char)((sb * sa + dst[2] * inv) / 255);
        dst[3] = 255u;
    }
}

static LB89HostCacheEntry *lb89_find_cached(LB89HostCanvas *canvas,
                                             LB89HostBank *bank,
                                             int group, int item)
{
    int i;
    for (i = 0; i < LB89_HOST_CACHE_SLOTS; ++i) {
        if (canvas->cache[i].valid && canvas->cache[i].bank == bank &&
            canvas->cache[i].group == group && canvas->cache[i].item == item)
            return &canvas->cache[i];
    }
    return 0;
}

static LB89HostCacheEntry *lb89_cache_sprite(LB89HostCanvas *canvas,
                                              LB89HostBank *bank,
                                              int group, int item)
{
    sff_u32 index;
    SffSpriteInfo info;
    sff_u16 w;
    sff_u16 h;
    unsigned long needed;
    int slot;
    int rc;
    LB89HostCacheEntry *entry;
    if (sff_find_sprite(&bank->sff, (sff_u16)group,
                        (sff_u16)item, &index) != SFF_OK) return 0;
    if (sff_get_sprite_info(&bank->sff, index, &info) != SFF_OK) return 0;
    needed = (unsigned long)info.w * (unsigned long)info.h * 4u;
    if (!canvas->cache_pixels || needed > canvas->cache_cap - canvas->cache_used)
        return 0;
    slot = -1;
    for (rc = 0; rc < LB89_HOST_CACHE_SLOTS; ++rc) {
        if (!canvas->cache[rc].valid) { slot = rc; break; }
    }
    if (slot < 0) return 0;
    entry = &canvas->cache[slot];
    rc = sff_decode_sprite_rgba_into(&bank->sff, index,
                                     canvas->cache_pixels + canvas->cache_used,
                                     (sff_u32)(canvas->cache_cap - canvas->cache_used),
                                     &w, &h,
                                     canvas->work,
                                     (sff_u32)canvas->work_cap);
    if (rc != SFF_OK || w == 0u || h == 0u) return 0;
    entry->bank = bank;
    entry->group = group;
    entry->item = item;
    entry->offset = canvas->cache_used;
    entry->w = w;
    entry->h = h;
    entry->axis_x = info.axis_x;
    entry->axis_y = info.axis_y;
    entry->valid = 1;
    canvas->cache_used += (unsigned long)w * (unsigned long)h * 4u;
    return entry;
}

void lb89_host_sprite(void *user, const LB89SpriteCommand *cmd)
{
    LB89HostCanvas *canvas;
    LB89HostBank *bank;
    LB89HostCacheEntry *cached;
    unsigned short w;
    unsigned short h;
    long sx_fp;
    long sy_fp;
    long scale_x;
    long scale_y;
    int out_w;
    int out_h;
    int left;
    int top;
    int dx;
    int dy;
    int sx;
    int sy;
    int px;
    int py;
    const unsigned char *pixels;
    const unsigned char *src;
    unsigned char *dst;
    if (!user || !cmd) return;
    canvas = (LB89HostCanvas *)user;
    if (cmd->bank < 0 || cmd->bank >= 5) return;
    bank = canvas->bank[cmd->bank];
    if (!bank || !bank->opened) return;
    if (cmd->group < 0 || cmd->item < 0) return;
    cached = lb89_find_cached(canvas, bank, cmd->group, cmd->item);
    if (!cached) cached = lb89_cache_sprite(canvas, bank, cmd->group, cmd->item);
    if (!cached) return;
    w = cached->w;
    h = cached->h;
    pixels = canvas->cache_pixels + cached->offset;
    scale_x = cmd->scale_x;
    scale_y = cmd->scale_y;
    if (scale_x == 0) scale_x = LB89_FP_ONE;
    if (scale_y == 0) scale_y = LB89_FP_ONE;
    scale_x = lb89_abs_int((int)scale_x);
    scale_y = lb89_abs_int((int)scale_y);
    out_w = (int)(((long)w * scale_x + LB89_FP_ONE - 1L) >> LB89_FP_SHIFT);
    out_h = (int)(((long)h * scale_y + LB89_FP_ONE - 1L) >> LB89_FP_SHIFT);
    if (out_w < 1) out_w = 1;
    if (out_h < 1) out_h = 1;
    if (cmd->facing >= 0)
        left = cmd->x - (int)(((long)cached->axis_x * scale_x) >> LB89_FP_SHIFT);
    else
        left = cmd->x - (int)(((long)((int)w - cached->axis_x) * scale_x) >> LB89_FP_SHIFT);
    if (cmd->vfacing >= 0)
        top = cmd->y - (int)(((long)cached->axis_y * scale_y) >> LB89_FP_SHIFT);
    else
        top = cmd->y - (int)(((long)((int)h - cached->axis_y) * scale_y) >> LB89_FP_SHIFT);
    for (dy = 0; dy < out_h; ++dy) {
        sy_fp = ((long)dy << LB89_FP_SHIFT) / scale_y;
        sy = (int)sy_fp;
        if (sy >= (int)h) sy = (int)h - 1;
        if (cmd->vfacing < 0) sy = (int)h - 1 - sy;
        py = top + dy;
        if (py < 0 || py >= canvas->height) continue;
        if (cmd->clip.enabled && (py < cmd->clip.y1 || py > cmd->clip.y2)) continue;
        for (dx = 0; dx < out_w; ++dx) {
            sx_fp = ((long)dx << LB89_FP_SHIFT) / scale_x;
            sx = (int)sx_fp;
            if (sx >= (int)w) sx = (int)w - 1;
            if (cmd->facing < 0) sx = (int)w - 1 - sx;
            px = left + dx;
            if (px < 0 || px >= canvas->width) continue;
            if (cmd->clip.enabled && (px < cmd->clip.x1 || px > cmd->clip.x2)) continue;
            src = pixels + (((unsigned long)sy * (unsigned long)w +
                  (unsigned long)sx) * 4u);
            dst = canvas->rgba + (((unsigned long)py * (unsigned long)canvas->width +
                  (unsigned long)px) * 4u);
            lb89_blend_pixel(dst, src, cmd);
        }
    }
}

static const unsigned char lb89_font5x7[37][7] = {
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14},{14,17,17,31,17,17,17},{30,17,17,30,17,17,30},
 {14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},
 {31,16,16,30,16,16,16},{14,17,16,23,17,17,14},{17,17,17,31,17,17,17},
 {14,4,4,4,4,4,14},{7,2,2,2,2,18,12},{17,18,20,24,20,18,17},
 {16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},
 {14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},
 {30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},
 {17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},
 {17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
 {0,0,0,0,0,0,0}
};

static int lb89_glyph_index(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c >= 'A' && c <= 'Z') return 10 + c - 'A';
    return 36;
}

static void lb89_put_dot(LB89HostCanvas *canvas, int x, int y,
                         int r, int g, int b)
{
    unsigned char *p;
    if (!canvas || x < 0 || y < 0 || x >= canvas->width || y >= canvas->height) return;
    p = canvas->rgba + (((unsigned long)y * (unsigned long)canvas->width +
         (unsigned long)x) * 4u);
    p[0] = (unsigned char)r;
    p[1] = (unsigned char)g;
    p[2] = (unsigned char)b;
    p[3] = 255u;
}

void lb89_host_text(void *user, const LB89TextCommand *cmd)
{
    LB89HostCanvas *canvas;
    int len;
    int scale;
    int start_x;
    int x;
    int y;
    int i;
    int row;
    int col;
    int gx;
    int gy;
    int idx;
    unsigned char bits;
    if (!user || !cmd) return;
    canvas = (LB89HostCanvas *)user;
    len = (int)strlen(cmd->text);
    scale = canvas->width >= 640 ? 2 : 1;
    start_x = cmd->x;
    if (cmd->align == 0) start_x -= (len * 6 * scale) / 2;
    else if (cmd->align < 0) start_x -= len * 6 * scale;
    for (i = 0; i < len; ++i) {
        idx = lb89_glyph_index((unsigned char)cmd->text[i]);
        for (row = 0; row < 7; ++row) {
            bits = lb89_font5x7[idx][row];
            for (col = 0; col < 5; ++col) {
                if ((bits & (1u << (4 - col))) == 0) continue;
                for (gy = 0; gy < scale; ++gy) {
                    for (gx = 0; gx < scale; ++gx) {
                        x = start_x + i * 6 * scale + col * scale + gx;
                        y = cmd->y + row * scale + gy;
                        lb89_put_dot(canvas, x, y, cmd->r, cmd->g, cmd->b);
                    }
                }
            }
        }
    }
}

void lb89_host_rect(void *user, int x1, int y1, int x2, int y2,
                    int r, int g, int b, int a, int layerno)
{
    LB89HostCanvas *canvas;
    int x;
    int y;
    (void)a;
    (void)layerno;
    canvas = (LB89HostCanvas *)user;
    for (y = y1; y <= y2; ++y)
        for (x = x1; x <= x2; ++x)
            lb89_put_dot(canvas, x, y, r, g, b);
}

int lb89_host_write_ppm(const LB89HostCanvas *canvas, const char *path)
{
    FILE *fp;
    int x;
    int y;
    const unsigned char *p;
    if (!canvas || !canvas->rgba || !path) return 0;
    fp = fopen(path, "wb");
    if (!fp) return 0;
    fprintf(fp, "P6\n%d %d\n255\n", canvas->width, canvas->height);
    for (y = 0; y < canvas->height; ++y) {
        for (x = 0; x < canvas->width; ++x) {
            p = canvas->rgba + (((unsigned long)y * (unsigned long)canvas->width +
                (unsigned long)x) * 4u);
            fwrite(p, 1u, 3u, fp);
        }
    }
    fclose(fp);
    return 1;
}
