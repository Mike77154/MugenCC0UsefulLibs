# Compatibilidad v0.1.0

| Área | Estado | Notas |
|---|---:|---|
| `fight.def` clásico | Sí | Parser case-insensitive, comentarios y strings |
| SFF v1 | Sí | PCX y paletas mediante sfflib |
| SFF v2 MUGEN 1.0/1.1 | Sí | RLE8/RLE5/LZ5/PNG según el decoder vendorizado |
| AIR inline | Sí | frames, ticks, LoopStart, H/V, A/A1/ASxDxxx |
| Single lifebar | Sí | P1/P2 |
| Simul lifebar | Sí | P1-P4 |
| Turns lifebar | Parcial | barras principales; teammate portraits pendientes |
| Life front/mid | Sí | recorte por `range.x` y retraso de midlife |
| Powerbar | Sí | front/bg/counter |
| Face | Sí | bancos externos P1-P4, sprite 9000,0 |
| Name / Time / Combo | Sí | fallback bitmap del host |
| Round/Fight/KO | Sí | texto o animación AIR |
| DKO/Time Over/Win/Draw | Sí | texto |
| `layerno` | Sí | transportado en el comando; orden completo será del provider |
| `window` | Básico | clipping rectangular |
| `fight.snd` | Descubierto | playback pendiente |
| Fuentes FNT/SFF/TTF | Parcial | paths parseados; renderer real pendiente |
| WinIcon | Pendiente | propiedades preservadas por parser |
| IKEMEN red life/warning/multi-front | Pendiente | extensión planificada |

## Coordenadas

El corpus clásico usa 320x240. El corpus HD suministrado usa `FightFx scale=4`
y se presenta a 1280x720. El parser también acepta `[Info] localcoord=x,y` como
override explícito para hosts o assets personalizados.
