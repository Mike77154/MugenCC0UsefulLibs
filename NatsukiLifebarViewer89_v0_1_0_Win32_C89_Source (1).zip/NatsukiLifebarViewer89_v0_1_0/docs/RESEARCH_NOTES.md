# Notas de investigación

Fuentes primarias consultadas al diseñar el subengine:

- Elecbyte MUGEN documentation: lista de archivos motif (`fight.def`,
  `fight.sff`, `fight.snd`) y especificaciones AIR/SFF/FNT.
- IKEMEN GO wiki, Lifebar features: capas, ventanas de clipping, localcoord,
  warning ranges, red life y múltiples elementos front.
- IKEMEN GO repository: compatibilidad hacia atrás con recursos MUGEN y
  separación entre runtime y motif.

Decisiones derivadas:

1. El DEF/AIR pertenece al subengine; la decodificación SFF pertenece a un
   provider.
2. `fight.sff` y los sprites de rostro del personaje son bancos distintos.
3. `layerno` y `window` se conservan en las órdenes aunque el host inicial sólo
   implemente un subconjunto.
4. La API preserva claves desconocidas para ampliar compatibilidad sin rehacer
   el parser.
