# Arquitectura

```text
fight.def bytes
     |
     v
+------------------+
| fightdef89       |  propiedades + AIR inline
+------------------+
     |
     v
+------------------+       datos del combate
| lifebarruntime89 | <---------------- CharacterRuntime89
+------------------+
     |
     v
+------------------+
| lifebarrender89  |  SpriteCommand / TextCommand / RectCommand
+------------------+
     |
     +--------------------+-----------------------+
     v                    v                       v
SFF/GDI provider      engine provider         test collector
(visor Win32)         (binding futuro)         (headless)
```

## Separación de responsabilidades

### `fightdef89`

Parser fijo de propiedades INI y acciones AIR embebidas. Conserva las claves
que no entiende para que una extensión posterior no obligue a cambiar el
formato interno.

### `lifebarruntime89`

Estado demostrable: cuatro vidas, cuatro powers, vida diferida, timer, combos,
modo de equipo y cue activo. No impone la lógica real de combate; el motor puede
sobrescribir esos valores cada tick.

### `lifebarrender89`

Interpreta el layout y emite comandos. No toca archivos ni memoria gráfica.
Los clips de front/mid se calculan desde `range.x` usando enteros.

### `lb89_host_sff`

Provider de referencia. Resuelve bancos Fight/P1-P4, decodifica SFF v1/v2 y
mantiene una caché fija de 128 entradas dentro de un pool de 16 MiB.

### `main_win32`

Ventana, teclado, diálogo Open y presentación GDI. Renderiza primero a un
framebuffer RGBA y luego hace un único `StretchDIBits`, evitando el flicker del
dibujo directo por componentes.

## Binding propuesto con NatsukiFight89

```text
CharacterRuntime89[0..3]
  life/max_life ----------> LB89Runtime.life[] normalizado 0..1000
  power/max_power --------> LB89Runtime.power[]
  display_name -----------> LB89Runtime.player_name[]
RoundRuntime89
  timer/round/cue --------> LB89Runtime
RendererProvider89
  draw_sprite ------------> LB89RenderSink.sprite
  draw_text --------------> LB89RenderSink.text
  draw_rect --------------> LB89RenderSink.rect
```
