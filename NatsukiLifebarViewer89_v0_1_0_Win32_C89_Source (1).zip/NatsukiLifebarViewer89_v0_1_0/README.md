# Natsuki Lifebar Viewer 89 v0.1.0

Visor especializado de lifebars MUGEN y subengine vendorizado, pensado para
integrarse después con `NatsukiFight89` sin convertir la ventana Win32 en la
fuente de verdad del HUD.

## Principios

- C89 estricto.
- Sin `malloc`, `realloc`, `free`, `calloc` ni heap.
- Sin `float` ni `double`; escalas Q16.16.
- Capacidades fijas y buffers propiedad del caller/host.
- SFF v1 y v2 mediante `vendor/sfflib`.
- Backend de dibujo por callbacks (`LB89RenderSink`).
- Host Win32 GDI con framebuffer propio, caché estática de sprites y
  `WM_ERASEBKGND` desactivado para evitar parpadeo.

## Qué contiene

```text
vendor/lifebar89/
  include/lifebar89.h      API pública
  src/fightdef89.c         parser fight.def + Begin Action
  src/runtime89.c          estado simulado del combate
  src/render89.c           emisor agnóstico de órdenes
  tests/test_lifebar89.c   prueba estricta C89
vendor/sfflib/             decoder SFF/PCX/PNG/zlib sin heap
src/
  lb89_host_sff.*          provider SFF + raster + caché
  main_win32.c             visor interactivo Win32
  preview_cli.c            renderer headless a PPM
corpus/
  default/                 lifebar clásico 320x240
  mugen1/                  lifebar MUGEN 1.0 HD 1280x720
  character/               rostro 9000,0 para probar Face
```

## Compilar en MSYS2 MinGW32

Desde una consola con `i686-w64-mingw32-gcc`:

```sh
./build_msys2_mingw32.bat
```

Salidas:

```text
bin/NatsukiLifebarViewer89.exe
bin/lb89_preview_cli.exe
bin/test_lifebar89.exe
bin/liblifebar89.a
```

## Controles del visor

| Tecla | Acción |
|---|---|
| `F1` / `F2` | Corpus clásico / HD |
| `O` | Abrir otro `fight.def`; busca su SFF relativo |
| `R` | Recargar el DEF actual |
| `1` / `2` / `3` | Single / Simul / Turns |
| `A D` / `J L` | Vida P1 / P2 |
| `W S` / `I K` | Power P1 / P2 |
| `C` | Recorrer ROUND, FIGHT, KO, DKO, TIME OVER, WIN, DRAW |
| `Espacio` | Pausa |
| `H` | Ayuda |

## API mínima

```c
LB89FightDef def;
LB89Runtime runtime;
LB89RenderSink sink;

lb89_fightdef_parse(&def, bytes, byte_count);
lb89_runtime_init(&runtime);

sink.user = my_renderer;
sink.sprite = my_sprite_provider;
sink.text = my_text_provider;
sink.rect = my_rect_provider;

lb89_render(&def, &runtime, &sink);
```

`lifebar89` no abre archivos, no decodifica imágenes y no conoce GDI. El host
inyecta esos servicios. Para bindearlo con el motor, sólo hay que mapear la
vida/power/timer/nombres del `CharacterRuntime89` a `LB89Runtime` y conectar el
sink al provider gráfico del engine.

## Estado v0.1.0

Implementado: `fight.def`, `[Files]`, `[FightFx]`, `Begin Action`, Single,
Simul, Turns, life front/mid/bg, power, faces, names, timer, combo y anuncios.
También respeta `offset`, `facing`, `vfacing`, `scale`, `layerno` y `window`
básico.

Pendiente para pases posteriores: fuentes FNT/SFF verdaderas en vez del fallback
bitmap del host, reproducción de `fight.snd`, win icons, teammate portraits de
Turns y extensiones amplias de IKEMEN GO como red life, múltiples fronts,
warning ranges, palfx y xshear.

## Validación incluida

```sh
./build/build_linux_validation.sh
```

El paquete fue validado con compilación `-std=c89 -pedantic -Wall -Wextra
-Werror` sobre los dos corpus. Los previews generados quedan en `validation/`.
