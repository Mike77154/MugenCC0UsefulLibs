# Terceros y corpus

- `vendor/sfflib`: decoder sin heap previamente desarrollado en el proyecto y
  copiado aquí como dependencia vendorizada.
- `corpus/default`, `corpus/mugen1`, `corpus/character`, `corpus/font`: assets
  de compatibilidad recuperados de los archivos previamente suministrados por
  el usuario. Conservan sus condiciones originales; el aviso CC0 de este
  paquete no los relicencia.
