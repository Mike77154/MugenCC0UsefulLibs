# Giffany Screenpack Tester 89 v0.4.3

Tester/runtime experimental de screenpacks MUGEN: C89, Win32 de 32 bits,
almacenamiento fijo y arquitectura vendorizada.


## Configuración separada de controles P1/P2

`OPTIONS → CONTROLS` ahora abre perfiles reales e independientes para ambos
jugadores. Cada perfil permite capturar:

- light, mid y hard punch;
- light, mid y hard kick;
- start;
- jump, move left, move right y crouch.

Enter sobre una acción deja a `scanemu_c89` escuchando el siguiente botón;
`Esc` cancela la captura. `EXPORT PLAYER INI` genera, junto al `system.def`
cargado:

```text
player1_controls.ini
player2_controls.ini
```

Los dos INI se vuelven a cargar automáticamente al abrir el screenpack. El
menú muestra el token estable (`KEY:0:90`, `PADBTN:0:2`, etc.) y cada jugador
puede restaurar sus valores predeterminados sin tocar al otro.

El `scanemu_c89` recibido fue vendorizado como fork integer-only: los ejes usan
Q16.16, sin heap ni tipos de punto flotante. El host Win32 de esta versión
captura teclado; la API ya admite adaptadores futuros de mouse y gamepad.

> La captura/INI ya funciona y persiste. El tester todavía conserva sus
> hotkeys diagnósticas fijas fuera de la pantalla de captura; el gameplay
> futuro consumirá estos perfiles mediante su input mapper.

Detalles: `CONTROL_CONFIG_INI.md`.

## Modos de operación

### Console mode — predeterminado

- El menú normal se usa sin insertar moneda.
- `ARCADE` y `TEAM ARCADE` cobran un crédito al MAIN al entrar.
- VS, Team VS, Training, Watch y demás modos no arcade son gratuitos.
- Un invasor sólo puede disparar `HERE COMES A NEW CHALLENGER` dentro de
  Arcade o Team Arcade, desde SELECT, VS o el futuro gameplay.
- El invasor siempre paga un crédito independiente.

### Cabinet mode

```text
INSERT COIN → PRESS START → sesión pagada del MAIN
```

- El primer START jugable cobra un crédito y abre una sesión para ese MAIN.
- Mientras la sesión siga activa, volver a TITLE, SELECT o VS no cobra otra vez.
- La autoridad MAIN se conserva al regresar al título.
- Una derrota reportada por el runner termina la sesión; el siguiente
  START/CONTINUE vuelve a requerir crédito.
- El jugador invasor paga su propia entrada aunque el MAIN tenga sesión activa.
- ATTRACT MODE sólo se activa en Cabinet mode.

`F9` alterna Console/Cabinet. Cambiar de modo termina cualquier sesión activa,
libera MAIN y vuelve al título sin alterar el saldo.

## Flujo disponible

```text
CABINET ATTRACT ↔ TITLE
                    ├── OPTIONS → TITLE
                    └── modos jugables
                          → SELECT
                          → VS
                          → TITLE
```

En Arcade y Team Arcade:

```text
MAIN ya pagó según la política activa
        ↓
SECONDARY pulsa START desde SELECT/VS/gameplay
        ↓
se comprueba y consume 1 crédito del pool
        ↓
HERE COMES A NEW CHALLENGER
        ↓
SECONDARY selecciona
        ↓
VS
```

## Controles

| Acción | P1 | P2 |
|---|---|---|
| Moneda | `1` | `2` |
| Mover | Flechas | W/A/S/D o numpad |
| START / confirmar | Enter o Espacio | F, Enter numérico, 5 o + |
| Cancelar | Esc | G, punto o - del numpad |
| FREE PLAY | F8 | F8 |
| Console/Cabinet | F9 | F9 |

## Vendors de crédito

```text
vendor/
├── credit_system/      backend de saldo aportado
├── coinsystem89/       inserción, gasto, FREE PLAY y etiquetas
├── creditpolicy89/     Console/Cabinet, sesión y reglas de cobro
├── attract_mode/       backend de páginas aportado
└── attractflow89/      espera y salida de ATTRACT
```

`creditpolicy89` no posee el saldo: sólo decide cuándo corresponde cobrar. El
saldo sigue perteneciendo a `coinsystem89`/`credit_system`.

## API importante

```c
gst89_engine_set_operation_mode(engine,
    GST89_ENGINE_OPERATION_CABINET);

gst89_engine_report_main_loss(engine, 1);

gst89_engine_request_challenger(engine, 2,
    GST89_ENGINE_CHALLENGER_SOURCE_GAMEPLAY);
```

El futuro runner debe llamar `gst89_engine_report_main_loss()` cuando determine
que MAIN perdió. El tester actual todavía no tiene combate real y, por tanto,
no inventa una derrota al terminar VS.

## Compilar en MSYS2 MinGW32

```sh
./build_msys2_mingw32.bat
```

Produce:

```text
build/libgst89_engine_win32.a
bin/GiffanyScreenpackTester89.exe
```

Para WOFF2 con Brotli:

```sh
./build_msys2_mingw32_brotli.bat
```

## Límites

- SELECT todavía usa retratos placeholder.
- La demo de ATTRACT es una representación, no gameplay automatizado.
- CONTINUE está contemplado, pero todavía no existe su pantalla.
- No se generó ni ejecutó el PE32 dentro de este entorno; debe compilarse en
  MSYS2 MINGW32.

## Validación

- `validation/CREDITPOLICY89_V042_PASS.txt`
- `validation/CREDIT_POLICY_ENGINE_V042_PASS.txt`
- `validation/CREDIT_POLICY_ALL_MOTIFS_V042_PASS.txt`
- `validation/FULL_OBJECT_ARCHIVE_V042_PASS.txt`
- `validation/WIN32_STRICT_C89_V042_PASS.txt`
- `validation/CONTROL_CONFIG_OPTIONS_V043_PASS.txt`
- `validation/ENGINE_CONTROL_CAPTURE_V043_PASS.txt`
- `validation/FULL_OBJECT_ARCHIVE_V043_PASS.txt`
- `validation/WIN32_STRICT_C89_V043_PASS.txt`
