# Changelog

## 0.4.3

- Vendoriza el `scanemu_c89` aportado y lo convierte a Q16.16 integer-only.
- Añade `controlconfig89`, con 11 acciones separadas para P1 y P2.
- `OPTIONS → CONTROLS` abre submenús completos de captura para ambos jugadores.
- `Esc` cancela una escucha sin sobrescribir el binding anterior.
- Exporta `player1_controls.ini` y `player2_controls.ini` junto al `system.def`.
- Recarga automáticamente ambos perfiles al volver a abrir el screenpack.
- Amplía la capacidad de Matroshka a 16 elementos por menú.
- Añade una API agnóstica de eventos crudos para hosts de teclado/pad/mouse.
- El host Win32 evita capturar el mismo Enter que abrió la escucha esperando su KEYUP.
- Build actualizado a 117 objetos; corpus Default/MUGEN1/Big/KFM sin regresiones.

## 0.4.2

- Añade `creditpolicy89` como vendor agnóstico de políticas Console/Cabinet.
- Console mode sólo cobra al MAIN al entrar en Arcade o Team Arcade.
- Cabinet mode cobra el primer START jugable y conserva una sesión pagada hasta que MAIN pierda.
- Volver a TITLE/SELECT/VS en Cabinet no vuelve a descontar.
- HERE COMES A NEW CHALLENGER sólo se admite en Arcade/Team Arcade desde SELECT, VS o gameplay y siempre cuesta un crédito independiente.
- Añade `gst89_engine_report_main_loss()` para que el futuro runner termine la sesión de cabinet.
- Añade `gst89_engine_request_challenger()` para invasiones desde gameplay futuro.
- F9 alterna Console/Cabinet; ATTRACT queda asociado a Cabinet mode.
- Build actualizado a 115 objetos y probado con Default, MUGEN1, Big y KFM.

## 0.4.1

- Vendoriza `credit_system` y `attract_mode` con su compatibilidad faltante.
- Añade `coinsystem89`: pool compartido, costes START/CHALLENGER/CONTINUE, máximo, FREE PLAY y etiqueta CREDIT.
- Añade `attractflow89` y vista ATTRACT tras 600 ticks sin crédito.
- Teclas 1/2 insertan moneda por jugador; F8 alterna FREE PLAY.
- START no reclama MAIN si no puede consumir crédito.
- HERE COMES A NEW CHALLENGER exige y consume un segundo crédito.
- Badge de créditos visible en TITLE, OPTIONS, SELECT, VS y CHALLENGER.
- Build actualizado a 114 objetos.

## v0.4.0 - 2026-08-02

- Separada la autoridad P1/P2 en `mainplayer89`.
- Separado el ciclo TITLE → SELECT → VS → TITLE en `title_select_vs_flow89`.
- Separado el árbol OPTIONS en `optionsflow89`.
- Añadido `newchallenger89` para HERE COMES A NEW CHALLENGER.
- Arcade y Team Arcade aceptan START del jugador secundario en SELECT o VS.
- El retador recibe su propio cursor, selecciona y entra a una nueva VS.
- Añadida fuente GAMEPLAY agnóstica para conexión futura con un runner.
- Actualizados build lists, response files, validaciones y documentación.

## v0.3.3 - 2026-08-02

- P1 y P2 pueden navegar TITLE desde el primer frame.
- El primer jugador que pulsa START reclama `main_player`.
- Añade `gst89_engine_player_command()` sin romper `gst89_engine_command()`.
- P2 puede iniciar ARCADE, VS, TEAM VS, TRAINING, WATCH y demás modos desde su propio lado.
- En modos dobles, MAIN elige primero y luego el jugador secundario.
- En modos simples, el rival placeholder se asigna al lado contrario.
- Input del jugador inactivo se ignora durante SELECT.
- Sólo MAIN puede omitir/cancelar VS.
- Al volver a TITLE desde SELECT/VS se libera autoridad.
- El cursor de TITLE muestra color e insignia P1/P2/MAIN.
- Añade controles P2 WASD + F/G y bloque numérico.
- Nuevas regresiones de P2-first y corpus completo MUGEN.

## v0.3.2 - 2026-08-02

- Corrige el build MinGW32: `ar` ya no recibe el comodín literal `build\engine_obj\*.o`.
- Genera `build/engine_objects.rsp` y archiva una lista explícita de objetos.
- Añade fallback objeto por objeto si el `ar` instalado no acepta response files.
- Los objetos llevan prefijo numérico para evitar futuras colisiones de nombres.
- Elimina `gst89_font_alignment` sin uso.
- Amplía el buffer del diálogo de error y elimina el signo invertido que podía verse como mojibake ANSI.
- Silencia `-Wmisleading-indentation` sólo para el decoder OTF vendorizado, sin ocultar warnings del engine.

## v0.3.1 - 2026-08-02

- Añade el ciclo `TITLE → SELECT → VS → TITLE`.
- `ARCADE`, `VERSUS`, `TEAM`, `SURVIVAL`, `TRAINING` y `WATCH` pueden entrar a SELECT.
- Nuevo `vendor/selectdef89`: parser C89, fijo y sin heap para `select.def`.
- Nuevo `vendor/selectflow89`: cursores P1/P2, confirmación, cancelación y estado READY.
- SELECT usa `[Select Info]`, `SelectBG`, roster real y celdas placeholder.
- VS usa `VersusBG`, nombres del roster, retratos placeholder y `[VS Screen] time`.
- Enter/Esc en VS vuelve al título; el timeout también reinicia el flujo.
- Main sigue en nueve líneas; toda la lógica permanece vendorizada.
- Añade validaciones de parser, flujo y ciclo completo en los cuatro motifs clásicos.

## v0.3.0 - 2026-08-02

- Toda la integración funcional se movió a `vendor/gst89_engine`.
- `src/main_win32.c` quedó en nueve líneas y sólo llama al host.
- Nueva API agnóstica `gst89_engine.h` con comandos y callbacks.
- Navegación, reloj, vistas y reproducción solicitada dejaron el main.
- Backends Win32 separados en `platform/win32` y `render/win32`.
- Build y response files actualizados al layout vendorizado.
- Añadidas validaciones de fachada y estructura.
- Sin regresiones en corpus MUGEN, fuentes, SFF, SND, AIR, tiling u OPTIONS.

## v0.2.7 - 2026-08-01

- Corrige el parser FNT v1 `Type = Fixed`: cada entrada de `[Map]` ahora
  avanza por `Size.x` dentro del atlas PCX, en vez de asignar offset cero a
  todos los caracteres.
- Corrige los color banks FNT v1 según el orden inverso de la paleta de
  Elecbyte: bank 0 usa el bloque final de la paleta y bank N retrocede
  `N * Colors` entradas.
- Añade regresión integrada con el `jg.fnt` real del MUGEN clásico:
  `A` y `B` deben producir máscaras distintas; bank 0 debe ser gris y bank 5
  amarillo.
- El log ahora puede confirmar que el backend abrió el archivo, pero las
  pruebas ya distinguen entre «abrió» y «renderizó los glifos correctos».

## v0.2.6 - 2026-08-01

- Integra completo `monika_fontcore` detrás de `gst89_font_provider`.
- Renderiza fuentes Elecbyte `.fnt` reales mediante PCX, mapa de glifos y
  bancos de paleta.
- Renderiza fuentes MUGEN FNT v2 bitmap `.def` mediante su SFF v2 y glifos
  grupo 0 / item ASCII.
- Interpreta FNT v2 TrueType y busca el archivo junto al DEF, mediante fallback
  MUGEN o en `%WINDIR%\Fonts`.
- Añade rutas TTF, OTF/CFF/CFF2, TTC, WOFF1, WOFF2, EOT y GMYY.
- Añade build opcional Brotli para WOFF2 comprimido real.
- Añade fallback `eotdec` para EOT raw/XOR cuando el scan directo no basta.
- Corrige la autoridad de slots: `fontN`, `FontSpec.slot=N` y provider usan el
  mismo índice literal; `font4` ya no consulta el slot 3.
- Cursor, halo, palabra activa y hit-test usan las métricas del glifo real.
- La auditoría muestra fuentes cargadas/solicitadas y backend normal/activo.
- Añade pruebas de render real para `jg.fnt` y `arcade.def`, matriz externa de
  formatos y comprobación 3/3, 6/6, 6/6 y 3/3 sobre los motifs clásicos.

## v0.2.5 - 2026-08-01

- Mide el texto visible con `GetTextExtentPoint32A` y ajusta la caja del cursor
  a los límites reales de cada palabra.
- Unifica la geometría usada por texto, cursor y hit-test del ratón.
- Corrige la interpretación de alineación MUGEN: 0 centrado, positivo a la
  izquierda del texto y negativo a la derecha.
- Añade halo luminoso permanente a la palabra activa, incluso cuando el motif
  desactiva `menu.boxcursor.visible`.
- Integra `matroshkanestanidize_submenus89` para abrir OPTIONS, submenús
  anidados, breadcrumb, BACK y restauración exacta de selección.
- Añade soporte de preview para `[OptionBGdef]` y `[OptionBG n]`, incluido SFF
  específico del BGDef.
- Añade adaptadores C89 de capacidad fija para `msubmenu89` y `listcycling89`,
  dependencias no incluidas en el ZIP recibido.
- Añade pruebas de pila, elementos deshabilitados, retorno al padre, restauración
  de OPTIONS, alineación textual y referencias OptionBG.

## v0.2.4 - 2026-08-01

- Elimina costuras negras móviles entre tiles horizontales y verticales.
- Proyecta los bordes izquierdo/derecho y superior/inferior como una pareja,
  en vez de convertir posición y tamaño por separado.
- Usa división piso para coordenadas locales negativas, evitando saltos de un
  píxel cuando un tile cruza el borde izquierdo o superior.
- Aplica la misma regla de bordes compartidos al eje vertical del parallax.
- Añade una prueba exhaustiva de fases y tamaños de viewport para comprobar
  que dos tiles contiguos comparten exactamente el mismo píxel frontera.
- Conserva el culling y la caché de v0.2.3.

## v0.2.3 - 2026-08-01

- Sustituye el rango conservador de tiling por culling exacto contra viewport y
  `window`.
- Reduce el título MUGEN1 de 716 llamadas de sprite teóricas a 15 visibles.
- Añade caché RGBA estática de 32 MiB; un sprite SFF no vuelve a decodificarse
  por cada tile ni por cada frame.
- Recorta `dx/dy` antes del raster; las ventanas `add1` de tres píxeles ya no
  recorren sprites completos de 320 filas.
- Añade mapa de coordenadas X para evitar división entera dentro del bucle por
  píxel.
- Añade fast path de copia directa para blend normal con alpha 255.
- Añade muestras `PERF` cada 120 frames y estadísticas de caché al log.
- Conserva C89, buffers estáticos y cero heap.

## v0.2.2 - 2026-08-01

- Corrige el origen horizontal de fondos MUGEN: `start.x = 0` ahora significa
  centro superior del espacio local, no borde izquierdo.
- Mantiene el eje SFF de cada sprite en el origen del BG, incluso durante
  cambios de frame AIR y flips H/V.
- Implementa `Loopstart`, frames de duración `-1`, flips y blend AIR en el
  preview de fondos animados.
- Normaliza la fase de `tile = 1` para que el número de copias permanezca
  acotado aunque el fondo lleve horas desplazándose.
- Respeta la diferencia de `tilespacing` entre fondos `normal` y `anim`.
- Añade raster trapezoidal para parallax clásico con `width` y escala vertical
  derivada de `yscalestart`.
- Sustituye el incremento por mensaje de 16 ms por un acumulador temporal de
  60 game-ticks por segundo.
- Extrae matemática de render y timeline AIR a módulos C89 comprobables.
- Añade pruebas deterministas de coordenadas, velocidad, tiling, flips,
  `Loopstart` y hold infinito.

## v0.2.1 - 2026-08-01

- Log persistente `screenpack_tester.log` desde el arranque.
- Registro de línea de comandos, CWD, normalización y errores Win32/CRT.
- Registro de cada ruta candidata usada por el fallback MUGEN.
- Registro detallado de apertura y decode SFF/SND.
- Diálogo del Explorador automático al abrir el EXE sin argumentos.
- Si una ruta falla, muestra el motivo y ofrece elegir `system.def` a mano.
- Detección y recuperación documentada de rutas ambiguas `D:carpeta`.
- Tecla `L` y `open_log.bat` para abrir el diagnóstico.

## v0.2.0 - 2026-08-01

- Validación sobre Default, MUGEN1, Big y KFM reales.
- Compatibilidad con terminador SND en EOF y WAV impar sin padding final.
- Fallback de recursos motif → data → raíz → font.
- SFF específico por `TitleBGdef`.
- Renderer de título endurecido y parser de Infobox corregido.

## v0.1.0 - 2026-08-01

- Host Win32/GDI y audio waveOut.
- Apertura por diálogo, línea de comandos y drag-and-drop.
- Preview de TitleBG y menú de título.
- Navegadores SFF y SND.
- PCM, Microsoft ADPCM e IMA ADPCM.
- Auditoría semántica MenuMotif89.
