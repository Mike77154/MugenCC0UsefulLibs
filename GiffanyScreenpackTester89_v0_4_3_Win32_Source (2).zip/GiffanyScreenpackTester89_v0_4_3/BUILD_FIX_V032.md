# Corrección de compilación v0.3.2

## Error observado

```text
ar: build\engine_obj\*.o: Invalid argument
```

En `cmd.exe`, GNU `ar` recibe el comodín literalmente; no lo expande como lo haría una shell POSIX.

## Corrección

Los scripts ahora:

1. Compilan cada fuente a un objeto numerado: `build/engine_obj/N_nombre.o`.
2. Escriben cada ruta en `build/engine_objects.rsp`.
3. Ejecutan `ar rcs build/libgst89_engine_win32.a @build/engine_objects.rsp`.
4. Si el `ar` instalado no acepta response files, reintentan agregando cada objeto por separado.

La numeración también evita colisiones futuras si dos bibliotecas vendorizadas contienen archivos `.c` con el mismo nombre base.

## Advertencias

- Se eliminó el helper `gst89_font_alignment` que ya no se utilizaba.
- El buffer del diálogo de error se amplió a 2048 bytes.
- `-Wmisleading-indentation` se silencia únicamente al compilar el decoder OTF vendorizado; el resto del engine conserva `-Wall -Wextra`.
