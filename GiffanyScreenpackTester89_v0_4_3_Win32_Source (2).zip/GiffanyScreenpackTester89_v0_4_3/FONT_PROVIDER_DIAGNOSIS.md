# Diagnóstico del font provider — v0.2.7

## Problema anterior

La v0.2.5 medía la palabra con una fuente Win32 provisional. El cursor encajaba
con lo que el tester dibujaba, pero no con la tipografía real del screenpack.
Además, la primera integración trató `fontN` como una matriz base cero:
`font4` podía terminar consultando el slot 3.

## Corrección de autoridad

MenuMotif89 conserva el número literal:

```text
font4 en [Files]             -> files.fonts[4]
menu.item.active.font = 4... -> FontSpec.slot = 4
provider                     -> font_slots[4]
```

No se resta uno.

## MUGEN FNT clásico

```text
ElecbyteFnt
├── header
├── PCX embebido
└── texto [Def]/[Map]
```

El provider extrae el PCX, decodifica índices/paleta y mide cada carácter con
su mapa de ancho/offset. El banco pedido por `font = slot,bank,align` remapea la
paleta antes de dibujar.

## MUGEN FNT v2 bitmap

```text
arcade.def
  Type    = bitmap
  Size    = 36,34
  Spacing = -12,4
  Offset  = -2,3
  File    = arcade.sff
        ↓
SFF v2: grupo 0, item = código ASCII
paleta: grupo 0, item = bank solicitado
```

El ancho del texto se calcula cargando sólo los glifos usados y almacenándolos
en una caché estática de índices. La caja, el halo y el hit-test consumen esa
misma métrica.

## MUGEN FNT v2 TrueType

El archivo `.def` conserva nombre, altura, spacing, offset y blend. Se busca el
archivo indicado junto al DEF, mediante el fallback MUGEN y finalmente en
`%WINDIR%\Fonts`. Si el archivo no está disponible, se crea la fuente por el
nombre declarado.

## FontCore externo

```text
TTF / OTF / TTC ───────────────┐
WOFF1 ──> SFNT ────────────────┤
WOFF2 ──> Brotli ──> SFNT ─────┤──> AddFontMemResourceEx ──> GDI
EOT ──> scan o eotdec ──> SFNT ┘
```

Las fuentes se registran de forma privada para el proceso. No se instalan en el
sistema ni se copian a la carpeta Fonts.

## Validación determinista

```text
PASS jg.fnt               56x8    píxeles=1029
PASS arcade.def/SFF      304x34   píxeles=21963
PASS TTF
PASS OTF/CFF
PASS WOFF1 -> SFNT
PASS EOT -> SFNT
PASS GMYY metadata
PASS WOFF2 -> SFNT (build Brotli)
```

Las fuentes usadas para la matriz externa fueron recursos locales de prueba y
no se incluyen en el release; `FONT_FORMAT_MATRIX_PASS.txt` conserva hashes y
resultados, no los binarios.


## Corrección v0.2.7: FNT v1 fixed y bancos inversos

El hecho de que un slot aparezca como `ok=1` sólo prueba apertura y decode.
La regresión de v0.2.7 también valida identidad de glifos y color bank. El
`jg.fnt` clásico reveló dos errores: offsets fixed colapsados a cero y
bancos calculados desde el inicio de la paleta. Ambos quedaron corregidos en
el codec/proveedor, no mediante sustitución de fuente.
