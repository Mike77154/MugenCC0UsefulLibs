# Coin, credit, attract y operation policy — v0.4.2

La descripción normativa está en `CONSOLE_CABINET_CREDIT_POLICY.md`.

## Capas

```text
credit_system → coinsystem89 → creditpolicy89 → gst89_engine
attract_mode  → attractflow89 ─────────────────┘
```

- `credit_system`: saldo elemental aportado.
- `coinsystem89`: monedas, gastos START/CHALLENGER/CONTINUE y FREE PLAY.
- `creditpolicy89`: decide cuándo cobrar según Console/Cabinet.
- `attractflow89`: ATTRACT sólo cuando Cabinet no tiene sesión activa.

La política no duplica el saldo ni conoce Win32.
