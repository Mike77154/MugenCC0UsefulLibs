# Arquitectura vendorizada v0.4.2

```text
src/main_win32.c
    ↓
gst89_win32_host
    ↓
gst89_engine (fachada agnóstica)
    ├── mainplayer89
    ├── title_select_vs_flow89
    ├── optionsflow89
    ├── selectflow89 / selectdef89
    ├── newchallenger89
    ├── coinsystem89 → credit_system
    ├── creditpolicy89 (Console/Cabinet/sesión)
    ├── attractflow89 → attract_mode
    ├── menumotif89
    ├── monika_fontcore
    ├── sfflib
    └── sndmuglib
```

El main no conoce créditos, attract, SELECT ni VS. Sólo arranca el host. El host
traduce teclas a comandos y el engine orquesta módulos agnósticos.

Los backends aportados `credit_system` y `attract_mode` permanecen aislados;
las reglas nuevas viven en adaptadores propios para que puedan reemplazarse sin
tocar el flujo de pantalla.

`creditpolicy89` decide cobros sin poseer el saldo y preserva la sesión MAIN de Cabinet hasta que el runner reporte una derrota.
