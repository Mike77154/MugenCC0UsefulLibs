# Log de diagnóstico v0.2.7

Cada ejecución intenta crear:

```text
bin\screenpack_tester.log
```

Si la carpeta del ejecutable no es escribible, usa el directorio temporal de
Windows. La ventana de error muestra la ubicación exacta.

El archivo se reinicia en cada ejecución y se vacía con `fflush` después de
cada línea para conservar el diagnóstico incluso si la carga se interrumpe.

## Qué registra

- Ruta del ejecutable y directorio actual.
- Línea de comandos completa y argumento extraído.
- Normalización con `GetFullPathNameA`.
- Detección de rutas ambiguas como `D:carpeta`.
- Resultado de `GetFileAttributesA` y errores Win32.
- Apertura y parseo de `system.def`, con `errno` si falla `fopen`.
- Cada candidato probado para SFF, SND y fuentes:
  - carpeta del motif;
  - `data/`;
  - raíz de MUGEN;
  - `font/`.
- Resultado interno de los decoders SFF y SND.
- Resumen de referencias y recursos faltantes.
- Resultado o cancelación del diálogo del Explorador.

## Cómo usarlo

1. Haz doble clic en `GiffanyScreenpackTester89.exe`.
2. Selecciona `system.def` en el diálogo y haz doble clic.
3. Si falla, pulsa **L** dentro del tester o ejecuta `open_log.bat`.
4. Comparte `screenpack_tester.log` completo.


## Líneas PERF

Cada 120 frames se añade una muestra como:

```text
[PERF] 120-frame sample | avg_ms=7 avg_draws=15 avg_pixels=900000 cache_hits=1797 cache_misses=3 fallback=0
```

Al recargar o cerrar se registra el total de aciertos, fallos, fallback y bytes
usados por la caché RGBA.
