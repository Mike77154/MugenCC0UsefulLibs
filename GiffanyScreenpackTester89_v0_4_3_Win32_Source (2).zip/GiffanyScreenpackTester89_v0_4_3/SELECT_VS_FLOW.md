# Flujo TITLE → SELECT → VS → TITLE v0.3.3

## Entrada simétrica

```text
TITLE (sin dueño)
  ├─ P1 START → P1 MAIN
  └─ P2 START → P2 MAIN
```

El jugador MAIN conserva su lado real. P2 MAIN no se remapea internamente como
P1.

## Modos de un jugador

ARCADE, TEAM ARCADE, TEAM CO-OP, SURVIVAL y SURVIVAL CO-OP:

```text
MAIN elige su celda
  → engine escoge el siguiente roster entry como rival placeholder
  → rival ocupa el lado contrario
  → VS
```

Ejemplo P2 ARCADE:

```text
P2 elige kfm720
P1 recibe kfm como CPU placeholder
VS muestra P1 a la izquierda y P2 [MAIN] a la derecha
```

## Modos que requieren ambos lados

VERSUS, TEAM VS, TRAINING y WATCH:

```text
MAIN elige primero
  → active_player = secondary_player
  → secundario elige
  → VS
```

Si P2 inició TEAM VS, el orden es P2 y luego P1.

## Cancelación

- Mientras selecciona el secundario, cancelar desconfirma MAIN y devuelve el
  control al cursor MAIN.
- Cancelar nuevamente vuelve a TITLE y libera autoridad.
- En VS sólo MAIN puede saltar o cancelar.
- El timeout de `[VS Screen] time` también vuelve a TITLE y libera autoridad.

## Placeholders

La pantalla usa el roster real de `select.def`, pero todavía no abre SFF de
personajes. Las celdas y retratos continúan como placeholders para probar el
flow antes de integrar `9000,0`/`9000,1`.
