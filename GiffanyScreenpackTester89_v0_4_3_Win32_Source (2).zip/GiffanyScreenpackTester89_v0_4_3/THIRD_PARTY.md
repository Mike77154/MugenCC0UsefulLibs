# Componentes vendorizados

- `vendor/gst89_engine`: integración propia CC0 que une core, host Win32,
  renderer, audio y diagnóstico detrás de una API agnóstica.
- `vendor/selectdef89`, `vendor/selectflow89`, `vendor/mainplayer89`,
  `vendor/title_select_vs_flow89`, `vendor/optionsflow89` y
  `vendor/newchallenger89`: módulos propios CC0 de flujo y selección.
- `vendor/scanemu_c89`: fork integer-only del paquete MIT aportado por el
  usuario. Conserva la API de captura simbólica, reemplazando valores de eje
  por Q16.16.
- `vendor/controlconfig89`: integración propia CC0 para perfiles P1/P2 e
  importación/exportación INI.
- `vendor/coinsystem89`, `vendor/attractflow89` y `vendor/m2d_common89`:
  adaptadores nuevos CC0, C89 y sin heap.
- `vendor/credit_system` y `vendor/attract_mode`: código aportado por el
  usuario. Los ZIP recibidos no incluían aviso de licencia; se conservan
  separados y no se les atribuye una licencia nueva. Verificar derechos antes
  de redistribuirlos fuera del proyecto.
- `vendor/menumotif89`: conserva su licencia CC0.
- `vendor/sndmuglib`: conserva su licencia MIT.
- `vendor/sfflib`: conserva el paquete recibido; verificar licencia de origen.
- `vendor/matroshkanestanidize_submenus89`: paquete aportado y adaptadores
  locales C89 de capacidad fija.
- `vendor/monika_fontcore`: se conserva completo con sus avisos y licencias.

El código nuevo del engine, adaptadores, scripts, documentación y pruebas se
entrega bajo CC0 1.0 Universal, sin alterar las licencias de terceros.
