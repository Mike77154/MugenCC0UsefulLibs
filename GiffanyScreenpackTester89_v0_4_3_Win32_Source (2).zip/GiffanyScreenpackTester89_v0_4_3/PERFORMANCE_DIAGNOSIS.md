# Diagnóstico de rendimiento — v0.2.2 → v0.2.3

## Síntoma

El motif clásico Default y KFM se movían con fluidez, pero `data/mugen1/system.def`
y `data/big/system.def` tenían una caída severa de velocidad aun usando sprites y
posiciones correctos.

## Causa real

MUGEN1 trabaja en `localcoord = 1280,720` y su título usa cinco capas tiled con
sprites de `800 × 320`. Dos capas son franjas `add1` recortadas mediante ventanas
de sólo tres píxeles.

El renderer v0.2.2 cometía tres gastos multiplicativos:

1. `gst89_rm_tile_range()` devolvía un rango deliberadamente amplio de
   `-(span/step+4)` a `+(span/step+4)` para tiles infinitos. En MUGEN1 eso era
   11 posiciones X por 13 posiciones Y: 143 copias por capa.
2. Cada llamada a `gst89_draw_sprite()` volvía a decodificar el sprite SFF a
   RGBA, incluso cuando la siguiente copia era exactamente el mismo sprite.
3. El clip se comprobaba dentro del bucle. Una ventana de tres píxeles seguía
   recorriendo las 320 filas y descartando 317 después de entrar al raster.

Cinco capas tiled daban 715 llamadas, más el logo: 716 llamadas de sprite por
frame.

## Cambios

### Culling exacto

`gst89_rm_visible_tile_range()` resuelve sólo los índices `n` cuyo rectángulo
puede cruzar el viewport o la ventana local. En el corpus MUGEN1:

- X: 2 tiles visibles.
- Top: 2 filas.
- Middle: 1 fila.
- Bottom: 2 filas.
- Cada franja add1: 1 fila.
- Logo: 1 llamada.

Total: 15 llamadas por frame.

### Caché SFF estática

Una arena estática de 32 MiB guarda hasta 32 sprites RGBA decodificados. La
clave es `(banco SFF, índice)`. No usa `malloc`, `realloc`, `free` ni heap.

El título MUGEN1 sólo necesita tres sprites únicos: `100,0`, `100,1` y `0,0`.
Después de tres misses iniciales, el resto son hits.

### Clip previo

El renderer calcula `dx0/dx1/dy0/dy1` antes de entrar al raster. Las franjas de
tres píxeles sólo recorren esos tres píxeles verticales.

### Menos divisiones

Se construye un mapa X de hasta 8192 columnas una vez por draw call. Cada fila
reutiliza ese mapa en lugar de dividir por cada píxel. Los píxeles opacos con
blend normal se copian directamente.

## Telemetría

Cada 120 frames, el log escribe una línea `PERF` con:

- milisegundos promedio por frame;
- draw calls promedio;
- píxeles recorridos promedio;
- hits, misses y fallback de caché.

Al recargar o cerrar se registra el consumo final de la arena de caché.

## Validación

`validation/MUGEN1_PERF_PLAN_PASS.txt` confirma de forma determinista:

```text
Old conservative draw calls=716
New clip-aware draw calls=15
Unique title sprites cached=3
MUGEN1 PERFORMANCE PLAN PASS
```

La validación del corpus real sigue pasando para Default, MUGEN1, Big y KFM.
