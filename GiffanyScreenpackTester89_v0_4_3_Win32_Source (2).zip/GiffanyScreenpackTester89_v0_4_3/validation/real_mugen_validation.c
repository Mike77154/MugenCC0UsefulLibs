#include <stdio.h>
#include <string.h>
#include "gst89_app.h"
#include "gst89_font_provider.h"

#define TEST_RGBA_CAP (2048u * 2048u * 4u)
#define TEST_WORK_CAP (32u * 1024u * 1024u)
#define TEST_WAV_CAP (8u * 1024u * 1024u)
#define TEST_PCM_CAP (8u * 1024u * 1024u)

static GST89_App app;
static unsigned char rgba[TEST_RGBA_CAP];
static unsigned char work[TEST_WORK_CAP];
static unsigned char wav_blob[TEST_WAV_CAP];
static unsigned char wav_data[TEST_WAV_CAP];
static wavc89_s16 pcm[TEST_PCM_CAP];

static int validate_sff(const char *label, GST89_SffBank *bank)
{
    unsigned long i;
    unsigned long count;
    unsigned long decoded;
    sff_u16 w;
    sff_u16 h;
    int rc;
    if (!bank || !bank->loaded) {
        printf("%s NOT LOADED\n", label);
        return 1;
    }
    count = (unsigned long)sff_sprite_count(&bank->file);
    decoded = 0ul;
    for (i = 0ul; i < count; ++i) {
        w = 0u;
        h = 0u;
        rc = sff_decode_sprite_rgba_into(&bank->file, (sff_u32)i,
                                         rgba, (sff_u32)sizeof(rgba),
                                         &w, &h, work,
                                         (sff_u32)sizeof(work));
        if (rc != SFF_OK) {
            printf("%s sprite[%lu] FAIL rc=%d\n", label, i, rc);
            return 2;
        }
        ++decoded;
    }
    printf("%s PASS decoded=%lu/%lu path=%s\n", label, decoded, count,
           bank->path);
    return 0;
}

static int validate_snd(void)
{
    unsigned long i;
    int rc;
    wavc89_info info;
    wavc89_io wav_io;
    wavc89_mem_reader wav_mem;
    wavc89_reader wav_reader;
    sndmug_u32 payload_size;
    wavc89_u32 read_size;
    wavc89_u32 sample_count;
    if (!app.snd.loaded) return 1;
    for (i = 0ul; i < (unsigned long)app.snd.reader.entry_count; ++i) {
        memset(&info, 0, sizeof(info));
        rc = sndmug_reader_get_wav_info(&app.snd.reader, (sndmug_u32)i,
                                        &info);
        if (rc != SNDMUG_OK) {
            printf("SND info[%lu] FAIL rc=%d\n", i, rc);
            return 2;
        }
        payload_size = 0u;
        rc = sndmug_reader_read_payload(&app.snd.reader, (sndmug_u32)i,
                                        wav_blob, (sndmug_u32)sizeof(wav_blob),
                                        &payload_size);
        if (rc != SNDMUG_OK) return 3;
        rc = wavc89_io_mem_reader_init(&wav_io, &wav_mem, wav_blob,
                                       payload_size);
        if (rc != WAVC89_OK) return 4;
        rc = wavc89_reader_open(&wav_reader, &wav_io, 0u, payload_size);
        if (rc != WAVC89_OK) return 5;
        read_size = 0u;
        rc = wavc89_reader_read_data(&wav_reader, 0u, wav_data,
                                     wav_reader.info.data_size, &read_size);
        if (rc != WAVC89_OK) return 6;
        sample_count = 0u;
        rc = wavc89_decode_to_s16(&wav_reader.info, wav_data, read_size,
                                  pcm, (wavc89_u32)(sizeof(pcm) / sizeof(pcm[0])),
                                  &sample_count);
        if (rc != WAVC89_OK || sample_count == 0u) return 7;
    }
    printf("SND PASS decoded=%lu/%lu path=%s eof_terminator=%s\n",
           (unsigned long)app.snd.reader.entry_count,
           (unsigned long)app.snd.reader.entry_count, app.snd.path,
           app.snd.reader.entry_count > 0u &&
           app.snd.reader.entries[app.snd.reader.entry_count - 1u].next_offset ==
           app.snd.reader.file_size ? "yes" : "no");
    return 0;
}

static int ci_starts(const char *text, const char *prefix)
{
    unsigned char a;
    unsigned char b;
    if (!text || !prefix) return 0;
    while (*prefix) {
        if (!*text) return 0;
        a = (unsigned char)*text++;
        b = (unsigned char)*prefix++;
        if (a >= 'A' && a <= 'Z') a = (unsigned char)(a + 32);
        if (b >= 'A' && b <= 'Z') b = (unsigned char)(b + 32);
        if (a != b) return 0;
    }
    return 1;
}

static int validate_title_references(void)
{
    const GST89_SffBank *bank;
    const MSD89_Property *property;
    const MA89_Action *action;
    const MA89_Frame *frame;
    sff_u32 index;
    int i;
    int j;
    int group;
    int item;
    int action_no;
    int checked;
    int failures;
    int already;
    bank = gst89_title_sff_bank(&app);
    if (!bank) return 1;
    checked = 0;
    failures = 0;
    for (i = 0; i < app.document.stats.pair_count; ++i) {
        property = &app.document.properties[i];
        if (!ci_starts(property->section, "TitleBG ")) continue;
        already = 0;
        for (j = 0; j < i; ++j) {
            if (strcmp(app.document.properties[j].section,
                       property->section) == 0) {
                already = 1;
                break;
            }
        }
        if (already) continue;
        property = gst89_property(&app.document, property->section,
                                  "spriteno");
        if (property && gst89_parse_pair(property->value, &group, &item)) {
            ++checked;
            if (sff_find_sprite(&bank->file, (sff_u16)group,
                                (sff_u16)item, &index) != SFF_OK) {
                printf("TITLE REF FAIL section=%s sprite=%d,%d bank=%s\n",
                       property->section, group, item, bank->path);
                ++failures;
            }
            continue;
        }
        property = gst89_property(&app.document,
                                  app.document.properties[i].section,
                                  "actionno");
        if (!property || sscanf(property->value, " %d", &action_no) != 1)
            continue;
        action = 0;
        for (j = 0; j < app.document.actions.action_count; ++j) {
            if (app.document.actions.actions[j].number == action_no) {
                action = &app.document.actions.actions[j];
                break;
            }
        }
        if (!action) {
            printf("TITLE ACTION FAIL section=%s action=%d missing\n",
                   app.document.properties[i].section, action_no);
            ++failures;
            continue;
        }
        for (j = 0; j < action->count; ++j) {
            frame = &app.document.actions.frames[action->first + j];
            ++checked;
            if (sff_find_sprite(&bank->file, (sff_u16)frame->group,
                                (sff_u16)frame->index, &index) != SFF_OK) {
                printf("TITLE ACTION REF FAIL action=%d frame=%d sprite=%d,%d\n",
                       action_no, j, frame->group, frame->index);
                ++failures;
            }
        }
    }
    printf("TITLE REFERENCES %s checked=%d bank=%s override=%s\n",
           failures == 0 ? "PASS" : "FAIL", checked, bank->path,
           app.title_sff.loaded ? "yes" : "no");
    return failures == 0 ? 0 : 2;
}

static int validate_sound_references(void)
{
    const MSD89_SoundBinding *binding;
    sndmug_u32 index;
    int i;
    int checked;
    int skipped_common;
    int failures;
    if (!app.snd.loaded) return 1;
    checked = 0;
    skipped_common = 0;
    failures = 0;
    for (i = 0; i < app.document.stats.sound_binding_count; ++i) {
        binding = &app.document.sound_bindings[i];
        if (!binding->in_use || !binding->sound.valid) continue;
        if (binding->sound.use_common) {
            ++skipped_common;
            continue;
        }
        ++checked;
        if (sndmug_reader_find(&app.snd.reader,
                               (sndmug_u32)binding->sound.group,
                               (sndmug_u32)binding->sound.index,
                               &index) != SNDMUG_OK) {
            printf("SOUND REF FAIL section=%s id=%s sound=%d,%d\n",
                   binding->section, binding->id,
                   binding->sound.group, binding->sound.index);
            ++failures;
        }
    }
    printf("SOUND REFERENCES %s checked=%d common_skipped=%d\n",
           failures == 0 ? "PASS" : "FAIL", checked, skipped_common);
    return failures == 0 ? 0 : 2;
}

int main(int argc, char **argv)
{
    const GST89_SffBank *title;
    int rc;
    if (argc < 2) {
        fprintf(stderr, "usage: %s system.def\n", argv[0]);
        return 64;
    }
    gst89_app_init(&app);
    if (!gst89_load_screenpack(&app, argv[1])) {
        printf("LOAD FAIL %s\n", app.status);
        return 1;
    }
    printf("NAME=%s PROFILE=%s localcoord=%d,%d\n",
           app.document.info.name,
           msd89_profile_name(app.document.info.profile),
           app.document.info.localcoord_x, app.document.info.localcoord_y);
    printf("PROPERTIES total=%d mapped=%d retained=%d actions=%d frames=%d\n",
           app.document.stats.pair_count, app.document.stats.mapped_count,
           app.document.stats.retained_only_count,
           app.document.actions.action_count,
           app.document.actions.frame_count);
    printf("LAYOUT base=%s data=%s root=%s missing=%d\n",
           app.base_dir, app.data_dir, app.mugen_root,
           app.missing_resource_count);
    printf("FONTS loaded=%d requested=%d max_slot_plus_one=%d\n",
           gst89_fonts_loaded_count(), gst89_fonts_requested_count(),
           app.resolved_font_count);
    if (gst89_fonts_loaded_count() != gst89_fonts_requested_count()) {
        printf("FONT PROVIDER FAIL loaded=%d requested=%d\n",
               gst89_fonts_loaded_count(), gst89_fonts_requested_count());
        return 4;
    }
    printf("RESOURCE REPORT\n%s", app.resource_report);
    rc = validate_sff("SYSTEM SFF", &app.sff);
    if (rc != 0) return 10 + rc;
    title = gst89_title_sff_bank(&app);
    if (app.title_sff.loaded) {
        rc = validate_sff("TITLE OVERRIDE SFF", &app.title_sff);
        if (rc != 0) return 20 + rc;
    } else if (!title) {
        puts("TITLE SFF FAIL no bank");
        return 23;
    }
    rc = validate_snd();
    if (rc != 0) return 30 + rc;
    rc = validate_title_references();
    if (rc != 0) return 40 + rc;
    rc = validate_sound_references();
    if (rc != 0) return 50 + rc;
    printf("AUDIT missing=%d detail=%s\n", app.audit.missing_count,
           app.audit.missing);
    gst89_app_close(&app);
    puts("REAL MUGEN CORPUS PASS");
    return 0;
}
