#include <stdio.h>
#include <string.h>
#include "gst89_engine.h"
#include "gst89_engine_internal.h"

static int redraw_count;
static int stop_count;
static int cache_count;

static int cb_pair(void *user, int group, int index)
{
    (void)user; (void)group; (void)index;
    return 1;
}

static int cb_index(void *user, unsigned long index)
{
    (void)user; (void)index;
    return 1;
}

static void cb_stop(void *user)
{
    (void)user;
    ++stop_count;
}

static const char *cb_error(void *user)
{
    (void)user;
    return "test audio error";
}

static void cb_cache(void *user)
{
    (void)user;
    ++cache_count;
}

static void cb_redraw(void *user)
{
    (void)user;
    ++redraw_count;
}

static int check_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %s got=%d expected=%d\n", name, got, expected);
        return 1;
    }
    printf("PASS %s value=%d\n", name, got);
    return 0;
}

int main(void)
{
    GST89_EngineCallbacks callbacks;
    GST89_Engine *engine;
    GST89_App *app;
    int failures;
    failures = 0;
    redraw_count = 0;
    stop_count = 0;
    cache_count = 0;
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.play_sound_pair = cb_pair;
    callbacks.play_sound_index = cb_index;
    callbacks.stop_audio = cb_stop;
    callbacks.audio_last_error = cb_error;
    callbacks.invalidate_render_cache = cb_cache;
    callbacks.request_redraw = cb_redraw;
    engine = gst89_engine_default();
    gst89_engine_init(engine, &callbacks, 0);
    app = gst89_engine_app_mutable(engine);
    failures += check_int("default view", gst89_engine_view(engine),
                          GST89_ENGINE_VIEW_TITLE);
    gst89_engine_advance_ms(engine, 250ul);
    gst89_engine_advance_ms(engine, 250ul);
    gst89_engine_advance_ms(engine, 250ul);
    gst89_engine_advance_ms(engine, 250ul);
    failures += check_int("60 Hz tick", (int)gst89_engine_tick(engine), 60);
    failures += check_int("tick requests redraw", redraw_count, 4);
    (void)gst89_engine_command(engine, GST89_ENGINE_CMD_VIEW_SPRITES);
    failures += check_int("view command", gst89_engine_view(engine),
                          GST89_ENGINE_VIEW_SPRITES);
    (void)gst89_engine_command(engine, GST89_ENGINE_CMD_TOGGLE_HELP);
    failures += check_int("help toggle", app->show_help, 1);
    (void)gst89_engine_command(engine, GST89_ENGINE_CMD_CANCEL);
    failures += check_int("cancel stops audio", stop_count, 1);
    gst89_engine_shutdown(engine);
    failures += check_int("shutdown stops audio", stop_count, 2);
    failures += check_int("no unexpected cache reset", cache_count, 0);
    if (failures != 0) return 1;
    puts("ENGINE FACADE VALIDATION PASS");
    return 0;
}
