#include <stdio.h>
#include <string.h>
#include "gst89_engine.h"

#define CHECK(x, msg) do { if (!(x)) { \
    printf("FAIL %s\n", msg); return 1; } \
    else printf("PASS %s\n", msg); } while (0)

static int cb_pair(void *user, int group, int index)
{ (void)user; (void)group; (void)index; return 1; }
static int cb_index(void *user, unsigned long index)
{ (void)user; (void)index; return 1; }
static void cb_void(void *user) { (void)user; }
static const char *cb_error(void *user)
{ (void)user; return "validation audio"; }

static void activate_title(GST89_Engine *engine, int index)
{
    (void)gst89_engine_select_title(engine, index, 0);
    (void)gst89_engine_select_title(engine, index, 1);
}

int main(int argc, char **argv)
{
    GST89_EngineCallbacks callbacks;
    GST89_Engine *engine;
    const char *path;

    path = argc > 1 ? argv[1] : "system.def";
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.play_sound_pair = cb_pair;
    callbacks.play_sound_index = cb_index;
    callbacks.stop_audio = cb_void;
    callbacks.audio_last_error = cb_error;
    callbacks.invalidate_render_cache = cb_void;
    callbacks.request_redraw = cb_void;
    engine = gst89_engine_default();
    gst89_engine_init(engine, &callbacks, 0);

    CHECK(gst89_engine_load(engine, path), "load real screenpack");
    CHECK(gst89_engine_operation_mode(engine) ==
          GST89_ENGINE_OPERATION_CONSOLE,
          "console mode is default");

    activate_title(engine, 0);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "console arcade blocked without credit");

    activate_title(engine, 1);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "console versus enters without credit");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "console versus consumed no credit");
    CHECK(gst89_engine_insert_coin(engine, 2, 1u),
          "non-arcade invader coin inserted");
    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_ACTIVATE);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "new challenger rejected outside arcade modes");
    CHECK(gst89_engine_credit_count(engine) == 1u,
          "rejected non-arcade invasion keeps credit");
    (void)gst89_engine_player_command(engine, 1,
        GST89_ENGINE_CMD_CANCEL);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "console select cancels to title");

    activate_title(engine, 0);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "console arcade enters after payment");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "console arcade charged one credit");

    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_ACTIVATE);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "challenger rejected without own credit");
    CHECK(gst89_engine_insert_coin(engine, 2, 1u),
          "challenger coin inserted");
    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_ACTIVATE);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_CHALLENGER,
          "arcade challenger paid from select onward");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "challenger consumed one credit");

    CHECK(gst89_engine_set_operation_mode(engine,
          GST89_ENGINE_OPERATION_CABINET),
          "switch to cabinet mode");
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "mode switch returns title");
    activate_title(engine, 1);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "cabinet first start blocked without credit");
    CHECK(gst89_engine_insert_coin(engine, 1, 1u),
          "cabinet coin inserted");
    activate_title(engine, 1);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "cabinet paid start enters versus");
    CHECK(gst89_engine_cabinet_session_active(engine),
          "cabinet session active");
    CHECK(gst89_engine_cabinet_session_player(engine) == 1,
          "cabinet session owned by P1");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "cabinet first start consumed one credit");

    (void)gst89_engine_player_command(engine, 1,
        GST89_ENGINE_CMD_CANCEL);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "cabinet select cancels to title");
    CHECK(gst89_engine_main_player(engine) == 1,
          "cabinet main preserved on title");
    CHECK(gst89_engine_cabinet_session_active(engine),
          "cabinet session preserved on title");
    activate_title(engine, 0);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "cabinet arcade reuses paid session");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "cabinet reused session without another charge");
    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_ACTIVATE);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_SELECT,
          "cabinet invader blocked without credit");
    CHECK(gst89_engine_insert_coin(engine, 2, 1u),
          "cabinet invader inserts separate credit");
    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_ACTIVATE);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_CHALLENGER,
          "cabinet invader pays one credit from select onward");
    CHECK(gst89_engine_credit_count(engine) == 0u,
          "cabinet challenger credit consumed");

    CHECK(gst89_engine_report_main_loss(engine, 1),
          "fight runner reports main loss");
    CHECK(!gst89_engine_cabinet_session_active(engine),
          "loss closes cabinet session");
    CHECK(gst89_engine_main_player(engine) == 0,
          "loss releases main authority");
    activate_title(engine, 0);
    CHECK(gst89_engine_view(engine) == GST89_ENGINE_VIEW_TITLE,
          "after loss next start needs credit");

    gst89_engine_shutdown(engine);
    puts("ENGINE CONSOLE/CABINET CREDIT POLICY VALIDATION PASS");
    return 0;
}
