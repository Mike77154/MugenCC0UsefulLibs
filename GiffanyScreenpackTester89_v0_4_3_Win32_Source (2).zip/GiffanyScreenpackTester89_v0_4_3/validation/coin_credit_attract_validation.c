#include <stdio.h>
#include <string.h>
#include "coinsystem89.h"
#include "attractflow89.h"

#define CHECK(x, msg) do { if (!(x)) { printf("FAIL %s\n", msg); return 1; } } while (0)

int main(void)
{
    CoinSystem89State coin;
    CoinSystem89Config config;
    AttractFlow89State attract;
    char label[32];
    int event;

    coinsystem89_init(&coin);
    CHECK(coinsystem89_count(&coin) == 0u, "initial credits");
    CHECK(!coinsystem89_can_spend(&coin, COINSYSTEM89_PURPOSE_START),
          "start blocked without credit");
    CHECK(coinsystem89_spend(&coin, 2, COINSYSTEM89_PURPOSE_START) ==
          COINSYSTEM89_EVENT_SPEND_REJECTED_NO_CREDIT,
          "rejected spend event");

    CHECK(coinsystem89_insert(&coin, 2, 1u) ==
          COINSYSTEM89_EVENT_COIN_ACCEPTED, "P2 coin accepted");
    CHECK(coinsystem89_count(&coin) == 1u, "credit increment");
    CHECK(coinsystem89_last_coin_player(&coin) == 2, "P2 attribution");
    CHECK(coinsystem89_spend(&coin, 2, COINSYSTEM89_PURPOSE_START) ==
          COINSYSTEM89_EVENT_SPEND_ACCEPTED, "P2 start accepted");
    CHECK(coinsystem89_count(&coin) == 0u, "start cost consumed");

    CHECK(coinsystem89_insert(&coin, 1, 2u) ==
          COINSYSTEM89_EVENT_COIN_ACCEPTED, "two coins accepted");
    CHECK(coinsystem89_spend(&coin, 2, COINSYSTEM89_PURPOSE_CHALLENGER) ==
          COINSYSTEM89_EVENT_SPEND_ACCEPTED, "challenger accepted");
    CHECK(coinsystem89_count(&coin) == 1u, "challenger cost consumed");
    CHECK(coinsystem89_last_spend_player(&coin) == 2,
          "challenger player attribution");

    config = coin.config;
    config.max_credits = 3u;
    coinsystem89_configure(&coin, &config);
    CHECK(coinsystem89_insert(&coin, 1, 99u) ==
          COINSYSTEM89_EVENT_COIN_ACCEPTED, "saturating add");
    CHECK(coinsystem89_count(&coin) == 3u, "max credits saturation");
    CHECK(coinsystem89_insert(&coin, 1, 1u) ==
          COINSYSTEM89_EVENT_COIN_REJECTED_MAX, "max rejection");

    CHECK(coinsystem89_set_free_play(&coin, 1) ==
          COINSYSTEM89_EVENT_FREE_PLAY_ENABLED, "free play enabled");
    CHECK(coinsystem89_spend(&coin, 1, COINSYSTEM89_PURPOSE_START) ==
          COINSYSTEM89_EVENT_SPEND_ACCEPTED, "free start accepted");
    CHECK(coinsystem89_count(&coin) == 3u, "free play preserves credits");
    coinsystem89_label(&coin, label, (unsigned int)sizeof(label));
    CHECK(strcmp(label, "FREE PLAY") == 0, "free play label");

    attractflow89_init(&attract);
    attractflow89_configure(&attract, 5ul);
    event = attractflow89_advance(&attract, 4ul, 1);
    CHECK(event == ATTRACTFLOW89_EVENT_NONE, "attract waits");
    event = attractflow89_advance(&attract, 1ul, 1);
    CHECK(event == ATTRACTFLOW89_EVENT_STARTED, "attract starts");
    CHECK(attractflow89_active(&attract), "attract active");
    event = attractflow89_advance(&attract, 91ul, 1);
    CHECK(event == ATTRACTFLOW89_EVENT_PAGE_CHANGED, "attract page changes");
    CHECK(attractflow89_observe_input(&attract) ==
          ATTRACTFLOW89_EVENT_STOPPED, "input stops attract");
    CHECK(!attractflow89_active(&attract), "attract inactive");

    printf("COIN CREDIT ATTRACT VALIDATION PASS\n");
    return 0;
}
