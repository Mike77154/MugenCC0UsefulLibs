#include <stdio.h>
#include "creditpolicy89.h"

#define CHECK(x, msg) do { if (!(x)) { \
    printf("FAIL %s\n", msg); return 1; } \
    else printf("PASS %s\n", msg); } while (0)

#define MODE_ARCADE 0
#define MODE_VERSUS 1
#define MODE_TEAM_ARCADE 2

int main(void)
{
    CreditPolicy89State state;
    CreditPolicy89Config config;
    int event;

    creditpolicy89_init(&state);
    config = state.config;
    config.operation_mode = CREDITPOLICY89_OPERATION_CONSOLE;
    config.arcade_modes = CREDITPOLICY89_MODE_BIT(MODE_ARCADE) |
                          CREDITPOLICY89_MODE_BIT(MODE_TEAM_ARCADE);
    creditpolicy89_configure(&state, &config);

    CHECK(creditpolicy89_main_start_requires_credit(
              &state, MODE_ARCADE, 1),
          "console arcade charges main");
    CHECK(creditpolicy89_main_start_requires_credit(
              &state, MODE_TEAM_ARCADE, 2),
          "console team arcade charges main");
    CHECK(!creditpolicy89_main_start_requires_credit(
              &state, MODE_VERSUS, 1),
          "console versus is free");
    CHECK(creditpolicy89_challenger_allowed(
              &state, MODE_ARCADE, 1, 2,
              CREDITPOLICY89_SOURCE_SELECT),
          "arcade challenger allowed from select");
    CHECK(creditpolicy89_challenger_allowed(
              &state, MODE_TEAM_ARCADE, 2, 1,
              CREDITPOLICY89_SOURCE_GAMEPLAY),
          "team arcade challenger allowed from gameplay");
    CHECK(!creditpolicy89_challenger_allowed(
              &state, MODE_VERSUS, 1, 2,
              CREDITPOLICY89_SOURCE_SELECT),
          "versus challenger rejected");

    event = creditpolicy89_set_operation_mode(
        &state, CREDITPOLICY89_OPERATION_CABINET);
    CHECK(event == CREDITPOLICY89_EVENT_OPERATION_CHANGED,
          "cabinet mode selected");
    CHECK(creditpolicy89_main_start_requires_credit(
              &state, MODE_VERSUS, 2),
          "cabinet first start charges any game mode");
    event = creditpolicy89_commit_main_start(
        &state, MODE_VERSUS, 2, 1);
    CHECK(event == CREDITPOLICY89_EVENT_SESSION_STARTED,
          "cabinet paid session starts");
    CHECK(creditpolicy89_cabinet_session_active(&state),
          "cabinet session active");
    CHECK(creditpolicy89_cabinet_session_player(&state) == 2,
          "cabinet session belongs to P2");
    CHECK(!creditpolicy89_main_start_requires_credit(
              &state, MODE_ARCADE, 2),
          "same cabinet main reuses session without charge");
    CHECK(creditpolicy89_main_start_requires_credit(
              &state, MODE_ARCADE, 1),
          "other player cannot reuse cabinet session");
    CHECK(creditpolicy89_preserve_main_on_title(&state, 2),
          "cabinet main preserved on title");

    event = creditpolicy89_report_main_loss(&state, 2);
    CHECK(event == CREDITPOLICY89_EVENT_SESSION_ENDED_BY_LOSS,
          "loss ends cabinet session");
    CHECK(!creditpolicy89_cabinet_session_active(&state),
          "session inactive after loss");
    CHECK(creditpolicy89_main_start_requires_credit(
              &state, MODE_ARCADE, 2),
          "next start costs after loss");

    puts("CREDITPOLICY89 CONSOLE/CABINET VALIDATION PASS");
    return 0;
}
