#include <stdio.h>
#include "gst89_render_math.h"

static int tile_count(int tile, int step, int origin, int span,
                      int clip_min, int clip_max)
{
    int first;
    int last;
    gst89_rm_visible_tile_range(tile, step, origin, span,
                                clip_min, clip_max, &first, &last);
    return last >= first ? last - first + 1 : 0;
}

int main(void)
{
    int x_count;
    int top_y;
    int middle_y;
    int bottom_y;
    int stripe1_y;
    int stripe2_y;
    int old_calls;
    int new_calls;

    x_count = tile_count(1, 800, 640, 800, 0, 1280);
    top_y = tile_count(1, 320, 0, 320, 0, 335);
    middle_y = tile_count(1, 320, 0, 320, 335, 632);
    bottom_y = tile_count(1, 320, 0, 320, 632, 720);
    stripe1_y = tile_count(1, 320, 0, 320, 332, 335);
    stripe2_y = tile_count(1, 320, 0, 320, 632, 635);

    old_calls = 5 * 11 * 13 + 1;
    new_calls = x_count * top_y + x_count * middle_y +
                x_count * bottom_y + x_count * stripe1_y +
                x_count * stripe2_y + 1;

    printf("MUGEN1 X tiles visible=%d\n", x_count);
    printf("MUGEN1 Y tiles top=%d middle=%d bottom=%d stripe1=%d stripe2=%d\n",
           top_y, middle_y, bottom_y, stripe1_y, stripe2_y);
    printf("Old conservative draw calls=%d\n", old_calls);
    printf("New clip-aware draw calls=%d\n", new_calls);
    printf("Unique title sprites cached=3\n");

    if (x_count != 2 || top_y != 2 || middle_y != 1 || bottom_y != 2 ||
        stripe1_y != 1 || stripe2_y != 1 || new_calls != 15) {
        puts("MUGEN1 PERFORMANCE PLAN FAIL");
        return 1;
    }
    puts("MUGEN1 PERFORMANCE PLAN PASS");
    return 0;
}
