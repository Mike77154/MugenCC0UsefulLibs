#include <stdio.h>
#include <string.h>
#include "gst89_engine.h"

static int cb_pair(void *user, int group, int index)
{ (void)user; (void)group; (void)index; return 1; }
static int cb_index(void *user, unsigned long index)
{ (void)user; (void)index; return 1; }
static void cb_void(void *user) { (void)user; }
static const char *cb_error(void *user)
{ (void)user; return "validation audio"; }

static int expect_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %s got=%d expected=%d\n", name, got, expected);
        return 0;
    }
    printf("PASS %s value=%d\n", name, got);
    return 1;
}

static void advance_ticks(GST89_Engine *engine, int chunks)
{
    int i;
    for (i = 0; i < chunks; ++i) gst89_engine_advance_ms(engine, 250ul);
}

int main(int argc, char **argv)
{
    GST89_EngineCallbacks callbacks;
    GST89_Engine *engine;
    const char *path;
    int ok;
    path = argc > 1 ? argv[1] : "system.def";
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.play_sound_pair = cb_pair;
    callbacks.play_sound_index = cb_index;
    callbacks.stop_audio = cb_void;
    callbacks.audio_last_error = cb_error;
    callbacks.invalidate_render_cache = cb_void;
    callbacks.request_redraw = cb_void;
    engine = gst89_engine_default();
    gst89_engine_init(engine, &callbacks, 0);
    ok = 1;

    ok &= expect_int("load", gst89_engine_load(engine, path), 1);
    ok &= expect_int("TITLE", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_TITLE);

    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P1 ARCADE SELECT", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("Arcade placeholder VS", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_VERSUS);

    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 starts challenger splash", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_CHALLENGER);
    ok &= expect_int("challenger is P2", gst89_engine_challenger_player(engine), 2);
    advance_ticks(engine, 6);
    ok &= expect_int("splash to SELECT", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    ok &= expect_int("P2 owns challenger cursor",
                     gst89_engine_select_player(engine), 2);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("challenger selection to VS", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_VERSUS);
    advance_ticks(engine, 10);
    ok &= expect_int("final VS to TITLE", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_TITLE);
    ok &= expect_int("MAIN released", gst89_engine_main_player(engine), 0);

    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_MOVE_DOWN);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_MOVE_DOWN);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 TEAM ARCADE SELECT", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    ok &= expect_int("P2 TEAM ARCADE MAIN", gst89_engine_main_player(engine), 2);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("Team Arcade placeholder VS", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_VERSUS);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P1 starts challenger", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_CHALLENGER);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P1 skips splash to SELECT", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    ok &= expect_int("P1 challenger cursor", gst89_engine_select_player(engine), 1);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P1 challenger VS", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_VERSUS);
    ok &= expect_int("P2 remains MAIN", gst89_engine_main_player(engine), 2);

    gst89_engine_shutdown(engine);
    if (!ok) return 1;
    puts("ARCADE TEAM ARCADE NEW CHALLENGER ENGINE VALIDATION PASS");
    return 0;
}
