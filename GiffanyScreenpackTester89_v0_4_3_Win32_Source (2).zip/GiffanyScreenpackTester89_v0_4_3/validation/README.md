# Validaciones v0.4.0

Resultados principales:

- `VENDORIZED_FLOWS_PASS.txt`: cuatro librerías de flujo aisladas.
- `NEW_CHALLENGER_ENGINE_PASS.txt`: Arcade y Team Arcade con retador secundario.
- `ENGINE_FACADE_V040_PASS.txt`: fachada pública.
- `TITLE_SELECT_VS_TITLE_V040_PASS.txt`: flujo P2-first sin regresiones.
- `OPTIONS_INTEGRATION_V040_PASS.txt`: OPTIONS vendorizado.
- `REAL_data_system_def_V040.txt`: motif Default.
- `REAL_data_mugen1_system_def_V040.txt`: motif MUGEN1.
- `REAL_data_big_system_def_V040.txt`: motif Big.
- `REAL_data_kfm_system_def_V040.txt`: motif KFM.
- `FULL_OBJECT_COMPILE_V040_PASS.txt`: compilación a objeto de todas las fuentes.
