#include <stdio.h>
#include "menuairdsl89.h"
#include "gst89_anim_timeline.h"

static int failures;

static void expect_frame(const MA89_Bank *bank, int action, unsigned long tick,
                         int expected_index)
{
    MA89_Frame frame;
    if (!gst89_anim_find_frame(bank, action, tick, &frame)) {
        printf("FAIL action=%d tick=%lu missing frame\n", action, tick);
        ++failures;
        return;
    }
    if (frame.index != expected_index) {
        printf("FAIL action=%d tick=%lu got=%d expected=%d\n",
               action, tick, frame.index, expected_index);
        ++failures;
    } else {
        printf("PASS action=%d tick=%lu frame=%d\n",
               action, tick, frame.index);
    }
}

int main(void)
{
    MA89_Bank bank;
    failures = 0;
    ma89_init(&bank);
    ma89_begin_action(&bank, 10);
    ma89_add_frame(&bank, 0, 0, 0, 0, 2, 0, 0);
    ma89_add_frame(&bank, 0, 1, 0, 0, 3, 0, 0);
    ma89_loopstart(&bank);
    ma89_add_frame(&bank, 0, 2, 0, 0, 2, 1, 1);
    ma89_add_frame(&bank, 0, 3, 0, 0, 1, 2, 2);
    expect_frame(&bank, 10, 0ul, 0);
    expect_frame(&bank, 10, 1ul, 0);
    expect_frame(&bank, 10, 2ul, 1);
    expect_frame(&bank, 10, 4ul, 1);
    expect_frame(&bank, 10, 5ul, 2);
    expect_frame(&bank, 10, 6ul, 2);
    expect_frame(&bank, 10, 7ul, 3);
    expect_frame(&bank, 10, 8ul, 2);
    expect_frame(&bank, 10, 11ul, 2);

    ma89_begin_action(&bank, 20);
    ma89_add_frame(&bank, 1, 4, 0, 0, 1, 0, 0);
    ma89_add_frame(&bank, 1, 5, 0, 0, -1, 0, 0);
    expect_frame(&bank, 20, 0ul, 4);
    expect_frame(&bank, 20, 1ul, 5);
    expect_frame(&bank, 20, 999ul, 5);

    if (failures) {
        printf("ANIM TIMELINE VALIDATION FAIL failures=%d\n", failures);
        return 1;
    }
    printf("ANIM TIMELINE VALIDATION PASS\n");
    return 0;
}
