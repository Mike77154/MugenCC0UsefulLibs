#include <sys/stat.h>
#include "windows.h"

DWORD GetFileAttributesA(const char *path)
{
    struct stat st;
    if (!path || stat(path, &st) != 0) return INVALID_FILE_ATTRIBUTES;
    return S_ISDIR(st.st_mode) ? FILE_ATTRIBUTE_DIRECTORY : 0u;
}
UINT GetWindowsDirectoryA(char *out, UINT cap)
{
    if (out && cap > 0u) out[0] = '\0';
    return 0u;
}
HANDLE AddFontMemResourceEx(PVOID data, DWORD size, PVOID reserved, DWORD *count)
{
    (void)data; (void)size; (void)reserved;
    if (count) *count = 1u;
    return (HANDLE)1;
}
BOOL RemoveFontMemResourceEx(HANDLE handle) { (void)handle; return TRUE; }
HFONT CreateFontA() { return (HFONT)1; }
BOOL DeleteObject(HGDIOBJ object) { (void)object; return TRUE; }
HGDIOBJ SelectObject(HDC dc, HGDIOBJ object) { (void)dc; return object; }
BOOL GetTextExtentPoint32A(HDC dc, const char *text, int len, SIZE *size)
{
    (void)dc; (void)text;
    if (size) { size->cx = len * 8; size->cy = 16; }
    return TRUE;
}
int SetBkMode(HDC dc, int mode) { (void)dc; return mode; }
COLORREF SetTextColor(HDC dc, COLORREF color) { (void)dc; return color; }
int DrawTextA(HDC dc, const char *text, int len, RECT *rect, UINT format)
{ (void)dc; (void)text; (void)len; (void)rect; (void)format; return 1; }
BOOL OffsetRect(RECT *rect, int dx, int dy)
{
    if (!rect) return FALSE;
    rect->left += dx; rect->right += dx;
    rect->top += dy; rect->bottom += dy;
    return TRUE;
}
