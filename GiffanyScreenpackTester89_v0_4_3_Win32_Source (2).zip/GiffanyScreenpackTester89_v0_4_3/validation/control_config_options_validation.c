#include "optionsflow89.h"
#include <stdio.h>
#include <string.h>

static int fail(const char *text)
{
    fprintf(stderr, "FAIL: %s\n", text);
    return 1;
}

int main(void)
{
    OptionsFlow89State state;
    const matroshka_submenus89_menu *menu;
    scanemu_event event;
    scanemu_token token;
    char text[128];
    const char *path;
    int loaded;

    path = "validation/player1_controls_test.ini";
    optionsflow89_init(&state);
    if (optionsflow89_validate(&state) != 0) return fail("tree validation");
    if (!optionsflow89_open(&state, 3)) return fail("open options");
    if (!optionsflow89_select(&state, 3)) return fail("select controls");
    if (optionsflow89_activate(&state) != OPTIONSFLOW89_EVENT_OPENED)
        return fail("open controls");
    if (!optionsflow89_select(&state, 0)) return fail("select p1");
    if (optionsflow89_activate(&state) != OPTIONSFLOW89_EVENT_OPENED)
        return fail("open p1");
    menu = optionsflow89_current_menu(&state);
    if (!menu || menu->item_count != 14) return fail("14 control items");
    if (!optionsflow89_select(&state, 0)) return fail("select light punch");
    if (optionsflow89_activate(&state) != OPTIONSFLOW89_EVENT_ACTION)
        return fail("begin capture");
    if (!optionsflow89_control_capture_active(&state))
        return fail("capture active");
    memset(&event, 0, sizeof(event));
    event.kind = SCANEMU_EV_PRESS;
    event.token.type = SCANEMU_T_KEY;
    event.token.device_id = 0;
    event.token.code = 81;
    if (!optionsflow89_control_feed(&state, &event))
        return fail("feed Q key");
    if (optionsflow89_control_capture_active(&state))
        return fail("capture finished");
    controlconfig89_binding_text(&state.controls, 1,
                                 CONTROLCONFIG89_LIGHT_PUNCH,
                                 text, (int)sizeof(text));
    if (strcmp(text, "KEY:0:81") != 0) return fail("serialized Q token");
    if (!optionsflow89_select(&state, 11)) return fail("select export");
    if (optionsflow89_activate(&state) != OPTIONSFLOW89_EVENT_ACTION)
        return fail("request export");
    if (optionsflow89_take_export_request(&state) != 1)
        return fail("take P1 export request");
    if (!optionsflow89_export_player_ini(&state, 1, path))
        return fail("export ini");
    controlconfig89_reset_player(&state.controls, 1);
    memset(&token, 0, sizeof(token));
    if (!controlconfig89_get(&state.controls, 1,
                             CONTROLCONFIG89_LIGHT_PUNCH, &token))
        return fail("default get");
    if (token.code == 81) return fail("reset changed Q");
    loaded = optionsflow89_load_player_ini(&state, 1, path);
    if (loaded != CONTROLCONFIG89_ACTION_COUNT)
        return fail("load all actions");
    memset(&token, 0, sizeof(token));
    if (!controlconfig89_get(&state.controls, 1,
                             CONTROLCONFIG89_LIGHT_PUNCH, &token) ||
        token.code != 81) return fail("reloaded Q");
    remove(path);
    printf("CONTROLS OPTIONS + SCANEMU + PLAYER INI PASS\n");
    return 0;
}
