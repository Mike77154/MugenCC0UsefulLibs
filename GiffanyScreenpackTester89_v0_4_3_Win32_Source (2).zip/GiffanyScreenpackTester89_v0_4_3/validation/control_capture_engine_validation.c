#include "gst89_engine.h"
#include "gst89_engine_internal.h"
#include "gst89_options.h"
#include <stdio.h>
#include <string.h>

static int fail(const char *text)
{
    fprintf(stderr, "FAIL: %s\n", text);
    return 1;
}

int main(int argc, char **argv)
{
    GST89_Engine *engine;
    GST89_App *app;
    GST89_EngineInputEvent event;
    const matroshka_submenus89_menu *menu;
    char label[192];
    if (argc < 2) return fail("system.def path required");
    engine = gst89_engine_default();
    gst89_engine_init(engine, 0, 0);
    if (!gst89_engine_load(engine, argv[1])) return fail("load screenpack");
    app = gst89_engine_app_mutable(engine);
    (void)mainplayer89_claim(&app->player_authority, 1);
    if (!gst89_options_open(app, 9)) return fail("open options");
    if (!gst89_engine_select_option(engine, 3, 0)) return fail("select controls");
    if (!gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE))
        return fail("open controls");
    if (!gst89_engine_select_option(engine, 0, 0)) return fail("select p1");
    if (!gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE))
        return fail("open p1 controls");
    menu = gst89_options_current_menu(app);
    if (!menu || menu->item_count != 14) return fail("p1 menu item count");
    if (!gst89_engine_select_option(engine, 0, 0)) return fail("select LP");
    if (!gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE))
        return fail("start capture");
    if (!gst89_engine_control_capture_active(engine))
        return fail("engine capture active");
    memset(&event, 0, sizeof(event));
    event.kind = GST89_ENGINE_INPUT_PRESS;
    event.type = GST89_ENGINE_INPUT_KEY;
    event.device_id = 0;
    event.code = 81;
    if (!gst89_engine_feed_input_event(engine, &event))
        return fail("feed key event");
    if (gst89_engine_control_capture_active(engine))
        return fail("capture ended");
    gst89_options_display_label(app, &menu->items[0], label,
                                (int)sizeof(label));
    if (!strstr(label, "KEY:0:81")) return fail("new binding visible");
    gst89_engine_shutdown(engine);
    puts("ENGINE CONTROL CAPTURE PASS");
    return 0;
}
