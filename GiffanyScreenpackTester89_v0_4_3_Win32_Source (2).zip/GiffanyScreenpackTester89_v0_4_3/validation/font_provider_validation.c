#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include "gst89_font_provider.h"

void gst89_logf(const char *category, const char *format, ...)
{
    va_list args;
    (void)category;
    va_start(args, format);
    vfprintf(stdout, format, args);
    fputc('\n', stdout);
    va_end(args);
}

void gst89_log_errno(const char *category, const char *operation,
                     const char *path)
{
    (void)category;
    fprintf(stdout, "errno operation=%s path=%s\n",
            operation ? operation : "", path ? path : "");
}

int gst89_resolve_font(const GST89_App *app, const char *path,
                       char *out, int cap)
{
    (void)app;
    if (out && cap > 0) out[0] = '\0';
    (void)path;
    return 0;
}

DWORD GetFileAttributesA(const char *path)
{
    struct stat st;
    if (!path || stat(path, &st) != 0) return INVALID_FILE_ATTRIBUTES;
    if (S_ISDIR(st.st_mode)) return FILE_ATTRIBUTE_DIRECTORY;
    return 0u;
}

UINT GetWindowsDirectoryA(char *out, UINT cap)
{
    if (out && cap > 0u) out[0] = '\0';
    return 0u;
}

HANDLE AddFontMemResourceEx(PVOID data, DWORD size, PVOID reserved,
                            DWORD *count)
{
    (void)data; (void)size; (void)reserved;
    if (count) *count = 1u;
    return (HANDLE)1;
}

BOOL RemoveFontMemResourceEx(HANDLE handle)
{
    (void)handle;
    return TRUE;
}

HFONT CreateFontA()
{
    return (HFONT)1;
}

BOOL DeleteObject(HGDIOBJ object)
{
    (void)object;
    return TRUE;
}

HGDIOBJ SelectObject(HDC dc, HGDIOBJ object)
{
    (void)dc;
    return object;
}

BOOL GetTextExtentPoint32A(HDC dc, const char *text, int len, SIZE *size)
{
    (void)dc; (void)text;
    if (size) { size->cx = len * 8; size->cy = 16; }
    return TRUE;
}

int SetBkMode(HDC dc, int mode) { (void)dc; return mode; }
COLORREF SetTextColor(HDC dc, COLORREF color) { (void)dc; return color; }
int DrawTextA(HDC dc, const char *text, int len, RECT *rect, UINT format)
{ (void)dc; (void)text; (void)len; (void)rect; (void)format; return 1; }
BOOL OffsetRect(RECT *rect, int dx, int dy)
{
    if (!rect) return FALSE;
    rect->left += dx; rect->right += dx;
    rect->top += dy; rect->bottom += dy;
    return TRUE;
}


static unsigned long hash_bytes(const unsigned char *bytes,
                                unsigned long size)
{
    unsigned long i;
    unsigned long hash;
    hash = 2166136261ul;
    for (i = 0ul; i < size; ++i) {
        hash ^= (unsigned long)bytes[i];
        hash *= 16777619ul;
    }
    return hash;
}

static void sum_bgr(const unsigned char *bytes, unsigned long size,
                    unsigned long *b_out, unsigned long *g_out,
                    unsigned long *r_out)
{
    unsigned long i;
    unsigned long b;
    unsigned long g;
    unsigned long r;
    b = 0ul; g = 0ul; r = 0ul;
    for (i = 0ul; i + 3ul < size; i += 4ul) {
        b += bytes[i + 0ul];
        g += bytes[i + 1ul];
        r += bytes[i + 2ul];
    }
    if (b_out) *b_out = b;
    if (g_out) *g_out = g;
    if (r_out) *r_out = r;
}
static unsigned long count_nonzero(const unsigned char *bytes,
                                   unsigned long size)
{
    unsigned long i;
    unsigned long count;
    count = 0ul;
    for (i = 0ul; i < size; ++i) if (bytes[i] != 0u) ++count;
    return count;
}

int main(void)
{
    static GST89_App app;
    static unsigned char pixels[640u * 128u * 4u];
    MSD89_FontSpec spec;
    RECT rect;
    int w;
    int h;
    int loaded;
    unsigned long nonzero;
    unsigned long hash_a;
    unsigned long hash_b;
    unsigned long bank0_b;
    unsigned long bank0_g;
    unsigned long bank0_r;
    unsigned long bank5_b;
    unsigned long bank5_g;
    unsigned long bank5_r;

    memset(&app, 0, sizeof(app));
    strcpy(app.document.files.fonts[3], "jg.fnt");
    strcpy(app.resolved_fonts[3],
           "/mnt/data/mugen_ref/mugen-master/font/jg.fnt");
    strcpy(app.document.files.fonts[4], "arcade.def");
    strcpy(app.resolved_fonts[4],
           "/mnt/data/mugen_ref/mugen-master/font/arcade.def");
    app.resolved_font_count = 5;

    loaded = gst89_fonts_load(&app);
    if (loaded != 2) {
        printf("FAIL loaded=%d\n", loaded);
        return 1;
    }

    memset(&spec, 0, sizeof(spec));
    spec.valid = 1;
    spec.slot = 3;
    spec.bank = 5;
    if (!gst89_font_measure(&app, &spec, "OPTIONS", 1, 1, 1, 1,
                            16, 0, 0, &w, &h) || w <= 0 || h != 8) {
        printf("FAIL legacy measure w=%d h=%d\n", w, h);
        return 1;
    }
    memset(pixels, 0, sizeof(pixels));
    rect.left = 10; rect.top = 10; rect.right = 10 + w; rect.bottom = 10 + h;
    if (!gst89_font_draw(&app, &spec, "OPTIONS", &rect, RGB(255,255,255),
                         1, pixels, 640, 128, 640 * 4, 0, 0)) {
        printf("FAIL legacy draw\n");
        return 1;
    }
    nonzero = count_nonzero(pixels, (unsigned long)sizeof(pixels));
    if (nonzero == 0ul) {
        printf("FAIL legacy empty\n");
        return 1;
    }
    printf("PASS legacy backend=%s w=%d h=%d pixels=%lu\n",
           gst89_fonts_backend_name(3), w, h, nonzero);

    /* Regression: the real jg.fnt is Type=Fixed.  A and B must not
       sample the same first cell, and bank 5 must select the yellow
       reverse palette bank rather than black entries near index 80. */
    spec.bank = 0;
    if (!gst89_font_measure(&app, &spec, "A", 1, 1, 1, 1,
                            16, 0, 0, &w, &h)) return 1;
    rect.left = 10; rect.top = 10; rect.right = 10 + w; rect.bottom = 10 + h;
    memset(pixels, 0, sizeof(pixels));
    if (!gst89_font_draw(&app, &spec, "A", &rect, RGB(255,255,255),
                         0, pixels, 640, 128, 640 * 4, 0, 0)) return 1;
    hash_a = hash_bytes(pixels, (unsigned long)sizeof(pixels));
    sum_bgr(pixels, (unsigned long)sizeof(pixels),
            &bank0_b, &bank0_g, &bank0_r);

    memset(pixels, 0, sizeof(pixels));
    if (!gst89_font_draw(&app, &spec, "B", &rect, RGB(255,255,255),
                         0, pixels, 640, 128, 640 * 4, 0, 0)) return 1;
    hash_b = hash_bytes(pixels, (unsigned long)sizeof(pixels));
    if (hash_a == hash_b) {
        printf("FAIL fixed FNT glyph offsets collapse A and B\n");
        return 1;
    }
    if (bank0_r == 0ul || bank0_r != bank0_g || bank0_g != bank0_b) {
        printf("FAIL legacy bank0 expected grayscale r=%lu g=%lu b=%lu\n",
               bank0_r, bank0_g, bank0_b);
        return 1;
    }

    spec.bank = 5;
    memset(pixels, 0, sizeof(pixels));
    if (!gst89_font_draw(&app, &spec, "A", &rect, RGB(255,255,255),
                         0, pixels, 640, 128, 640 * 4, 0, 0)) return 1;
    sum_bgr(pixels, (unsigned long)sizeof(pixels),
            &bank5_b, &bank5_g, &bank5_r);
    if (bank5_r == 0ul || bank5_r != bank5_g || bank5_b != 0ul) {
        printf("FAIL legacy bank5 expected yellow r=%lu g=%lu b=%lu\n",
               bank5_r, bank5_g, bank5_b);
        return 1;
    }
    printf("PASS fixed offsets A=0x%08lx B=0x%08lx | bank0=%lu,%lu,%lu | bank5=%lu,%lu,%lu\n",
           hash_a, hash_b, bank0_r, bank0_g, bank0_b,
           bank5_r, bank5_g, bank5_b);

    memset(&spec, 0, sizeof(spec));
    spec.valid = 1;
    spec.slot = 4;
    spec.bank = 5;
    if (!gst89_font_measure(&app, &spec, "OPTIONS", 1, 1, 1, 1,
                            34, 0, 0, &w, &h) || w <= 0 || h != 34) {
        printf("FAIL sff measure w=%d h=%d\n", w, h);
        return 1;
    }
    memset(pixels, 0, sizeof(pixels));
    rect.left = 10; rect.top = 10; rect.right = 10 + w; rect.bottom = 10 + h;
    if (!gst89_font_draw(&app, &spec, "OPTIONS", &rect, RGB(255,255,255),
                         1, pixels, 640, 128, 640 * 4, 0, 0)) {
        printf("FAIL sff draw\n");
        return 1;
    }
    nonzero = count_nonzero(pixels, (unsigned long)sizeof(pixels));
    if (nonzero == 0ul) {
        printf("FAIL sff empty\n");
        return 1;
    }
    printf("PASS sff backend=%s w=%d h=%d pixels=%lu\n",
           gst89_fonts_backend_name(4), w, h, nonzero);

    gst89_fonts_reset();
    printf("FONT PROVIDER VALIDATION PASS\n");
    return 0;
}
