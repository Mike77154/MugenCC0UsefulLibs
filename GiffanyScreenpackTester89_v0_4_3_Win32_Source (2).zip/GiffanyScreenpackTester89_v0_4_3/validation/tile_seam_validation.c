#include <stdio.h>
#include "gst89_render_math.h"

static int failures;

static void fail_case(const char *axis, int viewport, int phase,
                      int tile_span, int right_edge, int next_left)
{
    printf("FAIL %s viewport=%d phase=%d span=%d right=%d next=%d\n",
           axis, viewport, phase, tile_span, right_edge, next_left);
    ++failures;
}

static void sweep_axis(const char *axis, int local_span, int tile_span)
{
    int viewport;
    int phase;
    int tile;
    int left;
    int right;
    int next_left;
    for (viewport = 257; viewport <= 1537; viewport += 17) {
        for (phase = -tile_span * 2; phase <= tile_span * 2; ++phase) {
            for (tile = -3; tile <= 3; ++tile) {
                left = gst89_rm_project_edge(0, viewport, local_span,
                    phase + tile * tile_span);
                right = gst89_rm_project_edge(0, viewport, local_span,
                    phase + (tile + 1) * tile_span);
                next_left = gst89_rm_project_edge(0, viewport, local_span,
                    phase + (tile + 1) * tile_span);
                if (right != next_left || right < left) {
                    fail_case(axis, viewport, phase, tile_span,
                              right, next_left);
                    return;
                }
            }
        }
    }
    printf("PASS %s shared edges across all tested phases\n", axis);
}

int main(void)
{
    int old_left;
    int old_width;
    int old_right;
    int edge_right;
    failures = 0;

    old_left = gst89_rm_project_edge(0, 853, 1280, -800);
    old_width = (800 * 853) / 1280;
    old_right = old_left + old_width;
    edge_right = gst89_rm_project_edge(0, 853, 1280, 0);
    printf("INFO old split projection right=%d shared-edge right=%d\n",
           old_right, edge_right);
    if (old_right == edge_right) {
        printf("FAIL regression fixture did not expose old seam\n");
        ++failures;
    } else {
        printf("PASS regression fixture exposes one-pixel old seam\n");
    }

    sweep_axis("horizontal", 1280, 800);
    sweep_axis("vertical", 720, 320);

    if (failures != 0) {
        printf("TILE SEAM VALIDATION FAIL failures=%d\n", failures);
        return 1;
    }
    printf("TILE SEAM VALIDATION PASS\n");
    return 0;
}
