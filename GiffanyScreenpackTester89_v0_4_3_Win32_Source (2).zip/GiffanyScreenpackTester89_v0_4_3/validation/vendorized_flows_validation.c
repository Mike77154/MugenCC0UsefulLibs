#include <stdio.h>
#include "mainplayer89.h"
#include "title_select_vs_flow89.h"
#include "optionsflow89.h"
#include "newchallenger89.h"

static int expect(const char *name, int condition)
{
    if (!condition) {
        printf("FAIL %s\n", name);
        return 0;
    }
    printf("PASS %s\n", name);
    return 1;
}

int main(void)
{
    MainPlayer89State authority;
    TSVFlow89State tsv;
    OptionsFlow89State options;
    NewChallenger89State challenger;
    int ok;
    int event;
    ok = 1;

    mainplayer89_init(&authority);
    ok &= expect("title begins unclaimed", mainplayer89_main(&authority) == 0);
    (void)mainplayer89_observe_title_input(&authority, 2);
    ok &= expect("P2 owns free title cursor",
                 mainplayer89_title_controller(&authority) == 2);
    event = mainplayer89_claim(&authority, 2);
    ok &= expect("P2 claims MAIN", event == MAINPLAYER89_EVENT_CLAIMED &&
                 mainplayer89_main(&authority) == 2);
    ok &= expect("P1 rejected after P2 claim",
                 !mainplayer89_accepts(&authority, 1));
    (void)mainplayer89_release(&authority);
    ok &= expect("MAIN release is explicit", mainplayer89_main(&authority) == 0);

    tsvflow89_init(&tsv);
    ok &= expect("TSV starts TITLE", tsvflow89_stage(&tsv) ==
                 TSVFLOW89_STAGE_TITLE);
    (void)tsvflow89_enter_select(&tsv, 2, 2);
    ok &= expect("TSV SELECT stores P2 MAIN",
                 tsvflow89_stage(&tsv) == TSVFLOW89_STAGE_SELECT &&
                 tsvflow89_main_player(&tsv) == 2);
    (void)tsvflow89_enter_versus(&tsv, 150ul);
    event = tsvflow89_advance(&tsv, 149ul);
    ok &= expect("VS does not end early", event == TSVFLOW89_EVENT_NONE);
    event = tsvflow89_advance(&tsv, 1ul);
    ok &= expect("VS timeout emitted", event == TSVFLOW89_EVENT_VERSUS_TIMEOUT);
    (void)tsvflow89_enter_title(&tsv);
    ok &= expect("TSV returns TITLE", tsvflow89_stage(&tsv) ==
                 TSVFLOW89_STAGE_TITLE);

    optionsflow89_init(&options);
    ok &= expect("options tree valid", optionsflow89_validate(&options) == 0);
    ok &= expect("options opens", optionsflow89_open(&options, 9));
    ok &= expect("options is independent", optionsflow89_is_open(&options));
    (void)optionsflow89_move(&options, 1);
    while (optionsflow89_is_open(&options))
        (void)optionsflow89_back(&options);
    ok &= expect("options restores title selection",
                 optionsflow89_return_selection(&options) == 9);

    newchallenger89_init(&challenger);
    newchallenger89_configure(&challenger,
        NEWCHALLENGER89_MODE_BIT(0) | NEWCHALLENGER89_MODE_BIT(2), 90ul);
    newchallenger89_begin_session(&challenger, 0, 1);
    event = newchallenger89_request(&challenger, 2,
                                    NEWCHALLENGER89_SOURCE_VERSUS);
    ok &= expect("P2 starts challenger splash",
                 event == NEWCHALLENGER89_EVENT_SPLASH_STARTED);
    event = newchallenger89_advance(&challenger, 89ul);
    ok &= expect("splash keeps one tick", event == NEWCHALLENGER89_EVENT_NONE);
    event = newchallenger89_advance(&challenger, 1ul);
    ok &= expect("splash opens challenger select",
                 event == NEWCHALLENGER89_EVENT_ENTER_SELECT);
    event = newchallenger89_complete_selection(&challenger, 2);
    ok &= expect("challenger selection reaches VS",
                 event == NEWCHALLENGER89_EVENT_READY_FOR_VERSUS);

    if (!ok) return 1;
    puts("VENDORIZED FLOWS VALIDATION PASS");
    return 0;
}
