#include <stdio.h>
#include <string.h>
#include "gst89_options.h"

static GST89_App app;
static int failures;

static int ci_starts(const char *text, const char *prefix)
{
    unsigned char a;
    unsigned char b;
    if (!text || !prefix) return 0;
    while (*prefix) {
        if (!*text) return 0;
        a = (unsigned char)*text++;
        b = (unsigned char)*prefix++;
        if (a >= 'A' && a <= 'Z') a = (unsigned char)(a + 32);
        if (b >= 'A' && b <= 'Z') b = (unsigned char)(b + 32);
        if (a != b) return 0;
    }
    return 1;
}

static void check_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %-36s got=%d expected=%d\n", name, got, expected);
        ++failures;
    } else {
        printf("PASS %-36s value=%d\n", name, got);
    }
}

static int validate_option_bg(void)
{
    const GST89_SffBank *bank;
    const MSD89_Property *property;
    int i;
    int j;
    int checked;
    int group;
    int item;
    sff_u32 index;
    bank = gst89_option_sff_bank(&app);
    if (!bank) {
        puts("FAIL OptionBG has no SFF bank");
        return 1;
    }
    checked = 0;
    for (i = 0; i < app.document.stats.pair_count; ++i) {
        property = &app.document.properties[i];
        if (!ci_starts(property->section, "OptionBG ")) continue;
        for (j = 0; j < i; ++j) {
            if (strcmp(app.document.properties[j].section,
                       property->section) == 0) break;
        }
        if (j < i) continue;
        property = gst89_property(&app.document,
                                  app.document.properties[i].section,
                                  "spriteno");
        if (!property || !gst89_parse_pair(property->value, &group, &item))
            continue;
        ++checked;
        if (sff_find_sprite(&bank->file, (sff_u16)group, (sff_u16)item,
                            &index) != SFF_OK) {
            printf("FAIL OptionBG sprite %d,%d missing\n", group, item);
            return 2;
        }
    }
    if (checked == 0) {
        puts("FAIL OptionBG no sprite references checked");
        return 3;
    }
    printf("PASS OptionBG sprite references          checked=%d\n", checked);
    return 0;
}

int main(int argc, char **argv)
{
    const matroshka_submenus89_menu *menu;
    char label[160];
    int event;
    if (argc < 2) {
        fprintf(stderr, "usage: %s mugen1/system.def\n", argv[0]);
        return 64;
    }
    failures = 0;
    gst89_app_init(&app);
    check_int("load MUGEN1", gst89_load_screenpack(&app, argv[1]), 1);
    check_int("open OPTIONS", gst89_options_open(&app, 9), 1);
    check_int("view is options", app.view, GST89_VIEW_OPTIONS);
    menu = gst89_options_current_menu(&app);
    check_int("root item count", menu ? menu->item_count : -1, 5);
    check_int("root selection", gst89_options_selected(&app), 0);

    event = gst89_options_activate(&app);
    check_int("open VIDEO submenu", event, GST89_OPTIONS_EVENT_OPENED);
    menu = gst89_options_current_menu(&app);
    check_int("video item count", menu ? menu->item_count : -1, 3);
    gst89_options_display_label(&app, &menu->items[0], label,
                                (int)sizeof(label));
    if (strstr(label, "WINDOWED") == 0) {
        printf("FAIL display label value             text=%s\n", label);
        ++failures;
    } else printf("PASS display label value             text=%s\n", label);
    check_int("select VIDEO back", gst89_options_select(&app, 2), 1);
    check_int("back to root by action", gst89_options_activate(&app),
              GST89_OPTIONS_EVENT_OPENED);
    check_int("root selection restored", gst89_options_selected(&app), 0);
    check_int("select RETURN TO TITLE", gst89_options_select(&app, 4), 1);
    check_int("close OPTIONS", gst89_options_activate(&app),
              GST89_OPTIONS_EVENT_CLOSED);
    check_int("view restored title", app.view, GST89_VIEW_TITLE);
    check_int("title selection restored", app.title_selected, 9);

    if (validate_option_bg() != 0) ++failures;
    gst89_app_close(&app);
    if (failures != 0) {
        printf("OPTIONS INTEGRATION VALIDATION FAIL failures=%d\n", failures);
        return 1;
    }
    puts("OPTIONS INTEGRATION VALIDATION PASS");
    return 0;
}
