#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <sys/stat.h>
#include "gst89_font_provider.h"

void gst89_logf(const char *category, const char *format, ...)
{
    va_list args;
    printf("[%s] ", category ? category : "LOG");
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
    putchar('\n');
}
void gst89_log_errno(const char *category, const char *operation,
                     const char *path)
{
    printf("[%s] errno operation=%s path=%s\n", category ? category : "LOG",
           operation ? operation : "", path ? path : "");
}
int gst89_resolve_font(const GST89_App *app, const char *path,
                       char *out, int cap)
{
    (void)app; (void)path;
    if (out && cap > 0) out[0] = '\0';
    return 0;
}
DWORD GetFileAttributesA(const char *path)
{
    struct stat st;
    if (!path || stat(path, &st) != 0) return INVALID_FILE_ATTRIBUTES;
    return S_ISDIR(st.st_mode) ? FILE_ATTRIBUTE_DIRECTORY : 0u;
}
UINT GetWindowsDirectoryA(char *out, UINT cap)
{
    if (out && cap > 0u) out[0] = '\0';
    return 0u;
}
HANDLE AddFontMemResourceEx(PVOID data, DWORD size, PVOID reserved, DWORD *count)
{
    (void)data; (void)size; (void)reserved;
    if (count) *count = 1u;
    return (HANDLE)1;
}
BOOL RemoveFontMemResourceEx(HANDLE handle) { (void)handle; return TRUE; }
HFONT CreateFontA() { return (HFONT)1; }
BOOL DeleteObject(HGDIOBJ object) { (void)object; return TRUE; }
HGDIOBJ SelectObject(HDC dc, HGDIOBJ object) { (void)dc; return object; }
BOOL GetTextExtentPoint32A(HDC dc, const char *text, int len, SIZE *size)
{
    (void)dc; (void)text;
    if (size) { size->cx = len * 9; size->cy = 24; }
    return TRUE;
}
int SetBkMode(HDC dc, int mode) { (void)dc; return mode; }
COLORREF SetTextColor(HDC dc, COLORREF color) { (void)dc; return color; }
int DrawTextA(HDC dc, const char *text, int len, RECT *rect, UINT format)
{ (void)dc; (void)text; (void)len; (void)rect; (void)format; return 1; }
BOOL OffsetRect(RECT *rect, int dx, int dy)
{
    if (!rect) return FALSE;
    rect->left += dx; rect->right += dx; rect->top += dy; rect->bottom += dy;
    return TRUE;
}

static void add_slot(GST89_App *app, int index, const char *path)
{
    const char *slash;
    const char *back;
    const char *name;
    slash = strrchr(path, '/');
    back = strrchr(path, '\\');
    name = slash;
    if (!name || (back && back > name)) name = back;
    if (name) ++name; else name = path;
    strncpy(app->document.files.fonts[index], name,
            sizeof(app->document.files.fonts[index]) - 1u);
    strncpy(app->resolved_fonts[index], path,
            sizeof(app->resolved_fonts[index]) - 1u);
    app->document.files.font_height_set[index] = 1;
    app->document.files.font_heights[index] = 24;
}

int main(int argc, char **argv)
{
    static GST89_App app;
    int i;
    int loaded;
    int expected;
    MSD89_FontSpec spec;
    int w;
    int h;
    if (argc < 6) {
        fprintf(stderr, "usage: %s ttf otf woff1 eot yy [woff2]\n", argv[0]);
        return 2;
    }
    memset(&app, 0, sizeof(app));
    expected = argc - 1;
    if (expected > MSD89_MAX_FONTS) expected = MSD89_MAX_FONTS;
    for (i = 0; i < expected; ++i) add_slot(&app, i + 1, argv[i + 1]);
    app.resolved_font_count = expected + 1;
    loaded = gst89_fonts_load(&app);
    if (loaded != expected) {
        printf("FAIL loaded=%d expected=%d\n", loaded, expected);
        return 1;
    }
    for (i = 0; i < expected; ++i)
        printf("PASS slot=%d backend=%s\n", i + 1,
               gst89_fonts_backend_name(i + 1));
    memset(&spec, 0, sizeof(spec));
    spec.valid = 1;
    for (i = 0; i < expected; ++i) {
        const char *backend;
        backend = gst89_fonts_backend_name(i + 1);
        if (strstr(backend, "metadata-only") != 0) continue;
        spec.slot = i + 1;
        if (!gst89_font_measure(&app, &spec, "OPTIONS", 1, 1, 1, 1,
                                24, (HDC)1, (HFONT)1, &w, &h) ||
            w <= 0 || h <= 0) {
            printf("FAIL measure slot=%d backend=%s w=%d h=%d\n",
                   i + 1, backend, w, h);
            return 1;
        }
        printf("PASS measure slot=%d w=%d h=%d\n", i + 1, w, h);
    }
    gst89_fonts_reset();
    printf("FONT FORMAT MATRIX PASS count=%d\n", expected);
    return 0;
}
