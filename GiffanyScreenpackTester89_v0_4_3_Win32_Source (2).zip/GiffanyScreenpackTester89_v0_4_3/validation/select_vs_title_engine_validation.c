#include <stdio.h>
#include <string.h>
#include "gst89_engine.h"

static int redraw_count;
static int stop_count;
static int cache_count;

static int cb_pair(void *user, int group, int index)
{
    (void)user; (void)group; (void)index;
    return 1;
}
static int cb_index(void *user, unsigned long index)
{
    (void)user; (void)index;
    return 1;
}
static void cb_stop(void *user) { (void)user; ++stop_count; }
static const char *cb_error(void *user) { (void)user; return "audio test"; }
static void cb_cache(void *user) { (void)user; ++cache_count; }
static void cb_redraw(void *user) { (void)user; ++redraw_count; }

static int expect_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %s got=%d expected=%d\n", name, got, expected);
        return 0;
    }
    printf("PASS %s value=%d\n", name, got);
    return 1;
}

int main(int argc, char **argv)
{
    GST89_EngineCallbacks callbacks;
    GST89_Engine *engine;
    int ok;
    int i;
    int before;
    const char *path;
    path = argc > 1 ? argv[1] : "system.def";
    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.play_sound_pair = cb_pair;
    callbacks.play_sound_index = cb_index;
    callbacks.stop_audio = cb_stop;
    callbacks.audio_last_error = cb_error;
    callbacks.invalidate_render_cache = cb_cache;
    callbacks.request_redraw = cb_redraw;
    engine = gst89_engine_default();
    gst89_engine_init(engine, &callbacks, 0);
    ok = 1;
    ok &= expect_int("load real screenpack", gst89_engine_load(engine, path), 1);
    ok &= expect_int("starts at title", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_TITLE);
    ok &= expect_int("title starts unclaimed", gst89_engine_main_player(engine), 0);

    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 START claims main", gst89_engine_main_player(engine), 2);
    ok &= expect_int("P2 ARCADE enters select", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    ok &= expect_int("P2 is first active cursor",
                     gst89_engine_select_player(engine), 2);
    before = gst89_engine_select_cell(engine, 2);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_MOVE_RIGHT);
    ok &= expect_int("inactive P1 cannot move P2-main select",
                     gst89_engine_select_cell(engine, 2), before);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 ARCADE confirm enters VS", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_VERSUS);
    for (i = 0; i < 10; ++i) gst89_engine_advance_ms(engine, 250ul);
    ok &= expect_int("VS timeout returns title", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_TITLE);
    ok &= expect_int("returning title releases main",
                     gst89_engine_main_player(engine), 0);

    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_MOVE_DOWN);
    ok &= expect_int("P2 can move shared title cursor",
                     gst89_engine_title_controller(engine), 2);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 VERSUS enters select", gst89_engine_view(engine),
                     GST89_ENGINE_VIEW_SELECT);
    ok &= expect_int("P2 remains main in versus",
                     gst89_engine_main_player(engine), 2);
    ok &= expect_int("P2 selects first in versus",
                     gst89_engine_select_player(engine), 2);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P2 confirm hands control to P1",
                     gst89_engine_select_player(engine), 1);
    before = gst89_engine_select_cell(engine, 1);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_MOVE_RIGHT);
    ok &= expect_int("P2 cannot move after handoff",
                     gst89_engine_select_cell(engine, 1), before);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_MOVE_RIGHT);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_ACTIVATE);
    ok &= expect_int("P1 secondary confirm enters VS",
                     gst89_engine_view(engine), GST89_ENGINE_VIEW_VERSUS);
    (void)gst89_engine_player_command(engine, 1, GST89_ENGINE_CMD_CANCEL);
    ok &= expect_int("secondary cannot cancel P2-main VS",
                     gst89_engine_view(engine), GST89_ENGINE_VIEW_VERSUS);
    (void)gst89_engine_player_command(engine, 2, GST89_ENGINE_CMD_CANCEL);
    ok &= expect_int("P2 main cancels VS to title",
                     gst89_engine_view(engine), GST89_ENGINE_VIEW_TITLE);

    gst89_engine_shutdown(engine);
    if (!ok) return 1;
    printf("INFO redraws=%d stops=%d cache_resets=%d\n",
           redraw_count, stop_count, cache_count);
    puts("P2-FIRST TITLE SELECT VS TITLE ENGINE VALIDATION PASS");
    return 0;
}
