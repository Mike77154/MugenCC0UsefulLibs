#ifndef COMMDLG_H_STUB
#define COMMDLG_H_STUB
#include "windows.h"
#define OFN_FILEMUSTEXIST 0x1000
#define OFN_PATHMUSTEXIST 0x0800
#define OFN_HIDEREADONLY 0x0004
#define OFN_EXPLORER 0x80000
#define OFN_NOCHANGEDIR 0x0008
typedef struct tagOFNA { DWORD lStructSize; HWND hwndOwner; HINSTANCE hInstance; LPCSTR lpstrFilter; LPSTR lpstrCustomFilter; DWORD nMaxCustFilter; DWORD nFilterIndex; LPSTR lpstrFile; DWORD nMaxFile; LPSTR lpstrFileTitle; DWORD nMaxFileTitle; LPCSTR lpstrInitialDir; LPCSTR lpstrTitle; DWORD Flags; WORD nFileOffset; WORD nFileExtension; LPCSTR lpstrDefExt; LPARAM lCustData; void *lpfnHook; LPCSTR lpTemplateName; } OPENFILENAMEA;
BOOL GetOpenFileNameA();
DWORD CommDlgExtendedError();
#endif
