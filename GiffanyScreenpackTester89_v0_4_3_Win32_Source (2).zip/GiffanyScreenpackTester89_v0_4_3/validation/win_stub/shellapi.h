#ifndef SHELLAPI_H_STUB
#define SHELLAPI_H_STUB
#include "windows.h"
typedef void *HDROP;
void DragAcceptFiles();
UINT DragQueryFileA();
void DragFinish();
HINSTANCE ShellExecuteA();
#endif
