#ifndef WINDOWSX_H_STUB
#define WINDOWSX_H_STUB
#define GET_X_LPARAM(lp) ((int)(short)((lp) & 0xffff))
#define GET_Y_LPARAM(lp) ((int)(short)(((lp) >> 16) & 0xffff))
#endif
