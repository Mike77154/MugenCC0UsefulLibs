#ifndef WINDOWS_H_STUB
#define WINDOWS_H_STUB
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
#define WINAPI
#define CALLBACK
#define TRUE 1
#define FALSE 0
#define BI_RGB 0
#define DIB_RGB_COLORS 0
#define PS_SOLID 0
#define HOLLOW_BRUSH 5
#define TRANSPARENT 1
#define SRCCOPY 0x00CC0020ul
#define FW_NORMAL 400
#define FW_BOLD 700
#define ANSI_CHARSET 0
#define DEFAULT_CHARSET 1
#define OUT_DEFAULT_PRECIS 0
#define CLIP_DEFAULT_PRECIS 0
#define DEFAULT_QUALITY 0
#define ANTIALIASED_QUALITY 4
#define FIXED_PITCH 1
#define DEFAULT_PITCH 0
#define FF_MODERN 48
#define FF_DONTCARE 0
#define LOGPIXELSY 90
#define CS_HREDRAW 0x0002
#define CS_VREDRAW 0x0001
#define CS_DBLCLKS 0x0008
#define WS_OVERLAPPEDWINDOW 0x00CF0000ul
#define WS_VISIBLE 0x10000000ul
#define CW_USEDEFAULT ((int)0x80000000)
#define COLOR_WINDOW 5
#define IDC_ARROW ((const char*)32512)
#define IDI_APPLICATION ((const char*)32512)
#define WM_CREATE 1
#define WM_DESTROY 2
#define WM_SIZE 5
#define WM_PAINT 15
#define WM_ERASEBKGND 20
#define WM_TIMER 275
#define WM_KEYDOWN 256
#define WM_KEYUP 257
#define WM_CHAR 258
#define WM_LBUTTONDOWN 513
#define WM_LBUTTONDBLCLK 515
#define WM_DROPFILES 563
#define MB_OK 0x00000000ul
#define MB_YESNO 0x00000004ul
#define MB_ICONERROR 0x00000010ul
#define MB_ICONINFORMATION 0x00000040ul
#define IDYES 6
#define SW_SHOWNORMAL 1
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010ul
#define INVALID_FILE_ATTRIBUTES ((DWORD)0xFFFFFFFFul)
#define FORMAT_MESSAGE_IGNORE_INSERTS 0x00000200ul
#define FORMAT_MESSAGE_FROM_SYSTEM 0x00001000ul
#define VK_F1 0x70
#define VK_F2 0x71
#define VK_F3 0x72
#define VK_F4 0x73
#define VK_F5 0x74
#define VK_F8 0x77
#define VK_F9 0x78
#define VK_LEFT 0x25
#define VK_UP 0x26
#define VK_RIGHT 0x27
#define VK_DOWN 0x28
#define VK_PRIOR 0x21
#define VK_NEXT 0x22
#define VK_HOME 0x24
#define VK_END 0x23
#define VK_RETURN 0x0D
#define VK_SPACE 0x20
#define VK_ESCAPE 0x1B
#define DT_CENTER 0x0001
#define DT_RIGHT 0x0002
#define DT_VCENTER 0x0004
#define DT_WORDBREAK 0x0010
#define DT_SINGLELINE 0x0020
#define DT_NOPREFIX 0x0800
#define DT_END_ELLIPSIS 0x8000
#define DT_LEFT 0x0000

typedef int BOOL;
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned int UINT;
typedef unsigned long DWORD;
typedef long LONG;
typedef long LPARAM;
typedef unsigned long WPARAM;
typedef long LRESULT;
typedef unsigned long COLORREF;
typedef char *LPSTR;
typedef const char *LPCSTR;
typedef void *HANDLE;
typedef void *PVOID;
typedef void *HWND;
typedef void *HINSTANCE;
typedef void *HICON;
typedef void *HCURSOR;
typedef void *HBRUSH;
typedef void *HDC;
typedef void *HBITMAP;
typedef void *HFONT;
typedef void *HPEN;
typedef void *HGDIOBJ;
typedef void *HMENU;
typedef void *HGLOBAL;
typedef void *HRSRC;
typedef LRESULT (CALLBACK *WNDPROC)(HWND,UINT,WPARAM,LPARAM);

typedef struct tagRECT { LONG left, top, right, bottom; } RECT;
typedef struct tagPAINTSTRUCT { HDC hdc; int fErase; RECT rcPaint; int fRestore; int fIncUpdate; unsigned char rgbReserved[32]; } PAINTSTRUCT;
typedef struct tagBITMAPINFOHEADER { DWORD biSize; LONG biWidth; LONG biHeight; WORD biPlanes; WORD biBitCount; DWORD biCompression; DWORD biSizeImage; LONG biXPelsPerMeter; LONG biYPelsPerMeter; DWORD biClrUsed; DWORD biClrImportant; } BITMAPINFOHEADER;
typedef struct tagRGBQUAD { BYTE rgbBlue, rgbGreen, rgbRed, rgbReserved; } RGBQUAD;
typedef struct tagBITMAPINFO { BITMAPINFOHEADER bmiHeader; RGBQUAD bmiColors[1]; } BITMAPINFO;
typedef struct tagWNDCLASSEXA { UINT cbSize; UINT style; WNDPROC lpfnWndProc; int cbClsExtra; int cbWndExtra; HINSTANCE hInstance; HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground; LPCSTR lpszMenuName; LPCSTR lpszClassName; HICON hIconSm; } WNDCLASSEXA;
typedef struct tagPOINT { LONG x,y; } POINT;
typedef struct tagSIZE { LONG cx, cy; } SIZE;
typedef struct tagMSG { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; } MSG;

#define RGB(r,g,b) ((COLORREF)(((BYTE)(r)) | ((WORD)((BYTE)(g)) << 8) | (((DWORD)(BYTE)(b)) << 16)))

HGDIOBJ SelectObject();
BOOL DeleteObject();
BOOL DeleteDC();
HDC GetDC();
int ReleaseDC();
HDC CreateCompatibleDC();
HBITMAP CreateDIBSection();
HPEN CreatePen();
HGDIOBJ GetStockObject();
BOOL Rectangle();
int SetBkMode();
COLORREF SetTextColor();
int DrawTextA();
BOOL GetTextExtentPoint32A();
BOOL OffsetRect();
BOOL GetClientRect();
BOOL BitBlt();
int GetDeviceCaps();
int MulDiv();
HFONT CreateFontA();
HDC BeginPaint();
BOOL EndPaint();
BOOL InvalidateRect();
UINT SetTimer();
BOOL KillTimer();
void PostQuitMessage();
LRESULT DefWindowProcA();
unsigned short RegisterClassExA();
HWND CreateWindowExA();
BOOL ShowWindow();
BOOL UpdateWindow();
int MessageBoxA();
DWORD GetModuleFileNameA();
DWORD GetCurrentDirectoryA();
DWORD GetTempPathA();
DWORD GetFullPathNameA();
DWORD GetFileAttributesA();
UINT GetWindowsDirectoryA();
HANDLE AddFontMemResourceEx();
BOOL RemoveFontMemResourceEx();
DWORD GetLastError();
DWORD FormatMessageA();
LPSTR GetCommandLineA();
int GetMessageA();
BOOL TranslateMessage();
LRESULT DispatchMessageA();
HCURSOR LoadCursor();
HICON LoadIcon();
#ifdef __cplusplus
}
#endif
#endif

DWORD GetTickCount(void);
