#ifndef MMSYSTEM_H_STUB
#define MMSYSTEM_H_STUB
#include "windows.h"
#define WAVE_FORMAT_PCM 1
#define WAVE_MAPPER ((UINT)-1)
#define CALLBACK_NULL 0
#define MMSYSERR_NOERROR 0
typedef UINT MMRESULT;
typedef void *HWAVEOUT;
typedef struct waveformat_tag { WORD wFormatTag; WORD nChannels; DWORD nSamplesPerSec; DWORD nAvgBytesPerSec; WORD nBlockAlign; WORD wBitsPerSample; WORD cbSize; } WAVEFORMATEX;
typedef struct wavehdr_tag { LPSTR lpData; DWORD dwBufferLength; DWORD dwBytesRecorded; DWORD dwUser; DWORD dwFlags; DWORD dwLoops; struct wavehdr_tag *lpNext; DWORD reserved; } WAVEHDR;
MMRESULT waveOutReset();
MMRESULT waveOutUnprepareHeader();
MMRESULT waveOutClose();
MMRESULT waveOutOpen();
MMRESULT waveOutPrepareHeader();
MMRESULT waveOutWrite();
#endif
