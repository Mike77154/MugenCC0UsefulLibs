#include <stdio.h>
#include "gst89_render_math.h"

static int failures;

static void check_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %-28s got=%d expected=%d\n", name, got, expected);
        ++failures;
    } else {
        printf("PASS %-28s value=%d\n", name, got);
    }
}

int main(void)
{
    int first;
    int last;
    int left;
    int top;
    int width;
    int height;
    int phase;
    int viewport_w;
    int tile_origin;
    int tile_span;
    int edge_a;
    int edge_b;
    int next_edge;

    failures = 0;
    check_int("velocity -1 after 60 ticks",
              gst89_rm_motion_q1000(-1000, 60ul), -60);
    check_int("velocity .1 after 60 ticks",
              gst89_rm_motion_q1000(100, 60ul), 6);
    check_int("velocity -.5 after 1 tick",
              gst89_rm_motion_q1000(-500, 1ul), 0);
    check_int("velocity -.5 after 2 ticks",
              gst89_rm_motion_q1000(-500, 2ul), -1);

    gst89_rm_sprite_origin(160, 10, 512, 64, 130, 0,
                           1000, 1000, 0, 0,
                           &left, &top, &width, &height);
    check_int("classic BG top-center left", left, 30);
    check_int("classic BG top", top, 10);
    check_int("classic BG width", width, 512);

    gst89_rm_sprite_origin(160, 24, 280, 91, 140, 0,
                           1000, 1000, 0, 0,
                           &left, &top, &width, &height);
    check_int("KFM centered title left", left, 20);

    gst89_rm_text_anchor_rect(640, 100, 0, &left, &edge_a);
    check_int("center text left", left, 590);
    check_int("center text right", edge_a, 690);
    gst89_rm_text_anchor_rect(640, 100, 1, &left, &edge_a);
    check_int("left text left", left, 640);
    check_int("left text right", edge_a, 740);
    gst89_rm_text_anchor_rect(640, 100, -1, &left, &edge_a);
    check_int("right text left", left, 540);
    check_int("right text right", edge_a, 640);

    gst89_rm_sprite_origin(50, 60, 100, 80, 20, 30,
                           1000, 1000, 1, 1,
                           &left, &top, &width, &height);
    check_int("H flip preserves axis", left, -30);
    check_int("V flip preserves axis", top, 10);

    phase = gst89_rm_scroll_origin(160,
              gst89_rm_motion_q1000(-1000, 216000ul), 1, 512);
    if (phase < 0 || phase >= 512) {
        printf("FAIL bounded infinite phase       value=%d\n", phase);
        ++failures;
    } else {
        printf("PASS bounded infinite phase       value=%d\n", phase);
    }

    gst89_rm_tile_range(1, 512, 320, &first, &last);
    check_int("infinite tile first bounded", first, -4);
    check_int("infinite tile last bounded", last, 4);
    gst89_rm_tile_range(2, 64, 240, &first, &last);
    check_int("finite tile first", first, 0);
    check_int("finite tile last", last, 1);

    gst89_rm_visible_tile_range(1, 800, 640, 800, 0, 1280,
                                &first, &last);
    check_int("MUGEN1 visible X first", first, -1);
    check_int("MUGEN1 visible X last", last, 0);
    gst89_rm_visible_tile_range(1, 320, 0, 320, 0, 335,
                                &first, &last);
    check_int("MUGEN1 top Y first", first, 0);
    check_int("MUGEN1 top Y last", last, 1);
    gst89_rm_visible_tile_range(1, 320, 0, 320, 335, 632,
                                &first, &last);
    check_int("MUGEN1 middle Y first", first, 1);
    check_int("MUGEN1 middle Y last", last, 1);
    gst89_rm_visible_tile_range(1, 320, 0, 320, 632, 720,
                                &first, &last);
    check_int("MUGEN1 bottom Y first", first, 1);
    check_int("MUGEN1 bottom Y last", last, 2);
    gst89_rm_visible_tile_range(1, 320, 0, 320, 332, 335,
                                &first, &last);
    check_int("MUGEN1 stripe Y first", first, 1);
    check_int("MUGEN1 stripe Y last", last, 1);

    check_int("project negative edge floor",
              gst89_rm_project_edge(0, 853, 1280, -800), -534);
    check_int("project shared edge",
              gst89_rm_project_edge(0, 853, 1280, 0), 0);

    tile_span = 800;
    for (viewport_w = 319; viewport_w <= 1367; viewport_w += 37) {
        for (tile_origin = -1600; tile_origin <= 1600; ++tile_origin) {
            edge_a = gst89_rm_project_edge(0, viewport_w, 1280,
                                           tile_origin);
            edge_b = gst89_rm_project_edge(0, viewport_w, 1280,
                                           tile_origin + tile_span);
            next_edge = gst89_rm_project_edge(0, viewport_w, 1280,
                                              tile_origin + tile_span);
            if (edge_b != next_edge || edge_b < edge_a) {
                printf("FAIL shared-edge tiling viewport=%d origin=%d "
                       "left=%d right=%d next=%d\n",
                       viewport_w, tile_origin, edge_a, edge_b, next_edge);
                ++failures;
                viewport_w = 2000;
                break;
            }
        }
    }
    if (failures == 0)
        printf("PASS shared-edge tiling         no one-pixel gaps\n");

    if (failures != 0) {
        printf("RENDER MATH VALIDATION FAIL failures=%d\n", failures);
        return 1;
    }
    printf("RENDER MATH VALIDATION PASS\n");
    return 0;
}
