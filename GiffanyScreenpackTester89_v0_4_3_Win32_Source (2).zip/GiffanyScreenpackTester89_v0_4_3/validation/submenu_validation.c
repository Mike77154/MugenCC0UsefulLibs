#include <stdio.h>
#include "matroshkanestanidize_submenus89.h"

static int failures;

static void check_int(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("FAIL %-34s got=%d expected=%d\n", name, got, expected);
        ++failures;
    } else {
        printf("PASS %-34s value=%d\n", name, got);
    }
}

int main(void)
{
    msubmenu89_stack stack;
    matroshka_submenus89_state tree;
    matroshka_submenus89_activation activation;
    msubmenu89_frame closed;
    char crumb[256];

    failures = 0;
    msubmenu89_init(&stack);
    matroshka_submenus89_init(&tree, &stack, 42,
        MSUBMENU89_FLAG_MODAL | MSUBMENU89_FLAG_OVERLAY);
    check_int("define root index", matroshka_submenus89_define(
        &tree, "root", "OPTIONS", 0), 0);
    check_int("define video index", matroshka_submenus89_define(
        &tree, "video", "VIDEO", 0), 1);
    check_int("root submenu", matroshka_submenus89_add_item(
        &tree, "root", "VIDEO", MATROSHKA_SUBMENUS89_ITEM_SUBMENU,
        "video", 1, 0), 1);
    check_int("root disabled", matroshka_submenus89_add_item(
        &tree, "root", "DISABLED", MATROSHKA_SUBMENUS89_ITEM_ACTION,
        "disabled", 0, 0), 1);
    check_int("root return", matroshka_submenus89_add_item(
        &tree, "root", "RETURN", MATROSHKA_SUBMENUS89_ITEM_ACTION,
        "return", 1, 0), 1);
    check_int("video action", matroshka_submenus89_add_item(
        &tree, "video", "V-SYNC", MATROSHKA_SUBMENUS89_ITEM_ACTION,
        "vsync", 1, 0), 1);
    check_int("video back", matroshka_submenus89_add_item(
        &tree, "video", "BACK", MATROSHKA_SUBMENUS89_ITEM_ACTION,
        "back", 1, 0), 1);
    check_int("tree validation", (int)matroshka_submenus89_validate(&tree),
              (int)MATROSHKA_SUBMENUS89_VALIDATE_OK);
    check_int("open root", matroshka_submenus89_open(&tree, "root", 7), 1);
    check_int("root selected", matroshka_submenus89_selected(&tree), 0);
    check_int("move skips disabled", matroshka_submenus89_move(&tree, 1), 1);
    check_int("selected return", matroshka_submenus89_selected(&tree), 2);
    check_int("select video", matroshka_submenus89_set_selected(&tree, 0), 1);
    check_int("activate opens video", matroshka_submenus89_activate(
        &tree, &activation), MATROSHKA_SUBMENUS89_ACTIVATE_OPENED);
    check_int("stack depth two", stack.depth, 2);
    (void)matroshka_submenus89_breadcrumb(&tree, crumb, (int)sizeof(crumb),
                                           " > ");
    if (crumb[0] == '\0') {
        puts("FAIL breadcrumb empty");
        ++failures;
    } else printf("PASS breadcrumb                         %s\n", crumb);
    check_int("select child back", matroshka_submenus89_set_selected(
        &tree, 1), 1);
    check_int("back child", matroshka_submenus89_back(&tree, &closed), 1);
    check_int("parent selection restored", matroshka_submenus89_selected(
        &tree), 0);
    check_int("close root", matroshka_submenus89_back(&tree, &closed), 1);
    check_int("root return selection", closed.return_selection, 7);
    check_int("stack closed", msubmenu89_is_open(&stack), 0);

    if (failures != 0) {
        printf("SUBMENU VALIDATION FAIL failures=%d\n", failures);
        return 1;
    }
    puts("SUBMENU VALIDATION PASS");
    return 0;
}
