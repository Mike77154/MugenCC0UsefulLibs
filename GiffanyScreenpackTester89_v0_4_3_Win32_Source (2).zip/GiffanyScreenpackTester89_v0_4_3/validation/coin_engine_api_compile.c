#include "gst89_engine.h"

void coin_api_smoke(GST89_Engine *engine)
{
    (void)gst89_engine_insert_coin(engine, 1, 1u);
    (void)gst89_engine_player_command(engine, 2,
        GST89_ENGINE_CMD_INSERT_COIN);
    (void)gst89_engine_command(engine,
        GST89_ENGINE_CMD_TOGGLE_FREE_PLAY);
    (void)gst89_engine_command(engine,
        GST89_ENGINE_CMD_TOGGLE_CABINET_MODE);
    (void)gst89_engine_set_operation_mode(engine,
        GST89_ENGINE_OPERATION_CONSOLE);
    (void)gst89_engine_operation_mode(engine);
    (void)gst89_engine_cabinet_session_active(engine);
    (void)gst89_engine_cabinet_session_player(engine);
    (void)gst89_engine_report_main_loss(engine, 1);
    (void)gst89_engine_request_challenger(engine, 2,
        GST89_ENGINE_CHALLENGER_SOURCE_GAMEPLAY);
    (void)gst89_engine_credit_count(engine);
    (void)gst89_engine_free_play(engine);
    (void)gst89_engine_attract_active(engine);
}
