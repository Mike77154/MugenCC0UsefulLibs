#include "selectdef89.h"
#include "selectflow89.h"
#include <stdio.h>
#include <string.h>

static int require_true(int condition, const char *message)
{
    if (!condition) {
        fprintf(stderr, "FAIL %s\n", message);
        return 0;
    }
    printf("PASS %s\n", message);
    return 1;
}

int main(int argc, char **argv)
{
    SelectDef89Document roster;
    SelectFlow89State flow;
    int ok;
    int event;
    const char *path;
    path = argc > 1 ? argv[1] : "select.def";
    ok = 1;
    selectdef89_init(&roster);
    ok &= require_true(selectdef89_load(&roster, path),
                       "real select.def parses");
    ok &= require_true(roster.character_count == 2,
                       "real roster has two characters");
    ok &= require_true(roster.extra_stage_count == 1,
                       "real roster has one extra stage");
    ok &= require_true(strcmp(roster.characters[0].definition, "kfm") == 0,
                       "first character is kfm");
    ok &= require_true(strcmp(roster.characters[1].definition,
                              "kfm720") == 0,
                       "second character is kfm720");

    selectflow89_enter(&flow, SELECTFLOW89_MODE_VERSUS,
                       0, 4, 10, roster.character_count);
    ok &= require_true(flow.open, "P1 versus select opens");
    ok &= require_true(flow.main_player == 1 && flow.active_player == 1,
                       "legacy entry keeps P1 as main");
    event = selectflow89_activate(&flow, 10, roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_MAIN_CONFIRMED,
                       "P1 main confirm hands control to P2");
    event = selectflow89_move(&flow, 1, 0, 2, 5, 0, 0,
                              roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_MOVED && flow.p2_cell == 1,
                       "P2 moves to kfm720");
    event = selectflow89_activate(&flow, 10, roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_READY_FOR_VS,
                       "P2 confirm completes P1-main versus");

    selectflow89_enter_for_player(&flow, SELECTFLOW89_MODE_VERSUS, 2,
                                  0, 1, 10, roster.character_count);
    ok &= require_true(flow.main_player == 2 && flow.active_player == 2,
                       "P2 can enter as main from the first frame");
    event = selectflow89_activate(&flow, 10, roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_MAIN_CONFIRMED &&
                       flow.p2_confirmed && flow.active_player == 1,
                       "P2 main confirms first and hands control to P1");
    event = selectflow89_activate(&flow, 10, roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_READY_FOR_VS &&
                       flow.p1_confirmed,
                       "P1 secondary confirm completes P2-main versus");

    selectflow89_enter_for_player(&flow, SELECTFLOW89_MODE_ARCADE, 2,
                                  0, 1, 10, roster.character_count);
    event = selectflow89_activate(&flow, 10, roster.character_count);
    ok &= require_true(event == SELECTFLOW89_EVENT_READY_FOR_VS,
                       "P2-main arcade confirm auto-selects opponent");
    ok &= require_true(flow.p2_cell == 1 && flow.p1_cell == 0 &&
                       flow.p2_confirmed && flow.p1_confirmed,
                       "P2 remains human side and P1 receives placeholder CPU");

    selectflow89_enter_for_player(&flow, SELECTFLOW89_MODE_TEAM_VERSUS, 2,
                                  0, 1, 10, roster.character_count);
    (void)selectflow89_activate(&flow, 10, roster.character_count);
    event = selectflow89_cancel(&flow);
    ok &= require_true(event == SELECTFLOW89_EVENT_MAIN_UNCONFIRMED &&
                       flow.active_player == 2 && !flow.p2_confirmed,
                       "cancel returns authority to P2 main cursor");
    event = selectflow89_cancel(&flow);
    ok &= require_true(event == SELECTFLOW89_EVENT_RETURN_TITLE,
                       "second cancel returns to title");

    if (!ok) return 1;
    puts("P1/P2 MAIN AUTHORITY SELECT FLOW VALIDATION PASS");
    return 0;
}
