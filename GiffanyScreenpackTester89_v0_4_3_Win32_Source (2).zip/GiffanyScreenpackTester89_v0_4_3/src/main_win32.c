#include <windows.h>
#include "gst89_win32_host.h"

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previous,
                   LPSTR command_line, int show_command)
{
    return gst89_win32_host_run(instance, previous,
                                command_line, show_command);
}
