# Console/Cabinet credit policy — v0.4.2

## Separación de responsabilidades

```text
credit_system
    saldo elemental
        ↑
coinsystem89
    moneda, costes y FREE PLAY
        ↑
creditpolicy89
    decide si START/CHALLENGER debe cobrar
        ↑
gst89_engine
    ejecuta la transición TITLE/SELECT/VS
```

## Tabla de cobro

| Situación | Console | Cabinet |
|---|---:|---:|
| MAIN entra a Arcade | 1 | 1 sólo si no hay sesión |
| MAIN entra a Team Arcade | 1 | 1 sólo si no hay sesión |
| MAIN entra a Versus/Training/etc. | 0 | 1 sólo si no hay sesión |
| MAIN vuelve a TITLE/SELECT/VS | según nueva entrada | 0 mientras siga la sesión |
| MAIN pierde | sin sesión persistente | termina la sesión |
| SECONDARY invade Arcade/Team Arcade | 1 | 1 |
| SECONDARY intenta invadir otro modo | rechazado, no descuenta | rechazado, no descuenta |

## Autoridad

En Cabinet mode una sesión pagada guarda `session_player`. Al volver al título,
MAIN no se libera. El otro jugador no puede reutilizar esa sesión. La entrada
del retador es una compra separada y no cambia al MAIN original.

## Fuentes de invasión

```c
GST89_ENGINE_CHALLENGER_SOURCE_SELECT
GST89_ENGINE_CHALLENGER_SOURCE_VERSUS
GST89_ENGINE_CHALLENGER_SOURCE_GAMEPLAY
```

La fuente gameplay queda lista para el futuro loop de combate. Todas las fuentes
pasan por la misma comprobación: modo Arcade/Team Arcade, jugador secundario y
un crédito disponible.

## Derrota

```c
gst89_engine_report_main_loss(engine, player);
```

En Cabinet mode termina la sesión y libera MAIN. No se llama automáticamente al
terminar la pantalla VS porque VS no es una pelea ni demuestra quién perdió.
