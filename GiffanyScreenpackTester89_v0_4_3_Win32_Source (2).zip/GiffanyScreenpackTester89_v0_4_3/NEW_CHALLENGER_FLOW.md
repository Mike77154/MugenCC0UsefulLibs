# HERE COMES A NEW CHALLENGER — v0.4.0

## Modos habilitados

El engine arma la entrada de retador únicamente en:

- `ARCADE`
- `TEAM ARCADE`

La máscara se configura en un solo punto:

```c
newchallenger89_configure(
    &app->challenger_flow,
    NEWCHALLENGER89_MODE_BIT(SELECTFLOW89_MODE_ARCADE) |
    NEWCHALLENGER89_MODE_BIT(SELECTFLOW89_MODE_TEAM_ARCADE),
    90ul
);
```

## Regla de autoridad

El jugador que inició el modo conserva `MAIN`. El otro entra como `SECONDARY`; nunca se intercambian internamente los lados P1/P2.

Ejemplo con P2 MAIN:

```text
P2 inicia ARCADE
   ↓
P2 selecciona como MAIN
   ↓
P1 pulsa START
   ↓
HERE COMES A NEW CHALLENGER
   ↓
P1 selecciona como SECONDARY
   ↓
VS: P1 contra P2 MAIN
```

## Ventanas de entrada actuales

Como el tester todavía no tiene gameplay real, START secundario se acepta en:

1. SELECT de Arcade/Team Arcade, incluso antes de que MAIN termine de escoger.
2. La primera pantalla VS provisional.

Si el retador entra antes de que MAIN confirme, el anuncio se reproduce y después MAIN termina primero; enseguida se entrega el cursor al retador.

## Máquina agnóstica

```text
IDLE
  │ begin_session(modo, main)
  ▼
ARMED
  │ request(secundario, source)
  ▼
SPLASH ── START secundario ─┐
  │ timeout                  │
  └──────────────────────────┘
  ▼
SELECTING
  │ complete_selection(secundario)
  ▼
RESOLVED
```

La fuente `NEWCHALLENGER89_SOURCE_GAMEPLAY` ya existe. Un futuro runner sólo tendrá que llamar `newchallenger89_request()` cuando detecte START durante una pelea de Arcade o Team Arcade.

## Presentación del tester

El host Win32 muestra durante 90 ticks:

```text
HERE COMES A NEW CHALLENGER
P1/P2 HAS JOINED AS SECONDARY
```

El retador puede pulsar START otra vez para saltar el anuncio. Después recibe su cursor auténtico del motif y el flujo continúa a VS.

## Límites actuales

- No existe aún gameplay ni pausa de combate.
- Team Arcade todavía usa una selección placeholder por lado, no una plantilla completa de varios miembros.
- Los retratos individuales siguen siendo placeholders hasta integrar el provider de personajes.

Estas limitaciones están fuera de `newchallenger89`; la librería sólo gobierna la entrada, el anuncio y la entrega de selección.
