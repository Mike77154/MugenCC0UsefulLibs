@echo off
setlocal
cd /d "%~dp0"
call build_msys2_mingw32.bat
if errorlevel 1 exit /b 1
call run_tester.bat "%~1"
