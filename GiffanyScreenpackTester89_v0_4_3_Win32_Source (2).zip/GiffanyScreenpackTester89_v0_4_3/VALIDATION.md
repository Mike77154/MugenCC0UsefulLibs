# Validación v0.4.2

- `CREDITPOLICY89_V042_PASS.txt`: política aislada Console/Cabinet.
- `CREDIT_POLICY_ENGINE_V042_PASS.txt`: integración con el engine y un motif real.
- `CREDIT_POLICY_ALL_MOTIFS_V042_PASS.txt`: misma matriz en Default, MUGEN1, Big y KFM.
- `COIN_CABINET_ENGINE_API_COMPILE_PASS.txt`: fachada pública.
- `WIN32_STRICT_C89_V042_PASS.txt`: sintaxis estricta de los archivos modificados.
- `FULL_OBJECT_ARCHIVE_V042_PASS.txt`: 115 objetos y biblioteca estática de validación.

La ejecución visual del PE32 sigue pendiente del MSYS2 MinGW32 del usuario.
