# Diagnóstico: cursor textual y OPTIONS — v0.2.5

## Por qué el cursor no embonaba

El motif expresa una posición de ancla y una especificación de fuente, no una
caja exacta de píxeles. El tester anterior dibujaba un rectángulo derivado del
espaciado de filas; una palabra corta y una larga recibían prácticamente la
misma caja.

La nueva ruta hace:

```text
texto visible
   -> GetTextExtentPoint32A
   -> anchoring según align MUGEN
   -> rectángulo exacto
   -> halo / boxcursor / hit-test
```

Esto evita que el cursor parezca flotar a un lado de la palabra. Si el motif no
quiere caja, la palabra activa sigue brillando.

## Alineación

```text
align =  0: el ancla atraviesa el centro del texto
align =  1: el ancla es el borde izquierdo
align = -1: el ancla es el borde derecho
```

Los bordes se calculan en una función portable validada por pruebas.

## OPTIONS

La entrada `menu.itemname.options` ya no es una acción muerta. Abre una pila de
submenús basada en la biblioteca proporcionada. Cada frame guarda:

- menú actual;
- selección actual;
- selección que debe restaurarse al volver;
- flags modal/overlay.

`BACK` cierra un nivel. `RETURN TO TITLE` vacía la pila y recupera la posición
de OPTIONS en el título.

## Fondo

La vista OPTIONS interpreta `[OptionBGdef]` y `[OptionBG n]` mediante la misma
ruta de TitleBG, por lo que conserva sprites, AIR, scroll, tile, clipping,
blend, caché y corrección de costuras.

## Limitación de fuente

La caja coincide con la palabra que el tester dibuja. Hasta incorporar el
decoder `.fnt`/`.def`, la fuente es una sustitución Win32 y puede tener otra
anchura que la fuente original del screenpack. La geometría ya es correcta; la
fidelidad tipográfica exacta queda pendiente del decoder de fuentes.
