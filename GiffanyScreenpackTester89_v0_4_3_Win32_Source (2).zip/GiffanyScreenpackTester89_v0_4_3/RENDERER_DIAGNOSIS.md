# Diagnóstico del renderer v0.2.1 → v0.2.2

## 1. Origen equivocado

El renderer anterior trataba `start.x` como coordenada desde el borde izquierdo.
En los BG de MUGEN, el punto `start` coloca el eje SFF respecto del centro
superior de la pantalla. En un espacio 320x240, `start = 0,10` significa eje en
`160,10`, no en `0,10`.

Ejemplo del motif clásico:

```text
sprite 5,0: ancho 512, eje x 130
start = 0,10
izquierda correcta = 160 - 130 = 30
izquierda anterior = 0 - 130 = -130
```

## 2. Tiling infinito creciente

La versión anterior ampliaba el rango de tiles según el desplazamiento total.
Después de muchos ticks dibujaba cada vez más copias, aunque sólo unas pocas
podían tocar la pantalla. v0.2.2 reduce la posición a una fase dentro del
periodo del tile y conserva un rango constante alrededor del viewport.

## 3. Reloj incorrecto

Un `SetTimer(...,16)` no equivale a 60 ticks exactos y Windows puede agrupar o
retrasar mensajes. v0.2.2 mide milisegundos transcurridos y los convierte a
60 game-ticks por segundo con acumulador entero.

## 4. AIR incompleto

El preview anterior ignoraba `Loopstart`, H/V y la duración indefinida `-1`.
Además invertía los píxeles, pero no la caja del sprite alrededor de su eje.
v0.2.2 conserva el eje visual de cada frame y respeta el timeline AIR.

## 5. Parallax dibujado como sprite normal

El `TitleBG 0` clásico usa `width = 400,1200`. v0.2.1 no deformaba el sprite.
v0.2.2 interpola el ancho por scanline para producir el trapecio.
