# Diagnóstico FNT v1 fixed — v0.2.7

## Síntoma

`jg.fnt` aparecía como una serie de barras verticales. El archivo sí se
resolvía y el backend `MUGEN legacy ElecbyteFnt` quedaba activo, pero todos
los caracteres dibujaban el primer glifo del atlas.

## Causa 1: offsets colapsados

El texto embebido de `jg.fnt` declara:

```ini
[Def]
Size = 8,8
Colors = 16
Type = Fixed

[Map]
!
"
#
...
A
B
C
```

En una fuente fixed, las entradas de `[Map]` describen el orden horizontal
del atlas. El parser anterior asignaba `offset = 0` a cada entrada. La
corrección mantiene un cursor `fixed_offset` y avanza `Size.x` por entrada:

```text
! -> 0
" -> 8
# -> 16
...
A -> su celda real
B -> la siguiente celda
```

## Causa 2: color banks al revés

FNT v1 almacena el primer banco desde la entrada 255 hacia abajo. Si
`Colors = 16`, bank 0 ocupa 255..240, bank 1 ocupa 239..224, etc.

La versión anterior reconstruía el índice desde el comienzo de la paleta,
lo que elegía entradas negras. Ahora conserva el índice de bank 0 y, para
bank N, resta `N * Colors`. En `jg.fnt`, bank 5 cae en el banco amarillo
que pide `menu.item.active.font = 3,5,0`.

## Por qué la validación anterior no lo detectó

La prueba sólo comprobaba que el archivo abriera y que el framebuffer tuviera
píxeles no nulos. Una colección de signos `!` negros también cumple ambas
condiciones. La nueva regresión compara las máscaras de `A` y `B` y verifica
los colores de bank 0 y bank 5.

## Resultado esperado

- `menu.item.font = 3,0,0`: letras grises/blancas reales.
- `menu.item.active.font = 3,5,0`: las mismas letras con banco amarillo.
- Cada palabra conserva su forma, no una barra repetida por carácter.
