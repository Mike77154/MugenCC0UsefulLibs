# Vendor index v0.4.3

- `mainplayer89`: autoridad MAIN P1/P2.
- `title_select_vs_flow89`: TITLE → SELECT → VS → TITLE.
- `optionsflow89` v1.1.0: navegación OPTIONS y entrada a perfiles P1/P2.
- `scanemu_c89`: captura simbólica integer-only aportada por el usuario.
- `controlconfig89`: bindings, defaults e INI separados por jugador.
- `newchallenger89`: ingreso del secundario.
- `selectflow89`: cursores y confirmación.
- `coinsystem89`: moneda, créditos, gastos y FREE PLAY.
- `creditpolicy89`: Console/Cabinet, sesión pagada y cobro de invasión.
- `attractflow89`: inactividad y attract mode.
- `credit_system`: backend aportado.
- `attract_mode`: backend aportado.
