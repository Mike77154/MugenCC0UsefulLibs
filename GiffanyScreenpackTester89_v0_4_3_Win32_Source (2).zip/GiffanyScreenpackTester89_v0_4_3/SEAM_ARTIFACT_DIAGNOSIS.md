# Diagnóstico de las líneas negras móviles — v0.2.4

## Síntoma

En el motif MUGEN 1.0 aparecían líneas negras de un píxel que se desplazaban
con el fondo. Había líneas verticales y horizontales. Los sprites y paletas
eran correctos.

## Causa

La v0.2.3 convertía el rectángulo local de cada copia así:

```text
screen_left  = floor(local_left * escala)
screen_width = floor(local_width * escala)
screen_right = screen_left + screen_width
```

Para una escala fraccionaria, ese `screen_right` no siempre coincide con:

```text
floor((local_left + local_width) * escala)
```

La siguiente copia empezaba usando la segunda operación. La diferencia podía
ser un píxel, dejando visible el `bgclearcolor` negro. Como `velocity` modifica
el origen de los tiles, la grieta se movía.

## Corrección

La v0.2.4 proyecta bordes compartidos:

```text
screen_left  = project(local_left)
screen_right = project(local_right)
screen_width = screen_right - screen_left
```

El `local_right` de una copia es el mismo entero que el `local_left` de la
siguiente. Por ello ambas reciben exactamente la misma coordenada de pantalla.
La misma regla se aplica arriba/abajo y a las filas verticales de parallax.

## Coordenadas negativas

La proyección usa división piso en vez de truncamiento hacia cero. Esto evita
que una copia situada parcialmente fuera del viewport cambie de ancho al
cruzar el origen.

## Rendimiento

No se añadió overdraw ni una franja artificial para esconder la costura. Se
mantienen el culling exacto y la caché RGBA de v0.2.3.
