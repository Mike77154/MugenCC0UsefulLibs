#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p bin build/engine_obj

if ! command -v gcc >/dev/null 2>&1; then
  echo "ERROR: gcc no esta en PATH. Abre MSYS2 MinGW32." >&2
  exit 1
fi
if ! command -v ar >/dev/null 2>&1; then
  echo "ERROR: ar no esta en PATH." >&2
  exit 1
fi
MACHINE="$(gcc -dumpmachine 2>/dev/null || true)"
case "$MACHINE" in
  i686-w64-mingw32*) ;;
  *)
    echo "ERROR: se necesita i686-w64-mingw32. Detectado: $MACHINE" >&2
    exit 1
    ;;
esac

rm -f build/engine_obj/*.o build/libgst89_engine_win32.a build/engine_objects.rsp
: > build/engine_objects.rsp
COUNT=0
while IFS= read -r SRC; do
  [ -z "$SRC" ] && continue
  COUNT=$((COUNT + 1))
  BASE="$(basename "$SRC" .c)"
  OBJ="build/engine_obj/${COUNT}_${BASE}.o"
  EXTRA_WARN=()
  case "$SRC" in
    vendor/monika_fontcore/vendor/monika_otf_decoder_c89_interp/src/otf_c89.c)
      EXTRA_WARN=(-Wno-misleading-indentation)
      ;;
  esac
  gcc @engine_compile_flags_brotli.rsp "${EXTRA_WARN[@]}" -c "$SRC" -o "$OBJ"
  printf '%s
' "$OBJ" >> build/engine_objects.rsp
done < engine_sources_brotli.lst

if [ "$COUNT" -eq 0 ]; then
  echo "ERROR: engine_sources_brotli.lst no contiene fuentes." >&2
  exit 1
fi

ar rcs build/libgst89_engine_win32.a @build/engine_objects.rsp
gcc @app_link_brotli.rsp

echo "ENGINE BROTLI: build/libgst89_engine_win32.a ($COUNT objetos)"
echo "APP:    bin/GiffanyScreenpackTester89.exe"
echo "MAIN:   src/main_win32.c"
