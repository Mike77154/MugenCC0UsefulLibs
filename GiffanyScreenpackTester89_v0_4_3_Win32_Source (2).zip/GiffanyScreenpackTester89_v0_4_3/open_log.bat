@echo off
setlocal
cd /d "%~dp0"
if exist "bin\screenpack_tester.log" (
  start "" notepad.exe "bin\screenpack_tester.log"
  exit /b 0
)
if exist "screenpack_tester.log" (
  start "" notepad.exe "screenpack_tester.log"
  exit /b 0
)
echo No se encontro screenpack_tester.log.
echo Ejecuta primero bin\GiffanyScreenpackTester89.exe.
exit /b 1
