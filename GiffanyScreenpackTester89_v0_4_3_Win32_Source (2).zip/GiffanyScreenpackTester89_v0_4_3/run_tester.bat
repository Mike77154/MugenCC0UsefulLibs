@echo off
setlocal
cd /d "%~dp0"
if not exist bin\GiffanyScreenpackTester89.exe (
  echo Primero ejecuta build_msys2_mingw32.bat
  exit /b 1
)
if "%~1"=="" (
  start "" bin\GiffanyScreenpackTester89.exe
) else (
  start "" bin\GiffanyScreenpackTester89.exe "%~1"
)
