# Arquitectura — Giffany Screenpack Tester 89 v0.3.3

## Regla de dependencia

```text
main_win32.c
    ↓ única llamada
gst89_win32_host_run()
    ↓ traduce Win32 a comandos/callbacks
gst89_engine (core agnóstico)
    ↓ usa providers vendorizados
MenuMotif89 + SFF + SND + FontCore + Matroshka
```

`main` no conoce `GST89_App`, SFF, SND, fuentes, GDI, menús ni rutas.

## Capas

### 1. API pública

```text
vendor/gst89_engine/include/gst89_engine.h
vendor/gst89_engine/include/gst89_win32_host.h
```

La API principal usa comandos abstractos y callbacks. No incluye headers de
Win32.

### 2. Core

```text
vendor/gst89_engine/src/core/
├── gst89_engine.c             fachada, reloj, input y vistas
├── gst89_app.h                estado interno
├── gst89_resources.c          SFF/SND/font y resolución de rutas
├── gst89_systemdef.c          entrada del parser
├── gst89_options.c            árbol OPTIONS
├── gst89_render_math.c        fixed-point, proyección y tiling
└── gst89_anim_timeline.c      timeline AIR
```

### 3. Render backend

```text
vendor/gst89_engine/src/render/win32/
├── gst89_renderer_win32.c
└── gst89_font_provider.c
```

Aquí viven DIB/GDI, caché RGBA, texto y hit-test. No contaminan la API core.

### 4. Platform backend

```text
vendor/gst89_engine/src/platform/win32/
├── gst89_win32_host.c         ventana, mensajes y diálogo Explorer
└── gst89_audio_winmm.c        waveOut
```

El host traduce `WM_KEYDOWN` a `GST89_ENGINE_CMD_*`; no implementa reglas del
menú.

### 5. Diagnóstico

```text
vendor/gst89_engine/src/diagnostics/gst89_log.c
```

## Flujo de un frame

```text
WM_TIMER
  → elapsed_ms
  → gst89_engine_advance_ms
  → tick MUGEN 60 Hz
  → callback request_redraw
  → WM_PAINT
  → gst89_renderer_draw
```

## Flujo de input

```text
P2 tecla S
  → player=2 + GST89_ENGINE_CMD_MOVE_DOWN
  → gst89_engine_player_command
  → engine decide autoridad, título / SELECT / OPTIONS
  → callback de audio si aplica
  → callback request_redraw
```

## Portar a otra plataforma

1. Implementar callbacks de audio/redraw/cache.
2. Crear un host que traduzca su input a `GST89_ENGINE_CMD_*`.
3. Sustituir el renderer Win32 por otro backend que consuma el estado interno.
4. Mantener intactos core, parsers y providers.

No hay asignación dinámica en la fachada: `gst89_engine_default()` devuelve la
instancia estática del engine.

## Autoridad P1/P2

```text
host device → player id → abstract command → engine authority gate
```

El main y el host no deciden quién selecciona primero. Esa regla vive en
`gst89_engine` y `selectflow89`, por lo que también funciona con SDL, gamepads o
otro backend.
