# Autoridad MAIN de P1/P2 — v0.3.3

## Regla

`main_player = 0` significa que TITLE está libre. El primer jugador que manda
`GST89_ENGINE_CMD_ACTIVATE` desde TITLE reclama autoridad:

```text
P1 ACTIVATE primero → main_player = 1
P2 ACTIVATE primero → main_player = 2
```

Los movimientos anteriores a START sólo cambian `title_controller`; no
reclaman MAIN. Esto permite que ambos naveguen sin que una pulsación accidental
de dirección decida quién entra.

## Máquina de estados

```text
TITLE_FREE
  ├─ P1 START → TITLE_P1_MAIN → SELECT(active=P1)
  └─ P2 START → TITLE_P2_MAIN → SELECT(active=P2)

SELECT single-player
  └─ MAIN confirma → oponente placeholder al lado contrario → VS

SELECT two-player
  └─ MAIN confirma → active=secondary → secondary confirma → VS

VS
  ├─ timeout → TITLE_FREE
  └─ MAIN cancel/start → TITLE_FREE
```

## API

```c
int gst89_engine_player_command(
    GST89_Engine *engine,
    int player,
    GST89_EngineCommand command
);

int gst89_engine_main_player(const GST89_Engine *engine);
int gst89_engine_title_controller(const GST89_Engine *engine);
```

`gst89_engine_command()` se mantiene como wrapper de P1 para no romper hosts
anteriores.

## selectflow89

`SelectFlow89State` conserva posiciones físicas separadas:

```text
p1_cell / p1_confirmed
p2_cell / p2_confirmed
main_player
secondary_player
active_player
```

No se intercambian las etiquetas P1/P2. Si P2 es MAIN, permanece en el lado P2;
sólo cambia el orden de selección.

## Política de input

- TITLE sin MAIN: ambos jugadores pueden mover el cursor compartido.
- TITLE/OPTIONS con MAIN: sólo MAIN controla.
- SELECT: sólo `active_player` controla.
- VS: sólo MAIN puede omitir o cancelar.
- F1 o el retorno normal de VS reinicia MAIN a cero.

## Log

El log genera entradas como:

```text
[AUTH] P2 claimed main authority from TITLE START
[FLOW] TITLE -> SELECT | mode=VS MODE | main=P2
[FLOW] SELECT -> VS | main=P2 p1=0 p2=1
[FLOW] view=TITLE
```
