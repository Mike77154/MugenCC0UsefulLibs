@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not exist bin mkdir bin
if not exist build mkdir build
if not exist build\engine_obj mkdir build\engine_obj
where gcc >nul 2>nul || (echo ERROR: gcc no esta en PATH.& exit /b 1)
where ar >nul 2>nul || (echo ERROR: ar no esta en PATH.& exit /b 1)
for /f "delims=" %%M in ('gcc -dumpmachine') do set MACHINE=%%M
echo !MACHINE! | findstr /b /c:"i686-w64-mingw32" >nul || (
  echo ERROR: se necesita MinGW32 i686-w64-mingw32. Detectado: !MACHINE!
  exit /b 1
)
del /q build\engine_obj\*.o 2>nul
del /q build\libgst89_engine_win32.a 2>nul
del /q build\engine_objects.rsp 2>nul
type nul > build\engine_objects.rsp
set COUNT=0
for /f "usebackq delims=" %%S in ("engine_sources_brotli.lst") do (
  if not "%%S"=="" (
    set /a COUNT+=1
    set "OBJ=build/engine_obj/!COUNT!_%%~nS.o"
    set "EXTRA_WARN="
    echo %%S | findstr /c:"vendor/monika_fontcore/vendor/monika_otf_decoder_c89_interp/src/otf_c89.c" >nul && set "EXTRA_WARN=-Wno-misleading-indentation"
    gcc @engine_compile_flags_brotli.rsp !EXTRA_WARN! -c "%%S" -o "!OBJ!"
    if errorlevel 1 exit /b 1
    >>build\engine_objects.rsp echo !OBJ!
  )
)
if !COUNT! EQU 0 (
  echo ERROR: engine_sources_brotli.lst no contiene fuentes.
  exit /b 1
)
rem GNU ar no expande comodines en CMD. Usamos un response file explicito.
ar rcs build\libgst89_engine_win32.a @build\engine_objects.rsp
if errorlevel 1 (
  echo AVISO: ar no acepto el response file; reintentando objeto por objeto.
  del /q build\libgst89_engine_win32.a 2>nul
  for /f "usebackq delims=" %%O in ("build\engine_objects.rsp") do (
    ar rcs build\libgst89_engine_win32.a "%%O"
    if errorlevel 1 exit /b 1
  )
)
gcc @app_link_brotli.rsp
if errorlevel 1 exit /b 1
echo ENGINE BROTLI: build\libgst89_engine_win32.a (!COUNT! objetos)
echo APP:    bin\GiffanyScreenpackTester89.exe
echo MAIN:   src\main_win32.c
exit /b 0
