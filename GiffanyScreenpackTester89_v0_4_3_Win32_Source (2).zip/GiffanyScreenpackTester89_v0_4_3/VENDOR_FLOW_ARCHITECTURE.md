# Arquitectura de flujos vendorizados — v0.4.0

La aplicación ya no conserva dentro de `gst89_engine.c` las reglas fundamentales de autoridad y navegación. Cada responsabilidad vive en una librería C89 independiente.

```text
mainplayer89
    autoridad P1/P2
         │
         ▼
title_select_vs_flow89
    TITLE → SELECT → VERSUS → TITLE
         │
         ├──────────────► optionsflow89
         │                TITLE ↔ OPTIONS anidado
         │
         └──────────────► newchallenger89
                          START secundario → SPLASH → SELECT → VERSUS
```

## `mainplayer89`

No conoce menús ni modos de juego. Sólo resuelve:

- quién movió por última vez el TITLE libre;
- quién pulsó START primero;
- quién conserva la autoridad MAIN;
- cuándo se libera esa autoridad.

API principal:

```c
mainplayer89_observe_title_input(&authority, player);
mainplayer89_claim(&authority, player);
mainplayer89_release(&authority);
mainplayer89_accepts(&authority, player);
```

## `title_select_vs_flow89`

Máquina de tres estados sin renderer, audio, archivos ni plataforma:

```text
TITLE → SELECT → VERSUS → TITLE
```

Conserva modo, MAIN, secundario, reloj de estado y timeout de VS. OPTIONS y CHALLENGER pueden suspender visualmente el flujo sin contaminar sus tres estados base.

## `optionsflow89`

Posee exclusivamente:

- árbol y pila de submenús;
- selección actual y selección restaurada del padre;
- breadcrumb;
- valores de demostración del menú de opciones;
- retorno al índice original de TITLE.

Su única dependencia es `matroshkanestanidize_submenus89`.

## `newchallenger89`

No mueve cursores ni dibuja el anuncio. Produce eventos agnósticos:

```text
ARMED
  └─ START del jugador opuesto a MAIN
       → SPLASH
       → SELECTING
       → READY_FOR_VERSUS
```

Acepta fuentes `SELECT`, `VERSUS` y `GAMEPLAY`. En el tester actual se usa desde SELECT y VS porque todavía no existe un runner de gameplay; la fuente GAMEPLAY queda lista para conectarse después.

## Papel de `gst89_engine`

`gst89_engine` funciona como orquestador:

- traduce input a llamadas de las librerías;
- carga el motif y sus recursos;
- decide qué vista debe presentar el host;
- conecta sonidos, renderer y logs;
- no redefine internamente la autoridad ni las máquinas de flujo.

`src/main_win32.c` sigue limitándose a iniciar el host Win32.
